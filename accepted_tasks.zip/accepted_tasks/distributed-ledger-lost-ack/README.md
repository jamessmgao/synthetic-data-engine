# Distributed ledger lost acknowledged writes on restart

A three-node quorum ledger loses acknowledged writes after restart and leaves interrupted requests unresolved on retry. Compaction discards group-committed entries and request outcome records are never reconciled.

## Scenario

The Python service stores entries on three nodes and requires a quorum commit. On restart, recovery derives a canonical group ledger but each node then truncates only to its local committed prefix, while open request registers are left unchanged.

## Root cause (hidden from the agent)

Store.compact ignores the canonical entries argument and truncates to the per-node committed_index. Cluster._recover does not reconcile open request records against the canonical ledger after compaction.

## Correctness constraints

- **C1**: After a process restart, every append that returned ok=true is present in the ledger exactly once with its requested quantity.
- **C2**: Each request ID appears at most once in the ledger, and a repeated append for that ID does not add another entry.
- **C3**: A read reports the sum of the quantities of exactly the distinct acknowledged request IDs it contains.
- **C4**: The ledger never exposes a total above the credit limit of 10; an append rejected as over_limit must not become durable ledger state.
- **C5**: The service may crash between committing an entry on a quorum of nodes and writing the acknowledgment record. On restart, a client retries the same request ID: the retry must return the original outcome and the entry must appear exactly once. A request that crashed before any commit must not appear at all.

## Subgoals

1. Fix compaction to use the canonical group ledger instead of per-node truncation.
2. Reconcile open request records after recovery: complete those in the canonical ledger and discard the rest.

## Failure scenario

Three acknowledged writes on rotating quorums; after restart the last write is missing. A quorum-committed request with an open outcome record retries as pending. A request stopped before commit is never resolved.

## Expected agent pitfalls

- Fixing only compaction without reconciling request records leaves interrupted retries broken.
- Removing compaction entirely preserves entries but leaves request registers unchanged.

## Anti-shortcut measures

- Invariant-5 tests force SIGKILL at externally observable crash points and verify retry outcomes.
- Counterexample replay verifies all three acknowledged writes survive restart.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_acknowledged_append_survives_restart_exactly_once` |
| C2 | `test_repeated_request_id_never_adds_entry` |
| C3 | `test_read_totals_distinct_acknowledged_quantities` |
| C4 | `test_credit_limit_and_rejected_append_durability` |
| C5 | `test_crash_retry_resolves_original_outcome_once` |
