import json
import subprocess
import time
from pathlib import Path

APP = "/app"
SERVICE = f"{APP}/service.py"


def start(data):
    return subprocess.Popen(
        ["python3", SERVICE, "--data", str(data)],
        cwd=APP,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )


def request(process, command):
    try:
        process.stdin.write(json.dumps(command) + "\n")
        process.stdin.flush()
    except BrokenPipeError as exc:
        raise AssertionError(f"service closed its input: {exc}") from exc
    line = process.stdout.readline()
    if not line:
        process.wait(timeout=2)
        detail = process.stderr.read().strip()
        raise AssertionError(f"service closed before responding: {detail}")
    try:
        return json.loads(line)
    except json.JSONDecodeError as exc:
        raise AssertionError(f"invalid service response: {line!r}") from exc


def append(process, request_id, quantity):
    return request(process, {
        "op": "append",
        "request_id": request_id,
        "quantity": quantity,
    })


def read(process):
    return request(process, {"op": "read"})


def stop(process):
    if process.poll() is None:
        process.kill()
    process.wait(timeout=5)
    for stream in (process.stdin, process.stdout, process.stderr):
        if stream is not None:
            stream.close()


def restart(process, data):
    stop(process)
    return start(data)


def entry_map(response):
    if response.get("ok") is not True:
        raise AssertionError(f"read was not successful: {response}")
    entries = response.get("entries")
    if not isinstance(entries, list):
        raise AssertionError(f"read has no entries list: {response}")
    result = {}
    for entry in entries:
        if not isinstance(entry, dict):
            raise AssertionError(f"invalid ledger entry: {entry!r}")
        request_id = entry.get("request_id")
        quantity = entry.get("quantity")
        if not isinstance(request_id, str) or not isinstance(quantity, int):
            raise AssertionError(f"invalid ledger entry: {entry!r}")
        if request_id in result:
            raise AssertionError(f"duplicate request ID in ledger: {request_id}")
        result[request_id] = quantity
    total = response.get("total")
    if total != sum(result.values()):
        raise AssertionError(f"total does not match entries: {response}")
    return result


def assert_ledger(response, expected):
    actual = entry_map(response)
    assert actual == expected
    assert response["total"] == sum(expected.values())


def _read_node_json(data):
    for path in Path(data).rglob("*"):
        if not path.is_file() or path.name.startswith("."):
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(payload, dict):
                yield payload
        except (OSError, UnicodeError, json.JSONDecodeError):
            continue


def committed_votes(data, request_id):
    count = 0
    for payload in _read_node_json(data):
        entries = payload.get("entries", {})
        if not isinstance(entries, dict):
            continue
        for record in entries.values():
            if not isinstance(record, dict):
                continue
            if record.get("status") != "committed":
                continue
            entry = record.get("entry", {})
            if entry.get("request_id") == request_id:
                count += 1
                break
    return count


def identity_is_durable(data, request_id):
    for payload in _read_node_json(data):
        requests = payload.get("requests", {})
        if isinstance(requests, dict) and request_id in requests:
            return True
    return False


def crash_during_append(data, request_id, quantity, point):
    if point not in ("quorum_commit", "before_commit"):
        raise ValueError(point)
    process = start(data)
    try:
        process.stdin.write(json.dumps({
            "op": "append",
            "request_id": request_id,
            "quantity": quantity,
        }) + "\n")
        process.stdin.flush()
    except BrokenPipeError:
        pass

    votes = 0
    deadline = time.monotonic() + 3
    while time.monotonic() < deadline:
        votes = committed_votes(data, request_id)
        seen = identity_is_durable(data, request_id)
        if point == "quorum_commit" and votes >= 2:
            process.kill()
            break
        if point == "before_commit" and seen and votes == 0:
            process.kill()
            break
        if process.poll() is not None:
            detail = process.stderr.read().strip()
            raise AssertionError(
                f"service exited before the requested crash point: {detail}"
            )
        time.sleep(0.0002)
    else:
        process.kill()
        process.wait(timeout=2)
        raise AssertionError(f"crash point {point} was not observed")

    process.wait(timeout=2)
    if process.stdin is not None:
        process.stdin.close()
    if process.stdout is not None:
        process.stdout.close()
    if process.stderr is not None:
        process.stderr.close()
    return votes
