import argparse
import json
import sys

from cluster import Cluster


def process(cluster, command):
    if not isinstance(command, dict):
        return {"ok": False, "error": "invalid_command"}

    operation = command.get("op")
    if operation == "append":
        if "request_id" not in command or "quantity" not in command:
            return {"ok": False, "error": "invalid_command"}
        return cluster.append(command["request_id"], command["quantity"])

    if operation == "read":
        entries = cluster.committed_state()
        return {
            "ok": True,
            "leader": cluster.leader_id,
            "entries": entries,
            "total": sum(int(entry["quantity"]) for entry in entries),
        }

    return {"ok": False, "error": "unknown_operation"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    args = parser.parse_args()

    cluster = Cluster(args.data)
    for line in sys.stdin:
        if not line.strip():
            continue
        try:
            command = json.loads(line)
        except json.JSONDecodeError:
            response = {"ok": False, "error": "invalid_json"}
        else:
            response = process(cluster, command)
        print(json.dumps(response, sort_keys=True, separators=(",", ":")), flush=True)


if __name__ == "__main__":
    main()
