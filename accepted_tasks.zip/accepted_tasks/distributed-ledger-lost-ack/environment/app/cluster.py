from store import Store


class Cluster:
    """A fixed three-node group with a durable log on each node."""

    NODE_IDS = ("alpha", "beta", "gamma")
    QUORUM = 2
    CREDIT_LIMIT = 10

    def __init__(self, directory):
        self.directory = directory
        self.stores = {
            node_id: Store(node_id, f"{directory}/{node_id}")
            for node_id in self.NODE_IDS
        }
        self.leader_id = None
        self._recover()

    def _all_entries(self):
        entries = []
        for store in self.stores.values():
            entries.extend(store.committed_entries())
            entries.extend(store.prepared_entries())
        return entries

    def _request_record(self, request_id):
        for store in self.stores.values():
            record = store.request(request_id)
            if record is not None:
                return record
        return None

    def _distinct_committed(self):
        by_id = {}
        for entry in self._all_entries():
            if entry.get("status") != "committed":
                continue
            request_id = entry["request_id"]
            by_id.setdefault(request_id, entry)
        return [by_id[key] for key in sorted(by_id)]

    def _ledger_total(self):
        return sum(int(entry["quantity"]) for entry in self._distinct_committed())

    def _replicas(self, index):
        offset = (int(index) - 1) % len(self.NODE_IDS)
        return (
            self.NODE_IDS[offset],
            self.NODE_IDS[(offset + 1) % len(self.NODE_IDS)],
        )

    def append(self, request_id, quantity):
        request_id = str(request_id)
        if not isinstance(quantity, int) or isinstance(quantity, bool) or quantity <= 0:
            return {"ok": False, "status": "invalid_quantity"}

        record = self._request_record(request_id)
        if record is not None:
            if record["state"] == "complete":
                return {"ok": True, "status": "already_applied", "index": record["index"]}
            if record["state"] == "rejected":
                return {"ok": False, "status": "over_limit"}
            return {"ok": False, "status": "request_pending"}

        if self._ledger_total() + quantity > self.CREDIT_LIMIT:
            for store in self.stores.values():
                store.begin_request(request_id, quantity, 0)
                store.reject_request(request_id)
            return {"ok": False, "status": "over_limit"}

        index = max(
            [store.highest_committed() for store in self.stores.values()] + [0]
        ) + 1
        entry = {
            "index": index,
            "request_id": request_id,
            "quantity": quantity,
            "status": "prepared",
        }
        for store in self.stores.values():
            store.begin_request(request_id, quantity, index)
        replicas = self._replicas(index)
        for node_id in replicas:
            self.stores[node_id].prepare(entry)
        for node_id in replicas:
            self.stores[node_id].commit(index)
        for store in self.stores.values():
            store.complete_request(request_id)
        self.leader_id = replicas[-1]

        return {
            "ok": True,
            "status": "acknowledged",
            "index": index,
            "replicas": list(replicas),
        }

    def _recover(self):
        indexes = []
        for store in self.stores.values():
            indexes.extend(
                int(entry["index"])
                for entry in store.committed_entries() + store.prepared_entries()
            )
        durable_index = 0
        canonical = []
        for index in range(1, max(indexes, default=0) + 1):
            votes = {}
            for store in self.stores.values():
                record = store.record(index)
                if record is None or record["status"] != "committed":
                    continue
                identity = (
                    record["entry"]["request_id"],
                    int(record["entry"]["quantity"]),
                )
                votes.setdefault(identity, []).append(store)
            supported = [
                identity
                for identity, nodes in votes.items()
                if len(nodes) >= self.QUORUM
            ]
            if not supported:
                break
            request_id, quantity = supported[0]
            canonical.append({
                "index": index,
                "request_id": request_id,
                "quantity": quantity,
                "status": "committed",
            })
            durable_index = index

        self.leader_id = max(
            self.NODE_IDS,
            key=lambda node_id: max(
                (
                    int(entry["index"])
                    for entry in self.stores[node_id].committed_entries()
                    + self.stores[node_id].prepared_entries()
                ),
                default=0,
            ),
        )
        for store in self.stores.values():
            store.compact(durable_index, canonical)
    def committed_state(self):
        return self._distinct_committed()

    def describe(self):
        return {
            "leader": self.leader_id,
            "committed": self.committed_state(),
        }
