import json
import os
import tempfile
from pathlib import Path


class StoreError(RuntimeError):
    pass


class Store:
    """A durable per-node ledger log and request register."""

    def __init__(self, node_id, directory):
        self.node_id = node_id
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / f"{node_id}.json"
        self.committed_index = 0
        self.entries = {}
        self.requests = {}
        self._load()

    def _load(self):
        if not self.path.exists():
            return
        try:
            payload = json.loads(self.path.read_text())
            if payload.get("node_id") != self.node_id:
                raise StoreError("log belongs to another node")
            entries = payload.get("entries", {})
            requests = payload.get("requests", {})
            if not isinstance(entries, dict) or not isinstance(requests, dict):
                raise StoreError("invalid log")
            committed_index = int(payload.get("committed_index", 0))
            self.entries = {}
            for raw_index, record in entries.items():
                index = int(raw_index)
                if index <= 0 or record.get("status") not in ("prepared", "committed"):
                    raise StoreError("invalid entry")
                self.entries[index] = {
                    "entry": dict(record["entry"]),
                    "status": record["status"],
                }
            if committed_index and committed_index not in self.entries:
                raise StoreError("committed index is missing")
            if committed_index and self.entries[committed_index]["status"] != "committed":
                raise StoreError("committed index is not committed")
            self.committed_index = committed_index
            self.requests = {
                str(request_id): dict(record)
                for request_id, record in requests.items()
                if record.get("state") in ("open", "complete", "rejected")
            }
        except (OSError, ValueError, TypeError, KeyError) as exc:
            raise StoreError(f"cannot read log for {self.node_id}: {exc}") from exc

    def _save(self):
        payload = {
            "node_id": self.node_id,
            "committed_index": self.committed_index,
            "entries": {
                str(index): record
                for index, record in sorted(self.entries.items())
            },
            "requests": self.requests,
        }
        fd, temporary = tempfile.mkstemp(
            prefix=f".{self.node_id}.", dir=self.directory, text=True
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(payload, stream, sort_keys=True, separators=(",", ":"))
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            directory_fd = os.open(self.directory, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def begin_request(self, request_id, quantity, index):
        request_id = str(request_id)
        existing = self.requests.get(request_id)
        if existing is not None:
            return False
        self.requests[request_id] = {
            "quantity": int(quantity),
            "index": int(index),
            "state": "open",
        }
        self._save()
        return True

    def complete_request(self, request_id):
        request_id = str(request_id)
        record = self.requests.get(request_id)
        if record is None or record["state"] == "complete":
            return False
        record["state"] = "complete"
        self._save()
        return True

    def reject_request(self, request_id):
        request_id = str(request_id)
        record = self.requests.get(request_id)
        if record is None or record["state"] == "rejected":
            return False
        record["state"] = "rejected"
        self._save()
        return True

    def discard_request(self, request_id):
        request_id = str(request_id)
        if request_id not in self.requests:
            return False
        del self.requests[request_id]
        self._save()
        return True

    def request(self, request_id):
        record = self.requests.get(str(request_id))
        return dict(record) if record else None

    def prepare(self, entry):
        index = int(entry["index"])
        if index <= self.committed_index:
            return False
        existing = self.entries.get(index)
        if existing is not None:
            return existing["entry"] == entry
        self.entries[index] = {"entry": dict(entry), "status": "prepared"}
        self._save()
        return True

    def commit(self, index):
        index = int(index)
        record = self.entries.get(index)
        if record is None or index <= self.committed_index:
            return False
        record["status"] = "committed"
        record["entry"]["status"] = "committed"
        while (
            self.committed_index + 1 in self.entries
            and self.entries[self.committed_index + 1]["status"] == "committed"
        ):
            self.committed_index += 1
        self._save()
        return True

    def compact(self, index, entries=None):
        return self.truncate_after(self.committed_index)

    def truncate_after(self, index):
        index = int(index)
        removed = [candidate for candidate in self.entries if candidate > index]
        if not removed:
            return False
        for candidate in removed:
            del self.entries[candidate]
        self._save()
        return True

    def entry(self, index):
        record = self.entries.get(int(index))
        return dict(record["entry"]) if record else None

    def record(self, index):
        record = self.entries.get(int(index))
        if record is None:
            return None
        return {"entry": dict(record["entry"]), "status": record["status"]}

    def committed_entries(self):
        return [
            dict(record["entry"])
            for index, record in sorted(self.entries.items())
            if record["status"] == "committed"
        ]

    def prepared_entries(self):
        return [
            dict(record["entry"])
            for index, record in sorted(self.entries.items())
            if record["status"] == "prepared"
        ]

    def highest_committed(self):
        return self.committed_index
