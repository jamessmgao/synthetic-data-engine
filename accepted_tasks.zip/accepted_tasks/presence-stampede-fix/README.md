# Presence service cache stampede

A Go presence service caches room membership per tenant. When the cache expires, concurrent requests stampede the serialized store, causing latency violations. The fix must add single-flight deduplication keyed by tenant+room without breaking isolation.

## Scenario

The presence service exposes /join, /leave, /presence, /stats, and /reset endpoints. It uses an in-memory cache with a TTL and a serialized store that takes 100ms per query. When cache entries expire, all concurrent callers independently query the store, causing latency to scale with concurrency.

## Root cause (hidden from the agent)

cache.go Get() has no single-flight deduplication: on a cache miss, every concurrent caller independently calls store.GetPresence(), which serializes through a semaphore, causing N*latency worst-case.

## Correctness constraints

- **C1**: Each presence request completes within 300ms (5x test margin: 600ms)
- **C2**: Each presence response contains only users from the requesting tenant

## Subgoals

1. Add single-flight deduplication for cache misses
2. Key the single-flight by tenant:room to preserve isolation
3. Ensure cached results are shared only within the same tenant+room

## Failure scenario

Concurrent /presence requests after cache expiry all hit the serialized store independently, causing worst latency to exceed the 300ms bound.

## Expected agent pitfalls

- Keying single-flight by room only (breaks tenant isolation)
- Adding a mutex without deduplication (still serializes store calls)
- Using a process-local dedup that doesn’t survive concurrent goroutines

## Anti-shortcut measures

- Tenant isolation test with concurrent cross-tenant requests catches room-only single-flight
- Latency test with 8 concurrent requests catches missing deduplication
- Random schedules with restarts catch state leaks

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_presence_latency_bound`, `test_counterexample_stampede` |
| C2 | `test_tenant_isolation`, `test_concurrent_different_tenants_isolation` |
