package main

import (
"sync"
"time"
)

// PresenceStore is the backing database for room presence data.
// It is tenant-scoped: each tenant has its own namespace of rooms and users.
// Concurrency is limited to a single query at a time (simulating a
// connection pool of size 1), so concurrent lookups serialize.
type PresenceStore struct {
mu      sync.Mutex
sem     chan struct{}
tenants map[string]*tenantData
latency time.Duration
}

type tenantData struct {
rooms map[string][]string
}

func NewPresenceStore(latency time.Duration) *PresenceStore {
return &PresenceStore{
tenants: make(map[string]*tenantData),
sem:     make(chan struct{}, 1),
latency: latency,
}
}

func (s *PresenceStore) tenantRef(tenant string) *tenantData {
td, ok := s.tenants[tenant]
if !ok {
td = &tenantData{rooms: make(map[string][]string)}
s.tenants[tenant] = td
}
return td
}

// Join adds a user to a room's presence list.
func (s *PresenceStore) Join(tenant, room, user string) {
s.mu.Lock()
defer s.mu.Unlock()
td := s.tenantRef(tenant)
for _, u := range td.rooms[room] {
if u == user {
return
}
}
td.rooms[room] = append(td.rooms[room], user)
}

// Leave removes a user from a room's presence list.
func (s *PresenceStore) Leave(tenant, room, user string) {
s.mu.Lock()
defer s.mu.Unlock()
td := s.tenantRef(tenant)
users := td.rooms[room]
for i, u := range users {
if u == user {
td.rooms[room] = append(users[:i], users[i+1:]...)
return
}
}
}

// GetPresence returns the list of online users in a tenant's room.
// Access is serialized through the semaphore; each call takes s.latency.
func (s *PresenceStore) GetPresence(tenant, room string) []string {
s.sem <- struct{}{}
defer func() { <-s.sem }()

time.Sleep(s.latency)

s.mu.Lock()
defer s.mu.Unlock()
td := s.tenantRef(tenant)
result := make([]string, len(td.rooms[room]))
copy(result, td.rooms[room])
return result
}

// SetLatency adjusts the simulated query latency.
func (s *PresenceStore) SetLatency(d time.Duration) {
s.latency = d
}
