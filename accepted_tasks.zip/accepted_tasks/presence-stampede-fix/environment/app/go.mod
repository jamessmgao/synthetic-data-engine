module presence

go 1.23
