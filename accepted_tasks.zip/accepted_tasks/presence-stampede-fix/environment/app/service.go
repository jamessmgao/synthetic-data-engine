package main

import (
"encoding/json"
"fmt"
"io"
"net/http"
"strings"
"sync"
"sync/atomic"
"time"
)

// PresenceService handles room operations and presence fan-out.
// It guarantees each presence request completes within the bound.
type PresenceService struct {
store    *PresenceStore
cache    *PresenceCache
latMu   sync.Mutex
worst   time.Duration
reqCnt  int64
}

func NewPresenceService(store *PresenceStore, cache *PresenceCache) *PresenceService {
return &PresenceService{
store: store,
cache: cache,
}
}

// Join adds a user to a room and invalidates the cached presence.
func (svc *PresenceService) Join(tenant, room, user string) {
svc.store.Join(tenant, room, user)
svc.cache.Invalidate(tenant, room)
}

// Leave removes a user from a room and invalidates the cached presence.
func (svc *PresenceService) Leave(tenant, room, user string) {
svc.store.Leave(tenant, room, user)
svc.cache.Invalidate(tenant, room)
}

// GetPresence returns the online user list for a tenant's room.
func (svc *PresenceService) GetPresence(tenant, room string) []string {
return svc.cache.Get(tenant, room)
}

// recordLatency tracks the worst-case request duration.
func (svc *PresenceService) recordLatency(d time.Duration) {
svc.latMu.Lock()
if d > svc.worst {
svc.worst = d
}
svc.latMu.Unlock()
}

// WorstLatency returns the slowest request seen so far.
func (svc *PresenceService) WorstLatency() time.Duration {
svc.latMu.Lock()
defer svc.latMu.Unlock()
return svc.worst
}

// ResetLatency clears the worst tracker.
func (svc *PresenceService) ResetLatency() {
svc.latMu.Lock()
svc.worst = 0
svc.latMu.Unlock()
}

// ReqCount returns total requests served.
func (svc *PresenceService) ReqCount() int64 {
return atomic.LoadInt64(&svc.reqCnt)
}

type presenceResponse struct {
Users []string `json:"users"`
}

type statsResponse struct {
WorstMs   int64 `json:"worst_ms"`
ReqCount  int64 `json:"req_count"`
CacheHits   int64 `json:"cache_hits"`
CacheMisses int64 `json:"cache_misses"`
}

func (svc *PresenceService) ServeHTTP(w http.ResponseWriter, r *http.Request) {
start := time.Now()
atomic.AddInt64(&svc.reqCnt, 1)

switch {
case r.URL.Path == "/presence" && r.Method == "GET":
tenant := r.URL.Query().Get("tenant")
room := r.URL.Query().Get("room")
if tenant == "" || room == "" {
http.Error(w, "tenant and room required", 400)
return
}
users := svc.GetPresence(tenant, room)
w.Header().Set("Content-Type", "application/json")
json.NewEncoder(w).Encode(presenceResponse{Users: users})

case r.URL.Path == "/join" && r.Method == "POST":
tenant := r.URL.Query().Get("tenant")
room := r.URL.Query().Get("room")
user := r.URL.Query().Get("user")
if tenant == "" || room == "" || user == "" {
http.Error(w, "tenant, room and user required", 400)
return
}
svc.Join(tenant, room, user)
w.WriteHeader(204)

case r.URL.Path == "/leave" && r.Method == "POST":
tenant := r.URL.Query().Get("tenant")
room := r.URL.Query().Get("room")
user := r.URL.Query().Get("user")
if tenant == "" || room == "" || user == "" {
http.Error(w, "tenant, room and user required", 400)
return
}
svc.Leave(tenant, room, user)
w.WriteHeader(204)

case r.URL.Path == "/stats" && r.Method == "GET":
h, m := svc.cache.Stats()
w.Header().Set("Content-Type", "application/json")
json.NewEncoder(w).Encode(statsResponse{
WorstMs:     svc.WorstLatency().Milliseconds(),
ReqCount:    svc.ReqCount(),
CacheHits:   h,
CacheMisses: m,
})

case r.URL.Path == "/reset" && r.Method == "POST":
body, _ := io.ReadAll(r.Body)
svc.cache.Reset()
svc.ResetLatency()
dur, _ := time.ParseDuration(strings.TrimSpace(string(body)))
if dur > 0 {
svc.store.SetLatency(dur)
}
w.WriteHeader(204)

default:
http.NotFound(w, r)
}

svc.recordLatency(time.Since(start))
fmt.Printf("%s %s %dms\n", r.Method, r.URL.Path, time.Since(start).Milliseconds())
}
