package main

import (
"fmt"
"log"
"net/http"
"os"
"time"
)

func main() {
storeLatency := 200 * time.Millisecond
cacheTTL := 2 * time.Second
addr := ":8080"

if v := os.Getenv("STORE_LATENCY"); v != "" {
if d, err := time.ParseDuration(v); err == nil {
storeLatency = d
}
}
if v := os.Getenv("CACHE_TTL"); v != "" {
if d, err := time.ParseDuration(v); err == nil {
cacheTTL = d
}
}
if v := os.Getenv("LISTEN_ADDR"); v != "" {
addr = v
}

store := NewPresenceStore(storeLatency)
cache := NewPresenceCache(store, cacheTTL)
service := NewPresenceService(store, cache)

http.Handle("/presence", service)
http.Handle("/join", service)
http.Handle("/leave", service)
http.Handle("/stats", service)
http.Handle("/reset", service)

fmt.Printf("presence service starting on %s (store latency=%s, cache ttl=%s)\n", addr, storeLatency, cacheTTL)
log.Fatal(http.ListenAndServe(addr, service))
}
