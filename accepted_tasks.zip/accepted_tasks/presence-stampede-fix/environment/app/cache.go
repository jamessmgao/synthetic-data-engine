package main

import (
"sync"
"time"
)

// entry holds a cached presence list and its expiration.
type entry struct {
users []string
exp   time.Time
}

// PresenceCache provides tenant-scoped caching for presence lookups.
// Each cache key combines tenant and room, providing isolation between tenants.
// When an entry expires, every concurrent caller recomputes from the store.
type PresenceCache struct {
mu      sync.RWMutex
items   map[string]*entry
ttl     time.Duration
store   *PresenceStore
hits    int64
misses  int64
}

func NewPresenceCache(store *PresenceStore, ttl time.Duration) *PresenceCache {
return &PresenceCache{
items: make(map[string]*entry),
ttl:   ttl,
store: store,
}
}

func cacheKey(tenant, room string) string {
return tenant + ":" + room
}

// Get returns the presence list for a tenant's room.
// On a cache miss or expiration, it fetches from the store.
func (c *PresenceCache) Get(tenant, room string) []string {
key := cacheKey(tenant, room)

c.mu.RLock()
e, ok := c.items[key]
c.mu.RUnlock()

if ok && time.Now().Before(e.exp) {
c.hits++
result := make([]string, len(e.users))
copy(result, e.users)
return result
}

c.misses++

// Stampede: every concurrent caller with an expired key
// reaches here and hits the slow store independently.
users := c.store.GetPresence(tenant, room)

c.mu.Lock()
c.items[key] = &entry{
users: users,
exp:   time.Now().Add(c.ttl),
}
c.mu.Unlock()

result := make([]string, len(users))
copy(result, users)
return result
}

// Invalidate removes a cached entry (e.g. after a join/leave event).
func (c *PresenceCache) Invalidate(tenant, room string) {
key := cacheKey(tenant, room)
c.mu.Lock()
delete(c.items, key)
c.mu.Unlock()
}

// Stats returns cache hit and miss counts.
func (c *PresenceCache) Stats() (hits, misses int64) {
return c.hits, c.misses
}

// Reset clears all cached entries.
func (c *PresenceCache) Reset() {
c.mu.Lock()
c.items = make(map[string]*entry)
c.hits = 0
c.misses = 0
c.mu.Unlock()
}
