import argparse
import json
import sys

import store


def submit(request_id, account_id, units):
    charge = store.create_charge(request_id, account_id, units)
    event_id = charge["event_id"]
    reservation = store.reserve_units(event_id)
    result = {
        "request_id": request_id,
        "account_id": account_id,
        "units": units,
        "event_id": event_id,
        "reservation_id": reservation.get("reservation_id"),
        "reserved": reservation["reserved"],
    }
    if event_id is not None:
        delivery = store.settle_units(event_id)
        result["delivery_id"] = delivery.get("delivery_id")
        result["delivered"] = delivery["delivered"]
    else:
        result["delivered"] = False
    return result


def state():
    return store.snapshot()


def main(argv=None):
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)

    charge = commands.add_parser("submit")
    charge.add_argument("request_id")
    charge.add_argument("account_id")
    charge.add_argument("units", type=int)

    commands.add_parser("snapshot")

    args = parser.parse_args(argv)
    store.initialize()
    if args.command == "submit":
        output = submit(args.request_id, args.account_id, args.units)
    else:
        output = state()
    print(json.dumps(output, sort_keys=True, default=int))
    return 0


if __name__ == "__main__":
    sys.exit(main())
