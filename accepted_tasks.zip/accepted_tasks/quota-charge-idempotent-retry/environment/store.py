import json
import os

import psycopg2
from psycopg2.extras import RealDictCursor


def connect():
    return psycopg2.connect(
        dbname=os.environ.get("QUOTA_DB", "quota"),
        user="postgres",
        host="/var/run/postgresql",
        port=os.environ.get("PGPORT", "5433"),
    )


def initialize():
    conn = connect()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    "CREATE TABLE IF NOT EXISTS accounts ("
                    "account_id text PRIMARY KEY, "
                    "used_units bigint NOT NULL DEFAULT 0)"
                )
                cur.execute(
                    "CREATE TABLE IF NOT EXISTS charge_requests ("
                    "request_id text PRIMARY KEY, "
                    "account_id text NOT NULL REFERENCES accounts(account_id), "
                    "units bigint NOT NULL CHECK (units > 0), "
                    "status text NOT NULL DEFAULT 'queued')"
                )
                cur.execute(
                    "CREATE TABLE IF NOT EXISTS dispatch_events ("
                    "event_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, "
                    "request_id text NOT NULL REFERENCES charge_requests(request_id), "
                    "account_id text NOT NULL, "
                    "units bigint NOT NULL)"
                )
                cur.execute(
                    "CREATE TABLE IF NOT EXISTS dispatch_deliveries ("
                    "delivery_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, "
                    "event_id bigint NOT NULL UNIQUE REFERENCES dispatch_events(event_id), "
                    "request_id text NOT NULL, "
                    "account_id text NOT NULL, "
                    "units bigint NOT NULL)"
                )
                cur.execute(
                    "CREATE TABLE IF NOT EXISTS unit_reservations ("
                    "reservation_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, "
                    "event_id bigint NOT NULL REFERENCES dispatch_events(event_id), "
                    "request_id text NOT NULL, "
                    "account_id text NOT NULL, "
                    "units bigint NOT NULL)"
                )
    finally:
        conn.close()


def create_charge(request_id, account_id, units):
    if not isinstance(request_id, str) or not request_id:
        raise ValueError("request_id is required")
    if not isinstance(account_id, str) or not account_id:
        raise ValueError("account_id is required")
    if not isinstance(units, int) or isinstance(units, bool) or units <= 0:
        raise ValueError("units must be a positive integer")

    conn = connect()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO accounts (account_id) VALUES (%s) "
                    "ON CONFLICT (account_id) DO NOTHING",
                    (account_id,),
                )
                cur.execute(
                    "INSERT INTO charge_requests "
                    "(request_id, account_id, units) VALUES (%s, %s, %s) "
                    "ON CONFLICT (request_id) DO NOTHING",
                    (request_id, account_id, units),
                )
                inserted = cur.rowcount == 1
                event_id = None
                if inserted:
                    cur.execute(
                        "INSERT INTO dispatch_events "
                        "(request_id, account_id, units) "
                        "VALUES (%s, %s, %s) RETURNING event_id",
                        (request_id, account_id, units),
                    )
                    event_id = cur.fetchone()[0]
                else:
                    cur.execute(
                        "SELECT event_id FROM dispatch_events "
                        "WHERE request_id = %s ORDER BY event_id LIMIT 1",
                        (request_id,),
                    )
                    row = cur.fetchone()
                    if row is not None:
                        event_id = row[0]
        return {
            "request_id": request_id,
            "event_id": event_id,
            "status": "accepted",
        }
    finally:
        conn.close()


def reserve_units(event_id):
    conn = connect()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT request_id, account_id, units FROM dispatch_events "
                    "WHERE event_id = %s",
                    (event_id,),
                )
                event = cur.fetchone()
                if event is None:
                    return {"event_id": event_id, "reserved": False}
                request_id, account_id, units = event
                cur.execute(
                    "INSERT INTO unit_reservations "
                    "(event_id, request_id, account_id, units) "
                    "VALUES (%s, %s, %s, %s) RETURNING reservation_id",
                    (event_id, request_id, account_id, units),
                )
                reservation_id = cur.fetchone()[0]
                cur.execute(
                    "UPDATE accounts SET used_units = used_units + %s "
                    "WHERE account_id = %s",
                    (units, account_id),
                )
        return {
            "event_id": event_id,
            "reservation_id": reservation_id,
            "reserved": True,
        }
    finally:
        conn.close()


def settle_units(event_id):
    conn = connect()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT pg_advisory_xact_lock(1, %s)",
                    (event_id,),
                )
                cur.execute(
                    "SELECT d.request_id, d.account_id, d.units "
                    "FROM dispatch_events d "
                    "LEFT JOIN dispatch_deliveries p ON p.event_id = d.event_id "
                    "WHERE d.event_id = %s AND p.event_id IS NULL",
                    (event_id,),
                )
                event = cur.fetchone()
                if event is None:
                    return {"event_id": event_id, "delivered": False}
                request_id, account_id, units = event
                cur.execute(
                    "INSERT INTO dispatch_deliveries "
                    "(event_id, request_id, account_id, units) "
                    "VALUES (%s, %s, %s, %s) RETURNING delivery_id",
                    (event_id, request_id, account_id, units),
                )
                delivery_id = cur.fetchone()[0]
                cur.execute(
                    "UPDATE charge_requests SET status = 'delivered' "
                    "WHERE request_id = %s",
                    (request_id,),
                )
        return {
            "event_id": event_id,
            "delivery_id": delivery_id,
            "delivered": True,
        }
    finally:
        conn.close()


def snapshot():
    conn = connect()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                "SELECT a.account_id, a.used_units, "
                "COALESCE(SUM(d.units), 0) AS delivered_units "
                "FROM accounts a "
                "LEFT JOIN dispatch_deliveries d "
                "ON d.account_id = a.account_id "
                "GROUP BY a.account_id, a.used_units "
                "ORDER BY a.account_id"
            )
            accounts = [dict(row) for row in cur.fetchall()]
            cur.execute(
                "SELECT request_id, COUNT(*) AS reservation_count, "
                "COALESCE(SUM(units), 0) AS reserved_units "
                "FROM unit_reservations GROUP BY request_id ORDER BY request_id"
            )
            reservations = [dict(row) for row in cur.fetchall()]
            cur.execute(
                "SELECT request_id, COUNT(*) AS delivery_count, "
                "COALESCE(SUM(units), 0) AS delivered_units "
                "FROM dispatch_deliveries GROUP BY request_id "
                "ORDER BY request_id"
            )
            deliveries = [dict(row) for row in cur.fetchall()]
            cur.execute(
                "SELECT request_id, status FROM charge_requests "
                "ORDER BY request_id"
            )
            requests = [dict(row) for row in cur.fetchall()]
        return {
            "accounts": accounts,
            "reservations": reservations,
            "deliveries": deliveries,
            "requests": requests,
        }
    finally:
        conn.close()


if __name__ == "__main__":
    initialize()
    print(json.dumps(snapshot(), default=int))
