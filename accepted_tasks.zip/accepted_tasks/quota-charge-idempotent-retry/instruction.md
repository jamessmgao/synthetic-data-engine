The quota CLI in `/app` accepts `service.py submit <request-id> <account-id> <units>` and `service.py snapshot`.

Fix request handling so every request ID is processed exactly once: its units are reserved at most once, it is delivered exactly once, and each account's used units always equal its delivered units in the snapshot. Keep the existing commands and JSON output working, including multiple accounts and retries. Units are positive integers.
