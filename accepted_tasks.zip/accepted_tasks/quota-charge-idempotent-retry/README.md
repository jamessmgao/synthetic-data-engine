# Idempotent quota request processing

A PostgreSQL-backed quota CLI duplicates reservations on retries and can leave accepted requests queued after a process crash. The task requires exact request-level and account-level consistency under retries, concurrency, and restarts.

## Scenario

The agent receives a small quota service with submit and snapshot commands backed by PostgreSQL. Duplicate request IDs may be retried or submitted concurrently, and the submitter may be killed between internal steps.

## Root cause (hidden from the agent)

The reservation path treats every call as a new reservation, while the delivery path is separate from reservation creation. A retry after a committed reservation but before delivery can therefore either double reserved units or, with a simplistic unique-reservation fix, skip settlement entirely.

## Correctness constraints

- **C1**: Each request ID reserves its requested units at most once
- **C2**: Each accepted request is delivered exactly once
- **C3**: Every account's used units equal its delivered units
- **C4**: The public submit and snapshot commands keep working: valid submissions produce JSON with an event ID, retries reuse the original event ID, the snapshot reports aggregate observable state, and invalid requests fail without changing state.
- **C5**: Duplicate submissions that overlap, and retries after the submitting process is killed and restarted, converge to one reservation and one delivery for the same request ID.

## Subgoals

1. Make request and dispatch identity stable across retries.
2. Make reservation creation idempotent without losing the need to settle an existing reservation.
3. Preserve exactly-once delivery and account usage under concurrent retries.
4. Keep the public CLI and snapshot behavior compatible.

## Failure scenario

A submitter is killed after its request's units are reserved but before delivery commits. A retry must find the existing request and reservation, settle it exactly once, and keep account usage equal to delivered units.

## Expected agent pitfalls

- Adding only a unique constraint and ignoring an existing reservation.
- Trying to deduplicate in process memory, which cannot survive a crash.
- Merging reservation and delivery without preserving current transaction boundaries.
- Breaking concurrent duplicate submissions or ordinary retries.

## Anti-shortcut measures

- Tests replay a real SIGKILL after reservation and before delivery, then retry through the CLI.
- Tests inspect only the public JSON snapshot and command outcomes.
- Tests exercise ten fixed seeds with retries, crashes, and concurrent submissions.
- The plausible unique-reservation-only fix fails the queued-request invariant.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_1_each_request_id_reserves_requested_units_at_most_once`, `test_counterexample_crashed_retry_delivers_once`, `test_concurrent_retries_create_one_reservation_and_delivery`, `test_regression_retries_and_multiple_accounts` |
| C2 | `test_invariant_2_each_accepted_request_is_delivered_exactly_once`, `test_counterexample_crashed_retry_delivers_once`, `test_concurrent_retries_create_one_reservation_and_delivery`, `test_regression_retries_and_multiple_accounts` |
| C3 | `test_invariant_3_every_account_used_units_equal_delivered_units`, `test_counterexample_crashed_retry_delivers_once`, `test_concurrent_retries_create_one_reservation_and_delivery`, `test_regression_retries_and_multiple_accounts` |
| C4 | `test_regression_retries_and_multiple_accounts`, `test_regression_invalid_requests_leave_state_unchanged` |
| C5 | `test_invariant_1_each_request_id_reserves_requested_units_at_most_once`, `test_invariant_2_each_accepted_request_is_delivered_exactly_once`, `test_invariant_3_every_account_used_units_equal_delivered_units`, `test_counterexample_crashed_retry_delivers_once`, `test_concurrent_retries_create_one_reservation_and_delivery` |
