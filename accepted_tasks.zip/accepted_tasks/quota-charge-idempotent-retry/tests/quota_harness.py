import json
import os
import re
import signal
import subprocess
import time


WORKDIR = "/app"
PGDATA = "/tmp/quota-verifier-pgdata"
PGPORT = "55433"
PGSOCKET = "/var/run/postgresql"
DB = "quota"
PG_BIN = "/usr/lib/postgresql/16/bin"
TRACE = "/tmp/quota_strace.log"


def _env():
    e = os.environ.copy()
    e.update({"PGDATA": PGDATA, "PGPORT": PGPORT, "QUOTA_DB": DB, "PGHOST": PGSOCKET})
    return e


def _agent_prefix():
    if os.geteuid() == 0:
        return ["runuser", "-u", "agent", "--"]
    return []


def _run(cmd, timeout=60, cwd=WORKDIR):
    return subprocess.run(
        cmd,
        cwd=cwd,
        env=_env(),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=timeout,
    )


def _ensure_dirs():
    os.makedirs(PGDATA, exist_ok=True)
    os.makedirs(PGSOCKET, exist_ok=True)
    if os.geteuid() == 0:
        import pwd as _pwd
        _ap = _pwd.getpwnam("agent")
        for d in (PGDATA, PGSOCKET):
            try:
                os.chown(d, _ap.pw_uid, _ap.pw_gid)
            except OSError:
                pass
    os.chmod(PGDATA, 0o700)
    os.chmod(PGSOCKET, 0o775)


def _pg_isready(timeout=5):
    return _run(_agent_prefix() + [PG_BIN + "/pg_isready", "-h", PGSOCKET, "-p", PGPORT, "-U", "postgres"], timeout=timeout)


def _read_pg_log():
    try:
        return open("/tmp/quota_pg.log", errors="replace").read()
    except OSError:
        return ""


class QuotaEnv:
    def start(self):
        _ensure_dirs()
        if not os.path.exists(os.path.join(PGDATA, "PG_VERSION")):
            r = _run(_agent_prefix() + [PG_BIN + "/initdb", "-D", PGDATA,
                     "--username=postgres", "--auth-local=trust", "--auth-host=trust"], timeout=60)
            if r.returncode != 0:
                raise RuntimeError("initdb failed: " + r.stderr)
        # Check if server is already accepting connections
        if _pg_isready().returncode == 0:
            return
        # Not ready - stop any stale instance using this PGDATA
        _run(_agent_prefix() + [PG_BIN + "/pg_ctl", "-D", PGDATA, "-m", "immediate", "stop"], timeout=10)
        time.sleep(0.3)
        # Remove stale pid file if present
        pid_path = os.path.join(PGDATA, "postmaster.pid")
        if os.path.exists(pid_path):
            try:
                os.remove(pid_path)
            except OSError:
                pass
        # Start server
        log_path = "/tmp/quota_pg.log"
        r = _run(_agent_prefix() + [PG_BIN + "/pg_ctl", "-D", PGDATA,
                 "-o", f"-p {PGPORT} -k {PGSOCKET}", "-w",
                 "-l", log_path, "start"], timeout=60)
        if r.returncode != 0:
            raise RuntimeError("pg_ctl start failed: " + r.stderr + "\nPG_LOG:\n" + _read_pg_log())
        # Verify readiness
        for _ in range(30):
            if _pg_isready().returncode == 0:
                return
            time.sleep(0.5)
        raise RuntimeError("PostgreSQL not ready after start\nPG_LOG:\n" + _read_pg_log())

    def stop(self):
        _run(_agent_prefix() + [PG_BIN + "/pg_ctl", "-D", PGDATA, "-m", "fast", "-w", "stop"], timeout=30)

    def reset_db(self):
        r = _run(_agent_prefix() + [PG_BIN + "/dropdb", "--if-exists", "-p", PGPORT, "-U", "postgres", DB], timeout=30)
        if r.returncode != 0:
            raise RuntimeError("dropdb failed: " + r.stderr)
        r = _run(_agent_prefix() + [PG_BIN + "/createdb", "-p", PGPORT, "-U", "postgres", DB], timeout=30)
        if r.returncode != 0:
            raise RuntimeError("createdb failed: " + r.stderr)
        self.run_service(["snapshot"])

    def run_service(self, args, timeout=60):
        return _run(_agent_prefix() + ["python3", "/app/service.py"] + args, timeout=timeout)

    def submit(self, request_id, account_id, units, timeout=60):
        r = self.run_service(["submit", request_id, account_id, str(units)], timeout=timeout)
        if r.returncode == 0 and r.stdout.strip():
            return json.loads(r.stdout)
        return {"exit_code": r.returncode, "stdout": r.stdout, "stderr": r.stderr}

    def snapshot(self, timeout=60):
        r = self.run_service(["snapshot"], timeout=timeout)
        if r.returncode != 0:
            raise RuntimeError("snapshot failed: " + r.stderr)
        return json.loads(r.stdout)

    def submit_popen(self, request_id, account_id, units):
        cmd = _agent_prefix() + ["python3", "/app/service.py", "submit",
                                 request_id, account_id, str(units)]
        return subprocess.Popen(cmd, cwd=WORKDIR, env=_env(),
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    def submit_and_crash_before_delivery(self, request_id, account_id, units, timeout=20):
        if os.path.exists(TRACE):
            os.remove(TRACE)
        cmd = ["strace", "-f", "-e", "trace=connect",
               "-e", "inject=connect:signal=SIGSTOP", "-o", TRACE, "--"] + _agent_prefix() + [
            "python3", "/app/service.py", "submit", request_id, account_id, str(units)
        ]
        proc = subprocess.Popen(cmd, cwd=WORKDIR, env=_env(),
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                                start_new_session=True)
        seen = 0
        killed = False
        deadline = time.time() + timeout
        while proc.poll() is None and time.time() < deadline:
            events = _connect_events(TRACE)
            if len(events) <= seen:
                time.sleep(0.002)
                continue
            pid, is_pg = events[seen]
            seen += 1
            state = self.snapshot()
            reservations = {r["request_id"] for r in state["reservations"]}
            deliveries = {r["request_id"] for r in state["deliveries"]}
            if is_pg and request_id in reservations and request_id not in deliveries:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                    killed = True
                except ProcessLookupError:
                    pass
                break
            try:
                os.kill(pid, signal.SIGCONT)
            except ProcessLookupError:
                pass
        try:
            out, err = proc.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            out, err = proc.communicate(timeout=5)
        return {"returncode": proc.returncode, "stdout": out, "stderr": err,
                "killed": killed, "connect_count": len(_connect_events(TRACE))}


def _connect_events(path):
    if not os.path.exists(path):
        return []
    events = []
    with open(path, "r", errors="replace") as f:
        for line in f:
            if "connect(" not in line:
                continue
            m = re.search(r"(?:\[pid\s+(\d+)\s*\]|^(\d+))\s+connect\(", line)
            if m:
                events.append((int(m.group(1) or m.group(2)), ".s.PGSQL." in line))
    return events
