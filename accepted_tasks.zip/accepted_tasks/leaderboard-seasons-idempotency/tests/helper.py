import json
import os
import subprocess
import tempfile

LEADERBOARD = "/app/leaderboard"
TENANTS = ["alpha", "beta", "gamma"]
PLAYERS = ["alice", "bob", "carol", "dave", "eve"]
NODES = [1, 2, 3]

def run_plan(steps, timeout=30):
    plan = {"steps": steps}
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(plan, f)
        f.flush()
        plan_path = f.name
    try:
        result = subprocess.run(
            [LEADERBOARD, plan_path],
            capture_output=True, text=True, timeout=timeout
        )
        if result.returncode == 2:
            return None, 2
        state = json.loads(result.stdout) if result.stdout.strip() else None
        return state, result.returncode
    except (subprocess.TimeoutExpired, json.JSONDecodeError):
        return None, -1
    finally:
        os.unlink(plan_path)

def score(tenant, player, sc, request_id):
    return {"type": "score", "tenant": tenant, "player": player, "score": sc, "request_id": request_id}

def crash(node_id):
    return {"type": "crash", "from": node_id}

def start_node(node_id):
    return {"type": "start", "from": node_id}

def elect(node_id):
    return {"type": "elect", "to": node_id}

def sync(node_id):
    return {"type": "sync", "from": node_id}

def generate_random_plan(rng, num_steps=25):
    steps = []
    down = set()
    leader = 1
    for _ in range(num_steps):
        choices = ["score"]
        up_nodes = [n for n in NODES if n not in down]
        if len(up_nodes) > 1:
            choices.append("crash")
        if down:
            choices.append("start")
        if up_nodes:
            choices.append("elect")
        if leader is not None and leader not in down and len(up_nodes) >= 2:
            choices.append("sync")
        step_type = rng.choice(choices)
        if step_type == "score":
            tenant = rng.choice(TENANTS)
            player = rng.choice(PLAYERS)
            sc = rng.randint(1, 100)
            rid = f"req-{rng.randint(1, 15)}"
            steps.append(score(tenant, player, sc, rid))
        elif step_type == "crash":
            candidates = [n for n in up_nodes if len([x for x in up_nodes if x != n]) >= 1]
            if not candidates:
                continue
            node = rng.choice(candidates)
            steps.append(crash(node))
            down.add(node)
            if node == leader:
                leader = None
        elif step_type == "start":
            node = rng.choice(list(down))
            steps.append(start_node(node))
            down.discard(node)
        elif step_type == "elect":
            node = rng.choice(up_nodes)
            steps.append(elect(node))
            leader = node
        elif step_type == "sync":
            followers = [n for n in up_nodes if n != leader]
            if followers:
                node = rng.choice(followers)
                steps.append(sync(node))
    return steps

def player_in_leaderboard(node_state, tenant, player):
    for lb in node_state.get("leaderboard", []):
        if lb.get("tenant") == tenant:
            return any(e.get("player") == player for e in lb.get("entries", []))
    return False
