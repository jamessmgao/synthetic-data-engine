package main

type LogEntry struct {
Index     int      `json:"index"`
Term      int      `json:"term"`
Type      string   `json:"type"`
Tenant    string   `json:"tenant"`
Player    string   `json:"player"`
Score     int      `json:"score"`
RequestID string   `json:"request_id,omitempty"`
Season    int      `json:"season"`
Response  Response `json:"response"`
Committed bool     `json:"committed"`
}

type WAL struct {
Entries []LogEntry `json:"entries"`
}

func NewWAL() *WAL { return &WAL{Entries: []LogEntry{}} }

func (w *WAL) Append(entry LogEntry) int {
entry.Index = len(w.Entries) + 1
w.Entries = append(w.Entries, entry)
return entry.Index
}

func (w *WAL) LastIndex() int {
return len(w.Entries)
}

func (w *WAL) Get(index int) (LogEntry, bool) {
if index < 1 || index > len(w.Entries) {
return LogEntry{}, false
}
return w.Entries[index-1], true
}

func (w *WAL) MarkCommitted(index int) bool {
entry, ok := w.Get(index)
if !ok || entry.Committed {
return false
}
entry.Committed = true
w.Entries[index-1] = entry
return true
}

func (w *WAL) Clone() *WAL {
clone := &WAL{Entries: make([]LogEntry, len(w.Entries))}
copy(clone.Entries, w.Entries)
return clone
}

type Slot struct {
Owner    string
Response Response
}

type Node struct {
ID       int
Term     int
Role     string
LeaderID int
WAL      *WAL
Dedup    map[string]Slot
Boards   map[string]*TenantBoard
}

func NewNode(id int) *Node {
return &Node{
ID: id, Role: "follower", LeaderID: 1,
WAL: NewWAL(), Dedup: map[string]Slot{}, Boards: map[string]*TenantBoard{},
}
}

func dedupKey(tenant, requestID string) string {
return tenant + "\x1f" + requestID
}

func (n *Node) StoreResponse(tenant, requestID string, response Response) bool {
key := dedupKey(tenant, requestID)
if _, ok := n.Dedup[key]; ok {
return true
}
n.Dedup[key] = Slot{Owner: tenant, Response: response}
return false
}

func (n *Node) Lookup(tenant, requestID string) (Response, bool) {
if slot, ok := n.Dedup[dedupKey(tenant, requestID)]; ok {
return slot.Response, true
}
if slot, ok := n.Dedup[requestID]; ok && slot.Response.RequestID == requestID {
return slot.Response, true
}
return Response{}, false
}

func (n *Node) RebuildDedup() {
n.Dedup = map[string]Slot{}
for _, entry := range n.WAL.Entries {
if entry.Committed && entry.Type == "score" && entry.Response.RequestID != "" {
n.Dedup[entry.RequestID] = Slot{Owner: entry.Tenant, Response: entry.Response}
}
}
}

func (n *Node) RebuildBoard() {
n.Boards = map[string]*TenantBoard{}
for _, entry := range n.WAL.Entries {
if entry.Committed && entry.Type == "score" {
board := n.Board(entry.Tenant)
board.Players[entry.Player] += entry.Score
}
}
}

func (n *Node) Recover() {
n.RebuildBoard()
n.RebuildDedup()
}

func (n *Node) Board(tenant string) *TenantBoard {
board, ok := n.Boards[tenant]
if !ok {
board = &TenantBoard{Tenant: tenant, Season: 1, Players: map[string]int{}}
n.Boards[tenant] = board
}
return board
}

func (n *Node) ApplyScore(entry LogEntry) Response {
if cached, ok := n.Lookup(entry.Tenant, entry.RequestID); ok {
cached.FromCache = true
return cached
}
board := n.Board(entry.Tenant)
board.Players[entry.Player] += entry.Score
response := Response{
Tenant: entry.Tenant, RequestID: entry.RequestID, Player: entry.Player,
Score: board.Players[entry.Player], Season: board.Season, Rank: board.Rank(entry.Player), Applied: true,
}
n.StoreResponse(entry.Tenant, entry.RequestID, response)
if entry.Index >= 1 && entry.Index <= len(n.WAL.Entries) {
n.WAL.Entries[entry.Index-1].Response = response
}
return response
}

func (n *Node) Snapshot() NodeState {
state := NodeState{ID: n.ID, Role: n.Role, Leader: n.LeaderID, CommitIndex: 0, Leaderboard: []TenantState{}}
for _, entry := range n.WAL.Entries {
if entry.Committed && entry.Index > state.CommitIndex {
state.CommitIndex = entry.Index
}
}
keys := make([]string, 0, len(n.Dedup))
for key := range n.Dedup {
keys = append(keys, key)
}
sortStrings(keys)
for _, key := range keys {
state.DedupEntries = append(state.DedupEntries, DedupEntry{Key: key, Response: n.Dedup[key].Response})
}
tenants := make([]string, 0, len(n.Boards))
for t := range n.Boards {
tenants = append(tenants, t)
}
sortStrings(tenants)
for _, t := range tenants {
state.Leaderboard = append(state.Leaderboard, n.Boards[t].Snapshot())
}
return state
}
