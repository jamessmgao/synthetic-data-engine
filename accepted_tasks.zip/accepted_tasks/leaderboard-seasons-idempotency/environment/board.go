package main

import "sort"

type TenantBoard struct {
	Tenant  string
	Season  int
	Players map[string]int
}

func (b *TenantBoard) Ranked() []PlayerScore {
	ranked := make([]PlayerScore, 0, len(b.Players))
	for player, score := range b.Players {
		ranked = append(ranked, PlayerScore{Player: player, Score: score})
	}
	sort.Slice(ranked, func(i, j int) bool {
		if ranked[i].Score != ranked[j].Score {
			return ranked[i].Score > ranked[j].Score
		}
		return ranked[i].Player < ranked[j].Player
	})
	for i := range ranked {
		ranked[i].Rank = i + 1
	}
	return ranked
}

func (b *TenantBoard) Rank(player string) int {
	for _, row := range b.Ranked() {
		if row.Player == player {
			return row.Rank
		}
	}
	return 0
}

func (b *TenantBoard) Snapshot() TenantState {
	return TenantState{Tenant: b.Tenant, Season: b.Season, Entries: b.Ranked()}
}

func sortStrings(values []string) {
	sort.Strings(values)
}
