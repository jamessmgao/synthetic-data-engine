package main

import (
"fmt"
"sort"
)

type Cluster struct {
Nodes     map[int]*Node
LeaderID  int
Term      int
Down      map[int]bool
Responses []Response
Violated  bool
Reason    string
}

func NewCluster() *Cluster {
c := &Cluster{Nodes: map[int]*Node{}, LeaderID: 1, Term: 1, Down: map[int]bool{}}
for id := 1; id <= 3; id++ {
c.Nodes[id] = NewNode(id)
}
c.Nodes[1].Role = "leader"
return c
}

func (c *Cluster) upNodes() []*Node {
nodes := []*Node{}
for id := 1; id <= 3; id++ {
if !c.Down[id] {
nodes = append(nodes, c.Nodes[id])
}
}
sort.Slice(nodes, func(i, j int) bool { return nodes[i].ID < nodes[j].ID })
return nodes
}

func (c *Cluster) hasQuorum() bool { return len(c.upNodes()) >= 2 }

func (c *Cluster) Crash(nodeID int) {
c.Down[nodeID] = true
if node, ok := c.Nodes[nodeID]; ok && node.ID == c.LeaderID {
node.Role = "follower"
}
}

func (c *Cluster) Start(nodeID int) {
c.Down[nodeID] = false
if node, ok := c.Nodes[nodeID]; ok {
node.Recover()
}
}

func (c *Cluster) Elect(nodeID int) error {
if c.Down[nodeID] {
return fmt.Errorf("node %d is down", nodeID)
}
if old := c.Nodes[c.LeaderID]; old != nil && !c.Down[old.ID] {
old.Role = "follower"
}
c.LeaderID = nodeID
c.Term++
leader := c.Nodes[nodeID]
leader.Role = "leader"
leader.LeaderID = nodeID
leader.Term = c.Term
leader.Recover()
for _, node := range c.upNodes() {
if node.ID != nodeID {
node.Role = "follower"
node.LeaderID = nodeID
node.Term = c.Term
}
}
return nil
}

func (c *Cluster) Sync(nodeID int) error {
if c.Down[c.LeaderID] {
return fmt.Errorf("leader %d is down", c.LeaderID)
}
if c.Down[nodeID] {
return fmt.Errorf("node %d is down", nodeID)
}
leader := c.Nodes[c.LeaderID]
follower := c.Nodes[nodeID]
for i := follower.WAL.LastIndex() + 1; i <= leader.WAL.LastIndex(); i++ {
entry, ok := leader.WAL.Get(i)
if !ok {
continue
}
copyEntry := entry
copyEntry.Index = 0
follower.WAL.Append(copyEntry)
}
for i := 1; i <= follower.WAL.LastIndex() && i <= leader.WAL.LastIndex(); i++ {
leaderEntry, ok := leader.WAL.Get(i)
if !ok || !leaderEntry.Committed {
continue
}
if fEntry, ok := follower.WAL.Get(i); ok {
fEntry.Term = leaderEntry.Term
fEntry.Type = leaderEntry.Type
fEntry.Tenant = leaderEntry.Tenant
fEntry.Player = leaderEntry.Player
fEntry.Score = leaderEntry.Score
fEntry.RequestID = leaderEntry.RequestID
fEntry.Committed = true
follower.WAL.Entries[i-1] = fEntry
}
}
return nil
}

func (c *Cluster) syncFollowers() {
for _, node := range c.upNodes() {
if node.ID != c.LeaderID {
c.Sync(node.ID)
}
}
}

func (c *Cluster) SubmitScore(step Step) (Response, error) {
leader := c.Nodes[c.LeaderID]
if c.Down[leader.ID] {
return Response{}, fmt.Errorf("leader %d is down", leader.ID)
}
if cached, ok := leader.Lookup(step.Tenant, step.RequestID); ok {
cached.FromCache = true
return cached, nil
}
entry := LogEntry{
Term: c.Term, Type: "score", Tenant: step.Tenant, Player: step.Player,
Score: step.Score, RequestID: step.RequestID,
}
index := leader.WAL.Append(entry)
c.syncFollowers()
if !c.hasQuorum() {
return Response{Tenant: step.Tenant, RequestID: step.RequestID, Player: step.Player, Applied: false}, nil
}
for _, node := range c.upNodes() {
node.WAL.MarkCommitted(index)
}
var leaderResponse Response
for _, node := range c.upNodes() {
walEntry, _ := node.WAL.Get(index)
response := node.ApplyScore(walEntry)
if node.ID == c.LeaderID {
leaderResponse = response
}
}
return leaderResponse, nil
}

func (c *Cluster) BuildState() *State {
state := &State{Responses: c.Responses}
for id := 1; id <= 3; id++ {
state.Nodes = append(state.Nodes, c.Nodes[id].Snapshot())
}
for id := 1; id <= 3; id++ {
node := c.Nodes[id]
for _, slot := range node.Dedup {
resp := slot.Response
if resp.Tenant == "" || resp.Player == "" {
continue
}
board, ok := node.Boards[resp.Tenant]
if !ok {
c.Violated = true
c.Reason = fmt.Sprintf("node %d dedup response tenant %s not in leaderboard", id, resp.Tenant)
break
}
if _, ok := board.Players[resp.Player]; !ok {
c.Violated = true
c.Reason = fmt.Sprintf("node %d dedup response player %s not in tenant %s leaderboard", id, resp.Player, resp.Tenant)
break
}
}
if c.Violated {
break
}
}
if c.Violated {
state.InvariantViolated = true
state.Reason = c.Reason
}
return state
}

func RunPlan(plan *Plan) (*State, error) {
c := NewCluster()
for _, step := range plan.Steps {
switch step.Type {
case "score":
response, err := c.SubmitScore(step)
if err != nil {
return nil, err
}
c.Responses = append(c.Responses, response)
if response.Tenant != step.Tenant || response.Player != step.Player {
c.Violated = true
c.Reason = fmt.Sprintf("request %s for tenant %s returned tenant %s player %s",
step.RequestID, step.Tenant, response.Tenant, response.Player)
}
case "crash":
c.Crash(step.From)
case "start":
c.Start(step.From)
case "elect":
if err := c.Elect(step.To); err != nil {
return nil, err
}
case "sync":
if err := c.Sync(step.From); err != nil {
return nil, err
}
default:
return nil, fmt.Errorf("unknown step type %q", step.Type)
}
}
return c.BuildState(), nil
}
