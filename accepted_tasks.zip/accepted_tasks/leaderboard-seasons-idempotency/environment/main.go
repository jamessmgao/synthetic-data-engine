package main

import (
"encoding/json"
"fmt"
"os"
)

type Plan struct {
Steps []Step `json:"steps"`
}

type Step struct {
Type      string `json:"type"`
Tenant    string `json:"tenant,omitempty"`
Player    string `json:"player,omitempty"`
Score     int    `json:"score,omitempty"`
RequestID string `json:"request_id,omitempty"`
From      int    `json:"from,omitempty"`
To        int    `json:"to,omitempty"`
}

type Response struct {
Tenant    string `json:"tenant"`
RequestID string `json:"request_id"`
Player    string `json:"player"`
Score     int    `json:"score"`
Season    int    `json:"season"`
Rank      int    `json:"rank"`
Applied   bool   `json:"applied"`
FromCache bool   `json:"from_cache"`
}

type NodeState struct {
ID           int           `json:"id"`
Role         string        `json:"role"`
Leader       int           `json:"leader"`
CommitIndex  int           `json:"commit_index"`
DedupEntries []DedupEntry  `json:"dedup"`
Leaderboard  []TenantState `json:"leaderboard"`
}

type DedupEntry struct {
Key      string   `json:"key"`
Response Response `json:"response"`
}

type TenantState struct {
Tenant  string        `json:"tenant"`
Season  int           `json:"season"`
Entries []PlayerScore `json:"entries"`
}

type PlayerScore struct {
Player string `json:"player"`
Score  int    `json:"score"`
Rank   int    `json:"rank"`
}

type State struct {
InvariantViolated bool        `json:"invariant_violated"`
Reason            string      `json:"reason,omitempty"`
Responses         []Response  `json:"responses"`
Nodes             []NodeState `json:"nodes"`
}

func main() {
if len(os.Args) < 2 {
fmt.Fprintln(os.Stderr, "usage: leaderboard <plan.json>")
os.Exit(2)
}
data, err := os.ReadFile(os.Args[1])
if err != nil {
fmt.Fprintf(os.Stderr, "read plan: %v\n", err)
os.Exit(2)
}
var plan Plan
if err := json.Unmarshal(data, &plan); err != nil {
fmt.Fprintf(os.Stderr, "parse plan: %v\n", err)
os.Exit(2)
}
state, err := RunPlan(&plan)
if err != nil {
fmt.Fprintf(os.Stderr, "run: %v\n", err)
os.Exit(2)
}
out, err := json.MarshalIndent(state, "", "  ")
if err != nil {
fmt.Fprintf(os.Stderr, "marshal: %v\n", err)
os.Exit(2)
}
fmt.Println(string(out))
if state.InvariantViolated {
os.Exit(1)
}
}
