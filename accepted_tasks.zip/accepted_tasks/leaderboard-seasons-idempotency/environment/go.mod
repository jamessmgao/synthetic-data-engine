module leaderboard

go 1.23
