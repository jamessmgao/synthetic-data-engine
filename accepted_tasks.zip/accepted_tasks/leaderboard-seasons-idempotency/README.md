# Leaderboard Seasons Idempotency Fix

A Go leaderboard service with 3-node Raft-like replication has a defect where the idempotency cache is keyed by request_id only during WAL replay, and the Sync function overwrites follower WAL entry metadata without updating the Response field. After failover, this causes one tenant to receive a cached response belonging to a different tenant.

## Scenario

The service runs as /app/leaderboard taking a JSON plan file. Each plan contains score submissions, crash/start/elect/sync steps. After leader failover, resubmitted requests with the same request_id but different tenants can return the wrong tenant's cached response.

## Root cause (hidden from the agent)

Two bugs: (1) node.go RebuildDedup uses entry.RequestID as key instead of dedupKey(entry.Tenant, entry.RequestID), and Lookup has a fallback that doesn't check tenant; (2) scheduler.go Sync overwrites follower WAL entry fields (Term, Type, Tenant, Player, Score, RequestID, Committed) but not Response, leaving a stale Response that propagates on recovery.

## Correctness constraints

- **C1**: A response for a request_id from one tenant is never returned for a different tenant's request with the same request_id
- **C2**: After failover and cache recovery, each tenant's idempotency scope is preserved independently
- **C3**: Every dedup entry's response tenant and player must appear in that node's leaderboard for that tenant

## Subgoals

1. Fix the dedup key scoping in node.go RebuildDedup and Lookup
2. Fix the Sync function in scheduler.go to also update the Response field
3. Verify that both fixes are needed by testing crash/elect/sync/replay sequences

## Failure scenario

After a leader crash and election, a score request with the same request_id but a different tenant returns the previous tenant's cached response. The counterexample: crash node 2, submit alpha/alice/10 as req-1, crash node 1, start node 2, elect node 2, submit gamma/carol/30 as req-1, sync node 3, crash node 2, elect node 3, submit gamma/carol/5 as req-1. The last response returns tenant alpha player alice instead of gamma carol.

## Expected agent pitfalls

- Fixing only the dedup key in node.go without fixing the Sync WAL Response overwrite
- Adding tenant checks only to Lookup without fixing RebuildDedup key scoping
- Not testing sync/crash/elect sequences that expose the WAL corruption

## Anti-shortcut measures

- Tests use random schedules with crash/elect/sync that expose both bugs
- The wrong fix (only node.go changes) passes simple cross-tenant checks but fails after sync corruption
- Counterexample replay requires both fixes to pass

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_cross_tenant_never_returns_wrong_tenant`, `test_shared_request_id_across_tenants`, `test_counterexample` |
| C2 | `test_idempotent_after_failover`, `test_tenant_scoped_idempotency_after_failover`, `test_idempotent_resubmit`, `test_crash_restart_preserves_committed` |
| C3 | `test_dedup_entries_in_leaderboard`, `test_sync_corruption_detected` |
