"""Macro expansion for regex patterns with parameterized definitions."""

import re


class Macro:
    def __init__(self, name, params, body):
        self.name = name
        self.params = params
        self.body = body

    @staticmethod
    def parse(name, definition):
        if ':' in definition:
            colon_pos = definition.index(':')
            param_part = definition[:colon_pos]
            body = definition[colon_pos + 1:]
            params = [p.strip() for p in param_part.split(',') if p.strip()]
        else:
            params = []
            body = definition
        return Macro(name, params, body.strip())


class ExpansionContext:
    _shared_counter = 0

    def __init__(self, macro_name, depth=0):
        self.macro_name = macro_name
        self.depth = depth
        self._counter = ExpansionContext._shared_counter

    def gensym(self, prefix="_m"):
        name = f"{prefix}{self._counter}"
        self._counter += 1
        ExpansionContext._shared_counter = self._counter
        return name

    def make_capture_name(self):
        return self.gensym("_g")


class MacroExpander:
    PARAM_REF = re.compile("@([A-Za-z0-9_]+)[(]([^)]*)[)]")
    SIMPLE_REF = re.compile("@([A-Za-z0-9_]+)(?![A-Za-z0-9_(])")

    def __init__(self):
        self.macros = {}
        self._expansion_cache = {}
        self._generated_names = set()

    def define(self, name, definition):
        self.macros[name] = Macro.parse(name, definition)
        self._expansion_cache.clear()
        return self.macros[name]

    def expand(self, pattern, depth=0):
        result = pattern
        for _ in range(50):
            expanded = self._expand_once(result, depth)
            if expanded == result:
                break
            result = expanded
        return result

    def internal_names(self):
        return self._generated_names.copy()

    def _expand_once(self, pattern, depth):
        for match in self.PARAM_REF.finditer(pattern):
            name = match.group(1)
            if name not in self.macros:
                continue
            args = [a.strip() for a in match.group(2).split(',') if a.strip()]
            macro = self.macros[name]
            if len(args) != len(macro.params):
                continue
            expanded = self._invoke(macro, args, depth + 1)
            return pattern[:match.start()] + expanded + pattern[match.end():]

        for match in self.SIMPLE_REF.finditer(pattern):
            name = match.group(1)
            if name not in self.macros:
                continue
            macro = self.macros[name]
            if macro.params:
                continue
            expanded = self._invoke(macro, [], depth + 1)
            return pattern[:match.start()] + expanded + pattern[match.end():]

        return pattern

    def _invoke(self, macro, args, depth):
        cache_key = (macro.name, tuple(args))
        if cache_key in self._expansion_cache:
            return self._expansion_cache[cache_key]

        ctx = ExpansionContext(macro.name, depth)
        body = macro.body

        for i, param in enumerate(macro.params):
            if i < len(args):
                body = body.replace(f'${{{param}}}', args[i])

        body = self._process_captures(body, ctx)
        body = self.expand(body, depth)

        self._expansion_cache[cache_key] = body
        return body

    def _process_captures(self, body, ctx):
        result = body
        while '${_cap}' in result:
            cap_name = ctx.make_capture_name()
            self._generated_names.add(cap_name)
            result = result.replace('${_cap}', f'(?P<{cap_name}>', 1)
            if '${_end}' in result:
                result = result.replace('${_end}', ')', 1)
        return result
