"""Regex macro engine HTTP service."""

from flask import Flask, request, jsonify
from macro_expand import MacroExpander
import engine

app = Flask(__name__)
expander = MacroExpander()


@app.route('/macros', methods=['POST'])
def define_macro():
    data = request.json
    if not data or 'name' not in data or 'definition' not in data:
        return jsonify({'error': 'name and definition are required'}), 400
    expander.define(data['name'], data['definition'])
    return jsonify({'status': 'ok', 'name': data['name']})


@app.route('/match', methods=['POST'])
def match_pattern():
    data = request.json
    if not data or 'pattern' not in data or 'text' not in data:
        return jsonify({'error': 'pattern and text are required'}), 400
    try:
        expanded = expander.expand(data['pattern'])
        internal = expander.internal_names()
        program = engine.compile(expanded, internal_names=internal)
        result = program.match(data['text'])
    except engine.CompileError as exc:
        return jsonify({'error': 'compile_failed', 'detail': str(exc)}), 400
    return jsonify(result.as_dict())


@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok'})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
