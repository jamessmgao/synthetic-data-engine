"""Test helpers for regex macro hygiene tests - HTTP service only."""

import subprocess
import json
import time
import os
import urllib.request
import urllib.error


class ServiceManager:
    """Manages the regex macro service lifecycle for testing."""

    def __init__(self, port=8080):
        self.port = port
        self.proc = None
        self._stderr_output = ""

    def start(self, timeout=20):
        """Start the service and wait for it to be healthy."""
        self.stop()
        self.proc = subprocess.Popen(
            ["/usr/local/bin/python3", "service.py"],
            cwd="/app",
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            env={**os.environ, "FLASK_DEBUG": "0"}
        )
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.proc.poll() is not None:
                _, stderr = self.proc.communicate(timeout=5)
                self._stderr_output = stderr.decode("utf-8", errors="replace")
                self.proc = None
                return False
            try:
                r = urllib.request.urlopen(
                    f"http://127.0.0.1:{self.port}/health", timeout=2
                )
                if r.getcode() == 200:
                    return True
            except (urllib.error.URLError, ConnectionRefusedError, OSError):
                pass
            time.sleep(0.3)
        if self.proc and self.proc.poll() is not None:
            _, stderr = self.proc.communicate(timeout=5)
            self._stderr_output = stderr.decode("utf-8", errors="replace")
        self.stop()
        return False

    def get_stderr(self):
        """Get captured stderr from the service process."""
        return self._stderr_output

    def stop(self):
        """Stop the service gracefully."""
        if self.proc is not None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=5)
            self.proc = None

    def kill(self):
        """Kill the service (SIGKILL)."""
        if self.proc is not None:
            self.proc.kill()
            self.proc.wait(timeout=5)
            self.proc = None

    def define(self, name, definition):
        """Define a macro via the HTTP API."""
        data = json.dumps({"name": name, "definition": definition}).encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/macros",
            data=data, headers={"Content-Type": "application/json"}, method="POST"
        )
        urllib.request.urlopen(req, timeout=10)

    def match(self, pattern, text):
        """Match a pattern via the HTTP API."""
        data = json.dumps({"pattern": pattern, "text": text}).encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/match",
            data=data, headers={"Content-Type": "application/json"}, method="POST"
        )
        try:
            r = urllib.request.urlopen(req, timeout=10)
            return json.loads(r.read())
        except urllib.error.HTTPError as e:
            return json.loads(e.read())

    def health(self):
        """Check service health via the HTTP API."""
        try:
            r = urllib.request.urlopen(
                f"http://127.0.0.1:{self.port}/health", timeout=5
            )
            return json.loads(r.read())
        except (urllib.error.URLError, ConnectionRefusedError, OSError):
            return None
