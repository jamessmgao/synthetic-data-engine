# Regex macro capture hygiene

The regex macro engine has two bugs: repeated sibling macro invocations reuse the same expanded body from cache, producing duplicate named capture groups that cause incorrect match results, and internal _g-prefixed groups leak into match results.

## Scenario

A regex macro service allows users to define reusable patterns with auto-generated captures. When the same macro is used twice in a pattern (e.g. @inner@inner), the expansion cache returns the first invocation's body for both, creating duplicate capture names. The regex engine silently converts the duplicate to a non-capturing group, so the second capture always reports the first capture's value. Additionally, internal _g groups appear in match results because the service does not pass generated names to the compiler for filtering.

## Root cause (hidden from the agent)

The expansion cache in MacroExpander._invoke returns the cached body for repeated sibling invocations, producing duplicate capture group names. The service does not call expander.internal_names() or pass the result to engine.compile(), so internal groups are never filtered.

## Correctness constraints

- **C1**: A valid pattern using nested macro-generated captures compiles and matches its expected input without leaking internal capture groups.
- **C2**: Repeated independent macro invocations produce distinct generated capture names and compile successfully without leaking internal groups.
- **C3**: User-defined named capture groups always appear in match results with correct values.

## Subgoals

1. Identify that the expansion cache causes duplicate capture names for sibling invocations
2. Fix the expansion to produce unique capture names across all invocations
3. Ensure internal group names are tracked and passed to the engine for filtering
4. Verify user-defined groups are not accidentally filtered
5. Confirm the HTTP service correctly wires internal_names to engine.compile

## Failure scenario

Define macro inner as ${_cap}[0-9]+${_end}, expand @inner@inner, compile against abc123456. The second inner capture reports the first capture's value and _g-prefixed groups appear in match results.

## Expected agent pitfalls

- Adding a shared gensym counter without removing the expansion cache - still produces duplicate names from cache
- Filtering all _g-prefixed groups instead of only generated ones - removes user-defined groups starting with _g
- Fixing only the Python API but not the HTTP service endpoint - internal names still leak through /match

## Anti-shortcut measures

- Tests check distinct capture names in the expanded pattern string, not just match results
- Tests verify user-defined _g-prefixed groups are preserved when not in internal_names
- Tests exercise the HTTP /match endpoint to catch service-level wiring bugs

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_1_nested_macro_no_leakage`, `test_service_nested_macro_no_leakage`, `test_deeply_nested_macro`, `test_single_macro_invocation` |
| C2 | `test_invariant_2_distinct_sibling_captures`, `test_counterexample_sibling_duplicate_captures`, `test_service_sibling_distinct_captures`, `test_triple_sibling_invocation`, `test_multiple_seeds_service_consistency` |
| C3 | `test_invariant_3_user_groups_visible`, `test_service_user_groups_visible`, `test_parametric_macro`, `test_no_macro_plain_regex`, `test_user_group_g_prefix_not_filtered` |
