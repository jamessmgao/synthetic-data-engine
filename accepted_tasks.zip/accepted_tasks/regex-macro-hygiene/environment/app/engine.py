"""Compilation and execution of expanded regex patterns."""

import re


class CompileError(Exception):
    pass


class MatchResult:
    def __init__(self, matched, captures, spans):
        self.matched = matched
        self.captures = captures
        self.spans = spans

    def as_dict(self):
        return {
            "matched": self.matched,
            "captures": self.captures,
            "spans": self.spans,
        }


def _group_tags(source):
    marker = "(?P<"
    tags = []
    idx = 0
    while True:
        pos = source.find(marker, idx)
        if pos == -1:
            break
        start = pos + len(marker)
        end = source.find(">", start)
        if end == -1:
            break
        tags.append((pos, start, end, source[start:end]))
        idx = end + 1
    return tags


def _dedup_groups(source):
    tags = _group_tags(source)
    names = [name for _, _, _, name in tags]
    if len(names) == len(set(names)):
        return None
    seen = set()
    out = []
    last = 0
    for pos, start, end, name in tags:
        if name in seen:
            out.append(source[last:pos])
            out.append("(?:")
            last = end + 1
        seen.add(name)
    out.append(source[last:])
    return "".join(out)


class CompiledPattern:
    def __init__(self, source, internal_names=None):
        self.source = source
        self.internal_names = internal_names or set()
        try:
            self.program = re.compile(source)
        except re.error as exc:
            resolved = _dedup_groups(source)
            if resolved is None:
                raise CompileError(str(exc)) from exc
            try:
                self.program = re.compile(resolved)
            except re.error:
                raise CompileError(str(exc)) from exc

    def match(self, text):
        found = self.program.search(text)
        if found is None:
            return MatchResult(False, {}, {})
        captures = {}
        spans = {}
        for name, value in found.groupdict().items():
            if name in self.internal_names:
                continue
            captures[name] = value
            spans[name] = found.span(name)
        return MatchResult(True, captures, spans)


def compile(source, internal_names=None):
    return CompiledPattern(source, internal_names)
