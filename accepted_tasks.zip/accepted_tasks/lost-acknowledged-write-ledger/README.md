# Lost acknowledged write in shared durable ledger

A Python ledger service acknowledges appends before they are durable and serializes checks only inside each process. When processes share one durable data directory, concurrent and retried appends can create duplicate request IDs and exceed the capacity limit.

## Scenario

The repository contains a Python service that accepts JSON line commands for append and read. The service can be run with multiple node processes sharing the same durable data directory. Appends that return ok=true must be durable and unique across process restarts and concurrent processes.

## Root cause (hidden from the agent)

Cluster.append prepares entries but does not commit them before acknowledging; ledger/read can include prepared entries or lose them on recovery. process_batch checks capacity and duplicates in memory before issuing commands, and no cross-process coordination protects shared node logs.

## Correctness constraints

- **C1**: After a process restart, every append that returned ok=true is present in the ledger exactly once with its requested quantity.
- **C2**: Each request ID appears at most once in the ledger, and a repeated append for that ID does not add another entry.
- **C3**: A read reports the sum of the quantities of exactly the distinct acknowledged request IDs it contains.
- **C4**: The total quantity across all entries in the ledger must not exceed the capacity limit (MAX_QUANTITY=10).

## Subgoals

1. Make append durable before returning ok=true so restart recovery preserves acknowledged writes.
2. Ensure request ID deduplication and capacity checks are coordinated across processes sharing the durable data directory.
3. Keep read, append validation, and error status behaviors working.

## Failure scenario

Tests start fresh data directories, append entries, kill and restart services, retry request IDs, and run concurrent service processes against the same data directory to verify durability, uniqueness, read totals, and capacity under the world's allowed concurrency.

## Expected agent pitfalls

- Committing before acknowledging but keeping per-process in-memory dedup/capacity checks, which concurrent processes can pass independently.
- Serializing commands inside one service process while another process shares the same data directory.
- Including prepared but uncommitted entries in reads without durable recovery semantics.

## Anti-shortcut measures

- Tests run concurrent service processes against the same data directory, rejecting process-local serialization.
- Tests kill and restart processes, rejecting acknowledgements that are not durable.
- Tests assert exact totals and duplicate counts over many fixed seeds and exact counterexamples.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_restart_durability_acknowledged_appends`, `test_retry_after_crash_same_request_id` |
| C2 | `test_unique_request_id_no_duplicates`, `test_counterexample_duplicate_concurrent_append`, `test_retry_after_crash_same_request_id` |
| C3 | `test_read_sum_of_distinct_acknowledged_ids` |
| C4 | `test_capacity_limit_not_exceeded`, `test_counterexample_concurrent_capacity_exceed` |
