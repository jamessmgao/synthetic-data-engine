from store import Store


class Cluster:
    """A small ledger front end."""

    NODE_IDS = ("alpha", "beta", "gamma")
    QUORUM = 2
    MAX_QUANTITY = 10

    def __init__(self, directory, node_id=None):
        self.directory = directory
        self.node_id = node_id
        self.stores = {
            node_id: Store(node_id, f"{directory}/{node_id}")
            for node_id in self.NODE_IDS
        }
        self.leader_id = None
        self.admitted = set()
        self._recover()
        if self.node_id is None:
            self.node_id = self.leader_id

    def _all_entries(self):
        entries = []
        for store in self.stores.values():
            entries.extend(store.committed_entries())
            entries.extend(store.prepared_entries())
        return entries

    def _committed_request(self, request_id):
        for entry in self._all_entries():
            if entry["request_id"] == request_id and entry["status"] == "committed":
                return entry
        return None

    def _pending_request(self, request_id):
        for entry in self._all_entries():
            if entry["request_id"] == request_id:
                return entry
        return None

    def _next_index(self):
        highest = 0
        for store in self.stores.values():
            for entry in store.committed_entries() + store.prepared_entries():
                highest = max(highest, int(entry["index"]))
        return highest + 1

    def quantity_used(self):
        return sum(int(e["quantity"]) for e in self.ledger())

    def ledger(self):
        entries = []
        for store in self.stores.values():
            entries.extend(store.committed_entries())
            entries.extend(store.prepared_entries())
        entries.sort(key=lambda entry: (int(entry["index"]), entry["request_id"]))
        return entries

    def append(self, request_id, quantity, admitted=False):
        request_id = str(request_id)
        quantity = int(quantity)
        if quantity <= 0:
            return {"ok": False, "status": "invalid_quantity"}

        if not admitted:
            existing = self._committed_request(request_id)
            if existing is not None:
                return {
                    "ok": True,
                    "status": "already_applied",
                    "index": int(existing["index"]),
                }

            pending = self._pending_request(request_id)
            if pending is not None:
                return {
                    "ok": False,
                    "status": "request_pending",
                    "index": int(pending["index"]),
                }

        entry = {
            "index": self._next_index(),
            "request_id": request_id,
            "quantity": quantity,
            "status": "prepared",
        }
        if not self.stores[self.node_id].prepare(entry):
            return {"ok": False, "status": "unavailable"}

        return {
            "ok": True,
            "status": "acknowledged",
            "index": int(entry["index"]),
            "replicas": [self.node_id],
        }

    def _recover(self):
        self.leader_id = min(
            self.NODE_IDS,
            key=lambda node_id: (-self.stores[node_id].highest_committed(), node_id),
        )
        leader = self.stores[self.leader_id]
        durable_index = leader.highest_committed()
        for store in self.stores.values():
            store.truncate_after(durable_index)

    def node_status(self):
        entries = []
        for store in self.stores.values():
            entries.extend(store.committed_entries())
        entries.sort(key=lambda entry: (int(entry["index"]), entry["request_id"]))
        return entries

    def describe(self):
        return {
            "leader": self.leader_id,
            "committed": self.node_status(),
        }
