import json
import os
import tempfile
from pathlib import Path


class StoreError(RuntimeError):
    pass


class Store:
    """A node-local journal."""

    def __init__(self, node_id, directory):
        self.node_id = node_id
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / f"{node_id}.json"
        self.committed_index = 0
        self.entries = {}
        self.aborted = set()
        self._load()

    def _load(self):
        if not self.path.exists():
            return
        try:
            payload = json.loads(self.path.read_text())
            if payload.get("node_id") != self.node_id:
                raise StoreError("log belongs to another node")
            entries = payload.get("entries", {})
            if not isinstance(entries, dict):
                raise StoreError("invalid log entries")
            committed_index = int(payload.get("committed_index", 0))
            self.entries = {}
            for raw_index, record in entries.items():
                index = int(raw_index)
                if index <= 0:
                    raise StoreError("log indexes start at one")
                if record.get("status") not in ("prepared", "committed"):
                    raise StoreError("invalid entry status")
                self.entries[index] = {
                    "entry": dict(record["entry"]),
                    "status": record["status"],
                }
            if committed_index not in self.entries and committed_index != 0:
                raise StoreError("committed index is missing")
            if committed_index != 0 and self.entries[committed_index]["status"] != "committed":
                raise StoreError("committed index is not committed")
            self.committed_index = committed_index
            self.aborted = set(payload.get("aborted", []))
        except (OSError, ValueError, TypeError, KeyError) as exc:
            raise StoreError(f"cannot read log for {self.node_id}: {exc}") from exc

    def _save(self):
        payload = {
            "node_id": self.node_id,
            "committed_index": self.committed_index,
            "entries": {
                str(index): {
                    "entry": record["entry"],
                    "status": record["status"],
                }
                for index, record in sorted(self.entries.items())
            },
            "aborted": sorted(self.aborted),
        }
        fd, temporary = tempfile.mkstemp(
            prefix=f".{self.node_id}.", dir=self.directory, text=True
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(payload, stream, sort_keys=True, separators=(",", ":"))
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            directory_fd = os.open(self.directory, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def prepare(self, entry):
        index = int(entry["index"])
        if index <= self.committed_index:
            return False
        existing = self.entries.get(index)
        if existing is not None:
            return existing["entry"] == entry
        self.entries[index] = {"entry": dict(entry), "status": "prepared"}
        self._save()
        return True

    def commit(self, index):
        index = int(index)
        record = self.entries.get(index)
        if record is None or index <= self.committed_index:
            return False
        record["status"] = "committed"
        record["entry"]["status"] = "committed"
        self.committed_index = index
        self._save()
        return True

    def abort(self, request_id):
        if request_id in self.aborted:
            return False
        self.aborted.add(request_id)
        self._save()
        return True

    def is_aborted(self, request_id):
        return request_id in self.aborted

    def truncate_after(self, index):
        index = int(index)
        removed = [candidate for candidate in self.entries if candidate > index]
        if not removed:
            return False
        for candidate in removed:
            del self.entries[candidate]
        self._save()
        return True

    def entry(self, index):
        record = self.entries.get(int(index))
        return dict(record["entry"]) if record else None

    def record(self, index):
        record = self.entries.get(int(index))
        if record is None:
            return None
        return {"entry": dict(record["entry"]), "status": record["status"]}

    def committed_entries(self):
        return [
            dict(self.entries[index]["entry"])
            for index in sorted(self.entries)
            if self.entries[index]["status"] == "committed"
        ]

    def prepared_entries(self):
        return [
            dict(self.entries[index]["entry"])
            for index in sorted(self.entries)
            if self.entries[index]["status"] == "prepared"
        ]

    def highest_committed(self):
        return self.committed_index
