import argparse
import json
import os
import select
import sys

from cluster import Cluster


def validate(command):
    if not isinstance(command, dict):
        return {"ok": False, "error": "invalid_command"}
    operation = command.get("op")
    if operation == "append":
        if "request_id" not in command or "quantity" not in command:
            return {"ok": False, "error": "invalid_command"}
        return None
    if operation == "read":
        return None
    return {"ok": False, "error": "unknown_operation"}


def process_batch(cluster, commands):
    actions = []
    for command in commands:
        invalid = validate(command)
        if invalid is not None:
            actions.append(("response", invalid))
            continue

        if command.get("op") == "append":
            rid = str(command["request_id"])
            existing = cluster._committed_request(rid)
            if existing is not None:
                actions.append(("response", {
                    "ok": True,
                    "status": "already_applied",
                    "index": int(existing["index"]),
                }))
            elif cluster.quantity_used() + int(command["quantity"]) > Cluster.MAX_QUANTITY:
                actions.append(("response", {
                    "ok": False,
                    "status": "over_capacity",
                }))
            else:
                cluster.admitted.add(rid)
                actions.append(("append", command))
        else:
            actions.append(("read", None))

    responses = []
    for kind, value in actions:
        if kind == "response":
            responses.append(value)
        elif kind == "append":
            responses.append(cluster.append(
                value["request_id"],
                value["quantity"],
                admitted=True,
            ))
        elif kind == "read":
            entries = cluster.ledger()
            total = sum(int(e["quantity"]) for e in entries)
            responses.append({
                "ok": True,
                "entries": entries,
                "total": total,
            })

    return responses


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="/data")
    parser.add_argument("--node", choices=Cluster.NODE_IDS, default=None)
    args = parser.parse_args()

    os.makedirs(args.data, exist_ok=True)
    cluster = Cluster(args.data, args.node)

    while True:
        ready = select.select([sys.stdin], [], [], None)
        if not ready[0]:
            continue
        chunk = os.read(sys.stdin.fileno(), 65536)
        if not chunk:
            break
        lines = chunk.decode("utf-8", errors="replace").splitlines()
        commands = []
        for line in lines:
            if not line.strip():
                continue
            try:
                commands.append(json.loads(line))
            except json.JSONDecodeError:
                commands.append({"__invalid__": True})
        for response in process_batch(cluster, commands):
            print(json.dumps(response, sort_keys=True, separators=(",", ":")), flush=True)


if __name__ == "__main__":
    main()
