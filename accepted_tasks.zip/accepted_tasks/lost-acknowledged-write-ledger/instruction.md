The ledger service is run with `python3 /app/service.py --data <dir> [--node <node>]`. It reads JSON commands, one per line: `append` with `request_id` and `quantity`, and `read`. An `append` response has `ok`, `status`, and `index`; a `read` response has `entries` and `total`.

Users have seen appends that report `ok=true` disappear after the service is killed and restarted, duplicate request IDs appear in the ledger, and a ledger total above the capacity limit of 10.

Fix the service so every `append` that returns `ok=true` is durable and appears exactly once after a restart. The same `request_id` must never produce a duplicate ledger entry. `read` must report the total of the distinct acknowledged entries, and the ledger total must never exceed 10. These must hold when a process is killed and restarted at any time.
