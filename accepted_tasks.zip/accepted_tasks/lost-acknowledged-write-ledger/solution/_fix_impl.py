from pathlib import Path
import os

cluster_code = '''from contextlib import contextmanager
from fcntl import LOCK_EX, LOCK_UN, flock
from pathlib import Path
from store import Store


class Cluster:
    """A small ledger front end."""

    NODE_IDS = ("alpha", "beta", "gamma")
    QUORUM = 2
    MAX_QUANTITY = 10

    def __init__(self, directory, node_id=None):
        self.directory = Path(directory)
        self.node_id = node_id
        self.stores = {
            node_id: Store(node_id, str(self.directory / node_id))
            for node_id in self.NODE_IDS
        }
        self.leader_id = None
        self.admitted = set()
        self._lock_file = open(self.directory / "ledger.lock", "a+")
        self._recover()
        if self.node_id is None:
            self.node_id = self.leader_id

    @contextmanager
    def _lock(self):
        flock(self._lock_file.fileno(), LOCK_EX)
        try:
            yield
        finally:
            flock(self._lock_file.fileno(), LOCK_UN)

    def _reload(self):
        for store in self.stores.values():
            store._load()

    def _all_entries(self):
        seen = set()
        entries = []
        for store in self.stores.values():
            for entry in store.committed_entries():
                idx = int(entry["index"])
                if idx not in seen:
                    seen.add(idx)
                    entries.append(entry)
            for entry in store.prepared_entries():
                idx = int(entry["index"])
                if idx not in seen:
                    seen.add(idx)
                    entries.append(entry)
        return entries

    def _committed_request(self, request_id):
        for entry in self._all_entries():
            if entry["request_id"] == request_id and entry["status"] == "committed":
                return entry
        return None

    def _pending_request(self, request_id):
        for entry in self._all_entries():
            if entry["request_id"] == request_id:
                return entry
        return None

    def _next_index(self):
        highest = 0
        for store in self.stores.values():
            for entry in store.committed_entries() + store.prepared_entries():
                highest = max(highest, int(entry["index"]))
        return highest + 1
'''
Path('/app/cluster.py').write_text(cluster_code)

cluster_code2 = '''    def _committed_entries(self):
        seen = {}
        for store in self.stores.values():
            for entry in store.committed_entries():
                idx = int(entry["index"])
                if idx not in seen:
                    seen[idx] = entry
        entries = sorted(seen.values(), key=lambda entry: (int(entry["index"]), entry["request_id"]))
        return entries

    def quantity_used(self):
        return sum(int(e["quantity"]) for e in self._committed_entries())

    def ledger(self):
        with self._lock():
            self._reload()
            return self._committed_entries()

    def append(self, request_id, quantity, admitted=False):
        request_id = str(request_id)
        quantity = int(quantity)
        if quantity <= 0:
            return {"ok": False, "status": "invalid_quantity"}

        with self._lock():
            self._reload()
            existing = self._committed_request(request_id)
            if existing is not None:
                return {
                    "ok": True,
                    "status": "already_applied",
                    "index": int(existing["index"]),
                }
            pending = self._pending_request(request_id)
            if pending is not None:
                return {
                    "ok": False,
                    "status": "request_pending",
                    "index": int(pending["index"]),
                }

            if self.quantity_used() + quantity > self.MAX_QUANTITY:
                return {"ok": False, "status": "over_capacity"}

            entry = {
                "index": self._next_index(),
                "request_id": request_id,
                "quantity": quantity,
                "status": "prepared",
            }
            replicas = []
            order = [self.node_id] + [n for n in self.NODE_IDS if n != self.node_id]
            for node_id in order:
                if self.stores[node_id].prepare(entry):
                    replicas.append(node_id)
                    if len(replicas) == self.QUORUM:
                        break

            if len(replicas) < self.QUORUM:
                return {"ok": False, "status": "unavailable"}

            for node_id in replicas:
                self.stores[node_id].commit(entry["index"])

            return {
                "ok": True,
                "status": "acknowledged",
                "index": int(entry["index"]),
                "replicas": replicas,
            }

    def _recover(self):
        with self._lock():
            self._reload()
            self.leader_id = min(
                self.NODE_IDS,
                key=lambda node_id: (-self.stores[node_id].highest_committed(), node_id),
            )
            durable_index = self.stores[self.leader_id].highest_committed()
            for store in self.stores.values():
                store.truncate_after(durable_index)

    def node_status(self):
        return self._committed_entries()

    def describe(self):
        return {
            "leader": self.leader_id,
            "committed": self.node_status(),
        }
'''
Path('/app/cluster.py').write_text(Path('/app/cluster.py').read_text() + cluster_code2)

service_code = '''import argparse
import json
import os
import select
import sys
from cluster import Cluster


def validate(command):
    if not isinstance(command, dict) or "__invalid__" in command:
        return {"ok": False, "error": "invalid_command"}
    operation = command.get("op")
    if operation == "append":
        if "request_id" not in command or "quantity" not in command:
            return {"ok": False, "error": "missing_fields"}
    elif operation == "read":
        return None
    else:
        return {"ok": False, "error": "unknown_operation"}
    return None


def process_batch(cluster, commands):
    responses = []
    for command in commands:
        invalid = validate(command)
        if invalid is not None:
            responses.append(invalid)
            continue

        if command.get("op") == "append":
            responses.append(cluster.append(
                command["request_id"],
                command["quantity"],
            ))
        else:
            entries = cluster.ledger()
            total = sum(int(e["quantity"]) for e in entries)
            responses.append({
                "ok": True,
                "entries": entries,
                "total": total,
            })

    return responses


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="/data")
    parser.add_argument("--node", choices=Cluster.NODE_IDS, default=None)
    args = parser.parse_args()

    os.makedirs(args.data, exist_ok=True)
    cluster = Cluster(args.data, args.node)

    while True:
        ready = select.select([sys.stdin], [], [], None)
        if not ready[0]:
            continue
        chunk = os.read(sys.stdin.fileno(), 65536)
        if not chunk:
            break
        lines = chunk.decode("utf-8", errors="replace").splitlines()
        commands = []
        for line in lines:
            if not line.strip():
                continue
            try:
                commands.append(json.loads(line))
            except json.JSONDecodeError:
                commands.append({"__invalid__": True})
        for response in process_batch(cluster, commands):
            print(json.dumps(response, sort_keys=True, separators=(",", ":")), flush=True)


if __name__ == "__main__":
    main()
'''
Path('/app/service.py').write_text(service_code)
