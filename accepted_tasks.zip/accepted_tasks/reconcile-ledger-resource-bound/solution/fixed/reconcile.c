#include "reconcile.h"

#include <stdio.h>
#include <stdlib.h>

int reconcile_files(const char *allocation_path, const char *observation_path,
                    const char *output_path)
{
    WinnerSet *winners = NULL;
    FinalState *states = NULL;
    size_t state_count = 0;

    if (process_observations(observation_path, &winners) != 0)
        return 1;
    if (build_states(allocation_path, winners, &states, &state_count) != 0) {
        destroy_winners(winners);
        return 1;
    }

    int result = write_report(output_path, states, state_count);
    free(states);
    destroy_winners(winners);
    return result == 0 ? 0 : 1;
}

int main(int argc, char **argv)
{
    if (argc != 4) {
        fprintf(stderr, "usage: reconcile ALLOCATIONS OBSERVATIONS OUTPUT\n");
        return 2;
    }

    return reconcile_files(argv[1], argv[2], argv[3]);
}
