#define _POSIX_C_SOURCE 200809L
#include "reconcile.h"

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int compare_states(const void *left_ptr, const void *right_ptr)
{
    const FinalState *left = left_ptr;
    const FinalState *right = right_ptr;

    if (left->event_id < right->event_id)
        return -1;
    if (left->event_id > right->event_id)
        return 1;
    if (left->ordinal < right->ordinal)
        return -1;
    if (left->ordinal > right->ordinal)
        return 1;
    return strcmp(left->allocation_id, right->allocation_id);
}

static char *temporary_path(const char *path)
{
    const char *slash = strrchr(path, '/');
    size_t prefix = slash ? (size_t)(slash - path) + 1 : 0;
    size_t length = strlen(path) - prefix;
    char *temporary = malloc(prefix + length + sizeof(".report-XXXXXX"));
    if (!temporary)
        return NULL;
    if (prefix != 0)
        memcpy(temporary, path, prefix);
    memcpy(temporary + prefix, ".report-XXXXXX", sizeof(".report-XXXXXX"));
    return temporary;
}

int write_report(const char *path, FinalState *states, size_t count)
{
    char *temporary = temporary_path(path);
    if (!temporary) {
        fprintf(stderr, "cannot prepare report\n");
        return -1;
    }

    int descriptor = mkstemp(temporary);
    if (descriptor < 0) {
        fprintf(stderr, "cannot create report: %s\n", temporary);
        free(temporary);
        return -1;
    }

    FILE *file = fdopen(descriptor, "w");
    if (!file) {
        fprintf(stderr, "cannot open report: %s\n", temporary);
        close(descriptor);
        unlink(temporary);
        free(temporary);
        return -1;
    }

    qsort(states, count, sizeof(*states), compare_states);
    for (size_t i = 0; i < count; ++i) {
        const FinalState *state = &states[i];
        if (fprintf(file, "%s\t%s\t%llu\t%u\t%llu\n",
                    state->allocation_id, state->owner,
                    (unsigned long long)state->capacity, state->used,
                    (unsigned long long)state->event_id) < 0) {
            fprintf(stderr, "cannot write report\n");
            fclose(file);
            unlink(temporary);
            free(temporary);
            return -1;
        }
    }

    if (fflush(file) != 0 || fsync(descriptor) != 0 || fclose(file) != 0) {
        fprintf(stderr, "cannot finish report\n");
        unlink(temporary);
        free(temporary);
        return -1;
    }

    if (rename(temporary, path) != 0) {
        fprintf(stderr, "cannot replace report: %s\n", path);
        unlink(temporary);
        free(temporary);
        return -1;
    }

    free(temporary);
    return 0;
}
