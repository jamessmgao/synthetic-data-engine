#define _POSIX_C_SOURCE 200809L
#include "reconcile.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    unsigned char occupied;
    char id[96];
    uint64_t event_id;
    uint32_t used;
    size_t ordinal;
} WinnerEntry;

struct WinnerSet {
    WinnerEntry *slots;
    size_t capacity;
    size_t count;
};

static size_t hash_id(const char *id)
{
    size_t hash = 1469598103934665603ULL;
    for (const unsigned char *p = (const unsigned char *)id; *p; ++p) {
        hash ^= *p;
        hash *= 1099511628211ULL;
    }
    return hash;
}

static int reserve_winners(WinnerSet *set)
{
    if (set->count * 10 < set->capacity * 7)
        return 0;

    size_t next = set->capacity ? set->capacity * 2 : 1024;
    WinnerEntry *grown = calloc(next, sizeof(*grown));
    if (!grown) {
        fprintf(stderr, "winner store is unavailable\n");
        return -1;
    }

    for (size_t i = 0; i < set->capacity; ++i) {
        if (!set->slots[i].occupied)
            continue;
        size_t slot = hash_id(set->slots[i].id) & (next - 1);
        while (grown[slot].occupied)
            slot = (slot + 1) & (next - 1);
        grown[slot] = set->slots[i];
    }

    free(set->slots);
    set->slots = grown;
    set->capacity = next;
    return 0;
}

static WinnerEntry *find_winner(WinnerSet *set, const char *id)
{
    if (set->capacity == 0)
        return NULL;
    size_t slot = hash_id(id) & (set->capacity - 1);
    while (set->slots[slot].occupied) {
        if (strcmp(set->slots[slot].id, id) == 0)
            return &set->slots[slot];
        slot = (slot + 1) & (set->capacity - 1);
    }
    return NULL;
}

static int add_winner(WinnerSet *set, const char *id, uint64_t event_id,
                      uint32_t used, size_t ordinal)
{
    if (reserve_winners(set) != 0)
        return -1;

    WinnerEntry *entry = find_winner(set, id);
    if (entry) {
        if (event_id > entry->event_id ||
            (event_id == entry->event_id && ordinal < entry->ordinal)) {
            entry->event_id = event_id;
            entry->used = used;
            entry->ordinal = ordinal;
        }
        return 0;
    }

    size_t slot = hash_id(id) & (set->capacity - 1);
    while (set->slots[slot].occupied)
        slot = (slot + 1) & (set->capacity - 1);
    WinnerEntry *fresh = &set->slots[slot];
    fresh->occupied = 1;
    strcpy(fresh->id, id);
    fresh->event_id = event_id;
    fresh->used = used;
    fresh->ordinal = ordinal;
    ++set->count;
    return 0;
}

int process_observations(const char *path, WinnerSet **out)
{
    FILE *file = fopen(path, "r");
    if (!file) {
        fprintf(stderr, "cannot open observations: %s\n", path);
        return -1;
    }

    WinnerSet *set = calloc(1, sizeof(*set));
    if (!set) {
        fprintf(stderr, "winner store is unavailable\n");
        fclose(file);
        return -1;
    }

    char *line = NULL;
    size_t line_size = 0;
    size_t ordinal = 0;
    while (getline(&line, &line_size, file) != -1) {
        char id[96];
        unsigned long long event;
        unsigned long used;
        if (sscanf(line, "%95s %llu %lu", id, &event, &used) != 3) {
            fprintf(stderr, "invalid observation record\n");
            goto failed;
        }
        if (add_winner(set, id, (uint64_t)event, (uint32_t)used,
                       ordinal++) != 0)
            goto failed;
    }

    free(line);
    fclose(file);
    *out = set;
    return 0;

failed:
    free(line);
    fclose(file);
    destroy_winners(set);
    return -1;
}

int build_states(const char *path, WinnerSet *winners,
                 FinalState **out, size_t *count)
{
    FILE *file = fopen(path, "r");
    if (!file) {
        fprintf(stderr, "cannot open allocations: %s\n", path);
        return -1;
    }

    FinalState *states = NULL;
    size_t used = 0;
    size_t capacity = 0;
    char *line = NULL;
    size_t line_size = 0;

    while (getline(&line, &line_size, file) != -1) {
        char id[96];
        char owner[96];
        unsigned long long capacity_value;
        if (sscanf(line, "%95s %95s %llu", id, owner, &capacity_value) != 3) {
            fprintf(stderr, "invalid allocation record\n");
            goto failed;
        }

        WinnerEntry *winner = find_winner(winners, id);
        if (!winner)
            continue;

        if (used == capacity) {
            size_t next = capacity ? capacity * 2 : 64;
            FinalState *grown = realloc(states, next * sizeof(*states));
            if (!grown) {
                fprintf(stderr, "state store is unavailable\n");
                goto failed;
            }
            states = grown;
            capacity = next;
        }

        FinalState *state = &states[used++];
        strcpy(state->allocation_id, id);
        strcpy(state->owner, owner);
        state->capacity = (uint64_t)capacity_value;
        state->event_id = winner->event_id;
        state->used = winner->used;
        state->ordinal = winner->ordinal;
    }

    free(line);
    fclose(file);
    *out = states;
    *count = used;
    return 0;

failed:
    free(line);
    free(states);
    fclose(file);
    return -1;
}

void destroy_winners(WinnerSet *winners)
{
    if (!winners)
        return;
    free(winners->slots);
    free(winners);
}
