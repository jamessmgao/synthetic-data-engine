#ifndef RECONCILE_H
#define RECONCILE_H

#include <stddef.h>
#include <stdint.h>

typedef struct WinnerSet WinnerSet;

typedef struct {
    char allocation_id[96];
    char owner[96];
    uint64_t capacity;
    uint64_t event_id;
    uint32_t used;
    size_t ordinal;
} FinalState;

int process_observations(const char *path, WinnerSet **out);
int build_states(const char *path, WinnerSet *winners,
                 FinalState **out, size_t *count);
void destroy_winners(WinnerSet *winners);
int write_report(const char *path, FinalState *states, size_t count);
int reconcile_files(const char *allocation_path, const char *observation_path,
                    const char *output_path);

#endif
