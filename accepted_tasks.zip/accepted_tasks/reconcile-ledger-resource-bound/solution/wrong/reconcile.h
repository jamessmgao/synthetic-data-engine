#ifndef RECONCILE_H
#define RECONCILE_H

#include <stddef.h>
#include <stdint.h>

typedef struct RecordIndex RecordIndex;

typedef struct {
    char allocation_id[96];
    char owner[96];
    uint64_t capacity;
    uint64_t event_id;
    uint32_t used;
    size_t ordinal;
} FinalState;

int index_allocations(const char *path, RecordIndex **out);
int process_observations(const char *path, RecordIndex *index);
int build_states(const char *path, RecordIndex *index,
                 FinalState **out, size_t *count);
void destroy_index(RecordIndex *index);
int write_report(const char *path, FinalState *states, size_t count);
int reconcile_files(const char *allocation_path, const char *observation_path,
                    const char *output_path);

#endif
