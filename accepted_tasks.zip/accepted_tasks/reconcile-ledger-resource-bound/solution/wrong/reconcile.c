#include "reconcile.h"

#include <stdlib.h>

int reconcile_files(const char *allocation_path, const char *observation_path,
                    const char *output_path)
{
    RecordIndex *index = NULL;
    FinalState *states = NULL;
    size_t state_count = 0;

    if (index_allocations(allocation_path, &index) != 0)
        return 1;
    if (process_observations(observation_path, index) != 0) {
        destroy_index(index);
        return 1;
    }
    if (build_states(allocation_path, index, &states, &state_count) != 0) {
        destroy_index(index);
        return 1;
    }

    int result = write_report(output_path, states, state_count);
    free(states);
    destroy_index(index);
    return result == 0 ? 0 : 1;
}

int main(int argc, char **argv)
{
    if (argc != 4)
        return 2;
    return reconcile_files(argv[1], argv[2], argv[3]);
}
