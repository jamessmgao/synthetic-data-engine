#define _POSIX_C_SOURCE 200809L
#include "reconcile.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    unsigned char occupied;
    unsigned char has_winner;
    char id[96];
    uint64_t event_id;
    uint32_t used;
    size_t ordinal;
} IndexEntry;

struct RecordIndex {
    IndexEntry *slots;
    size_t capacity;
    size_t count;
};

static size_t hash_id(const char *id)
{
    size_t hash = 1469598103934665603ULL;
    for (const unsigned char *p = (const unsigned char *)id; *p; ++p) {
        hash ^= *p;
        hash *= 1099511628211ULL;
    }
    return hash;
}

static int reserve_index(RecordIndex *index)
{
    if (index->count * 10 < index->capacity * 7)
        return 0;

    size_t next = index->capacity ? index->capacity * 2 : 1024;
    IndexEntry *grown = calloc(next, sizeof(*grown));
    if (!grown) {
        fprintf(stderr, "record index is unavailable\n");
        return -1;
    }
    for (size_t i = 0; i < index->capacity; ++i) {
        if (!index->slots[i].occupied)
            continue;
        size_t slot = hash_id(index->slots[i].id) & (next - 1);
        while (grown[slot].occupied)
            slot = (slot + 1) & (next - 1);
        grown[slot] = index->slots[i];
    }
    free(index->slots);
    index->slots = grown;
    index->capacity = next;
    return 0;
}

static IndexEntry *find_entry(RecordIndex *index, const char *id)
{
    if (index->capacity == 0)
        return NULL;
    size_t slot = hash_id(id) & (index->capacity - 1);
    while (index->slots[slot].occupied) {
        if (strcmp(index->slots[slot].id, id) == 0)
            return &index->slots[slot];
        slot = (slot + 1) & (index->capacity - 1);
    }
    return NULL;
}

int index_allocations(const char *path, RecordIndex **out)
{
    FILE *file = fopen(path, "r");
    if (!file) {
        fprintf(stderr, "cannot open allocations: %s\n", path);
        return -1;
    }

    RecordIndex *index = calloc(1, sizeof(*index));
    if (!index) {
        fprintf(stderr, "record index is unavailable\n");
        fclose(file);
        return -1;
    }

    char *line = NULL;
    size_t line_size = 0;
    while (getline(&line, &line_size, file) != -1) {
        char id[96];
        char owner[96];
        unsigned long long capacity_value;
        if (sscanf(line, "%95s %95s %llu", id, owner,
                   &capacity_value) != 3) {
            fprintf(stderr, "invalid allocation record\n");
            goto failed;
        }
        if (reserve_index(index) != 0)
            goto failed;
        IndexEntry *entry = find_entry(index, id);
        if (entry)
            continue;
        size_t slot = hash_id(id) & (index->capacity - 1);
        while (index->slots[slot].occupied)
            slot = (slot + 1) & (index->capacity - 1);
        IndexEntry *fresh = &index->slots[slot];
        fresh->occupied = 1;
        strcpy(fresh->id, id);
        ++index->count;
    }

    free(line);
    fclose(file);
    *out = index;
    return 0;

failed:
    free(line);
    fclose(file);
    destroy_index(index);
    return -1;
}

int process_observations(const char *path, RecordIndex *index)
{
    FILE *file = fopen(path, "r");
    if (!file) {
        fprintf(stderr, "cannot open observations: %s\n", path);
        return -1;
    }

    char *line = NULL;
    size_t line_size = 0;
    size_t ordinal = 0;
    while (getline(&line, &line_size, file) != -1) {
        char id[96];
        unsigned long long event;
        unsigned long used;
        if (sscanf(line, "%95s %llu %lu", id, &event, &used) != 3) {
            fprintf(stderr, "invalid observation record\n");
            goto failed;
        }
        IndexEntry *entry = find_entry(index, id);
        if (entry && (!entry->has_winner || event > entry->event_id ||
                      (event == entry->event_id && ordinal < entry->ordinal))) {
            entry->has_winner = 1;
            entry->event_id = (uint64_t)event;
            entry->used = (uint32_t)used;
            entry->ordinal = ordinal;
        }
        ++ordinal;
    }

    free(line);
    fclose(file);
    return 0;

failed:
    free(line);
    fclose(file);
    return -1;
}

int build_states(const char *path, RecordIndex *index,
                 FinalState **out, size_t *count)
{
    FILE *file = fopen(path, "r");
    if (!file) {
        fprintf(stderr, "cannot open allocations: %s\n", path);
        return -1;
    }

    FinalState *states = NULL;
    size_t used = 0;
    size_t capacity = 0;
    char *line = NULL;
    size_t line_size = 0;
    while (getline(&line, &line_size, file) != -1) {
        char id[96];
        char owner[96];
        unsigned long long capacity_value;
        if (sscanf(line, "%95s %95s %llu", id, owner,
                   &capacity_value) != 3) {
            fprintf(stderr, "invalid allocation record\n");
            goto failed;
        }
        IndexEntry *entry = find_entry(index, id);
        if (!entry || !entry->has_winner)
            continue;
        if (used == capacity) {
            size_t next = capacity ? capacity * 2 : 64;
            FinalState *grown = realloc(states, next * sizeof(*states));
            if (!grown) {
                fprintf(stderr, "state store is unavailable\n");
                goto failed;
            }
            states = grown;
            capacity = next;
        }
        FinalState *state = &states[used++];
        strcpy(state->allocation_id, id);
        strcpy(state->owner, owner);
        state->capacity = (uint64_t)capacity_value;
        state->event_id = entry->event_id;
        state->used = entry->used;
        state->ordinal = entry->ordinal;
    }

    free(line);
    fclose(file);
    *out = states;
    *count = used;
    return 0;

failed:
    free(line);
    free(states);
    fclose(file);
    return -1;
}

void destroy_index(RecordIndex *index)
{
    if (!index)
        return;
    free(index->slots);
    free(index);
}
