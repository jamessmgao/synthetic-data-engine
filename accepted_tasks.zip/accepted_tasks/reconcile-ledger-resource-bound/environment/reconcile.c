#include "reconcile.h"

#include <stdio.h>
#include <stdlib.h>

int reconcile_files(const char *allocation_path, const char *observation_path,
                    const char *output_path)
{
    Allocation *allocations = NULL;
    Observation *observations = NULL;
    FinalState *states = NULL;
    size_t allocation_count = 0;
    size_t observation_count = 0;
    size_t state_count = 0;

    if (load_allocations(allocation_path, &allocations, &allocation_count) != 0)
        return 1;
    if (load_observations(observation_path, &observations, &observation_count) != 0) {
        free(allocations);
        return 1;
    }
    if (select_final_states(allocations, allocation_count, observations,
                            observation_count, &states, &state_count) != 0) {
        free(allocations);
        free(observations);
        return 1;
    }

    int result = write_report(output_path, states, state_count) == 0 ? 0 : 1;
    free(states);
    free(observations);
    free(allocations);
    return result;
}

int main(int argc, char **argv)
{
    if (argc != 4) {
        fprintf(stderr, "usage: reconcile ALLOCATIONS OBSERVATIONS OUTPUT\n");
        return 2;
    }

    return reconcile_files(argv[1], argv[2], argv[3]);
}
