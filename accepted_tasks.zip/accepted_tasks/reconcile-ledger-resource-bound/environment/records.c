#define _POSIX_C_SOURCE 200809L
#include "reconcile.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int reserve(void **ptr, size_t used, size_t *capacity, size_t width)
{
    if (used < *capacity)
        return 0;

    size_t next = *capacity ? *capacity * 2 : 64;
    while (next <= used)
        next *= 2;

    void *grown = realloc(*ptr, next * width);
    if (!grown) {
        fprintf(stderr, "allocation store is unavailable\n");
        return -1;
    }

    *ptr = grown;
    *capacity = next;
    return 0;
}

int load_allocations(const char *path, Allocation **out, size_t *count)
{
    FILE *file = fopen(path, "r");
    if (!file) {
        fprintf(stderr, "cannot open allocations: %s\n", path);
        return -1;
    }

    Allocation *records = NULL;
    size_t used = 0;
    size_t capacity = 0;
    char *line = NULL;
    size_t line_size = 0;
    ssize_t length;

    while ((length = getline(&line, &line_size, file)) != -1) {
        Allocation record;
        unsigned long long capacity_value;

        if (sscanf(line, "%95s %95s %llu",
                   record.id, record.owner, &capacity_value) != 3) {
            fprintf(stderr, "invalid allocation record\n");
            goto failed;
        }
        record.capacity = (uint64_t)capacity_value;

        if (reserve((void **)&records, used, &capacity, sizeof(*records)) != 0)
            goto failed;
        records[used++] = record;
    }

    free(line);
    fclose(file);
    *out = records;
    *count = used;
    return 0;

failed:
    free(line);
    free(records);
    fclose(file);
    return -1;
}

int load_observations(const char *path, Observation **out, size_t *count)
{
    FILE *file = fopen(path, "r");
    if (!file) {
        fprintf(stderr, "cannot open observations: %s\n", path);
        return -1;
    }

    Observation *records = NULL;
    size_t used = 0;
    size_t capacity = 0;
    char *line = NULL;
    size_t line_size = 0;
    ssize_t length;

    while ((length = getline(&line, &line_size, file)) != -1) {
        Observation record;
        unsigned long long event;
        unsigned long used_value;

        if (sscanf(line, "%95s %llu %lu",
                   record.allocation_id, &event, &used_value) != 3) {
            fprintf(stderr, "invalid observation record\n");
            goto failed;
        }
        record.event_id = (uint64_t)event;
        record.used = (uint32_t)used_value;
        record.ordinal = used;

        if (reserve((void **)&records, used, &capacity, sizeof(*records)) != 0)
            goto failed;
        records[used++] = record;
    }

    free(line);
    fclose(file);
    *out = records;
    *count = used;
    return 0;

failed:
    free(line);
    free(records);
    fclose(file);
    return -1;
}

int select_final_states(const Allocation *allocations, size_t allocation_count,
                        const Observation *observations, size_t observation_count,
                        FinalState **out, size_t *count)
{
    FinalState *states = calloc(allocation_count, sizeof(*states));
    if (!states && allocation_count != 0) {
        fprintf(stderr, "state store is unavailable\n");
        return -1;
    }

    size_t selected = 0;
    for (size_t i = 0; i < allocation_count; ++i) {
        const Observation *winner = NULL;

        for (size_t j = 0; j < observation_count; ++j) {
            const Observation *candidate = &observations[j];
            if (strcmp(allocations[i].id, candidate->allocation_id) != 0)
                continue;

            if (!winner || candidate->event_id > winner->event_id ||
                (candidate->event_id == winner->event_id &&
                 candidate->ordinal < winner->ordinal))
                winner = candidate;
        }

        if (!winner)
            continue;

        FinalState *state = &states[selected++];
        memcpy(state->allocation_id, allocations[i].id, sizeof(state->allocation_id));
        memcpy(state->owner, allocations[i].owner, sizeof(state->owner));
        state->capacity = allocations[i].capacity;
        state->event_id = winner->event_id;
        state->used = winner->used;
        state->ordinal = winner->ordinal;
    }

    *out = states;
    *count = selected;
    return 0;
}
