#include "reconcile.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int compare_states(const void *left_ptr, const void *right_ptr)
{
    const FinalState *left = left_ptr;
    const FinalState *right = right_ptr;

    if (left->event_id < right->event_id)
        return -1;
    if (left->event_id > right->event_id)
        return 1;
    if (left->ordinal < right->ordinal)
        return -1;
    if (left->ordinal > right->ordinal)
        return 1;
    return strcmp(left->allocation_id, right->allocation_id);
}

int write_report(const char *path, FinalState *states, size_t count)
{
    FILE *file = fopen(path, "w");
    if (!file) {
        fprintf(stderr, "cannot open report: %s\n", path);
        return -1;
    }

    qsort(states, count, sizeof(*states), compare_states);

    for (size_t i = 0; i < count; ++i) {
        const FinalState *state = &states[i];
        if (fprintf(file, "%s\t%s\t%llu\t%u\t%llu\n",
                    state->allocation_id, state->owner,
                    (unsigned long long)state->capacity, state->used,
                    (unsigned long long)state->event_id) < 0) {
            fprintf(stderr, "cannot write report\n");
            fclose(file);
            return -1;
        }
    }

    if (fclose(file) != 0) {
        fprintf(stderr, "cannot finish report\n");
        return -1;
    }

    return 0;
}
