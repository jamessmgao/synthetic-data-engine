# Resource-bounded once-only ledger reconciliation

A reconciliation command must turn millions of allocation and observation records into the exact final-state report while inputs may be readable only once and output publication may be concurrent.

## Scenario

The installed C command works on small regular-file ledgers but cannot deliver the production report within the stated time and memory envelope. The production ledgers are large, may arrive through FIFO streams, and several commands can publish the same report path.

## Root cause (hidden from the agent)

The starting implementation materializes both full ledgers and selects winners with an allocation-by-allocation scan, producing quadratic work and excessive peak memory. Report publication also truncates and writes the destination directly, exposing partial records to concurrent readers.

## Correctness constraints

- **C1**: Each allocation's reported final state uses the observation with the highest event_id; among observations with equal event_id, the one appearing earliest in the observation file wins.
- **C2**: The report lists all observed allocations sorted by final event_id ascending, then by original observation position ascending.
- **C3**: When either input is a non-seekable stream that can be read exactly once, the command produces the same correct report without reopening or seeking either input, within the production time and memory budgets.
- **C4**: Concurrent commands publishing to the same report path never expose a partial record, the final report is correct, and a killed command can be rerun without leaving partial output.
- **C5**: The installed command keeps its three-path interface, accepts the documented tab-separated allocation and observation records, and emits the exact five-column report format for regular files, including empty and unobserved cases.

## Subgoals

1. Replace the quadratic selection and full-ledger retention with bounded single-pass state tracking.
2. Preserve the highest-event and earliest-tie winner rule exactly.
3. Produce the required report ordering and byte-identical rows for regular and once-only stream inputs.
4. Publish reports atomically so concurrent readers and reruns after a process kill never see partial data.

## Failure scenario

The production case has 200,000 allocations and 2,000,000 observations, including tied final events. Both inputs are supplied through FIFOs under a 256 MiB virtual-memory limit, and the report is compared with independently derived rows. The same report path is then written concurrently while a reader checks that only complete reports are visible.

## Expected agent pitfalls

- Indexing allocations and then reopening the allocation path fails when that path is a once-only FIFO.
- Dropping the observation ordinal breaks the required tie ordering.
- Retaining all observations or all allocation rows exceeds the production memory budget.
- Writing the report directly rather than atomically replacing it exposes partial rows to concurrent readers.

## Anti-shortcut measures

- Tests independently derive expected winners and ordering rather than trusting the implementation.
- Fixed-seed cases cover tied maximum events, unobserved allocations, unknown observations, both FIFO input combinations, kill-and-retry behavior, and concurrent publication.
- The exact production workload runs under the production memory and timeout limits.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_highest_event_and_earliest_tied_observation_wins` |
| C2 | `test_all_observed_allocations_are_in_event_and_position_order` |
| C3 | `test_once_only_non_seekable_inputs_produce_the_same_report`, `test_production_counterexample_with_fifo_and_concurrent_publishing` |
| C4 | `test_concurrent_publishers_never_expose_a_partial_record`, `test_killed_command_can_be_rerun_without_partial_output`, `test_production_counterexample_with_fifo_and_concurrent_publishing` |
| C5 | `test_exact_regression_and_edge_cases` |
