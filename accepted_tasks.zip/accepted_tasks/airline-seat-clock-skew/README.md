# Airline seat check-in lost under clock skew

A replicated airline seat service uses last-writer-wins merge based on timestamps. When nodes have skewed clocks, a cancel operation from a skewed node can override a check-in, making the seat appear available and losing the passenger from the boarding manifest.

## Scenario

The airline seat service runs on multiple regional nodes that replicate seat and manifest state. Nodes timestamp operations with their local clock, which may be skewed. Last-writer-wins merge compares timestamps naively.

## Root cause (hidden from the agent)

Both SeatStore.merge_record and BoardingManifest.merge_entry use pure timestamp-based last-writer-wins. A node with a skewed clock can assign a higher timestamp to a cancel operation than a prior check-in, causing the check-in to be dropped during merge in both the seat store and the boarding manifest.

## Correctness constraints

- **C1**: Once a seat has been checked in, every converged node must report it as checked_in with the correct passenger
- **C2**: After a checked-in seat, every converged node must report the correct passenger in the boarding manifest

## Subgoals

1. Fix seat store merge to protect checked_in status
2. Fix manifest merge to preserve passenger assignment
3. Ensure cancel of available seat still works
4. Ensure normal reserve/check-in/cancel flow without skew is preserved

## Failure scenario

Node B has +100 clock skew. After A checks in seat 1A, B cancels from its stale reserved state with a skewed timestamp. During replication, B's cancel (ts=120) beats A's check-in (ts=10) via LWW, making seat 1A available on B and losing the passenger from the manifest.

## Expected agent pitfalls

- Fixing only the seat store merge without fixing the manifest merge
- Using version-based merge without considering that cancel also increments version
- Adding a status-order guard to seat_store but leaving manifest on pure LWW

## Anti-shortcut measures

- Tests check both seat status and manifest passenger on every node
- Random scenarios with varying skew expose the issue in both components
- The counterexample test checks both invariants on all nodes

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_checked_in_seat_visible_after_convergence`, `test_counterexample_repro`, `test_basic_reserve_checkin_no_skew`, `test_multiple_seats_convergence`, `test_cancel_then_reserve_different_passenger`, `test_skew_check_in_preserved_across_nodes` |
| C2 | `test_manifest_passenger_after_check_in`, `test_counterexample_repro`, `test_basic_reserve_checkin_no_skew`, `test_cancel_then_reserve_different_passenger`, `test_skew_check_in_preserved_across_nodes` |
