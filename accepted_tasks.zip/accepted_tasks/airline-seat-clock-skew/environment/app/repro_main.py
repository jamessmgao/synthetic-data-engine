import json, sys
from service import run_sequence

def check(results, symptom_only=False):
    state = results["state"]
    nodes_to_check = ["C"] if symptom_only else list(state.keys())
    violated = False
    for node_id in nodes_to_check:
        node_data = state[node_id]
        seats = node_data.get("seats", node_data)
        seat = seats.get("1A")
        if seat and seat["status"] != "checked_in":
            print(f"INVARIANT VIOLATED on {node_id}: "
                  f"seat 1A is {seat['status']} "
                  f"(passenger={seat['passenger']}) "
                  f"but should be checked_in (Alice)",
                  file=sys.stderr)
            violated = True
        if not symptom_only:
            manifest = node_data.get("manifest", {})
            entry = manifest.get("1A")
            if entry and entry.get("passenger") != "Alice":
                print(f"INVARIANT VIOLATED on {node_id}: "
                      f"manifest for 1A shows passenger={entry.get('passenger')} "
                      f"but should be Alice",
                      file=sys.stderr)
                violated = True
    return not violated

if __name__ == "__main__":
    symptom = "--symptom" in sys.argv
    args = [a for a in sys.argv[1:] if a != "--symptom"]
    seq = args[0] if args else "/world/repro/sequence.json"
    results = run_sequence(seq)
    if not check(results, symptom):
        sys.exit(1)
    sys.exit(0)
