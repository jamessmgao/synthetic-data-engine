"""Airline seat map and check-in service.

A cluster is made up of regional service nodes.  Each node owns a local
seat store and boarding manifest; the cluster driver executes one request
at a time and copies records between nodes on demand.
"""

import argparse
import json

from clock import ControlledClock
from seat_store import SeatStore
from manifest import BoardingManifest


class SeatService:
    """Local API for one regional service node."""

    def __init__(self, node_id, clock):
        self.node_id = node_id
        self.clock = clock
        self.store = SeatStore(clock)
        self.manifest = BoardingManifest(clock)

    def reserve(self, seat_id, passenger):
        result = self.store.reserve(seat_id, passenger)
        self.manifest.add(seat_id, passenger)
        return result

    def check_in(self, seat_id):
        result = self.store.check_in(seat_id)
        rec = self.store.get(seat_id)
        self.manifest.add(seat_id, rec.passenger)
        return result

    def cancel(self, seat_id):
        result = self.store.cancel(seat_id)
        self.manifest.remove(seat_id)
        return result

    def seat(self, seat_id):
        return self.store.get(seat_id)

    def seats(self):
        return self.store.list_seats()


class SeatCluster:
    """Deterministic driver for a small group of service nodes."""

    def __init__(self, node_specs=None):
        if node_specs is None:
            node_specs = [
                {"id": "A", "skew": 0},
                {"id": "B", "skew": 0},
                {"id": "C", "skew": 0},
            ]
        self.nodes = {}
        for spec in node_specs:
            node_id = spec["id"]
            if node_id in self.nodes:
                raise ValueError(f"duplicate node id {node_id}")
            clock = ControlledClock(skew=spec.get("skew", 0))
            self.nodes[node_id] = SeatService(node_id, clock)

    def advance(self, dt):
        for service in self.nodes.values():
            service.clock.advance(dt)

    def perform(self, node_id, action, seat_id, passenger=None):
        service = self.nodes[node_id]
        if action == "reserve":
            if passenger is None:
                raise ValueError("reserve requires a passenger")
            return service.reserve(seat_id, passenger)
        if action == "check_in":
            return service.check_in(seat_id)
        if action == "cancel":
            return service.cancel(seat_id)
        raise ValueError(f"unknown seat action {action}")

    def replicate(self, source_id, target_id):
        if source_id == target_id:
            return
        source = self.nodes[source_id]
        target = self.nodes[target_id]
        for record in source.store.snapshot():
            target.store.merge_record(record)
        for entry in source.manifest.snapshot():
            target.manifest.merge_entry(entry)

    def state(self):
        result = {}
        for node_id, service in self.nodes.items():
            seats = {}
            for record in service.seats():
                seats[record.seat_id] = {
                    "status": record.status,
                    "passenger": record.passenger,
                    "version": record.version,
                    "ts": record.ts,
                }
            manifest = {}
            for entry in service.manifest.list_entries():
                manifest[entry.seat_id] = {
                    "passenger": entry.passenger,
                    "version": entry.version,
                    "ts": entry.ts,
                }
            result[node_id] = {"seats": seats, "manifest": manifest}
        return result


def _run_step(cluster, step):
    action = step["op"]
    if action == "advance":
        cluster.advance(step["dt"])
        return
    if action == "seat":
        cluster.perform(
            step["node"], step["action"], step["seat"],
            step.get("passenger"),
        )
        return
    if action == "replicate":
        cluster.replicate(step["from"], step["to"])
        return
    if action == "observe":
        return
    raise ValueError(f"unknown sequence operation {action}")


def run_sequence(path):
    with open(path, encoding="utf-8") as handle:
        document = json.load(handle)
    cluster = SeatCluster(document.get("nodes"))
    for step in document.get("steps", []):
        _run_step(cluster, step)
    return {
        "nodes": list(cluster.nodes),
        "state": cluster.state(),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sequence", required=True)
    args = parser.parse_args()
    print(json.dumps(run_sequence(args.sequence), sort_keys=True))


if __name__ == "__main__":
    main()
