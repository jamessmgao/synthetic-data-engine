"""Clock abstractions for the airline seat service.

Nodes timestamp every seat-map write with their local clock.
Replication compares these timestamps with last-writer-wins.
"""


class Clock:
    """Base clock interface returning integer timestamps."""

    def now(self):
        raise NotImplementedError


class ControlledClock(Clock):
    """Deterministic clock for reproducible tests.

    Time advances only when advance() is called explicitly.
    An optional skew offset shifts all reads, simulating a
    desynchronized wall clock.
    """

    def __init__(self, skew=0):
        self._time = 0
        self._skew = skew

    def advance(self, dt):
        if dt < 0:
            raise ValueError("cannot advance backwards")
        self._time += dt

    def now(self):
        return self._time + self._skew
