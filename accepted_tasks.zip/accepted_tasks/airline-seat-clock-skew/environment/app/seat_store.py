"""Seat data store with last-writer-wins replication.

Each seat record carries a version counter and a timestamp.
"""

from clock import Clock


class SeatRecord:
    """Immutable snapshot of a seat's state."""

    __slots__ = ("seat_id", "status", "passenger", "version", "ts")

    def __init__(self, seat_id, status="available", passenger=None,
                 version=0, ts=0):
        self.seat_id = seat_id
        self.status = status
        self.passenger = passenger
        self.version = version
        self.ts = ts

    def copy(self, **overrides):
        kw = {s: getattr(self, s) for s in self.__slots__}
        kw.update(overrides)
        return SeatRecord(**kw)


class SeatStore:
    """Local seat store with last-writer-wins merge.

    Updates originating locally increment the version counter and
    take a timestamp from the provided Clock.  Replication applies
    incoming records via merge_record.
    """

    def __init__(self, clock: Clock):
        self._clock = clock
        self._seats: dict[str, SeatRecord] = {}

    # -- local reads ------------------------------------------------

    def get(self, seat_id: str) -> SeatRecord:
        return self._seats.get(seat_id,
                               SeatRecord(seat_id))

    def list_seats(self) -> list[SeatRecord]:
        return list(self._seats.values())

    # -- local writes -----------------------------------------------

    def _put(self, seat_id: str, status: str, passenger,
             base: SeatRecord | None = None) -> SeatRecord:
        if base is None:
            base = self.get(seat_id)
        rec = base.copy(
            status=status,
            passenger=passenger,
            version=base.version + 1,
            ts=self._clock.now(),
        )
        self._seats[seat_id] = rec
        return rec

    def reserve(self, seat_id: str, passenger: str) -> SeatRecord:
        cur = self.get(seat_id)
        if cur.status != "available":
            raise ValueError(
                f"seat {seat_id} is {cur.status}, cannot reserve")
        return self._put(seat_id, "reserved", passenger)

    def check_in(self, seat_id: str) -> SeatRecord:
        cur = self.get(seat_id)
        if cur.status != "reserved":
            raise ValueError(
                f"seat {seat_id} is {cur.status}, cannot check in")
        return self._put(seat_id, "checked_in", cur.passenger)

    def cancel(self, seat_id: str) -> SeatRecord:
        cur = self.get(seat_id)
        if cur.status not in ("reserved", "available"):
            raise ValueError(
                f"seat {seat_id} is {cur.status}, cannot cancel")
        return self._put(seat_id, "available", None)

    # -- replication ------------------------------------------------

    def merge_record(self, incoming: SeatRecord):
        """Apply an incoming replicated record (last-writer-wins)."""
        local = self.get(incoming.seat_id)
        if incoming.ts > local.ts:
            self._seats[incoming.seat_id] = incoming
        elif incoming.ts == local.ts and incoming.version > local.version:
            self._seats[incoming.seat_id] = incoming

    def merge_store(self, other: "SeatStore"):
        """Pull every record from *other* into this store."""
        for rec in other.list_seats():
            self.merge_record(rec)

    def snapshot(self) -> list[SeatRecord]:
        """Return all records for sending to another store."""
        return list(self._seats.values())
