"""Boarding manifest for the airline seat service.

Tracks passenger assignments per seat across cluster nodes.
"""

from clock import Clock


class ManifestEntry:
    """Entry for a seat in the boarding manifest."""

    __slots__ = ("seat_id", "passenger", "version", "ts")

    def __init__(self, seat_id, passenger=None, version=0, ts=0):
        self.seat_id = seat_id
        self.passenger = passenger
        self.version = version
        self.ts = ts

    def copy(self, **overrides):
        kw = {s: getattr(self, s) for s in self.__slots__}
        kw.update(overrides)
        return ManifestEntry(**kw)


class BoardingManifest:
    """Local boarding manifest with last-writer-wins merge."""

    def __init__(self, clock: Clock):
        self._clock = clock
        self._entries: dict[str, ManifestEntry] = {}

    def get(self, seat_id: str) -> ManifestEntry:
        return self._entries.get(seat_id, ManifestEntry(seat_id))

    def list_entries(self) -> list[ManifestEntry]:
        return list(self._entries.values())

    def _put(self, seat_id, passenger, base=None):
        if base is None:
            base = self.get(seat_id)
        entry = base.copy(
            passenger=passenger,
            version=base.version + 1,
            ts=self._clock.now(),
        )
        self._entries[seat_id] = entry
        return entry

    def add(self, seat_id: str, passenger: str) -> ManifestEntry:
        return self._put(seat_id, passenger)

    def remove(self, seat_id: str) -> ManifestEntry:
        return self._put(seat_id, None)

    def merge_entry(self, incoming: ManifestEntry):
        """Apply an incoming replicated entry (last-writer-wins)."""
        local = self.get(incoming.seat_id)
        if incoming.ts > local.ts:
            self._entries[incoming.seat_id] = incoming
        elif incoming.ts == local.ts and incoming.version > local.version:
            self._entries[incoming.seat_id] = incoming

    def merge_manifest(self, other: "BoardingManifest"):
        """Pull every entry from *other* into this manifest."""
        for entry in other.list_entries():
            self.merge_entry(entry)

    def snapshot(self) -> list[ManifestEntry]:
        """Return all entries for sending to another manifest."""
        return list(self._entries.values())
