# Feed cache stampede on shared miss

A Python recommendation feed service has a TTL cache but no request coalescing, so concurrent misses for the same tenant/user rebuild the feed many times. The fix must coalesce misses per tenant+user while preserving tenant isolation and deterministic feed output.

## Scenario

The service exposes FeedService.get_feed(tenant_id, user_id, limit). It uses FeedCache and FeedRepository. The repository records build_count and build_log. The cache records hits, loads, and evaluations.

## Root cause (hidden from the agent)

FeedService.get_feed checks the cache and, on a miss, immediately builds the feed. Concurrent misses for the same tenant/user all build. A naive user-only single-flight fix would merge results across tenants.

## Correctness constraints

- **C1**: At most one repository build per (tenant, user) per cache miss burst, regardless of concurrent request count.
- **C2**: Feed items returned for tenant A must all belong to tenant A (no cross-tenant contamination).

## Subgoals

1. Add request coalescing for concurrent cache misses.
2. Scope coalescing by tenant_id and user_id so tenant isolation is preserved.
3. Preserve existing cache TTL, invalidation, stats, deterministic feed ordering, and error behavior.

## Failure scenario

Warm alpha/u1, wait for TTL expiry, then issue 8 concurrent get_feed(alpha,u1) calls. The starting code performs 8 repository builds instead of 1. Then concurrent alpha/u1 and beta/u1 calls expose user-only dedup contamination.

## Expected agent pitfalls

- Keying deduplication only by user_id, which fixes the stampede but contaminates tenants.
- Keying by a global key without tenant/user, which merges unrelated feeds.
- Breaking deterministic feed ordering or cache hit behavior while adding locking.
- Adding a timeout or sleep that hides the stampede but does not guarantee one build.

## Anti-shortcut measures

- Tests read repository build_count to assert exactly one build per miss burst.
- Tests run concurrent same-user different-tenant requests to reject user-only dedup.
- Tests replay the exact counterexample with default service settings.
- Tests check deterministic feed output, sort order, limits, cache hits, invalidation, and errors.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_stampede_invariant`, `test_counterexample_replay` |
| C2 | `test_tenant_isolation_invariant`, `test_counterexample_replay`, `test_regression_edge_cases` |
