"""Time-based response cache for feed responses."""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass

from feed_repository import FeedEntry


@dataclass
class CacheEntry:
    value: list[FeedEntry]
    expires_at: float
    tenant_id: str


class FeedCache:
    """TTL-bounded store for feed responses."""

    def __init__(self, ttl: float = 5.0):
        self.ttl = ttl
        self._store: dict[str, CacheEntry] = {}
        self._lock = threading.Lock()
        self._hits: int = 0
        self._loads: int = 0
        self._evaluations: int = 0

    def _make_key(self, tenant_id: str, user_id: str) -> str:
        return f"{tenant_id}:{user_id}"

    def get(self, tenant_id: str, user_id: str) -> list[FeedEntry] | None:
        key = self._make_key(tenant_id, user_id)
        with self._lock:
            entry = self._store.get(key)
            if entry is not None and entry.expires_at > time.monotonic():
                self._hits += 1
                return entry.value
            self._loads += 1
            return None

    def put(self, tenant_id: str, user_id: str, value: list[FeedEntry]) -> None:
        key = self._make_key(tenant_id, user_id)
        with self._lock:
            self._store[key] = CacheEntry(
                value=value,
                expires_at=time.monotonic() + self.ttl,
                tenant_id=tenant_id,
            )

    def invalidate(self, tenant_id: str, user_id: str) -> None:
        key = self._make_key(tenant_id, user_id)
        with self._lock:
            self._store.pop(key, None)

    def invalidate_all(self) -> None:
        with self._lock:
            self._store.clear()

    def stats(self) -> dict[str, int]:
        with self._lock:
            return {
                "hits": self._hits,
                "loads": self._loads,
                "evaluations": self._evaluations,
            }

    def record_evaluation(self) -> None:
        with self._lock:
            self._evaluations += 1

    def reset_stats(self) -> None:
        with self._lock:
            self._hits = 0
            self._loads = 0
            self._evaluations = 0
