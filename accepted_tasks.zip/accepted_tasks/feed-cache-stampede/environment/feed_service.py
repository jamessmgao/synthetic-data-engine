"""Front-end service for building tenant-scoped recommendation feeds."""

from __future__ import annotations

import os

from feed_cache import FeedCache
from feed_repository import FeedEntry, FeedRepository


class FeedService:
    """Coordinates the repository and cache for feed requests."""

    def __init__(self, repository=None, cache_ttl=5.0, item_count=None, work_units=None):
        if repository is None:
            repository = FeedRepository(item_count=item_count, work_units=work_units)
        self.repository = repository
        self.cache = FeedCache(ttl=cache_ttl)

    def get_feed(self, tenant_id: str, user_id: str, limit: int = 20) -> list[FeedEntry]:
        cached = self.cache.get(tenant_id, user_id)
        if cached is not None:
            return cached
        self.cache.record_evaluation()
        feed = self.repository.build_feed(tenant_id, user_id, limit)
        self.cache.put(tenant_id, user_id, feed)
        return feed

    def tenants(self) -> list[str]:
        return self.repository.tenant_ids()

    def known_tenant(self, tenant_id: str) -> bool:
        return self.repository.known_tenant(tenant_id)

    def known_user(self, tenant_id: str, user_id: str) -> bool:
        return self.repository.known_user(tenant_id, user_id)

    def reset(self) -> None:
        self.repository.reset_metrics()
        self.cache.invalidate_all()
        self.cache.reset_stats()

    def stats(self) -> dict[str, object]:
        repo_stats = self.repository.metrics()
        cache_stats = self.cache.stats()
        return {
            "builds": repo_stats["build_count"],
            "build_log": repo_stats["build_log"],
            "cache": cache_stats,
        }
