"""Recommendation feed repository for the social feed builder."""

from __future__ import annotations

import math
import os
import random
import threading
import zlib
from dataclasses import dataclass


@dataclass(frozen=True)
class FeedItem:
    item_id: str
    tenant_id: str
    author_id: str
    topic: str
    popularity: float
    published_at: int


@dataclass(frozen=True)
class FeedEntry:
    item_id: str
    score: float
    topic: str
    author_id: str


class FeedRepository:
    """Owns the feed item catalog and builds ranked feeds for tenants."""

    def __init__(self, item_count=None, seed=20240607, work_units=None):
        if item_count is None:
            item_count = int(os.getenv("FEED_ITEM_COUNT", "2400"))
        if work_units is None:
            work_units = int(os.getenv("FEED_SCORE_WORK", "4800"))
        self.item_count = item_count
        self.work_units = work_units
        self._items: list[FeedItem] = []
        self._tenants: set[str] = set()
        self._users_by_tenant: dict[str, list[str]] = {}
        self._build_count = 0
        self._build_log: list[dict[str, object]] = []
        self._lock = threading.Lock()
        self._populate(seed)

    def _populate(self, seed: int) -> None:
        rng = random.Random(seed)
        tenants = ["alpha", "beta", "gamma"]
        topics = ["music", "sports", "tech", "books", "food", "travel", "art", "finance"]
        for tenant in tenants:
            self._users_by_tenant[tenant] = [f"u{i}" for i in range(1, 25)]
        per_tenant = max(1, self.item_count // len(tenants))
        n = 0
        for tenant in tenants:
            for _ in range(per_tenant):
                n += 1
                self._items.append(
                    FeedItem(
                        item_id=f"i{n:05d}",
                        tenant_id=tenant,
                        author_id=rng.choice(self._users_by_tenant[tenant]),
                        topic=rng.choice(topics),
                        popularity=round(rng.random(), 6),
                        published_at=1700000000 + rng.randint(0, 31536000),
                    )
                )
                self._tenants.add(tenant)
        while n < self.item_count:
            n += 1
            self._items.append(
                FeedItem(
                    item_id=f"i{n:05d}",
                    tenant_id="alpha",
                    author_id=rng.choice(self._users_by_tenant["alpha"]),
                    topic=rng.choice(topics),
                    popularity=round(rng.random(), 6),
                    published_at=1700000000 + rng.randint(0, 31536000),
                )
            )

    def tenant_ids(self) -> list[str]:
        return sorted(self._tenants)

    def known_tenant(self, tenant_id: str) -> bool:
        return tenant_id in self._users_by_tenant

    def known_user(self, tenant_id: str, user_id: str) -> bool:
        return user_id in self._users_by_tenant.get(tenant_id, [])

    def user_interests(self, user_id: str) -> dict[str, float]:
        seed = zlib.crc32(user_id.encode("utf-8"))
        rng = random.Random(seed)
        topics = ["music", "sports", "tech", "books", "food", "travel", "art", "finance"]
        return {topic: round(rng.random(), 6) for topic in topics}

    def score_item(self, item: FeedItem, interests: dict[str, float]) -> float:
        weight = interests.get(item.topic, 0.0)
        value = item.popularity * weight
        for _ in range(self.work_units):
            value = math.sin(value + item.popularity) + math.sqrt(abs(value) + 1.0)
        return value

    def build_feed(self, tenant_id: str, user_id: str, limit: int = 20) -> list[FeedEntry]:
        if not self.known_tenant(tenant_id):
            raise ValueError(f"unknown tenant: {tenant_id}")
        if not self.known_user(tenant_id, user_id):
            raise ValueError(f"unknown user for tenant: {tenant_id}/{user_id}")
        with self._lock:
            self._build_count += 1
            self._build_log.append(
                {
                    "tenant": tenant_id,
                    "user": user_id,
                    "thread": threading.get_ident(),
                }
            )
        interests = self.user_interests(user_id)
        entries: list[FeedEntry] = []
        for item in self._items:
            if item.tenant_id != tenant_id:
                continue
            score = self.score_item(item, interests)
            entries.append(
                FeedEntry(
                    item_id=item.item_id,
                    score=score,
                    topic=item.topic,
                    author_id=item.author_id,
                )
            )
        entries.sort(key=lambda entry: (-entry.score, entry.item_id))
        return entries[:limit]

    def reset_metrics(self) -> None:
        with self._lock:
            self._build_count = 0
            self._build_log = []

    def metrics(self) -> dict[str, object]:
        with self._lock:
            return {
                "build_count": self._build_count,
                "build_log": list(self._build_log),
            }
