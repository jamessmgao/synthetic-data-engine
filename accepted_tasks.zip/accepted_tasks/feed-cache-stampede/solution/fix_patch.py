"""Apply the real fix: tenant-scoped request deduplication."""
import sys

# Patch feed_cache.py
cache_path = '/app/feed_cache.py'
with open(cache_path) as f:
    content = f.read()

flight_class = '''
class RequestFlight:
    """Tracks in-flight feed computations."""

    def __init__(self):
        self._flights: dict[str, threading.Event] = {}
        self._results: dict[str, list] = {}
        self._lock = threading.Lock()

    def _make_key(self, tenant_id: str, user_id: str) -> str:
        return f"{tenant_id}:{user_id}"

    def start(self, tenant_id: str, user_id: str):
        key = self._make_key(tenant_id, user_id)
        with self._lock:
            if key in self._flights:
                return False, self._flights[key]
            event = threading.Event()
            self._flights[key] = event
            return True, event

    def complete(self, tenant_id: str, user_id: str, result) -> None:
        key = self._make_key(tenant_id, user_id)
        with self._lock:
            self._results[key] = result
            event = self._flights.pop(key, None)
        if event:
            event.set()

    def get_result(self, tenant_id: str, user_id: str):
        key = self._make_key(tenant_id, user_id)
        with self._lock:
            return self._results.get(key)

'''

content = content.replace('class FeedCache:', flight_class + 'class FeedCache:')
content = content.replace(
    'self._evaluations: int = 0',
    'self._evaluations: int = 0\n        self.flight = RequestFlight()'
)

with open(cache_path, 'w') as f:
    f.write(content)

# Patch feed_service.py
service_path = '/app/feed_service.py'
with open(service_path) as f:
    content = f.read()

old = '''    def get_feed(self, tenant_id: str, user_id: str, limit: int = 20) -> list[FeedEntry]:
        cached = self.cache.get(tenant_id, user_id)
        if cached is not None:
            return cached
        self.cache.record_evaluation()
        feed = self.repository.build_feed(tenant_id, user_id, limit)
        self.cache.put(tenant_id, user_id, feed)
        return feed'''

new = '''    def get_feed(self, tenant_id: str, user_id: str, limit: int = 20) -> list[FeedEntry]:
        cached = self.cache.get(tenant_id, user_id)
        if cached is not None:
            return cached
        self.cache.record_evaluation()
        is_leader, event = self.cache.flight.start(tenant_id, user_id)
        if is_leader:
            feed = self.repository.build_feed(tenant_id, user_id, limit)
            self.cache.put(tenant_id, user_id, feed)
            self.cache.flight.complete(tenant_id, user_id, feed)
            return feed
        else:
            event.wait()
            result = self.cache.flight.get_result(tenant_id, user_id)
            if result is not None:
                return result
            feed = self.repository.build_feed(tenant_id, user_id, limit)
            self.cache.put(tenant_id, user_id, feed)
            return feed'''

content = content.replace(old, new)

with open(service_path, 'w') as f:
    f.write(content)

print('Fix applied: tenant-scoped request deduplication')
