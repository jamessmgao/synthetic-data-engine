"""Connection, schema, and account helpers."""

import os

import psycopg2


DEFAULT_CONNECT = {
    "dbname": os.environ.get("PGDATABASE", "postgres"),
    "user": os.environ.get("PGUSER", "postgres"),
    "host": os.environ.get("PGHOST", "/var/run/postgresql"),
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    account_id text PRIMARY KEY,
    capacity integer NOT NULL CHECK (capacity >= 0),
    remaining integer NOT NULL CHECK (remaining >= 0),
    used integer NOT NULL CHECK (used >= 0),
    CHECK (remaining <= capacity),
    CHECK (used <= capacity)
);

CREATE TABLE IF NOT EXISTS reservations (
    request_id text PRIMARY KEY,
    account_id text NOT NULL REFERENCES accounts(account_id),
    units integer NOT NULL CHECK (units > 0),
    accepted_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE TABLE IF NOT EXISTS dispatch_calls (
    request_id text PRIMARY KEY REFERENCES reservations(request_id),
    account_id text NOT NULL,
    units integer NOT NULL,
    status text NOT NULL CHECK (status IN ('queued', 'sent', 'done')),
    created_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE TABLE IF NOT EXISTS deliveries (
    request_id text PRIMARY KEY,
    account_id text NOT NULL,
    units integer NOT NULL CHECK (units > 0),
    delivered_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE INDEX IF NOT EXISTS dispatch_status_idx
    ON dispatch_calls (status, created_at, request_id);
"""


def connect(dbname=None):
    settings = dict(DEFAULT_CONNECT)
    if dbname is not None:
        settings["dbname"] = dbname
    return psycopg2.connect(**settings)


def transaction(conn):
    conn.autocommit = False
    return conn


def initialize():
    conn = connect("postgres")
    conn.autocommit = True
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (DEFAULT_CONNECT["dbname"],))
    exists = cur.fetchone() is not None
    if not exists:
        cur.execute('CREATE DATABASE "world"')
    cur.close()
    conn.close()

    conn = connect()
    conn.autocommit = True
    cur = conn.cursor()
    cur.execute(SCHEMA)
    cur.close()
    conn.close()


def reset():
    conn = connect()
    conn.autocommit = True
    cur = conn.cursor()
    cur.execute("TRUNCATE deliveries, dispatch_calls, reservations RESTART IDENTITY")
    cur.execute("DELETE FROM accounts")
    cur.close()
    conn.close()


def add_account(account_id, capacity):
    conn = connect()
    with conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO accounts (account_id, capacity, remaining, used) VALUES (%s, %s, %s, 0)",
                (account_id, capacity, capacity),
            )
    conn.close()
