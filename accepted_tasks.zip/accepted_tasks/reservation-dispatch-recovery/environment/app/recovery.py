"""Recovery worker that retries incomplete dispatch calls."""

import db
import service


def recover():
    """Find dispatch calls that have not completed and retry them."""
    conn = db.connect()
    conn.autocommit = True
    with conn.cursor() as cur:
        cur.execute(
            "SELECT request_id FROM dispatch_calls "
            "WHERE status != 'done' ORDER BY created_at"
        )
        pending = [row[0] for row in cur.fetchall()]
    conn.close()

    completed = []
    failed = []
    for request_id in pending:
        try:
            service.dispatch(request_id)
            completed.append(request_id)
        except Exception:
            failed.append(request_id)
    return {"completed": completed, "failed": failed}


def main():
    result = recover()
    print(result)


if __name__ == "__main__":
    main()
