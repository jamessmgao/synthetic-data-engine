"""Reservation acceptance and delivery dispatch operations."""

import sys

import db


class ReservationError(Exception):
    """A reservation request cannot be accepted."""


class ServiceUnavailable(Exception):
    """The requested reservation has not reached a known state."""


def _connection():
    conn = db.connect()
    conn.autocommit = False
    return conn


def accept(request_id, account_id, units):
    conn = _connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT remaining FROM accounts WHERE account_id = %s FOR UPDATE",
                (account_id,),
            )
            account = cur.fetchone()
            if account is None:
                raise ReservationError("unknown account")
            cur.execute(
                "SELECT units FROM reservations WHERE request_id = %s", (request_id,)
            )
            prior = cur.fetchone()
            if prior is not None:
                conn.commit()
                return {"request_id": request_id, "units": prior[0], "state": "accepted"}
            if units > account[0]:
                raise ReservationError("insufficient remaining capacity")
            cur.execute(
                "INSERT INTO reservations (request_id, account_id, units) "
                "VALUES (%s, %s, %s)",
                (request_id, account_id, units),
            )
            cur.execute(
                "INSERT INTO dispatch_calls "
                "(request_id, account_id, units, status) VALUES (%s, %s, %s, 'queued')",
                (request_id, account_id, units),
            )
            cur.execute(
                "UPDATE accounts SET remaining = remaining - %s WHERE account_id = %s",
                (units, account_id),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return {"request_id": request_id, "units": units, "state": "accepted"}


def dispatch(request_id, acknowledgement=None, settlement_notice=None):
    conn = _connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT status FROM dispatch_calls WHERE request_id = %s FOR UPDATE",
                (request_id,),
            )
            call = cur.fetchone()
            if call is None:
                raise ReservationError("unknown dispatch call")
            if call[0] == "done":
                conn.commit()
                return True
            cur.execute(
                "INSERT INTO deliveries (request_id, account_id, units) "
                "SELECT request_id, account_id, units FROM dispatch_calls "
                "WHERE request_id = %s",
                (request_id,),
            )
            cur.execute(
                "UPDATE dispatch_calls SET status = 'sent' WHERE request_id = %s",
                (request_id,),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    if acknowledgement is not None:
        acknowledgement(request_id)

    conn = _connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE accounts SET used = used + deliveries.units "
                "FROM deliveries WHERE deliveries.request_id = %s "
                "AND accounts.account_id = deliveries.account_id",
                (request_id,),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    if settlement_notice is not None:
        settlement_notice(request_id)

    conn = _connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE dispatch_calls SET status = 'done' WHERE request_id = %s",
                (request_id,),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return True


def add_account(account_id, capacity):
    db.add_account(account_id, capacity)
    return {"account_id": account_id, "capacity": capacity}


def _worker():
    for line in sys.stdin:
        fields = line.split()
        if not fields:
            continue
        command, arguments = fields[0], fields[1:]
        try:
            if command == "account" and len(arguments) == 2:
                result = add_account(arguments[0], int(arguments[1]))
            elif command == "accept" and len(arguments) == 3:
                result = accept(arguments[0], arguments[1], int(arguments[2]))
            elif command == "dispatch" and len(arguments) == 1:
                request_id = arguments[0]
                dispatch(
                    request_id,
                    lambda value: print("sent", value, flush=True),
                    lambda value: print("settled", value, flush=True),
                )
                result = {"request_id": request_id, "state": "done"}
            else:
                raise ValueError("unknown command")
            print("ok", result, flush=True)
        except Exception as exc:
            print("error", type(exc).__name__, str(exc), flush=True)


def main():
    if len(sys.argv) == 2 and sys.argv[1] == "worker":
        _worker()
    else:
        raise SystemExit("usage: service.py worker")


if __name__ == "__main__":
    main()
