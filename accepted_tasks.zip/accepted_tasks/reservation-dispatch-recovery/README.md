# Reservation dispatch recovery consistency

Fix PostgreSQL-backed reservation dispatch so account totals and dispatch state stay consistent across worker crashes and retries. Tests cover fixed seeds, the exact crash counterexample, and concurrent dispatches.

## Scenario

The service accepts reservations and dispatches them through a worker backed by PostgreSQL. A worker can be killed at any moment, and recovery retries pending dispatches. The starting repository has a defect that can leave account totals inconsistent after a crash.

## Root cause (hidden from the agent)

dispatch() commits the delivery row and then updates accounts.used in a separate transaction. If the worker is killed between those commits, recovery retries dispatch(), but the delivery insert can conflict and the account summary commit can be lost or repeated.

## Correctness constraints

- **C1**: For every account, accounts.used equals the total delivered units for that account.
- **C2**: For every account, accounts.remaining plus accounts.used equals accounts.capacity.
- **C3**: Every delivery has a completed dispatch call.
- **C4**: The worker and recovery interfaces continue to produce their existing success and error output format.

## Subgoals

1. Make dispatch retry after a crash preserve exactly-once account summary and delivery effects.
2. Keep worker and recovery command interfaces and output format unchanged.
3. Preserve normal accept and dispatch behavior, including duplicate reservations and invalid input rejection.
4. Maintain account totals under concurrent workers and recovery.

## Failure scenario

The exact counterexample is: account acct 5, accept r1 acct 2, dispatch r1, kill after the sent notification, then run recovery. The original service leaves accounts.used=0 while deliveries sum to 2 and dispatch_calls.status remains sent.

## Expected agent pitfalls

- Treating duplicate delivery inserts as harmless and retrying the account update unconditionally, causing used double-counting.
- Changing only the recovery script and missing the worker's dispatch path.
- Breaking normal dispatch or duplicate accept behavior.
- Assuming a single worker and missing concurrent dispatch and recovery races.

## Anti-shortcut measures

- Random seeded schedules and exact crash and restart cases inspect PostgreSQL state after recovery.
- A plausible ON CONFLICT wrong fix is explicitly tested and must fail.
- Tests exercise concurrent workers and preserve the worker interface.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_1_used_equals_delivered` |
| C2 | `test_invariant_2_remaining_plus_used_equals_capacity` |
| C3 | `test_invariant_3_every_delivery_has_completed_dispatch` |
| C4 | `test_regression_edge_cases` |
