# Alias and freeze snapshot semantics in a DSL optimizer

A small Go DSL service optimizes alias bindings but transforms freeze and plain val aliases in a way that changes program semantics. The task is to fix the optimizer/runtime so freeze bindings are snapshots and plain val aliases remain live aliases without being captured by local shadowing.

## Scenario

The service reads a DSL program from stdin or a file, parses it, optimizes alias chains, and runs it. The current optimization rewrites names globally without respecting freeze snapshots or block scope, so emitted values can be wrong after assignments or local declarations.

## Root cause (hidden from the agent)

The parser lowers freeze to a Val with Keyword="freeze", and the optimizer in runtime.go compactTargets/rewriteTree folds all Val aliases globally. This turns freeze into a live alias to the source cell and also folds plain val aliases across scopes. The reference fix evaluates freeze immediately into an immutable binding, gives plain val a runtime alias binding, and excludes freeze from optimizer folding.

## Correctness constraints

- **C1**: A freeze binding keeps the value of its source at the moment of declaration.
- **C2**: Later assignments to the source do not change a frozen binding.
- **C3**: A local binding with the same name as the source does not change a frozen binding.
- **C4**: Plain val chains continue to fold to their original source; reads through an alias reflect the current source value after later assignments.
- **C5**: A local binding with the same name as a plain alias source does not change the alias value; the alias still resolves to the outer source.
- **C6**: The CLI accepts a program from stdin or a file path, prints emitted integer values one per line, and exits nonzero on syntax/runtime errors.
- **C7**: Existing control flow, expression evaluation, immutability, and error behavior continue to work.

## Subgoals

1. Separate freeze snapshot semantics from plain val alias folding.
2. Ensure optimizer folding does not make freeze names live aliases.
3. Ensure plain val aliases remain live aliases to their original source even when a local binding shadows the source name.
4. Preserve CLI input modes, control flow, expressions, and error handling.

## Failure scenario

Tests run the DSL on programs that declare freeze and val aliases, then mutate the source or shadow the source name in nested blocks. The original optimizer rewrites frozen names and plain aliases to the source name globally, producing wrong emitted values. The exact counterexample is replayed from the repro script.

## Expected agent pitfalls

- Adding a freeze-only guard to alias maps fixes freeze symptoms but leaves plain val aliases globally folded, so local shadowing of the source captures the alias.
- Deleting the alias rewrite entirely fixes freeze snapshots but breaks plain val chain folding and live-alias behavior.
- Snapshotting every Val breaks the distinction between freeze and plain val.
- Only fixing the runtime without considering the parser/optimizer boundary can leave one path broken.

## Anti-shortcut measures

- Tests assert all five invariants over 10 fixed seeds with random assignments, blocks, and alias chains.
- The exact counterexample is replayed and must produce the specified output.
- Invariant 5 uses a local val shadowing a plain alias source, which fails the plausible wrong fix.
- Regression tests check while loops, if/else, arithmetic, immutability errors, and CLI input modes.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_1_freeze_keeps_value_at_declaration`, `test_counterexample_replay` |
| C2 | `test_invariant_2_later_assignments_do_not_change_frozen_binding`, `test_counterexample_replay` |
| C3 | `test_invariant_3_local_binding_same_name_as_source_does_not_change_frozen_binding`, `test_counterexample_replay` |
| C4 | `test_invariant_4_plain_val_chains_fold_to_original_source`, `test_regression_edge_cases` |
| C5 | `test_invariant_5_local_binding_same_name_as_plain_alias_source_does_not_change_alias_value`, `test_counterexample_replay` |
| C6 | `test_cli_input_modes_and_errors`, `test_kill_and_restart` |
| C7 | `test_regression_edge_cases` |
