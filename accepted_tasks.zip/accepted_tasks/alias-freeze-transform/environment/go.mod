module dslworld

go 1.23
