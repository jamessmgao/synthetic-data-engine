package language

import (
	"fmt"
	"io"
)

type Value int

type binding struct {
	value   Value
	mutable bool
}

type Env struct {
	parent *Env
	vars   map[string]*binding
}

func newEnv(parent *Env) *Env {
	return &Env{parent: parent, vars: make(map[string]*binding)}
}

func (e *Env) define(name string, value Value, mutable bool) error {
	if _, exists := e.vars[name]; exists {
		return fmt.Errorf("name %q is already defined", name)
	}
	e.vars[name] = &binding{value: value, mutable: mutable}
	return nil
}

func (e *Env) lookup(name string) (Value, bool, bool) {
	for scope := e; scope != nil; scope = scope.parent {
		if b, ok := scope.vars[name]; ok {
			return b.value, true, b.mutable
		}
	}
	return 0, false, false
}

func (e *Env) assign(name string, value Value) error {
	for scope := e; scope != nil; scope = scope.parent {
		if b, ok := scope.vars[name]; ok {
			if !b.mutable {
				return fmt.Errorf("cannot assign to immutable name %q", name)
			}
			b.value = value
			return nil
		}
	}
	return fmt.Errorf("undefined name %q", name)
}

func Run(program Program, stdout io.Writer) error {
	env := newEnv(nil)
	for _, statement := range program.Body {
		if err := exec(statement, env, stdout); err != nil {
			return err
		}
	}
	return nil
}

func exec(node Node, env *Env, stdout io.Writer) error {
	switch statement := node.(type) {
	case Cell:
		value, err := eval(statement.Init, env)
		if err != nil {
			return err
		}
		return env.define(statement.Name, value, true)
	case Val:
		value, err := eval(statement.Init, env)
		if err != nil {
			return err
		}
		return env.define(statement.Name, value, false)
	case Set:
		value, err := eval(statement.Value, env)
		if err != nil {
			return err
		}
		return env.assign(statement.Name, value)
	case Block:
		child := newEnv(env)
		for _, item := range statement.Items {
			if err := exec(item, child, stdout); err != nil {
				return err
			}
		}
		return nil
	case If:
		condition, err := eval(statement.Cond, env)
		if err != nil {
			return err
		}
		if condition != 0 {
			return exec(statement.Then, env, stdout)
		}
		if statement.Else != nil {
			return exec(statement.Else, env, stdout)
		}
		return nil
	case While:
		for {
			condition, err := eval(statement.Cond, env)
			if err != nil {
				return err
			}
			if condition == 0 {
				return nil
			}
			if err := exec(statement.Body, env, stdout); err != nil {
				return err
			}
		}
	case Emit:
		value, err := eval(statement.Value, env)
		if err != nil {
			return err
		}
		_, err = fmt.Fprintln(stdout, value)
		return err
	default:
		return fmt.Errorf("unsupported statement")
	}
}

func eval(node Node, env *Env) (Value, error) {
	switch expression := node.(type) {
	case Number:
		return Value(expression.Value), nil
	case NameExpr:
		value, found, _ := env.lookup(expression.Name)
		if !found {
			return 0, fmt.Errorf("undefined name %q", expression.Name)
		}
		return value, nil
	case Unary:
		operand, err := eval(expression.Operand, env)
		if err != nil {
			return 0, err
		}
		if expression.Op == "-" {
			return -operand, nil
		}
		return 0, fmt.Errorf("unsupported unary operator %q", expression.Op)
	case Binary:
		return evalBinary(expression, env)
	default:
		return 0, fmt.Errorf("unsupported expression")
	}
}

func evalBinary(expression Binary, env *Env) (Value, error) {
	if expression.Op == "&&" {
		left, err := eval(expression.Left, env)
		if err != nil {
			return 0, err
		}
		if left == 0 {
			return 0, nil
		}
		right, err := eval(expression.Right, env)
		if err != nil {
			return 0, err
		}
		if right == 0 {
			return 0, nil
		}
		return 1, nil
	}
	if expression.Op == "||" {
		left, err := eval(expression.Left, env)
		if err != nil {
			return 0, err
		}
		if left != 0 {
			return 1, nil
		}
		right, err := eval(expression.Right, env)
		if err != nil {
			return 0, err
		}
		if right != 0 {
			return 1, nil
		}
		return 0, nil
	}
	left, err := eval(expression.Left, env)
	if err != nil {
		return 0, err
	}
	right, err := eval(expression.Right, env)
	if err != nil {
		return 0, err
	}
	switch expression.Op {
	case "+":
		return left + right, nil
	case "-":
		return left - right, nil
	case "*":
		return left * right, nil
	case "/":
		if right == 0 {
			return 0, fmt.Errorf("division by zero")
		}
		return left / right, nil
	case "%":
		if right == 0 {
			return 0, fmt.Errorf("division by zero")
		}
		return left % right, nil
	case "==":
		if left == right {
			return 1, nil
		}
		return 0, nil
	case "!=":
		if left != right {
			return 1, nil
		}
		return 0, nil
	case "<":
		if left < right {
			return 1, nil
		}
		return 0, nil
	case "<=":
		if left <= right {
			return 1, nil
		}
		return 0, nil
	case ">":
		if left > right {
			return 1, nil
		}
		return 0, nil
	case ">=":
		if left >= right {
			return 1, nil
		}
		return 0, nil
	default:
		return 0, fmt.Errorf("unsupported operator %q", expression.Op)
	}
}

func Optimize(program Program) Program {
	targets := map[string]string{}
	compactTargets(program.Body, targets)
	if len(targets) == 0 {
		return program
	}
	return Program{Body: rewriteTree(program.Body, targets, false)}
}

func compactTargets(statements []Node, targets map[string]string) {
	for _, statement := range statements {
		switch item := statement.(type) {
		case Val:
			if item.Keyword != "freeze" {
				if source, ok := item.Init.(NameExpr); ok && source.Name != item.Name {
					targets[item.Name] = source.Name
				}
			}
		case Block:
			compactTargets(item.Items, targets)
		case If:
			compactTargets([]Node{item.Then}, targets)
			if item.Else != nil {
				compactTargets([]Node{item.Else}, targets)
			}
		case While:
			compactTargets([]Node{item.Body}, targets)
		}
	}
}

func rewriteTree(items []Node, targets map[string]string, skipTop bool) []Node {
	result := make([]Node, 0, len(items))
	for _, statement := range items {
		result = append(result, rewriteStatement(statement, targets, skipTop))
	}
	return result
}

func rewriteStatement(statement Node, targets map[string]string, skip bool) Node {
	switch item := statement.(type) {
	case Cell:
		if !skip {
			item.Init = rewriteExpression(item.Init, targets)
		}
		return item
	case Val:
		if !skip {
			item.Init = rewriteExpression(item.Init, targets)
		}
		return item
	case Set:
		if !skip {
			item.Value = rewriteExpression(item.Value, targets)
		}
		return item
	case Block:
		item.Items = rewriteTree(item.Items, targets, false)
		return item
	case If:
		if !skip {
			item.Cond = rewriteExpression(item.Cond, targets)
		}
		item.Then = rewriteStatement(item.Then, targets, false)
		if item.Else != nil {
			item.Else = rewriteStatement(item.Else, targets, false)
		}
		return item
	case While:
		if !skip {
			item.Cond = rewriteExpression(item.Cond, targets)
		}
		item.Body = rewriteStatement(item.Body, targets, false)
		return item
	case Emit:
		if !skip {
			item.Value = rewriteExpression(item.Value, targets)
		}
		return item
	default:
		return statement
	}
}

func rewriteExpression(expression Node, targets map[string]string) Node {
	switch item := expression.(type) {
	case NameExpr:
		return NameExpr{Name: foldName(item.Name, targets), Start: item.Start}
	case Unary:
		item.Operand = rewriteExpression(item.Operand, targets)
		return item
	case Binary:
		item.Left = rewriteExpression(item.Left, targets)
		item.Right = rewriteExpression(item.Right, targets)
		return item
	default:
		return expression
	}
}

func foldName(name string, targets map[string]string) string {
	for i := 0; i < len(targets); i++ {
		source, ok := targets[name]
		if !ok || source == name {
			break
		}
		name = source
	}
	return name
}
