package language

import "strings"

type Node interface{ node() }

type Program struct{ Body []Node }
type Cell struct {
	Name  string
	Init  Node
	Start int
}
type Val struct {
	Name    string
	Init    Node
	Start   int
	Keyword string
}
type Set struct {
	Name  string
	Value Node
	Start int
}
type Block struct {
	Items []Node
	Start int
}
type If struct {
	Cond  Node
	Then  Node
	Else  Node
	Start int
}
type While struct {
	Cond  Node
	Body  Node
	Start int
}
type Emit struct {
	Value Node
	Start int
}
type Number struct {
	Value int
	Start int
}
type NameExpr struct {
	Name  string
	Start int
}
type Binary struct {
	Op    string
	Left  Node
	Right Node
	Start int
}
type Unary struct {
	Op      string
	Operand Node
	Start   int
}

func (Program) node()  {}
func (Cell) node()     {}
func (Val) node()      {}
func (Set) node()      {}
func (Block) node()    {}
func (If) node()       {}
func (While) node()    {}
func (Emit) node()     {}
func (Number) node()   {}
func (NameExpr) node() {}
func (Binary) node()   {}
func (Unary) node()    {}

type tokenKind int

const (
	tokenEOF tokenKind = iota
	tokenNumber
	tokenName
	symbol
)

type token struct {
	kind tokenKind
	text string
	pos  int
}
type ParseError struct {
	Offset  int
	Message string
}

func (e ParseError) Error() string { return e.Message }

type parser struct {
	tokens []token
	pos    int
}

func Parse(source string) (Program, error) {
	tokens, err := scan(source)
	if err != nil {
		return Program{}, err
	}
	p := &parser{tokens: tokens}
	var body []Node
	for !p.at(tokenEOF) {
		item, err := p.statement()
		if err != nil {
			return Program{}, err
		}
		body = append(body, item)
	}
	return prepare(Program{Body: body}), nil
}

func (p *parser) at(k tokenKind) bool { return p.tokens[p.pos].kind == k }
func (p *parser) accept(t string) bool {
	if tok := p.tokens[p.pos]; tok.kind == symbol && tok.text == t || tok.kind == tokenName && tok.text == t {
		p.pos++
		return true
	}
	return false
}
func (p *parser) expect(t string) error {
	if p.accept(t) {
		return nil
	}
	return ParseError{Offset: p.tokens[p.pos].pos, Message: "expected " + t}
}
func (p *parser) name() (string, int, error) {
	t := p.tokens[p.pos]
	if t.kind != tokenName {
		return "", t.pos, ParseError{Offset: t.pos, Message: "expected a name"}
	}
	p.pos++
	return t.text, t.pos, nil
}

func (p *parser) statement() (Node, error) {
	t := p.tokens[p.pos]
	switch {
	case t.kind == symbol && t.text == "{":
		return p.block()
	case t.kind != tokenName:
		return nil, ParseError{Offset: t.pos, Message: "expected a statement"}
	}
	switch t.text {
	case "cell":
		p.pos++
		name, start, err := p.name()
		if err != nil {
			return nil, err
		}
		if err := p.expect("="); err != nil {
			return nil, err
		}
		init, err := p.expression()
		if err != nil {
			return nil, err
		}
		if err := p.expect(";"); err != nil {
			return nil, err
		}
		return Cell{Name: name, Init: init, Start: start}, nil
	case "val":
		p.pos++
		name, start, err := p.name()
		if err != nil {
			return nil, err
		}
		if err := p.expect("="); err != nil {
			return nil, err
		}
		init, err := p.expression()
		if err != nil {
			return nil, err
		}
		if err := p.expect(";"); err != nil {
			return nil, err
		}
		return Val{Name: name, Init: init, Start: start, Keyword: "val"}, nil
	case "freeze":
		p.pos++
		source, start, err := p.name()
		if err != nil {
			return nil, err
		}
		if err := p.expect("as"); err != nil {
			return nil, err
		}
		alias, _, err := p.name()
		if err != nil {
			return nil, err
		}
		if err := p.expect(";"); err != nil {
			return nil, err
		}
		return Val{Name: alias, Init: NameExpr{Name: source, Start: start}, Start: start, Keyword: "freeze"}, nil
	case "set":
		p.pos++
		name, start, err := p.name()
		if err != nil {
			return nil, err
		}
		if err := p.expect("="); err != nil {
			return nil, err
		}
		value, err := p.expression()
		if err != nil {
			return nil, err
		}
		if err := p.expect(";"); err != nil {
			return nil, err
		}
		return Set{Name: name, Value: value, Start: start}, nil
	case "emit":
		p.pos++
		value, err := p.expression()
		if err != nil {
			return nil, err
		}
		if err := p.expect(";"); err != nil {
			return nil, err
		}
		return Emit{Value: value, Start: t.pos}, nil
	case "if":
		p.pos++
		if err := p.expect("("); err != nil {
			return nil, err
		}
		cond, err := p.expression()
		if err != nil {
			return nil, err
		}
		if err := p.expect(")"); err != nil {
			return nil, err
		}
		then, err := p.block()
		if err != nil {
			return nil, err
		}
		var elseB Node
		if p.accept("else") {
			elseB, err = p.block()
			if err != nil {
				return nil, err
			}
		}
		return If{Cond: cond, Then: then, Else: elseB, Start: t.pos}, nil
	case "while":
		p.pos++
		if err := p.expect("("); err != nil {
			return nil, err
		}
		cond, err := p.expression()
		if err != nil {
			return nil, err
		}
		if err := p.expect(")"); err != nil {
			return nil, err
		}
		body, err := p.block()
		if err != nil {
			return nil, err
		}
		return While{Cond: cond, Body: body, Start: t.pos}, nil
	default:
		return nil, ParseError{Offset: t.pos, Message: "unknown statement " + t.text}
	}
}

func (p *parser) block() (Node, error) {
	start := p.tokens[p.pos].pos
	if err := p.expect("{"); err != nil {
		return nil, err
	}
	var items []Node
	for !p.accept("}") {
		if p.at(tokenEOF) {
			return nil, ParseError{Offset: p.tokens[p.pos].pos, Message: "unterminated block"}
		}
		item, err := p.statement()
		if err != nil {
			return nil, err
		}
		items = append(items, item)
	}
	return Block{Items: items, Start: start}, nil
}

func (p *parser) expression() (Node, error) { return p.orExpr() }

func (p *parser) orExpr() (Node, error) {
	left, err := p.andExpr()
	if err != nil {
		return nil, err
	}
	for p.accept("||") {
		right, err := p.andExpr()
		if err != nil {
			return nil, err
		}
		left = Binary{Op: "||", Left: left, Right: right}
	}
	return left, nil
}

func (p *parser) andExpr() (Node, error) {
	left, err := p.cmpExpr()
	if err != nil {
		return nil, err
	}
	for p.accept("&&") {
		right, err := p.cmpExpr()
		if err != nil {
			return nil, err
		}
		left = Binary{Op: "&&", Left: left, Right: right}
	}
	return left, nil
}

func (p *parser) cmpExpr() (Node, error) {
	left, err := p.addExpr()
	if err != nil {
		return nil, err
	}
	for {
		op := ""
		if p.accept("==") {
			op = "=="
		} else if p.accept("!=") {
			op = "!="
		} else if p.accept("<=") {
			op = "<="
		} else if p.accept(">=") {
			op = ">="
		} else if p.accept("<") {
			op = "<"
		} else {
			break
		}
		right, err := p.addExpr()
		if err != nil {
			return nil, err
		}
		left = Binary{Op: op, Left: left, Right: right}
	}
	return left, nil
}

func (p *parser) addExpr() (Node, error) {
	left, err := p.mulExpr()
	if err != nil {
		return nil, err
	}
	for {
		op := ""
		if p.accept("+") {
			op = "+"
		} else if p.accept("-") {
			op = "-"
		} else {
			break
		}
		right, err := p.mulExpr()
		if err != nil {
			return nil, err
		}
		left = Binary{Op: op, Left: left, Right: right}
	}
	return left, nil
}

func (p *parser) mulExpr() (Node, error) {
	left, err := p.unaryExpr()
	if err != nil {
		return nil, err
	}
	for {
		op := ""
		if p.accept("*") {
			op = "*"
		} else if p.accept("/") {
			op = "/"
		} else if p.accept("%") {
			op = "%"
		} else {
			break
		}
		right, err := p.unaryExpr()
		if err != nil {
			return nil, err
		}
		left = Binary{Op: op, Left: left, Right: right}
	}
	return left, nil
}

func (p *parser) unaryExpr() (Node, error) {
	if p.accept("-") {
		operand, err := p.unaryExpr()
		if err != nil {
			return nil, err
		}
		return Unary{Op: "-", Operand: operand}, nil
	}
	return p.primary()
}

func (p *parser) primary() (Node, error) {
	t := p.tokens[p.pos]
	switch {
	case t.kind == tokenNumber:
		p.pos++
		v := 0
		for _, c := range t.text {
			v = v*10 + int(c-'0')
		}
		return Number{Value: v, Start: t.pos}, nil
	case t.kind == tokenName:
		p.pos++
		return NameExpr{Name: t.text, Start: t.pos}, nil
	case t.kind == symbol && t.text == "(":
		p.pos++
		expr, err := p.expression()
		if err != nil {
			return nil, err
		}
		if err := p.expect(")"); err != nil {
			return nil, err
		}
		return expr, nil
	default:
		return nil, ParseError{Offset: t.pos, Message: "unexpected token"}
	}
}

func scan(source string) ([]token, error) {
	var out []token
	for i := 0; i < len(source); {
		c := source[i]
		switch {
		case c == ' ' || c == '\t' || c == '\r' || c == '\n':
			i++
		case c >= '0' && c <= '9':
			s := i
			for i < len(source) && source[i] >= '0' && source[i] <= '9' {
				i++
			}
			out = append(out, token{kind: tokenNumber, text: source[s:i], pos: s})
		case c == '_' || c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z':
			s := i
			for i < len(source) && (source[i] == '_' || source[i] >= '0' && source[i] <= '9' || source[i] >= 'a' && source[i] <= 'z' || source[i] >= 'A' && source[i] <= 'Z') {
				i++
			}
			out = append(out, token{kind: tokenName, text: source[s:i], pos: s})
		default:
			s := i
			if i+1 < len(source) {
				pair := source[i : i+2]
				if pair == "==" || pair == "!=" || pair == "<=" || pair == ">=" || pair == "&&" || pair == "||" {
					i += 2
					out = append(out, token{kind: symbol, text: pair, pos: s})
					continue
				}
			}
			if strings.ContainsRune("+-*/%(){};!=<", rune(c)) {
				i++
				out = append(out, token{kind: symbol, text: string(c), pos: s})
				continue
			}
			return nil, ParseError{Offset: s, Message: "unexpected character"}
		}
	}
	out = append(out, token{kind: tokenEOF, pos: len(source)})
	return out, nil
}

func prepare(program Program) Program {
	targets := map[string]string{}
	prepareTargets(program.Body, targets)
	if len(targets) == 0 {
		return program
	}
	return Program{Body: rewriteTree(program.Body, targets, true)}
}

func prepareTargets(statements []Node, targets map[string]string) {
	for _, statement := range statements {
		switch item := statement.(type) {
		case Val:
			if item.Keyword != "freeze" {
				if source, ok := item.Init.(NameExpr); ok && source.Name != item.Name {
					targets[item.Name] = source.Name
				}
			}
		case Block:
			prepareTargets(item.Items, targets)
		case If:
			prepareTargets([]Node{item.Then}, targets)
			if item.Else != nil {
				prepareTargets([]Node{item.Else}, targets)
			}
		case While:
			prepareTargets([]Node{item.Body}, targets)
		}
	}
}
