# Concurrent settlement withdrawals must preserve bank invariants

The settlement service checks a global floor and then writes an account balance without serializing concurrent withdrawals. The fix must make withdrawal transactions safe under concurrency while preserving the HTTP API and ledger semantics.

## Scenario

A PostgreSQL-backed HTTP bank accepts withdrawals from two settlement accounts and exposes consistency state through POST endpoints. Concurrent clients can pass stale global checks and drive the total below the configured floor.

## Root cause (hidden from the agent)

bank.withdraw performs reads and writes in a default READ COMMITTED transaction. Concurrent transactions on different accounts can both observe a total above the floor and then commit allocations that jointly violate it. service.process_withdrawal also has no serialization-failure retry path.

## Correctness constraints

- **C1**: The sum of all account balances must remain at or above the configured total floor after every withdrawal, including concurrent withdrawals and service restarts.
- **C2**: Each account balance must equal its opening balance minus the sum of its allocation amounts after every withdrawal, including concurrent withdrawals and service restarts.
- **C3**: The documented withdrawal and state HTTP interfaces must keep their existing successful and rejected JSON response shapes and reasons.
- **C4**: Confirmed withdrawals and ledger state must persist across a service process crash and restart.

## Subgoals

1. Serialize the decision and write that jointly affect the global floor.
2. Handle serialization conflicts without exposing them as HTTP failures.
3. Preserve account and allocation ledger accounting.
4. Preserve the HTTP response format and restart persistence.

## Failure scenario

Two clients read balances and totals before either commits, then withdraw from different accounts. Both see a total that permits the withdrawal, so both confirm and the resulting total is below the floor. The exact scheduled case is replayed by the counterexample test.

## Expected agent pitfalls

- Changing only the account UPDATE fixes lost updates on one account but not cross-account write skew.
- Using a lock only for one account leaves the global check race-prone.
- Serializable transactions are rejected by PostgreSQL under conflict and require retry handling at the service boundary.
- Disabling or weakening the ledger inspection can hide an inconsistency rather than fix it.

## Anti-shortcut measures

- Fixed-seed schedules mix single requests, concurrent pairs, retries, and SIGKILL restarts.
- The exact synchronized cross-account counterexample must leave only one confirmed withdrawal.
- Regression tests pin response shapes, rejection reasons, exact ledger values, and persistence across restart.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_total_floor_after_every_random_step`, `test_exact_counterexample_pair` |
| C2 | `test_account_ledger_after_every_random_step`, `test_exact_counterexample_pair` |
| C3 | `test_documented_api_and_restart_regression` |
| C4 | `test_documented_api_and_restart_regression` |
