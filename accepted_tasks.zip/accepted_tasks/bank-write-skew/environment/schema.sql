DROP TABLE IF EXISTS allocations;
DROP TABLE IF EXISTS accounts;
DROP TABLE IF EXISTS policy;

CREATE TABLE accounts (
    id INTEGER PRIMARY KEY,
    label TEXT NOT NULL UNIQUE,
    opening_balance INTEGER NOT NULL CHECK (opening_balance >= 0),
    balance INTEGER NOT NULL CHECK (balance >= 0)
);

CREATE TABLE policy (
    id INTEGER PRIMARY KEY,
    total_floor INTEGER NOT NULL
);

CREATE TABLE allocations (
    id BIGSERIAL PRIMARY KEY,
    account_id INTEGER NOT NULL REFERENCES accounts(id),
    amount INTEGER NOT NULL CHECK (amount > 0),
    created_at TIMESTAMP NOT NULL DEFAULT clock_timestamp()
);

INSERT INTO accounts (id, label, opening_balance, balance)
VALUES (1, 'settlement-a', 500, 500),
       (2, 'settlement-b', 500, 500);

INSERT INTO policy (id, total_floor) VALUES (1, 800);
