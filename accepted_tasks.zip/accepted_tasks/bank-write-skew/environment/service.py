import http.server
import json
import urllib.parse

from bank import Bank


def process_withdrawal(bank, account_id, amount):
    return bank.withdraw(account_id, amount)


class BankHandler(http.server.BaseHTTPRequestHandler):
    bank = None

    def do_POST(self):
        route = urllib.parse.urlparse(self.path).path
        if route == "/withdrawals":
            length = int(self.headers.get("Content-Length", 0))
            request = json.loads(self.rfile.read(length))
            result = process_withdrawal(
                self.bank, request["account_id"], request["amount"]
            )
        elif route == "/state":
            result = self.bank.inspect()
        else:
            self.send_response(404)
            self.end_headers()
            return

        body = json.dumps(result, default=str).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        pass


def run_server(dsn="dbname=postgres user=postgres host=/app/pgsocket", port=8080):
    BankHandler.bank = Bank(dsn)
    server = http.server.ThreadingHTTPServer(("0.0.0.0", port), BankHandler)
    server.serve_forever()


if __name__ == "__main__":
    run_server()
