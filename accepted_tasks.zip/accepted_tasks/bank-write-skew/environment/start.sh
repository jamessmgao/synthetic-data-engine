#!/bin/bash
set -euo pipefail
/app/start_db.sh
exec python3 /app/service.py
