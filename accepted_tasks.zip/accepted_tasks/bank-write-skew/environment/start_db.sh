#!/bin/bash
set -euo pipefail

export PATH="/usr/lib/postgresql/16/bin:$PATH"
export PGDATA=/app/pgdata
export PGHOST=/app/pgsocket
export POSTGRES_HOST_AUTH_METHOD=trust

mkdir -p "$PGDATA" "$PGHOST"

if ! pg_isready -q -h "$PGHOST" -U postgres; then
    if [ ! -f "$PGDATA/PG_VERSION" ]; then
        initdb -D "$PGDATA" --username=postgres \
            --auth-local=trust --auth-host=trust >/tmp/initdb.log
    fi
    pg_ctl -D "$PGDATA" -l "$PGDATA/server.log" \
        -o "-k $PGHOST" -w start
fi

pg_isready -q -h "$PGHOST" -U postgres
psql -h "$PGHOST" -v ON_ERROR_STOP=1 -U postgres -d postgres \
    -f /app/schema.sql >/dev/null
