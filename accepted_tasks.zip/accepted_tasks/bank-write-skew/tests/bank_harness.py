import http.client
import json
import os
import pwd
import shutil
import signal
import subprocess
import tempfile
import threading
import time


PATH = "/usr/lib/postgresql/16/bin:" + os.environ.get("PATH", "")


def _agent(command):
    return ["setpriv", "--reuid=agent", "--regid=agent", "--init-groups", *command]


def _service_pids():
    pids = []
    for entry in os.listdir("/proc"):
        if not entry.isdigit():
            continue
        try:
            cmdline = open(f"/proc/{entry}/cmdline", "rb").read()
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        if b"/app/service.py" not in cmdline:
            continue
        pids.append(int(entry))
    return pids


class BankHarness:
    def __init__(self):
        self.root = tempfile.mkdtemp(prefix="bank-test-", dir="/tmp")
        self.data = os.path.join(self.root, "pgdata")
        self.log = os.path.join(self.root, "postgres.log")
        self.service_log = os.path.join(self.root, "service.log")
        self.service = None
        self.service_log_handle = None
        self._stop_existing_service()
        self._stop_existing_postgres()
        try:
            self._start_db()
            self._start_service()
            self._wait_ready()
        except Exception:
            self.close()
            raise

    def _stop_existing_service(self):
        for pid in _service_pids():
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                continue
            deadline = time.monotonic() + 3
            while time.monotonic() < deadline:
                if not os.path.exists(f"/proc/{pid}"):
                    break
                time.sleep(0.05)
            if os.path.exists(f"/proc/{pid}"):
                os.kill(pid, signal.SIGKILL)
                time.sleep(0.1)

    def _stop_existing_postgres(self):
        if not os.path.exists("/app/pgdata/PG_VERSION"):
            return
        env = os.environ.copy()
        env["PATH"] = PATH
        subprocess.run(
            _agent(["pg_ctl", "-D", "/app/pgdata", "-w", "stop"]),
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10,
            check=False,
        )

    def _run_agent(self, command, timeout=30):
        return subprocess.run(
            _agent(command),
            cwd="/app",
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
        )

    def _start_db(self):
        os.mkdir(self.data)
        os.chmod(self.root, 0o777)
        agent_user = pwd.getpwnam("agent")
        os.chown(self.data, agent_user.pw_uid, agent_user.pw_gid)
        os.chmod(self.data, 0o700)
        init = self._run_agent(
            [
                "initdb",
                "-D",
                self.data,
                "--username=postgres",
                "--auth-local=trust",
                "--auth-host=trust",
            ]
        )
        if init.returncode != 0:
            raise RuntimeError(init.stderr.strip() or "initdb failed")
        start = self._run_agent(
            [
                "pg_ctl",
                "-D",
                self.data,
                "-l",
                self.log,
                "-o",
                "-k /app/pgsocket",
                "-w",
                "start",
            ]
        )
        if start.returncode != 0:
            raise RuntimeError(start.stderr.strip() or "PostgreSQL startup failed")
        schema = self._run_agent(
            [
                "psql",
                "-h",
                "/app/pgsocket",
                "-U",
                "postgres",
                "-d",
                "postgres",
                "-v",
                "ON_ERROR_STOP=1",
                "-f",
                "/app/schema.sql",
            ]
        )
        if schema.returncode != 0:
            raise RuntimeError(schema.stderr.strip() or "schema initialization failed")

    def _start_service(self):
        self.service_log_handle = open(self.service_log, "w+b")
        self.service = subprocess.Popen(
            _agent(["/usr/bin/python3", "/app/service.py"]),
            cwd="/app",
            stdout=self.service_log_handle,
            stderr=subprocess.STDOUT,
        )

    def _wait_ready(self, timeout=10):
        deadline = time.monotonic() + timeout
        last = None
        while time.monotonic() < deadline:
            if self.service.poll() is not None:
                raise RuntimeError("service exited during startup")
            try:
                self.state()
                return
            except Exception as exc:
                last = exc
                time.sleep(0.05)
        raise RuntimeError(f"service never became ready: {last}")

    def request(self, path, payload=None, timeout=5):
        body = None if payload is None else json.dumps(payload)
        conn = http.client.HTTPConnection("127.0.0.1", 8080, timeout=timeout)
        try:
            conn.request("POST", path, body=body)
            response = conn.getresponse()
            raw = response.read()
            if response.status != 200:
                raise RuntimeError(f"HTTP {response.status}: {raw!r}")
            return json.loads(raw)
        finally:
            conn.close()

    def state(self):
        return self.request("/state")

    def withdrawal(self, account_id, amount):
        return self.request(
            "/withdrawals", {"account_id": account_id, "amount": amount}
        )

    def concurrent_withdrawals(self, requests):
        results = [None] * len(requests)
        barrier = threading.Barrier(len(requests))

        def run(index):
            barrier.wait()
            try:
                results[index] = self.withdrawal(*requests[index])
            except Exception as exc:
                results[index] = {"status": "error", "reason": str(exc)}

        threads = [threading.Thread(target=run, args=(i,)) for i in range(len(requests))]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        return results

    def reset(self):
        result = self._run_agent(
            [
                "psql",
                "-h",
                "/app/pgsocket",
                "-U",
                "postgres",
                "-d",
                "postgres",
                "-v",
                "ON_ERROR_STOP=1",
                "-f",
                "/app/schema.sql",
            ]
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or "database reset failed")

    def restart(self):
        if self.service is None:
            raise RuntimeError("service is not running")
        self.service.kill()
        self.service.wait(timeout=3)
        self._start_service()
        self._wait_ready()

    def close(self):
        if self.service is not None and self.service.poll() is None:
            self.service.kill()
            self.service.wait(timeout=3)
        if os.path.exists(os.path.join(self.data, "PG_VERSION")):
            env = os.environ.copy()
            env["PATH"] = PATH
            subprocess.run(
                _agent(["pg_ctl", "-D", self.data, "-w", "stop"]),
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=10,
                check=False,
            )
        if self.service_log_handle is not None:
            self.service_log_handle.close()
        shutil.rmtree(self.root, ignore_errors=True)
