import psycopg2


class Bank:
    def __init__(self, dsn):
        self.dsn = dsn

    def get_connection(self):
        return psycopg2.connect(self.dsn)

    def get_account_balance(self, conn, account_id):
        with conn.cursor() as cur:
            cur.execute("SELECT balance FROM accounts WHERE id = %s", (account_id,))
            row = cur.fetchone()
            if row is None:
                raise ValueError("unknown account")
            return row[0]

    def get_total_balance(self, conn):
        with conn.cursor() as cur:
            cur.execute("SELECT COALESCE(SUM(balance), 0) FROM accounts")
            return cur.fetchone()[0]

    def get_total_floor(self, conn):
        with conn.cursor() as cur:
            cur.execute("SELECT total_floor FROM policy WHERE id = 1")
            row = cur.fetchone()
            if row is None:
                raise ValueError("policy is unavailable")
            return row[0]

    def withdraw(self, account_id, amount):
        if amount <= 0:
            return {"status": "rejected", "reason": "invalid_amount"}

        conn = self.get_connection()
        try:
            conn.set_isolation_level(
                psycopg2.extensions.ISOLATION_LEVEL_SERIALIZABLE
            )
            with conn:
                current = self.get_account_balance(conn, account_id)
                if current < amount:
                    return {"status": "rejected", "reason": "insufficient_account_balance"}

                total = self.get_total_balance(conn)
                floor = self.get_total_floor(conn)
                if total - amount < floor:
                    return {"status": "rejected", "reason": "below_total_floor"}

                new_balance = current - amount
                with conn.cursor() as cur:
                    cur.execute(
                        "UPDATE accounts SET balance = %s WHERE id = %s",
                        (new_balance, account_id),
                    )
                    cur.execute(
                        "INSERT INTO allocations (account_id, amount) VALUES (%s, %s)",
                        (account_id, amount),
                    )
            return {"status": "confirmed", "account_id": account_id, "amount": amount}
        finally:
            conn.close()

    def inspect(self):
        conn = self.get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT COALESCE(SUM(balance), 0), "
                    "COALESCE((SELECT total_floor FROM policy WHERE id = 1), 0) "
                    "FROM accounts"
                )
                total, floor = cur.fetchone()
                cur.execute(
                    "SELECT a.id, a.opening_balance - COALESCE(SUM(l.amount), 0), a.balance "
                    "FROM accounts a "
                    "LEFT JOIN allocations l ON l.account_id = a.id "
                    "GROUP BY a.id, a.opening_balance, a.balance "
                    "ORDER BY a.id"
                )
                ledger_rows = cur.fetchall()
        finally:
            conn.close()

        ledger_ok = all(expected == actual for _, expected, actual in ledger_rows)
        return {
            "total_floor": {"holds": total >= floor, "total": total, "floor": floor},
            "ledger": {"holds": ledger_ok, "accounts": ledger_rows},
        }
