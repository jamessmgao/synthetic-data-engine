# Charge ledger retry credit

A SQLite charge ledger service credits wallets during retry from a separate settlement path. After a worker crash and restart, the same pending request can be credited again, producing balances that exceed applied ledger entries.

## Scenario

The agent receives the charge ledger CLI and source in /app. The service stores charge requests, ledger entries, and wallet balances in SQLite. The retry command processes pending charges; workers can be killed at any point and restarted.

## Root cause (hidden from the agent)

apply_charge credits the wallet in one transaction and marks the ledger applied in a second. retry_pending uses Store.settle_pending, which also credits wallets before marking ledger entries and charges. A crash between those transactions lets retry credit again; concurrent retries can interleave the separate transactions.

## Correctness constraints

- **C1**: For each customer, the wallet balance equals the sum of that customer's applied ledger entries.
- **C2**: Each charge request credits its amount to the wallet at most once, even after a worker crash and retry or concurrent retry processing.
- **C3**: The documented CLI commands and state shapes continue to work: reset, submit, apply, mark, settle, retry, balance, and state behave as documented by --help and the JSON state output.

## Subgoals

1. Identify that retry_pending settles pending work through Store.settle_pending, not only apply_charge.
2. Make ledger application and wallet credit atomic and guarded by the ledger applied state on every path that credits a wallet.
3. Preserve existing command outputs and state transitions for valid operations.

## Failure scenario

Tests reset the database, submit one charge, run retry under a deterministic crash injector that delays SQLite commit syncs, kill the worker after the wallet credit is visible but before settlement completes, run retry again, and inspect state. The unfixed and wrong fix produce balance 20 for one 10 charge; the reference fix produces balance 10.

## Expected agent pitfalls

- Guarding only apply_charge while Store.settle_pending still credits wallets unguarded.
- Assuming SQLite transactions are unnecessary because retry appears sequential.
- Breaking documented outputs such as applied, settled, and the retry JSON list.

## Anti-shortcut measures

- Tests exercise fixed seeds, crash/retry schedules, and concurrent retries through the CLI only.
- The wrong fix that only guards apply_charge is rejected by crash/retry and concurrency tests.
- Regression tests check exact state JSON and command outputs.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_1_wallet_balance_equals_applied_ledger`, `test_counterexample_replayed_from_repro`, `test_concurrent_retry_does_not_double_credit`, `test_regression_commands_and_edge_cases` |
| C2 | `test_invariant_2_charge_request_credited_at_most_once`, `test_counterexample_replayed_from_repro`, `test_concurrent_retry_does_not_double_credit`, `test_regression_commands_and_edge_cases` |
| C3 | `test_regression_commands_and_edge_cases` |
