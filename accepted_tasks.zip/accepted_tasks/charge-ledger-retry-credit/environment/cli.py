"""Command-line entry point for the charge ledger service."""

from __future__ import annotations

import argparse
import json
import sys

from service import LedgerPay


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="run charge ledger operations")
    parser.add_argument("--db", default="/app/redemptions.db", help="database path")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("reset", help="reset the database")

    p = sub.add_parser("submit", help="submit a request")
    p.add_argument("request_id")
    p.add_argument("customer_id")
    p.add_argument("amount", type=int)

    p = sub.add_parser("apply", help="process a request")
    p.add_argument("request_id")

    p = sub.add_parser("mark", help="update a request")
    p.add_argument("request_id")

    p = sub.add_parser("settle", help="process and update a request")
    p.add_argument("request_id")

    sub.add_parser("retry", help="process pending requests")

    p = sub.add_parser("balance", help="print a balance")
    p.add_argument("customer_id")

    sub.add_parser("state", help="print service state as JSON")

    args = parser.parse_args(argv)
    svc = LedgerPay(args.db)

    try:
        if args.cmd == "reset":
            svc.reset()
            print("reset")
        elif args.cmd == "submit":
            print(svc.submit_charge(args.request_id, args.customer_id, args.amount))
        elif args.cmd == "apply":
            print(svc.apply_charge(args.request_id))
        elif args.cmd == "mark":
            print(svc.mark_charged(args.request_id))
        elif args.cmd == "settle":
            print(svc.settle_charge(args.request_id))
        elif args.cmd == "retry":
            print(json.dumps(svc.retry_pending()))
        elif args.cmd == "balance":
            print(svc.wallet_balance(args.customer_id))
        elif args.cmd == "state":
            print(json.dumps(svc.state(), sort_keys=True))
        return 0
    finally:
        svc.close()


if __name__ == "__main__":
    sys.exit(main())
