"""SQLite storage helpers for the redemption service."""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

DEFAULT_DB_PATH = "/app/redemptions.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS charges (
    request_id TEXT PRIMARY KEY,
    customer_id TEXT NOT NULL,
    amount INTEGER NOT NULL,
    state TEXT NOT NULL DEFAULT 'submitted'
);

CREATE TABLE IF NOT EXISTS ledger (
    entry_id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL,
    customer_id TEXT NOT NULL,
    amount INTEGER NOT NULL,
    applied INTEGER NOT NULL DEFAULT 0,
    UNIQUE(code)
);

CREATE TABLE IF NOT EXISTS wallets (
    customer_id TEXT PRIMARY KEY,
    balance INTEGER NOT NULL DEFAULT 0
);
"""


class Store:
    """A thin wrapper over a single SQLite connection."""

    def __init__(self, path: str = DEFAULT_DB_PATH) -> None:
        self.path = path
        self.conn = sqlite3.connect(path, timeout=30, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")

    def init(self) -> None:
        self.conn.executescript(SCHEMA)

    def close(self) -> None:
        self.conn.close()

    def execute(self, sql: str, params: tuple[Any, ...] = ()) -> sqlite3.Cursor:
        return self.conn.execute(sql, params)

    def query_one(self, sql: str, params: tuple[Any, ...] = ()) -> sqlite3.Row | None:
        return self.conn.execute(sql, params).fetchone()

    def query_all(self, sql: str, params: tuple[Any, ...] = ()) -> list[sqlite3.Row]:
        return self.conn.execute(sql, params).fetchall()

    def pending_charges(self) -> list[sqlite3.Row]:
        return self.query_all(
            "SELECT request_id, customer_id, amount FROM charges WHERE state != 'charged' ORDER BY request_id"
        )

    def credit_wallet(self, customer_id: str, amount: int) -> None:
        with self.transaction():
            self.execute(
                "INSERT INTO wallets(customer_id, balance) VALUES(?, ?) "
                "ON CONFLICT(customer_id) DO UPDATE SET balance = balance + excluded.balance",
                (customer_id, amount),
            )

    def record_settlement(self, request_id: str) -> None:
        with self.transaction():
            self.execute(
                "UPDATE ledger SET applied = 1 WHERE code = ?",
                (request_id,),
            )
            self.execute(
                "UPDATE charges SET state = 'charged' WHERE request_id = ?",
                (request_id,),
            )

    def settle_pending(self) -> list[str]:
        rows = self.pending_charges()
        for row in rows:
            self.credit_wallet(row["customer_id"], int(row["amount"]))
        for row in rows:
            self.record_settlement(row["request_id"])
        return [row["request_id"] for row in rows]

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            yield self.conn
            self.conn.execute("COMMIT")
        except Exception:
            self.conn.execute("ROLLBACK")
            raise


def connect(path: str = DEFAULT_DB_PATH) -> Store:
    store = Store(path)
    store.init()
    return store


def reset(path: str = DEFAULT_DB_PATH) -> None:
    Path(path).unlink(missing_ok=True)
    if Path(path + "-wal").exists():
        Path(path + "-wal").unlink()
    if Path(path + "-shm").exists():
        Path(path + "-shm").unlink()
    connect(path).close()
