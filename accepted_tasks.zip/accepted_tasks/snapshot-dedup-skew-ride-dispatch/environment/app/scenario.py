"""Scenario actors and invariants for the ride dispatch world."""

from dispatch import DispatchCluster


def build_world(scheduler):
    """Build a fresh cluster and spawn actors for exploration."""
    cluster = DispatchCluster(node_count=3)
    requests = [
        ("REQ-1", "Airport", "Downtown"),
        ("REQ-2", "Mall", "Station"),
    ]
    submitted = []

    def client():
        for rid, p, d in requests:
            try:
                cluster.submit(rid, p, d)
                submitted.append(rid)
            except RuntimeError:
                pass
            yield f"submit-{rid}"

    def dispatch_actor():
        for node_name in ["node-1"]:
            node = cluster.nodes[node_name]
            if not node.down:
                try:
                    node.dispatch()
                except RuntimeError:
                    pass
            yield "dispatch"

    def snapshot():
        try:
            cluster.begin_snapshot("node-1")
        except RuntimeError:
            return
        yield "snap-begin"
        try:
            cluster.commit_snapshot("node-1")
        except RuntimeError:
            return
        yield "snap-commit"

    def crash():
        for i in range(6):
            yield f"pre-crash-{i}"
        cluster.crash("node-1")
        yield "crash"
        cluster.restart("node-1")
        yield "restart"

    scheduler.spawn("client", client())
    scheduler.spawn("dispatch", dispatch_actor())
    scheduler.spawn("snapshot", snapshot())
    scheduler.spawn("crash", crash())
    cluster._submitted = submitted
    return cluster


def check_invariants(cluster):
    """Check dispatch consistency invariants."""
    for name, node in cluster.nodes.items():
        counts = node.store.get_dispatch_counts()
        for rid, count in counts.items():
            if count > 1:
                return f"{name} dispatches {rid} {count} times"
        # invariant: 1 - at most once
        ride_ids = {r["request_id"] for r in node.store.rides}
        missing = ride_ids - set(node.store.dedup)
        if missing:
            return f"{name} dedup missing {sorted(missing)}"
        # invariant: 2 - exactly once per node for submitted requests
        for rid in getattr(cluster, '_submitted', []):
            if rid not in counts:
                return f"{name} accepted but never dispatched {rid}"
    return None


INVARIANTS = {
    "each request dispatched exactly once per node and dedup matches rides": check_invariants,
}


def check_state(cluster):
    """Return violation message or None."""
    return check_invariants(cluster)
