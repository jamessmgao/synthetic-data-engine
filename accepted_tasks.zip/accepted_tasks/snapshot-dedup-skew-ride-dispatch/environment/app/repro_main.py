"""Replay a saved schedule and check invariants."""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from sde_sched import Scheduler
from sde_repro import repro_main as harness_main
from scenario import build_world, INVARIANTS


def run(sequence):
    """Replay the sequence and return the cluster state."""
    scheduler = Scheduler(replay=sequence)
    cluster = build_world(scheduler)
    scheduler.run()
    return cluster


if __name__ == "__main__":
    harness_main(run, INVARIANTS)
