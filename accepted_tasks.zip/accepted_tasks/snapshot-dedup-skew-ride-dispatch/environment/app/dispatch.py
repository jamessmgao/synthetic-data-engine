"""Ride dispatch cluster: leader, followers, quorum replication, and snapshots."""

import copy

from store import RideStore


class DispatcherNode:
    """A single dispatcher node with its own WAL, dedup table, and rides."""

    def __init__(self, name):
        self.name = name
        self.role = "follower"
        self.store = RideStore()
        self.down = False
        self.dispatch_cache = {}   # request_id -> ride for pending notifications
        self._snapshot_cache = None

    def become_leader(self):
        self.role = "leader"

    def become_follower(self):
        self.role = "follower"

    def crash(self):
        self.down = True

    def restart(self):
        self.down = False
        self.store.recover_from_snapshot()
        # Replay dispatch cache from snapshot
        if self.store.snapshot and "cache" in self.store.snapshot:
            for request_id, ride in self.store.snapshot["cache"].items():
                self.store.rides.append(dict(ride))
        self.dispatch_cache = {}
        self._snapshot_cache = None

    def submit(self, request_id, pickup, dropoff):
        if self.down:
            raise RuntimeError(f"{self.name} is down")
        if self.role != "leader":
            raise RuntimeError(f"{self.name} is not leader")
        before = self.store.commit_index
        self.store.append_entry(request_id, pickup, dropoff)
        if self.store.commit_index == before:
            return self._find_ride(request_id)
        return True

    def dispatch(self):
        if self.down:
            raise RuntimeError(f"{self.name} is down")
        results = self.store.dispatch_pending()
        for ride in results:
            if ride is not None:
                self.dispatch_cache[ride["request_id"]] = dict(ride)
        return results

    def apply_committed(self):
        self.store.dispatch_pending()

    def replicate(self, entry):
        if self.down:
            return False
        if entry["request_id"] in self.store.dedup:
            return True
        self.store.wal[entry["index"]] = copy.deepcopy(entry)
        if entry["index"] > self.store.commit_index:
            self.store.commit_index = entry["index"]
        self.store.dispatch_pending()
        return True

    def begin_snapshot(self):
        if self.down:
            raise RuntimeError(f"{self.name} is down")
        self._snapshot_cache = dict(self.dispatch_cache)
        self.store.prepare_snapshot()

    def commit_snapshot(self):
        if self.down:
            raise RuntimeError(f"{self.name} is down")
        self.store.finalize_snapshot(cache=self._snapshot_cache)
        self.dispatch_cache = {}
        self._snapshot_cache = None

    def _find_ride(self, request_id):
        for ride in reversed(self.store.rides):
            if ride["request_id"] == request_id:
                return dict(ride)
        return None

    def status(self):
        return {
            "name": self.name,
            "role": self.role,
            "down": self.down,
            "commit_index": self.store.commit_index,
            "last_applied": self.store.last_applied,
            "rides": len(self.store.rides),
            "dedup_entries": len(self.store.dedup),
        }


class DispatchCluster:
    """A small ride dispatch cluster with a leader and followers."""

    def __init__(self, node_count=3):
        self.nodes = {}
        for i in range(1, node_count + 1):
            self.nodes[f"node-{i}"] = DispatcherNode(f"node-{i}")
        self.leader = "node-1"
        self.nodes[self.leader].become_leader()

    def set_leader(self, name):
        if name not in self.nodes:
            raise KeyError(name)
        if self.leader in self.nodes and not self.nodes[self.leader].down:
            self.nodes[self.leader].become_follower()
        self.leader = name
        self.nodes[name].become_leader()

    def submit(self, request_id, pickup, dropoff):
        leader = self.nodes[self.leader]
        if leader.down:
            raise RuntimeError(f"leader {self.leader} is down")
        before = leader.store.commit_index
        leader.store.append_entry(request_id, pickup, dropoff)
        if leader.store.commit_index == before:
            return leader._find_ride(request_id)
        acked = 1
        for name, node in self.nodes.items():
            if name == self.leader or node.down:
                continue
            if node.replicate(leader.store.wal[leader.store.commit_index]):
                acked += 1
        if acked * 2 > len(self.nodes):
            leader.store.dispatch_pending()
            ride = leader._find_ride(request_id)
            if ride:
                leader.dispatch_cache[request_id] = dict(ride)
            return ride
        return None

    def begin_snapshot(self, node_name):
        node = self.nodes[node_name]
        node.begin_snapshot()

    def commit_snapshot(self, node_name):
        node = self.nodes[node_name]
        node.commit_snapshot()

    def crash(self, node_name):
        self.nodes[node_name].crash()

    def restart(self, node_name):
        self.nodes[node_name].restart()
