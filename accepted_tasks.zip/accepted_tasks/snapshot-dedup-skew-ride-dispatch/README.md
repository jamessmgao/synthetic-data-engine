# Snapshot dedup skew in ride dispatch recovery

A Python ride dispatch cluster uses WAL, dedup, and snapshots. A snapshot captures dedup too early, so recovery restores stale dedup and skips or loses accepted-but-unapplied requests. The fix must preserve at-most-once dispatch and exactly-once accepted dispatch across crash/restart and snapshot schedules.

## Scenario

The repository contains a small ride dispatch cluster in /app with leader, followers, WAL, snapshots, and a repro harness. The defect is behavior-only and visible through repro and cluster state after crash/restart.

## Root cause (hidden from the agent)

RideStore.finalize_snapshot uses _snapshot_dedup captured at prepare_snapshot time instead of re-capturing dedup at finalize time. DispatcherNode.restart replays snapshot cache without checking dedup and without dispatching pending WAL entries after recovery.

## Correctness constraints

- **C1**: Each request ID is dispatched at most once per node.
- **C2**: Each accepted request is dispatched exactly once per node after recovery; ride assignments for accepted requests survive crash/restart and remain present in the node's reported rides.

## Subgoals

1. Capture current dedup at snapshot finalization.
2. Make recovery replay cached rides without duplicating already-applied requests.
3. Ensure pending committed WAL entries are applied after recovery.
4. Keep normal submit/dispatch/idempotency behavior working.

## Failure scenario

The fixed sequence from the world repro is replayed through repro_main.py and a property driver over 10 fixed seeds; the unfixed code reports node-1 accepted but never dispatched REQ-1, while the fixed code holds both invariants.

## Expected agent pitfalls

- Marking dedup at commit time to prevent duplicates, which breaks exactly-once after crash before apply.
- Replaying snapshot cache without dedup checks, causing duplicate rides.
- Forgetting to dispatch pending WAL entries after snapshot recovery.

## Anti-shortcut measures

- Tests drive the public cluster API and inspect observable state only.
- Random schedules use fixed seeds and include crash/restart, snapshots, retries, and concurrency where allowed.
- The wrong fix that marks dedup at commit time is rejected by exactly-once assertions.
- The exact counterexample is replayed independently.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_each_request_id_dispatched_at_most_once_per_node`, `test_counterexample_repro_holds`, `test_duplicate_submit_is_idempotent_regression` |
| C2 | `test_invariant_each_accepted_request_dispatched_exactly_once_per_node_after_recovery`, `test_counterexample_repro_holds`, `test_snapshot_trims_wal_and_restores_rides_regression` |
