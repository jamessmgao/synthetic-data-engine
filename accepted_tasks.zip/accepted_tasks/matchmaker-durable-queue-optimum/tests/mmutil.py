from __future__ import annotations

import dataclasses
import os
import random
import subprocess
import tempfile
from typing import List, Optional, Tuple

MAX_PLAYERS = 64
MIN_MATCH = 2
MAX_MATCH = 4
MAX_CARRY = 2
HIST_NONE = 0


@dataclasses.dataclass(frozen=True)
class Player:
    name: str
    skill: int
    region: int
    veteran: int


@dataclasses.dataclass(frozen=True)
class Match:
    start: int
    count: int
    cost: int


@dataclasses.dataclass(frozen=True)
class Plan:
    matches: List[Match]
    total: int
    players: List[Player]


def parse_players_text(text: str) -> List[Player]:
    players: List[Player] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        parts = stripped.split()
        if len(parts) != 4:
            raise ValueError(f"invalid player record: {line!r}")
        name = parts[0]
        skill = int(parts[1])
        region = int(parts[2])
        veteran = int(parts[3])
        if not (0 <= skill <= 1000 and 0 <= region <= 99 and 0 <= veteran <= 1):
            raise ValueError(f"invalid player fields: {line!r}")
        if len(name) >= 32:
            raise ValueError(f"player name too long: {name!r}")
        players.append(Player(name, skill, region, veteran))
    if len(players) > MAX_PLAYERS:
        raise ValueError("player limit exceeded")
    return players


def format_players(players: List[Player]) -> str:
    return "".join(f"{p.name} {p.skill} {p.region} {p.veteran}\n" for p in players)


def parse_output(text: str) -> Optional[Plan]:
    lines = text.splitlines()
    if not lines or not lines[0].startswith("matches "):
        return None
    try:
        match_count = int(lines[0].split()[1])
    except (IndexError, ValueError):
        return None
    matches: List[Match] = []
    players: List[Player] = []
    i = 1
    while i < len(lines) and lines[i].startswith("match "):
        parts = lines[i].split()
        if len(parts) != 4:
            return None
        start, count, cost = int(parts[1]), int(parts[2]), int(parts[3])
        matches.append(Match(start, count, cost))
        i += 1
        while i < len(lines) and lines[i].startswith("  "):
            pparts = lines[i].split()
            if len(pparts) != 4:
                return None
            players.append(Player(pparts[0], int(pparts[1]), int(pparts[2]), int(pparts[3])))
            i += 1
    if i >= len(lines) or not lines[i].startswith("total "):
        return None
    try:
        total = int(lines[i].split()[1])
    except (IndexError, ValueError):
        return None
    if len(matches) != match_count:
        return None
    return Plan(matches=matches, total=total, players=players)


def match_cost(players: List[Player], start: int, count: int, incoming_carry: int) -> Tuple[int, int]:
    lo_s = hi_s = players[start].skill
    lo_r = hi_r = players[start].region
    featured = 0
    for i in range(start, start + count):
        p = players[i]
        if p.skill < lo_s:
            lo_s = p.skill
        if p.skill > hi_s:
            hi_s = p.skill
        if p.region < lo_r:
            lo_r = p.region
        if p.region > hi_r:
            hi_r = p.region
        if p.veteran and p.skill >= 900:
            featured += 1
    cost = 3 * (hi_s - lo_s) + 8 * (hi_r - lo_r)
    if incoming_carry == 1:
        cost += 7
    elif incoming_carry == 2:
        cost -= 2
    out_carry = min(featured, MAX_CARRY)
    return cost, out_carry


def optimal_total(players: List[Player]) -> Optional[int]:
    n = len(players)
    if n <= 0:
        return None
    INF = float("inf")
    dp = [[[[[INF for _ in range(5)] for _ in range(5)] for _ in range(3)] for _ in range(3)] for _ in range(n + 1)]
    for c in range(3):
        for p in range(3):
            for h1 in range(5):
                for h2 in range(5):
                    dp[n][c][p][h1][h2] = 0
    for i in range(n - 1, -1, -1):
        for c in range(3):
            for p in range(3):
                for h1 in range(5):
                    for h2 in range(5):
                        best = INF
                        for cnt in range(MIN_MATCH, MAX_MATCH + 1):
                            nxt = i + cnt
                            if nxt > n:
                                break
                            if h1 != 0 and h1 == h2 and h2 == cnt:
                                continue
                            if h1 != 0 and abs(cnt - h1) > 1:
                                continue
                            co, prod = match_cost(players, i, cnt, c)
                            nc = p
                            np = 0 if cnt == MAX_MATCH else prod
                            dst = dp[nxt][nc][np][cnt][h1]
                            if dst < INF:
                                cand = co + dst
                                if cand < best:
                                    best = cand
                        dp[i][c][p][h1][h2] = best
    ans = dp[0][0][0][HIST_NONE][HIST_NONE]
    return int(ans) if ans < INF else None


def compute_plan_costs(players: List[Player], matches: List[Match]) -> List[int]:
    carry = 0
    pending = 0
    costs: List[int] = []
    for m in matches:
        cost, prod = match_cost(players, m.start, m.count, carry)
        costs.append(cost)
        old_pending = pending
        carry = old_pending
        pending = 0 if m.count == MAX_MATCH else prod
    return costs


def validate_plan(players: List[Player], matches: List[Match], total: int) -> bool:
    covered = 0
    computed = 0
    carry = 0
    pending = 0
    prev1 = 0
    prev2 = 0
    for m in matches:
        if m.start != covered:
            return False
        if not (MIN_MATCH <= m.count <= MAX_MATCH):
            return False
        if m.start + m.count > len(players):
            return False
        if m.count == prev1 and prev1 == prev2 and prev1 != 0:
            return False
        if prev1 != 0 and abs(m.count - prev1) > 1:
            return False
        cost, prod = match_cost(players, m.start, m.count, carry)
        if cost != m.cost:
            return False
        computed += cost
        covered += m.count
        old_pending = pending
        carry = old_pending
        pending = 0 if m.count == MAX_MATCH else prod
        prev2 = prev1
        prev1 = m.count
    return covered == len(players) and computed == total


def clean_queue_file() -> None:
    try:
        os.remove("/tmp/matchmaker_queue.bin")
    except FileNotFoundError:
        pass


def run_matchmaker(players: List[Player], runs: int = 2, clean: bool = True) -> List[subprocess.CompletedProcess]:
    fd, path = tempfile.mkstemp(suffix=".txt")
    try:
        with os.fdopen(fd, "w") as f:
            f.write(format_players(players))
        if clean:
            clean_queue_file()
        results: List[subprocess.CompletedProcess] = []
        for _ in range(runs):
            p = subprocess.run(
                ["/app/matchmaker", path],
                capture_output=True,
                text=True,
                timeout=10,
                cwd="/app",
            )
            results.append(p)
        return results
    finally:
        try:
            os.unlink(path)
        except FileNotFoundError:
            pass


def run_matchmaker_text(text: str, runs: int = 1, clean: bool = True) -> List[subprocess.CompletedProcess]:
    fd, path = tempfile.mkstemp(suffix=".txt")
    try:
        with os.fdopen(fd, "w") as f:
            f.write(text)
        if clean:
            clean_queue_file()
        results: List[subprocess.CompletedProcess] = []
        for _ in range(runs):
            p = subprocess.run(
                ["/app/matchmaker", path],
                capture_output=True,
                text=True,
                timeout=10,
                cwd="/app",
            )
            results.append(p)
        return results
    finally:
        try:
            os.unlink(path)
        except FileNotFoundError:
            pass


def generate_queue(seed: int, n: Optional[int] = None) -> List[Player]:
    rng = random.Random(seed)
    if n is None:
        n = rng.randint(5, 12)
    players: List[Player] = []
    for i in range(n):
        name = f"P{i:02d}"
        skill = rng.randint(0, 1000)
        region = rng.randint(0, 99)
        veteran = rng.randint(0, 1)
        players.append(Player(name, skill, region, veteran))
    return players


def edge_queues() -> List[List[Player]]:
    return [
        [Player("A", 10, 1, 0), Player("B", 20, 1, 1)],
        [Player("A", 10, 1, 0), Player("B", 20, 1, 1), Player("C", 30, 2, 0)],
        [Player("A", 10, 1, 0), Player("B", 20, 1, 1), Player("C", 30, 2, 0), Player("D", 40, 2, 1)],
        [Player("A", 10, 1, 0), Player("B", 20, 1, 1), Player("C", 30, 2, 0), Player("D", 40, 2, 1), Player("E", 50, 3, 0)],
        [Player("A", 100, 1, 0), Player("B", 200, 1, 1), Player("C", 300, 2, 0), Player("D", 400, 2, 1), Player("E", 500, 3, 0), Player("F", 600, 3, 1)],
        [
            Player("A", 900, 1, 1),
            Player("B", 950, 1, 1),
            Player("C", 800, 2, 0),
            Player("D", 850, 2, 0),
            Player("E", 990, 3, 1),
            Player("F", 910, 3, 1),
            Player("G", 700, 4, 0),
            Player("H", 720, 4, 0),
        ],
    ]

import time


def run_matchmaker_killed_on_stdin() -> subprocess.CompletedProcess:
    p = subprocess.Popen(
        ["/app/matchmaker", "-"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd="/app",
    )
    time.sleep(0.01)
    p.kill()
    out, err = p.communicate(timeout=1)
    return subprocess.CompletedProcess(
        args=p.args, returncode=p.returncode, stdout=out, stderr=err
    )


def run_schedule(players: List[Player], seed: int):
    rng = random.Random(seed)
    clean_queue_file()
    steps = []
    actions = ["run"]
    for _ in range(rng.randint(4, 6)):
        actions.append(rng.choice(["run", "rerun", "clean", "kill"]))
    for action in actions:
        if action == "clean":
            clean_queue_file()
            steps.append((action, None, None))
        elif action == "kill":
            res = run_matchmaker_killed_on_stdin()
            steps.append((action, res, None))
        else:
            if action == "run" and rng.random() < 0.5:
                clean_queue_file()
            res = run_matchmaker(players, runs=1, clean=False)[0]
            plan = parse_output(res.stdout) if res.returncode == 0 else None
            steps.append((action, res, plan))
    return steps
