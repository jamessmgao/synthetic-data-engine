#ifndef MM_H
#define MM_H

#include <stdio.h>

#define MAX_PLAYERS 64
#define MIN_MATCH 2
#define MAX_MATCH 4
#define MAX_CARRY 2
#define MAX_MATCHES 32
#define QUEUE_FILE "/tmp/matchmaker_queue.bin"

typedef struct {
    char name[32];
    int skill;
    int region;
    int veteran;
} Player;

typedef struct {
    int start;
    int count;
    long cost;
} Match;

long match_cost(const Player *players, int start, int count,
                int incoming_carry, int *out_carry);
int parse_players(FILE *in, Player *players, int max_players);
int plan_matches(const Player *players, int n, Match *matches,
                 int *match_count);

#endif
