# Matchmaker durable queue optimum

A command-line matchmaker plans contiguous matches from a player queue and caches the queue durably. After a restart, it reports a total that is not the true optimum for the original queue.

## Scenario

The system reads player records, plans contiguous matches of 2-4 players, carries a match class between matches, and writes a durable queue cache. Re-running the same input can load that cache and must not change the queue or the optimum plan.

## Root cause (hidden from the agent)

players.c reorders a cached durable queue when count > 4, and main.c lacks validation for the adjacent-match-size rule. Together these let a recovered queue be reordered and produce a non-optimal, invalid plan.

## Correctness constraints

- **C1**: For every input queue, the reported total equals the minimum cost over all complete contiguous match plans.
- **C2**: Every player appears in exactly one match, in queue order.
- **C3**: Each reported match cost is the cost of that match under the carried match class produced by the preceding matches.
- **C4**: No three consecutive matches have the same player count.
- **C5**: Adjacent match sizes must not differ by more than 1 (e.g., a 2-player match cannot be followed directly by a 4-player match and vice versa).

## Subgoals

1. Preserve the input queue order across durable cache load and restart.
2. Enforce all match-plan validity rules in validation and planning.
3. Keep the planner's optimum DP correct for all small queues.
4. Keep the CLI, output format, and error behavior working.

## Failure scenario

Running the counterexample queue twice causes the second run to load the durable cache, reorder the queue, and report a total of 5110/5117 instead of 1311. Tests replay this and run random schedules with restarts and crashes.

## Expected agent pitfalls

- Assuming the planner DP state is the only bug and leaving durable recovery untouched.
- Adding local validation without fixing queue reordering.
- Breaking the documented output format or error exit codes.
- Hard-coding the counterexample total instead of fixing the general algorithm.

## Anti-shortcut measures

- Random-seed property tests compare the reported total to an independent exhaustive oracle.
- Tests replay the exact counterexample and require the correct total.
- Tests inspect player order and match costs after restarts, crashes, and concurrent retries.
- Regression tests pin exact small outputs and CLI behavior.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_counterexample_replay`, `test_regression_edge_cases`, `test_invariant_1_minimum_total` |
| C2 | `test_invariant_2_player_order_and_coverage` |
| C3 | `test_invariant_3_match_costs_under_carried_class` |
| C4 | `test_invariant_4_no_three_consecutive_same_size` |
| C5 | `test_invariant_5_adjacent_sizes_differ_by_at_most_one` |
