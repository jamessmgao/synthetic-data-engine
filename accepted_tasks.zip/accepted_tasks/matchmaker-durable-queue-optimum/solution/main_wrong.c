#include "mm.h"

#include <stdlib.h>
#include <string.h>

int validate_plan(const Player *players, int n, const Match *matches,
                  int match_count, long total) {
    int covered = 0;
    long computed = 0;
    int carry = 0;
    int prev1 = 0;
    int prev2 = 0;

    if (n < 0 || n > MAX_PLAYERS || match_count < 0 ||
        (match_count > 0 && matches == NULL))
        return 0;

    for (int i = 0; i < match_count; i++) {
        if (matches[i].start != covered ||
            matches[i].count < MIN_MATCH ||
            matches[i].count > MAX_MATCH ||
            matches[i].start + matches[i].count > n)
            return 0;
        if (matches[i].count == prev1 && prev1 == prev2 && prev1 != 0)
            return 0;

        int produced = 0;
        long cost = match_cost(players, matches[i].start,
                               matches[i].count, carry, &produced);
        if (cost != matches[i].cost)
            return 0;
        computed += cost;
        covered += matches[i].count;

        carry = produced;
        prev2 = prev1;
        prev1 = matches[i].count;
    }
    return covered == n && computed == total;
}

void print_plan(const Player *players, const Match *matches,
                int match_count, long total) {
    printf("matches %d\n", match_count);
    for (int i = 0; i < match_count; i++) {
        printf("match %d %d %ld\n", matches[i].start,
               matches[i].count, matches[i].cost);
        for (int j = 0; j < matches[i].count; j++) {
            const Player *player = &players[matches[i].start + j];
            printf("  %s %d %d %d\n", player->name, player->skill,
                   player->region, player->veteran);
        }
    }
    printf("total %ld\n", total);
}

int main(int argc, char **argv) {
    Player players[MAX_PLAYERS];
    Match matches[MAX_PLAYERS];
    int count = 0;
    int match_count = 0;
    long total = 0;
    FILE *in = stdin;

    if (argc > 1 && strcmp(argv[1], "-") != 0) {
        in = fopen(argv[1], "r");
        if (in == NULL) {
            perror(argv[1]);
            return 2;
        }
    }
    count = parse_players(in, players, MAX_PLAYERS);
    if (in != stdin)
        fclose(in);
    if (count < 0)
        return 2;
    if (count == 0) {
        fprintf(stderr, "empty queue\n");
        return 2;
    }
    if (!plan_matches(players, count, matches, &match_count)) {
        fprintf(stderr, "no complete matchmaking plan\n");
        return 2;
    }
    for (int i = 0; i < match_count; i++)
        total += matches[i].cost;
    if (!validate_plan(players, count, matches, match_count, total)) {
        fprintf(stderr, "invalid matchmaking plan\n");
        return 2;
    }
    print_plan(players, matches, match_count, total);
    return 0;
}
