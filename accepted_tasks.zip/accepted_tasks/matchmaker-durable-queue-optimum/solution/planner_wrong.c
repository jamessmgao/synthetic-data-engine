#include "mm.h"
#include <stdlib.h>

#define NUM_HIST 5
#define HIST_NONE 0
#define HIST_2 2
#define HIST_3 3
#define HIST_4 4
#define STATE_WIDTH ((MAX_CARRY + 1) * NUM_HIST * NUM_HIST)

typedef struct {
    unsigned char valid;
    int next;
    int choice;
    long total;
} State;

long match_cost(const Player *players, int start, int count,
                int incoming_carry, int *out_carry) {
    int lo_s = players[start].skill, hi_s = players[start].skill;
    int lo_r = players[start].region, hi_r = players[start].region;
    int featured = 0;
    long cost;
    if (out_carry) *out_carry = 0;
    if (count < MIN_MATCH || count > MAX_MATCH) return 0;
    for (int i = start; i < start + count; i++) {
        if (players[i].skill < lo_s) lo_s = players[i].skill;
        if (players[i].skill > hi_s) hi_s = players[i].skill;
        if (players[i].region < lo_r) lo_r = players[i].region;
        if (players[i].region > hi_r) hi_r = players[i].region;
        if (players[i].veteran && players[i].skill >= 900) featured++;
    }
    cost = 3L * (long)(hi_s - lo_s) + 8L * (long)(hi_r - lo_r);
    if (incoming_carry == 1) cost += 7L;
    else if (incoming_carry == 2) cost -= 2L;
    if (out_carry)
        *out_carry = featured > MAX_CARRY ? MAX_CARRY : featured;
    return cost;
}

static unsigned slot(int index, int carry, int prev1, int prev2) {
    return (unsigned)index * STATE_WIDTH
         + (unsigned)carry * NUM_HIST * NUM_HIST
         + (unsigned)prev1 * NUM_HIST
         + (unsigned)prev2;
}

int plan_matches(const Player *players, int n, Match *matches,
                 int *match_count) {
    if (n < 0 || n > MAX_PLAYERS || !matches || !match_count) return 0;
    State *tbl = calloc((size_t)(n + 1) * STATE_WIDTH, sizeof tbl[0]);
    if (!tbl) return 0;
    for (int c = 0; c <= MAX_CARRY; c++)
        for (int h1 = 0; h1 < NUM_HIST; h1++)
            for (int h2 = 0; h2 < NUM_HIST; h2++) {
                State *e = &tbl[slot(n, c, h1, h2)];
                e->valid = 1; e->next = n;
                e->choice = 0; e->total = 0;
            }
    for (int i = n - 1; i >= 0; i--)
      for (int c = 0; c <= MAX_CARRY; c++)
        for (int h1 = 0; h1 < NUM_HIST; h1++)
          for (int h2 = 0; h2 < NUM_HIST; h2++) {
            State *src = &tbl[slot(i, c, h1, h2)];
            src->valid = 0; src->next = i;
            src->choice = 0; src->total = 0;
            for (int cnt = MIN_MATCH; cnt <= MAX_MATCH; cnt++) {
                int nxt = i + cnt;
                if (nxt > n) break;
                if (h1 && h1 == h2 && h2 == cnt) continue;
                if (h1 && h1 != HIST_NONE && abs(cnt - h1) > 1) continue;
                int prod = 0;
                long co = match_cost(players, i, cnt, c, &prod);
                const State *dst = &tbl[slot(nxt, prod, cnt, h1)];
                if (!dst->valid) continue;
                long cand = co + dst->total;
                if (!src->valid || cand < src->total ||
                    (cand == src->total && cnt < src->choice)) {
                    src->valid = 1; src->next = nxt;
                    src->choice = cnt; src->total = cand;
                }
            }
          }
    State *s0 = &tbl[slot(0, 0, HIST_NONE, HIST_NONE)];
    if (!s0->valid) { free(tbl); return 0; }
    int cnt = 0, idx = 0, carry = 0;
    int p1 = HIST_NONE, p2 = HIST_NONE;
    while (idx < n) {
        const State *st = &tbl[slot(idx, carry, p1, p2)];
        if (!st->valid || st->next <= idx ||
            st->next - idx != st->choice) { free(tbl); return 0; }
        int prod = 0;
        matches[cnt].start = idx;
        matches[cnt].count = st->choice;
        matches[cnt].cost = match_cost(players, idx, st->choice, carry, &prod);
        carry = prod;
        p2 = p1; p1 = st->choice;
        idx = st->next; cnt++;
    }
    *match_count = cnt;
    free(tbl);
    return 1;
}
