#include "mm.h"
#include <ctype.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>

static int compare_players(const void *left_ptr, const void *right_ptr) {
    const Player *left = left_ptr;
    const Player *right = right_ptr;
    if (left->region != right->region)
        return left->region < right->region ? -1 : 1;
    if (left->skill != right->skill)
        return left->skill < right->skill ? -1 : 1;
    if (left->veteran != right->veteran)
        return left->veteran < right->veteran ? -1 : 1;
    return strcmp(left->name, right->name);
}

static void order_players(Player *players, int count) {
    qsort(players, (size_t)count, sizeof players[0], compare_players);
}

static unsigned hash_players(const Player *players, int count) {
    unsigned h = 2166136261u;
    for (int i = 0; i < count; i++) {
        const Player *p = &players[i];
        h ^= (unsigned char)p->name[0];
        h *= 16777619u;
        h ^= (unsigned)p->skill;
        h *= 16777619u;
        h ^= (unsigned)p->region;
        h *= 16777619u;
        h ^= (unsigned)p->veteran;
        h *= 16777619u;
    }
    return h;
}

static int read_record(char *line, Player *player) {
    char *cursor = line;
    size_t used = 0;
    while (*cursor != '\0' && !isspace((unsigned char)*cursor)) {
        if (used + 1 >= sizeof player->name) return 0;
        player->name[used++] = *cursor++;
    }
    player->name[used] = '\0';
    if (used == 0) return 0;
    while (*cursor != '\0' && isspace((unsigned char)*cursor)) cursor++;
    char *end = NULL;
    errno = 0;
    long skill = strtol(cursor, &end, 10);
    if (end == cursor || errno != 0 || skill < 0 || skill > 1000) return 0;
    player->skill = (int)skill;
    cursor = end;
    while (*cursor != '\0' && isspace((unsigned char)*cursor)) cursor++;
    errno = 0;
    long region = strtol(cursor, &end, 10);
    if (end == cursor || errno != 0 || region < 0 || region > 99) return 0;
    player->region = (int)region;
    cursor = end;
    while (*cursor != '\0' && isspace((unsigned char)*cursor)) cursor++;
    errno = 0;
    long veteran = strtol(cursor, &end, 10);
    if (end == cursor || errno != 0 || veteran < 0 || veteran > 1) return 0;
    player->veteran = (int)veteran;
    cursor = end;
    while (*cursor != '\0' && isspace((unsigned char)*cursor)) cursor++;
    return *cursor == '\0';
}

static void save_queue(const Player *players, int count, unsigned hash) {
    FILE *f = fopen(QUEUE_FILE, "wb");
    if (!f) return;
    if (fwrite(&count, sizeof count, 1, f) == 1 &&
        fwrite(&hash, sizeof hash, 1, f) == 1)
        fwrite(players, sizeof players[0], (size_t)count, f);
    fclose(f);
}

static int load_queue(Player *players, int max_players, unsigned expected_hash) {
    FILE *f = fopen(QUEUE_FILE, "rb");
    if (!f) return -1;
    int count = -1;
    unsigned hash = 0;
    if (fread(&count, sizeof count, 1, f) != 1 ||
        count < 0 || count > max_players ||
        fread(&hash, sizeof hash, 1, f) != 1 ||
        hash != expected_hash ||
        fread(players, sizeof players[0], (size_t)count, f) != (size_t)count)
        count = -1;
    fclose(f);
    return count;
}

int parse_players(FILE *in, Player *players, int max_players) {
    char line[256];
    int count = 0;
    int line_number = 0;
    while (fgets(line, sizeof line, in)) {
        line_number++;
        char *cursor = line;
        while (*cursor && isspace((unsigned char)*cursor)) cursor++;
        if (!*cursor || *cursor == '#') continue;
        if (count == max_players) {
            fprintf(stderr, "line %d: player limit exceeded\n", line_number);
            return -1;
        }
        if (!read_record(cursor, &players[count])) {
            fprintf(stderr, "line %d: invalid player record\n", line_number);
            return -1;
        }
        count++;
    }
    if (ferror(in)) { fprintf(stderr, "input read failed\n"); return -1; }

    unsigned hash = hash_players(players, count);
    Player cached[MAX_PLAYERS];
    int cached_count = load_queue(cached, max_players, hash);
    if (cached_count >= 0) {
        memcpy(players, cached, sizeof players[0] * (size_t)cached_count);
        count = cached_count;
        save_queue(players, count, hash);
        return count;
    }
    save_queue(players, count, hash);
    return count;
}
