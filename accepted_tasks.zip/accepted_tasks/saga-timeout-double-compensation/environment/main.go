package main

import (
"fmt"
    "log"
"net/http"
"os"
)

type route struct {
pattern string
handler func(http.ResponseWriter, *http.Request)
}

var routes = []route{
{"/healthz", func(w http.ResponseWriter, r *http.Request) {
w.WriteHeader(http.StatusOK)
_, _ = w.Write([]byte("ok"))
}},
}

func main() {
    if len(os.Args) > 1 {
        if err := clientMain(); err != nil {
            fmt.Fprintln(os.Stderr, err)
            os.Exit(1)
        }
        return
    }
addr := ":8080"
if port := os.Getenv("PORT"); port != "" {
addr = ":" + port
}

mux := http.NewServeMux()
for _, rt := range routes {
mux.HandleFunc(rt.pattern, rt.handler)
}

log.Printf("listening on %s", addr)
if err := http.ListenAndServe(addr, mux); err != nil {
log.Fatal(err)
}
}
