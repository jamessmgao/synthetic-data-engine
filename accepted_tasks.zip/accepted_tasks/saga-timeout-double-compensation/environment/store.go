package main

import (
    "encoding/json"
    "errors"
    "fmt"
    "net/http"
    "os"
    "strings"
    "sync"
)

type Account struct {
    Balance int `json:"balance"`
}

type Delivery struct {
    Recipient    string `json:"recipient"`
    Fee          int    `json:"fee"`
    Available    bool   `json:"available"`
    AckAt        int    `json:"ackAt"`
    Succeeded    bool   `json:"succeeded"`
    Acked        bool   `json:"acked"`
    Credited     bool   `json:"credited"`
    CreditFailed bool   `json:"creditFailed"`
}

type Saga struct {
    OrderID               string   `json:"orderId"`
    Sender                string   `json:"sender"`
    Fee                   int      `json:"fee"`
    Deadline              int      `json:"deadline"`
    Status                string   `json:"status"`
    SettlementAttempts int      `json:"settlementAttempts"`
    Recipients            []string `json:"recipients"`
}

type LedgerEntry struct {
    Account   string `json:"account"`
    Kind      string `json:"kind"`
    Amount    int    `json:"amount"`
    OrderID   string `json:"orderId"`
    Recipient string `json:"recipient,omitempty"`
}

type WorldState struct {
    Clock      int                            `json:"clock"`
    Accounts   map[string]*Account            `json:"accounts"`
    Sagas      map[string]*Saga               `json:"sagas"`
    Deliveries map[string]map[string]*Delivery `json:"deliveries"`
    Ledger     []LedgerEntry                  `json:"ledger"`
    CreditKeys map[string]bool                `json:"creditKeys"`
}

type Store struct {
    mu   sync.Mutex
    path string
    data *WorldState
}

var theStore *Store

func openStore(path string) (*Store, error) {
    if path == "" {
        if env := os.Getenv("STATE_PATH"); env != "" {
            path = env
        } else {
            path = "/app/state/world.json"
        }
    }
    s := &Store{path: path, data: &WorldState{
        Accounts:   make(map[string]*Account),
        Sagas:      make(map[string]*Saga),
        Deliveries: make(map[string]map[string]*Delivery),
        CreditKeys: make(map[string]bool),
    }}
    b, err := os.ReadFile(path)
    if errors.Is(err, os.ErrNotExist) {
        return s, nil
    }
    if err != nil {
        return nil, err
    }
    if err := json.Unmarshal(b, s.data); err != nil {
        return nil, err
    }
    if s.data.Accounts == nil {
        s.data.Accounts = make(map[string]*Account)
    }
    if s.data.Sagas == nil {
        s.data.Sagas = make(map[string]*Saga)
    }
    if s.data.Deliveries == nil {
        s.data.Deliveries = make(map[string]map[string]*Delivery)
    }
    if s.data.CreditKeys == nil {
        s.data.CreditKeys = make(map[string]bool)
    }
    return s, nil
}

func init() {
    s, err := openStore("")
    if err != nil {
        panic(err)
    }
    theStore = s
}

func (s *Store) save() error {
    b, err := json.MarshalIndent(s.data, "", "  ")
    if err != nil {
        return err
    }
    tmp := s.path + ".tmp"
    if err := os.WriteFile(tmp, b, 0600); err != nil {
        return err
    }
    return os.Rename(tmp, s.path)
}

func (s *Store) createAccount(id string, balance int) error {
    s.mu.Lock()
    defer s.mu.Unlock()
    if _, ok := s.data.Accounts[id]; ok {
        return fmt.Errorf("account exists")
    }
    s.data.Accounts[id] = &Account{Balance: balance}
    return s.save()
}

func (s *Store) advanceClock(n int) int {
    s.mu.Lock()
    defer s.mu.Unlock()
    s.data.Clock += n
    return s.data.Clock
}

func (s *Store) charge(account, order string, amount int) error {
    s.mu.Lock()
    defer s.mu.Unlock()
    acc, ok := s.data.Accounts[account]
    if !ok || acc.Balance < amount {
        return fmt.Errorf("insufficient credit")
    }
    acc.Balance -= amount
    s.data.Ledger = append(s.data.Ledger, LedgerEntry{Account: account, Kind: "charge", Amount: amount, OrderID: order})
    return s.save()
}

func (s *Store) createSaga(order, sender string, recipients []string, fee, deadline int) error {
    s.mu.Lock()
    defer s.mu.Unlock()
    if _, ok := s.data.Sagas[order]; ok {
        return fmt.Errorf("saga exists")
    }
    total := fee * len(recipients)
    acc, ok := s.data.Accounts[sender]
    if !ok || acc.Balance < total {
        return fmt.Errorf("insufficient credit")
    }
    acc.Balance -= total
    s.data.Sagas[order] = &Saga{OrderID: order, Sender: sender, Fee: fee, Deadline: deadline, Status: "delivering", Recipients: recipients}
    s.data.Deliveries[order] = make(map[string]*Delivery)
    for _, r := range recipients {
        s.data.Deliveries[order][r] = &Delivery{Recipient: r, Fee: fee}
    }
    s.data.Ledger = append(s.data.Ledger, LedgerEntry{Account: sender, Kind: "charge", Amount: total, OrderID: order})
    return s.save()
}

func (s *Store) setPresence(order, recipient string, available bool) error {
    s.mu.Lock()
    defer s.mu.Unlock()
    if _, ok := s.data.Deliveries[order]; !ok {
        return fmt.Errorf("unknown saga")
    }
    del, ok := s.data.Deliveries[order][recipient]
    if !ok {
        return fmt.Errorf("unknown recipient")
    }
    del.Available = available
    return s.save()
}

func (s *Store) deliver(order, recipient string) (bool, error) {
    s.mu.Lock()
    defer s.mu.Unlock()
    del, ok := s.data.Deliveries[order][recipient]
    if !ok {
        return false, fmt.Errorf("unknown delivery")
    }
    if !del.Available {
        return false, nil
    }
    del.Succeeded = true
    return true, s.save()
}

func (s *Store) ackDelivery(order, recipient string) error {
    s.mu.Lock()
    defer s.mu.Unlock()
    del, ok := s.data.Deliveries[order][recipient]
    if !ok {
        return fmt.Errorf("unknown delivery")
    }
    if !del.Succeeded {
        return fmt.Errorf("delivery not succeeded")
    }
    del.Acked = true
    del.AckAt = s.data.Clock
    return s.save()
}

func (s *Store) creditAccount(account, order, recipient string, amount int, key string) (bool, error) {
    s.mu.Lock()
    defer s.mu.Unlock()
    if s.data.CreditKeys[key] {
        return false, nil
    }
    acc, ok := s.data.Accounts[account]
    if !ok {
        return false, fmt.Errorf("unknown account")
    }
    deliveries, ok := s.data.Deliveries[order]
    if !ok {
        return false, fmt.Errorf("unknown saga")
    }
    del, ok := deliveries[recipient]
    if !ok {
        return false, fmt.Errorf("unknown delivery")
    }
    s.data.CreditKeys[key] = true
    acc.Balance += amount
    del.Credited = true
    s.data.Ledger = append(s.data.Ledger, LedgerEntry{Account: account, Kind: "credit", Amount: amount, OrderID: order, Recipient: recipient})
    return true, s.save()
}

func (s *Store) setSagaStatus(order, status string, attempts int) error {
    s.mu.Lock()
    defer s.mu.Unlock()
    saga, ok := s.data.Sagas[order]
    if !ok {
        return fmt.Errorf("unknown saga")
    }
    saga.Status = status
    saga.SettlementAttempts = attempts
    return s.save()
}

func (s *Store) snapshot() *WorldState {
    s.mu.Lock()
    defer s.mu.Unlock()
    b, _ := json.Marshal(s.data)
    out := &WorldState{}
    _ = json.Unmarshal(b, out)
    return out
}

func writeJSON(w http.ResponseWriter, status int, v any) {
    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(status)
    _ = json.NewEncoder(w).Encode(v)
}

func init() {
    routes = append(routes,
        route{"/accounts", func(w http.ResponseWriter, r *http.Request) {
            if r.Method != http.MethodPost {
                writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST required"})
                return
            }
            var req struct {
                Account string `json:"account"`
                Balance int    `json:"balance"`
            }
            if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.Account == "" {
                writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid account"})
                return
            }
            if err := theStore.createAccount(req.Account, req.Balance); err != nil {
                writeJSON(w, http.StatusConflict, map[string]string{"error": err.Error()})
                return
            }
            writeJSON(w, http.StatusCreated, map[string]string{"status": "created"})
        }},
        route{"/clock", func(w http.ResponseWriter, r *http.Request) {
            if r.Method != http.MethodPost {
                writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST required"})
                return
            }
            var req struct {
                Advance int `json:"advance"`
            }
            _ = json.NewDecoder(r.Body).Decode(&req)
            writeJSON(w, http.StatusOK, map[string]int{"clock": theStore.advanceClock(req.Advance)})
        }},
        route{"/state", func(w http.ResponseWriter, r *http.Request) {
            if r.Method != http.MethodGet {
                writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET required"})
                return
            }
            writeJSON(w, http.StatusOK, theStore.snapshot())
        }},
        route{"/accounts/", func(w http.ResponseWriter, r *http.Request) {
            if r.Method != http.MethodGet {
                writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET required"})
                return
            }
            id := strings.TrimPrefix(r.URL.Path, "/accounts/")
            theStore.mu.Lock()
            acc := theStore.data.Accounts[id]
            clock := theStore.data.Clock
            theStore.mu.Unlock()
            if acc == nil {
                writeJSON(w, http.StatusNotFound, map[string]string{"error": "unknown account"})
                return
            }
            writeJSON(w, http.StatusOK, map[string]any{"account": id, "balance": acc.Balance, "clock": clock})
        }},
    )
}
