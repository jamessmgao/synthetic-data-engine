package main

import (
    "net/http"
)

func recoveryMain(w http.ResponseWriter, r *http.Request) {
    if r.Method != http.MethodPost {
        writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST required"})
        return
    }
    state := theStore.snapshot()
    recovered := 0
    for _, order := range sortedSagaIDs(state) {
        saga := state.Sagas[order]
        if saga.Status != "expired" || state.Clock < saga.Deadline {
            continue
        }
        reversed, err := settleOrder(order, "recovery")
        if err != nil {
            writeJSON(w, http.StatusInternalServerError, map[string]string{"error": err.Error()})
            return
        }
        recovered += reversed
    }
    writeJSON(w, http.StatusOK, map[string]any{"status": "recovered", "reversed": recovered})
}

func sortedSagaIDs(state *WorldState) []string {
    ids := make([]string, 0, len(state.Sagas))
    for id := range state.Sagas {
        ids = append(ids, id)
    }
    for i := 1; i < len(ids); i++ {
        for j := i; j > 0 && ids[j] < ids[j-1]; j-- {
            ids[j], ids[j-1] = ids[j-1], ids[j]
        }
    }
    return ids
}

func init() {
    routes = append(routes, route{"/recovery", recoveryMain})
}
