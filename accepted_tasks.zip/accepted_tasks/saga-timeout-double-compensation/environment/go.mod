module chatpresence

go 1.23
