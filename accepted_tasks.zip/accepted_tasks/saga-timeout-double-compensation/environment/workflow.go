package main

import (
    "bytes"
    "fmt"
    "io"
    "net/http"
    "os"
    "strings"
    "time"
)

func clientMain() error {
    if len(os.Args) < 2 {
        return fmt.Errorf("usage: workflow <url> [json-body]")
    }
    target := os.Args[1]
    method := http.MethodPost
    if target == "state" {
        target = "http://127.0.0.1:8080/state"
        method = http.MethodGet
    }
    if strings.HasPrefix(target, "GET ") {
        method = http.MethodGet
        target = strings.TrimPrefix(target, "GET ")
    }
    body := ""
    if len(os.Args) > 2 {
        body = os.Args[2]
    }
    req, err := http.NewRequest(method, target, bytes.NewReader([]byte(body)))
    if err != nil {
        return err
    }
    if method == http.MethodPost {
        req.Header.Set("Content-Type", "application/json")
    }
    client := &http.Client{Timeout: 2 * time.Second}
    resp, err := client.Do(req)
    if err != nil {
        return err
    }
    defer resp.Body.Close()
    b, _ := io.ReadAll(resp.Body)
    fmt.Printf("%d %s\n", resp.StatusCode, string(b))
    return nil
}
