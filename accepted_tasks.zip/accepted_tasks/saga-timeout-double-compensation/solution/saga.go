package main

import (
    "encoding/json"
    "fmt"
    "net/http"
    "strings"
)

func createOrderHandler(w http.ResponseWriter, r *http.Request) {
    if r.Method != http.MethodPost {
        writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST required"})
        return
    }
    var req struct {
        OrderID    string   `json:"orderId"`
        Sender     string   `json:"sender"`
        Recipients []string `json:"recipients"`
        Fee        int      `json:"fee"`
        Deadline   int      `json:"deadline"`
    }
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid order"})
        return
    }
    seen := make(map[string]bool)
    for _, recipient := range req.Recipients {
        if recipient == "" || seen[recipient] {
            writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid recipients"})
            return
        }
        seen[recipient] = true
    }
    if req.OrderID == "" || req.Sender == "" || req.Fee <= 0 || req.Deadline <= 0 || len(req.Recipients) == 0 {
        writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid order"})
        return
    }
    if err := theStore.createSaga(req.OrderID, req.Sender, req.Recipients, req.Fee, req.Deadline); err != nil {
        writeJSON(w, http.StatusConflict, map[string]string{"error": err.Error()})
        return
    }
    writeJSON(w, http.StatusCreated, map[string]string{"status": "delivering"})
}

func presenceHandler(w http.ResponseWriter, r *http.Request) {
    if r.Method != http.MethodPost {
        writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST required"})
        return
    }
    var req struct {
        OrderID   string `json:"orderId"`
        Recipient string `json:"recipient"`
        Available bool   `json:"available"`
    }
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.OrderID == "" || req.Recipient == "" {
        writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid presence"})
        return
    }
    if err := theStore.setPresence(req.OrderID, req.Recipient, req.Available); err != nil {
        writeJSON(w, http.StatusNotFound, map[string]string{"error": err.Error()})
        return
    }
    writeJSON(w, http.StatusOK, map[string]any{"recipient": req.Recipient, "available": req.Available})
}

func settleOrder(order, namespace string) (int, error) {
    state := theStore.snapshot()
    saga, ok := state.Sagas[order]
    if !ok {
        return 0, fmt.Errorf("unknown saga")
    }
    if state.Clock < saga.Deadline {
        return 0, fmt.Errorf("deadline not reached")
    }
    reversed := 0
    for _, recipient := range saga.Recipients {
        delivery := state.Deliveries[order][recipient]
        if delivery.Acked || delivery.Credited {
            continue
        }
        k := namespace + ":" + order + ":" + recipient
        done, err := theStore.creditAccount(saga.Sender, order, recipient, saga.Fee, k)
        if err != nil {
            return reversed, err
        }
        if done {
            reversed++
        }
    }
    return reversed, theStore.setSagaStatus(order, "expired", saga.SettlementAttempts+1)
}

func orderPathHandler(w http.ResponseWriter, r *http.Request) {
    if r.Method != http.MethodPost {
        writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST required"})
        return
    }
    parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
    if len(parts) != 4 {
        writeJSON(w, http.StatusNotFound, map[string]string{"error": "unknown operation"})
        return
    }
    order, operation, recipient := parts[1], parts[2], parts[3]
    switch operation {
    case "deliver":
        delivered, err := theStore.deliver(order, recipient)
        if err != nil {
            writeJSON(w, http.StatusNotFound, map[string]string{"error": err.Error()})
            return
        }
        writeJSON(w, http.StatusOK, map[string]bool{"delivered": delivered})
    case "ack":
        if err := theStore.ackDelivery(order, recipient); err != nil {
            writeJSON(w, http.StatusConflict, map[string]string{"error": err.Error()})
            return
        }
        writeJSON(w, http.StatusOK, map[string]string{"status": "acknowledged"})
    case "timeout":
        reversed, err := settleOrder(order, "saga")
        if err != nil {
            writeJSON(w, http.StatusConflict, map[string]string{"error": err.Error()})
            return
        }
        writeJSON(w, http.StatusOK, map[string]any{"status": "timeout", "reversed": reversed})
    default:
        writeJSON(w, http.StatusNotFound, map[string]string{"error": "unknown operation"})
    }
}

func init() {
    routes = append(routes,
        route{"/orders", createOrderHandler},
        route{"/presence", presenceHandler},
        route{"/orders/", orderPathHandler},
    )
}
