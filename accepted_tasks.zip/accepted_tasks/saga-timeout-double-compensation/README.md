# Saga timeout double compensation

A Go saga settlement service incorrectly refunds senders for deliveries that were later acknowledged after timeout, causing senders to retain both the refund and the delivery, and allowing credits to exceed charges.

## Scenario

The agent works with a Go HTTP service that manages order deliveries with saga-based compensation. Orders are charged upfront, delivered to recipients, and may time out. On timeout, unacknowledged deliveries are refunded. On recovery after a crash, pending refunds are replayed.

## Root cause (hidden from the agent)

settleOrder uses a single credit key (namespace:order) shared across all recipients, so only the first un-acked recipient is credited. Recovery uses a different namespace, causing duplicate credits. More critically, when a delivery is acknowledged after already being credited/refunded, ackDelivery does not reverse the credit, so the sender retains both the refund and the delivery fee charge.

## Correctness constraints

- **C1**: Credits for a given order never exceed the amount charged for that order.
- **C2**: After deadline expiry and recovery, a sender with no acknowledged deliveries holds the balance they had before the order.
- **C3**: The net debit for acknowledged deliveries equals the fee per acknowledged delivery.

## Subgoals

1. Make credit keys per-delivery (namespace:order:recipient) so each recipient is credited independently
2. Skip already-credited deliveries in settleOrder to prevent duplicate credits
3. Reverse the credit when an acknowledgment arrives for a delivery that was already credited

## Failure scenario

After an order times out and settlement credits the sender for an unacknowledged delivery, an acknowledgment arrives but does not reverse the credit. The sender ends up with both the refund and the delivery fee charged. Recovery replay can also double-credit due to shared credit keys.

## Expected agent pitfalls

- Adding per-delivery idempotency keys without also reversing credits on acknowledgment fixes the double-credit but leaves the net-debit invariant broken
- Capping credits at the order charge without reversing on ack hides the symptom but violates the net-debit invariant for acknowledged deliveries
- Only fixing the recovery path without fixing the live timeout path misses the core issue

## Anti-shortcut measures

- Tests check net debit per acknowledged delivery, not just total balance, so capping credits without reversal fails
- Randomized schedules with kill/restart ensure recovery correctness under crash scenarios
- Multi-recipient orders test partial ack scenarios that expose incomplete fixes

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_1_credit_cap`, `test_counterexample` |
| C2 | `test_invariant_2_sender_balance_no_acks`, `test_counterexample`, `test_crash_recovery_balance` |
| C3 | `test_invariant_3_net_debit_acked`, `test_counterexample`, `test_ack_after_settlement`, `test_multi_recipient_order` |
