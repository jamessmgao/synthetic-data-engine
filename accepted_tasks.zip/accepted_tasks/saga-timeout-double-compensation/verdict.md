# Verdict: aws-w8-l1-new-t04

**ACCEPTED: v2 passed 2 of 4 scored agent runs, early-stopped (band 1–3 of 5 was certain)**

## Spec

```json
{
  "dial": 3,
  "difficulty": {
    "dial": 3,
    "form": "behavior_preserving"
  },
  "domain": "chat_presence",
  "domain_label": "chat presence and message fan-out service",
  "environment": "Go service",
  "family": "cross_component_stateful",
  "mechanism": "saga_timeout_double_compensation",
  "mechanism_note": "a step times out after succeeding; the orchestrator compensates and recovery replay compensates again; a per-order idempotency key blocks legitimate partial refunds",
  "shape": "fix",
  "taxonomy": {
    "core_capability": "saga timeout double compensation",
    "domain": "chat_presence",
    "environment": "Go service",
    "failure_mode": "saga timeout double compensation",
    "skill_interaction": "multiple interacting constraints",
    "task_type": "Debugging"
  },
  "verification": "state_machine_test"
}
```

## Versions

| v | origin | operator | mutations | world | bundle | gates | runs |
|---|---|---|---|---|---|---|---|
| 1 | initial | - | - | `923c6cf22aed` (OK) | `b61880ab49c6` | OK (wrong_fix ✓, leak ✓) | ✓✓✓✓✓ |
| 2 | mutation | - | remove_cues, generate_counterexample, introduce_temporal_constraint | `9456dc4af243` (OK) | `337316945dd9` | OK (wrong_fix ✓, leak ✓) | ✗✓✗✓· |

## World mutations

- v1 → v2 (4/5 passed, harder): remove_cues, generate_counterexample, introduce_temporal_constraint
  - the instruction points at the fix; rewrite those sentences at the interface level
  - Make acknowledgments a concurrently served operation that can arrive at any time — including after compensation has started — and state in the instruction that the service can be killed between any two durable writes (e.g., after a refund is persisted but before the saga's compensated status is persisted), with POST /recovery still required to leave all balances correct. The current simple fix — refund, then mark the saga compensated — fails in these interleavings: an ack landing mid-compensation, or a crash in the refund/status write window followed by recovery, re-refunds or refunds an already-acked delivery. A correct solution must persist a single per-order compensation decision that both the live path and recovery consult, which the current task never exercises because recovery compensates a static, already-settled set of timeout sagas (E21).
  - the fix leaned on timing; the order of operations must matter
  - aimed at: The evidence contains no diffs, so the exact edit can only be bounded: every passing run wrote exactly `recovery.go`, `saga.go`, and `store.go` (E1, E18, E35). Their analyses state what they targeted: making refund accounting idempotent and capped against the order charge instead of per-delivery/namespace-keyed (E4, E5, E22, E39), and making recovery reconstruct correct balances across the crash window (E21, E38: recovery compensation via a namespace key, timeout-marked sagas).

## Rollouts

| job | outcome | reward | error | cost | trace |
|---|---|---|---|---|---|
| aws-w8-l1-new-t04-v1-rollout1-r0 | VALID_PASS | 1.0 |  | $0.0391 | s3://sde-pipeline-artifacts-284460774261/traces/aws-w8-l1-new-t04-v1-rollout1-r0/ |
| aws-w8-l1-new-t04-v1-rollout2-r0 | VALID_PASS | 1.0 |  | $0.0361 | s3://sde-pipeline-artifacts-284460774261/traces/aws-w8-l1-new-t04-v1-rollout2-r0/ |
| aws-w8-l1-new-t04-v1-rollout3-r0 | VALID_PASS | 1.0 |  | $0.0415 | s3://sde-pipeline-artifacts-284460774261/traces/aws-w8-l1-new-t04-v1-rollout3-r0/ |
| aws-w8-l1-new-t04-v1-rollout4-r0 | VALID_PASS | 1.0 |  | $0.0803 | s3://sde-pipeline-artifacts-284460774261/traces/aws-w8-l1-new-t04-v1-rollout4-r0/ |
| aws-w8-l1-new-t04-v1-rollout5-r0 | VALID_PASS | 1.0 |  | $0.0342 | s3://sde-pipeline-artifacts-284460774261/traces/aws-w8-l1-new-t04-v1-rollout5-r0/ |
| aws-w8-l1-new-t04-v2-rollout1-r0 | VALID_FAIL | 0.0 |  | $0.0798 | s3://sde-pipeline-artifacts-284460774261/traces/aws-w8-l1-new-t04-v2-rollout1-r0/ |
| aws-w8-l1-new-t04-v2-rollout2-r0 | VALID_PASS | 1.0 |  | $0.0398 | s3://sde-pipeline-artifacts-284460774261/traces/aws-w8-l1-new-t04-v2-rollout2-r0/ |
| aws-w8-l1-new-t04-v2-rollout3-r0 | VALID_FAIL | 0.0 |  | $0.1159 | s3://sde-pipeline-artifacts-284460774261/traces/aws-w8-l1-new-t04-v2-rollout3-r0/ |
| aws-w8-l1-new-t04-v2-rollout4-r0 | VALID_PASS | 1.0 |  | $0.0815 | s3://sde-pipeline-artifacts-284460774261/traces/aws-w8-l1-new-t04-v2-rollout4-r0/ |
| aws-w8-l1-new-t04-v2-rollout5-r0 | SKIPPED | - | early-stopped: certain in band after 4 scored | - | - |

## Why runs failed

### aws-w8-l1-new-t04-v2-rollout1-r0
- attribution: model
- failing tests: test_outputs.py::test_counterexample, test_outputs.py::test_invariant_1_credit_cap, test_outputs.py::test_invariant_2_sender_balance_no_acks, test_outputs.py::test_invariant_3_net_debit_acked, test_outputs.py::test_ack_after_settlement, test_outputs.py::test_crash_recovery_balance
- explanation: The failures are all genuine invariant violations of exactly what the instruction required, and the agent's own actions show it verified too narrowly and declared success prematurely.

**The tests check what the instruction asked for.** The instruction states that "After recovery, a sender with no acknowledged deliveries must hold exactly the balance they had before the order" — this is precisely what test_counterexample (E2: 'After o1 timeout+recovery, alice balance=110, expected 100'), test_ack_after_settlement (E15: 'After ack: 100, expected 90'), and test_crash_recovery_balance (E18: 'After crash recovery: 110, expected 100') verify. The instruction states "Refunds for an order must never exceed what was charged" — test_invariant_1_credit_cap checks exactly this (E5: 'credits=20 > charge=10'). The instruction states "Each acknowledged delivery must cost exactly its per-delivery fee — no more, no less" — test_invariant_2_sender_balance_no_acks (E8) and test_invariant_3_net_debit_acked (E11) check debit/charge exactness. Every failing test maps directly to a requirement in the visible instruction; none checks behavior the instruction never asked for, and there is no contradiction between the instruction and the tests.

**The failures reflect real implementation bugs, not environment breakage.** The assertion errors are consistent behavioral symptoms — balances too high after recovery (E2, E18), refunds exceeding charges (E5), and incorrect net debits (E11) — i.e., the code over-credits senders, which the instruction explicitly prohibits. There is no evidence of a broken environment, missing service, or flaky harness; the verifier ran to the call phase and produced concrete, deterministic assertions.

**The model's process was inadequate.** The agent's own verification consisted of `go test ./...` and a build check (E24), then declared the task complete twice (E26, E27) with the claim that 'all tested scenarios passed' (E28). Yet the verifier's Python-based tests failed on every stated requirement (E1–E19). The agent never exercised the actual failure modes the verifier tests (timeout+recovery balance, credit caps, net debit after acks, crash recovery) through the service's HTTP/behavioral surface — it relied only on its Go unit tests, which evidently did not cover the recovery/refund logic the instruction centered on. The discrepancy between 'all tested scenarios passed' (E28) and seven verifier failures (E1–E19) shows the model's own tests were insufficient and its completion declaration was unfounded.

Nothing in the evidence suggests an ambiguous instruction, a broken environment, or tests exceeding the stated requirements, so the failure is attributable to the model.
  > FAILED test_outputs.py::test_counterexample - The test failed in the call phase due to an assertion error
  > E           AssertionError: After o1 timeout+recovery, alice balance=110, expected 100
  > E           assert 110 == 100
  > FAILED test_outputs.py::test_invariant_1_credit_cap - The test failed in the call phase due to an assertion error
  > E           AssertionError: Order o1: credits=20 > charge=10
  > E           assert 20 <= 10
  > FAILED test_outputs.py::test_invariant_2_sender_balance_no_acks - The test failed in the call phase due to an assertion error
  > E           AssertionError: Order o2: no acks but credits=10 != charge=20
  > E           assert 10 == 20
  > FAILED test_outputs.py::test_invariant_3_net_debit_acked - The test failed in the call phase due to an assertion error
  > E           AssertionError: Account a2: net_debit=20 != expected=40
  > E           assert 20 == 40
  > FAILED test_outputs.py::test_ack_after_settlement - The test failed in the call phase due to an assertion error
  > assert bal_after_timeout == 100, f'After timeout: {bal_after_timeout}'
  > E           AssertionError: After ack: 100, expected 90
  > E           assert 100 == 90
  > FAILED test_outputs.py::test_crash_recovery_balance - The test failed in the call phase due to an assertion error
  > E           AssertionError: After crash recovery: 110, expected 100
  > E           assert 110 == 100
  > $ git rev-parse --is-inside-work-tree 2>&1 || true; ps -eo pid,ppid,cmd | grep '/tmp/service' | grep -v grep || true
  > $ grep -n -A45 'func (s \*Store) ackDelivery\|func (s \*Store) settleSaga\|func (s \*Store) creditAccount' store.go
  > $ ps -eo pid,ppid,cmd | grep '/tmp/service' | grep -v grep || true
→ New Terminal Output:

agent@8cea04956617:/app$ ps -eo pid,ppid,cmd | grep '/tmp/service' | grep -v grep || true
   3790     296 /tmp/service
agent@8cea04956617:/app$
  > $ kill 3790; sleep 0.2; rm -f /tmp/service /tmp/service-final /tmp/test-state*.json /tmp/race-state.json /tmp/restart-state.json /tmp/*.log /tmp/service*.pid /tmp/race*.pid /tmp/restart*.pid
  > $ go test ./... && go build -o /tmp/service-check . && rm -f /tmp/service-check
  > $ ps -eo pid,ppid,cmd | grep '/tmp/service' | grep -v grep || true
  > agent declared the task complete
  > agent declared the task complete
  > final message: Analysis: Yes. The implementation compiles and all tested scenarios passed: exact recovery for orders with no acknowledged deliveries, per-delivery exact fees, idempotent acknowledgement and recovery, late ACK after timeout, concurrent ACK/settlement, and durable clock/state recovery after restart.
Plan: No further changes are needed.

### aws-w8-l1-new-t04-v2-rollout3-r0
- attribution: model
- failing tests: test_outputs.py::test_invariant_3_net_debit_acked, test_outputs.py::test_ack_after_settlement, test_outputs.py::test_crash_recovery_balance, test_outputs.py::test_multi_recipient_order
- explanation: The instruction explicitly requires that 'Each acknowledged delivery must cost exactly its per-delivery fee — no more, no less' and that balances must not be too high after recovery [task instruction]. The failing tests check precisely these behaviors: test_ack_after_settlement expects the balance to drop to 90 after an acknowledgement, but the service returns 100 — the sender was never charged for the acknowledged delivery [E5][E6][E7]. The same 'balance too high' symptom appears in test_crash_recovery_balance (100 vs 90) [E9][E10][E11], test_multi_recipient_order (100 vs 90 after a partial ack) [E13][E14], and test_invariant_3_net_debit_acked, where the acknowledged sender's net debit is 0 instead of the expected 20 [E2][E3]. None of these tests contradict the instruction — they directly implement 'after timeout/refund, a subsequent acknowledged delivery must cost exactly its per-delivery fee,' so the instruction is neither ambiguous nor inconsistent with the tests, and nothing in the evidence suggests a broken environment. The agent's own evidence shows it only ran Go builds, vet, and Go tests [E16][E18][E19], never the verifier's test_outputs.py, and twice declared the task complete with the final claim that 'All targeted tests passed' [E21][E22][E23], which the verifier results [E1][E4][E8][E12] contradict. Therefore the failure is attributable to the model's implementation, which failed to debit the per-delivery fee after settlement/refund.
  > FAILED test_outputs.py::test_invariant_3_net_debit_acked - The test failed in the call phase due to an assertion error
  > E           AssertionError: Account a2: net_debit=0 != expected=20
  > E           assert 0 == 20
  > FAILED test_outputs.py::test_ack_after_settlement - The test failed in the call phase due to an assertion error
  > assert bal_after_timeout == 100, f'After timeout: {bal_after_timeout}'
  > E           AssertionError: After ack: 100, expected 90
  > E           assert 100 == 90
  > FAILED test_outputs.py::test_crash_recovery_balance - The test failed in the call phase due to an assertion error
  > assert bal == 100, f'After crash recovery: {bal}, expected 100'
  > E           AssertionError: After ack post-recovery: 100, expected 90
  > E           assert 100 == 90
  > FAILED test_outputs.py::test_multi_recipient_order - The test failed in the call phase due to an assertion error
  > E           AssertionError: After partial ack: 100, expected 90
  > E           assert 100 == 90
  > $ python3 -m json.tool /tmp/final-state.json | sed -n '1,170p'; nl -ba store.go | sed -n '130,150p'
  > $ go build -o /app/service . && go vet . && go test -run '^$' -count=1 . && echo FINAL_CHECK_OK; ls -la
  > $ rm -f /tmp/no-ack-state.json*; STATE_PATH=/tmp/no-ack-state.json PORT=18089 /app/service >/tmp/no-ack.log 2>&1 & echo $! >/tmp/no-ack.pid; sleep 0.2; curl -sS -X POST localhost:18089/accounts -d '{"account":"s","balance":37}' >/dev/null; curl -sS -X POST localhost:18089/orders -d '{"orderId":"o","se
  > $ gofmt -w saga.go store.go recovery.go && go build -o /app/service . && go vet . && go test -run '^$' -count=1 . && echo ALL_CHECKS_OK
  > $ timeout 20 go test ./...; echo normal_test_status=$?
  > $ pgrep -af '/app/service|/tmp/service' || true
  > agent declared the task complete
  > agent declared the task complete
  > final message: Analysis: All targeted tests passed and no service processes are running.
Plan: No further action.

## Cost

$12.1167 recorded across 21 jobs.
