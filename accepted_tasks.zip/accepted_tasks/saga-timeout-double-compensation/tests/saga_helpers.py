"""Helper module for saga timeout settlement tests."""
import subprocess
import json
import time
import os
import socket
import http.client


def find_free_port():
    """Find a free TCP port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return s.getsockname()[1]


def start_service(state_path, port, timeout=15):
    """Start the service and wait for it to be healthy."""
    env = os.environ.copy()
    env['STATE_PATH'] = state_path
    env['PORT'] = str(port)
    env['GOCACHE'] = '/tmp/gocache'
    proc = subprocess.Popen(
        ['/app/service'],
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            conn = http.client.HTTPConnection('127.0.0.1', port, timeout=1)
            conn.request('GET', '/healthz')
            resp = conn.getresponse()
            conn.close()
            if resp.status == 200:
                return proc
        except Exception:
            pass
        time.sleep(0.05)
    proc.kill()
    proc.wait(timeout=5)
    raise RuntimeError('Service failed to start within timeout')


def stop_service(proc, timeout=5):
    """Stop the service gracefully."""
    proc.terminate()
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=timeout)


def kill_service(proc, timeout=5):
    """Kill the service abruptly (simulates crash)."""
    proc.kill()
    proc.wait(timeout=timeout)


def post(port, path, body=None, timeout=10):
    """Make a POST request to the service."""
    conn = http.client.HTTPConnection('127.0.0.1', port, timeout=timeout)
    if body is not None:
        conn.request('POST', path, json.dumps(body), {'Content-Type': 'application/json'})
    else:
        conn.request('POST', path, '', {'Content-Type': 'application/json'})
    resp = conn.getresponse()
    data = resp.read()
    conn.close()
    try:
        parsed = json.loads(data) if data else {}
    except json.JSONDecodeError:
        parsed = {}
    return resp.status, parsed


def get(port, path, timeout=10):
    """Make a GET request to the service."""
    conn = http.client.HTTPConnection('127.0.0.1', port, timeout=timeout)
    conn.request('GET', path)
    resp = conn.getresponse()
    data = resp.read()
    conn.close()
    try:
        parsed = json.loads(data) if data else {}
    except json.JSONDecodeError:
        parsed = {}
    return resp.status, parsed


def get_balance(port, account):
    """Get the balance of an account."""
    status, data = get(port, f'/accounts/{account}')
    if status != 200:
        return None
    return data.get('balance')


def get_state(port):
    """Get the full world state."""
    status, data = get(port, '/state')
    return data if status == 200 else {}
