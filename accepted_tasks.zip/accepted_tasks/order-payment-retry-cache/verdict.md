# Verdict: aws-iter2-t07

**ACCEPTED: v1 passed 3/5 valid rollouts (band 1–3)**

## Spec

```json
{
  "dial": 3,
  "difficulty": {
    "dial": 3,
    "form": "behavior_preserving"
  },
  "environment": "Python service",
  "family": "cross_component_stateful",
  "mechanism": "retry_cache_commit_interaction",
  "shape": "fix",
  "taxonomy": {
    "core_capability": "retry cache commit interaction",
    "domain": "Stateful cross-component systems",
    "environment": "Python service",
    "failure_mode": "retry cache commit interaction",
    "skill_interaction": "multiple interacting constraints",
    "task_type": "Debugging"
  },
  "verification": "integration"
}
```

## Versions

| v | origin | operator | mutations | world | bundle | gates | runs |
|---|---|---|---|---|---|---|---|
| 1 | initial | - | - | `ab2db672fbc1` (OK) | `0876aedc7258` | OK (wrong_fix ✓, leak ✓) | ✓✓✓✗✗ |

## Rollouts

| job | outcome | reward | error | cost | trace |
|---|---|---|---|---|---|
| aws-iter2-t07-v1-rollout1-r0 | VALID_PASS | 1.0 |  | $0.1274 | s3://sde-pipeline-artifacts-284460774261/traces/aws-iter2-t07-v1-rollout1-r0/ |
| aws-iter2-t07-v1-rollout2-r0 | VALID_PASS | 1.0 |  | $0.1711 | s3://sde-pipeline-artifacts-284460774261/traces/aws-iter2-t07-v1-rollout2-r0/ |
| aws-iter2-t07-v1-rollout3-r0 | VALID_PASS | 1.0 |  | $0.0694 | s3://sde-pipeline-artifacts-284460774261/traces/aws-iter2-t07-v1-rollout3-r0/ |
| aws-iter2-t07-v1-rollout4-r0 | VALID_FAIL | 0.0 |  | $0.0289 | s3://sde-pipeline-artifacts-284460774261/traces/aws-iter2-t07-v1-rollout4-r0/ |
| aws-iter2-t07-v1-rollout5-r0 | VALID_FAIL | 0.0 |  | $0.0743 | s3://sde-pipeline-artifacts-284460774261/traces/aws-iter2-t07-v1-rollout5-r0/ |

## Why runs failed

### aws-iter2-t07-v1-rollout4-r0
- attribution: model
- failing tests: test_outputs.py::test_counterexample_lost_capture_retry, test_outputs.py::test_direct_capture_and_duplicate_request_regression
- explanation: The failing tests point to concrete, reproducible mismatches in the service's output that the model introduced or failed to verify, and nothing in the evidence shows the task instruction, environment, or tests are unfair.

**What the failures are.** The verifier shows two failed tests with precise assertion diffs. In `test_countercounterexample_lost_capture_retry`, the expected `request_id` is `'order-1:1'` but the service produced `'order-1'` [E2, E4, E5, E7]. In `test_direct_capture_and_duplicate_request_regression`, a status/ledger dict comparison failed: the two dicts share 6 identical items but differ in others, and the expected `request_id` is `'edge-1'` with `status == 'captured'` [E8, E9, E10, E11, E12, E14]. These are deterministic output-shape/value mismatches, not flaky or environment errors — the tests ran and produced explicit expected-vs-actual diffs.

**Why this is a model failure, not a task failure.** The instruction explicitly requires preserving "normal captured and declined handling, duplicate request behavior, and the documented JSON CLI output," so output-format fidelity is in scope; a test asserting exact `request_id` and captured-status fields [E3, E5, E10] checks behavior the instruction asks the agent to preserve. There is no evidence of a broken environment (the agent's own scripts ran fine and files compiled [E16, E20]), no evidence of contradictory or ambiguous instructions, and no evidence that the tests check behavior the instruction never asked for — the hidden-spec section is explicitly empty. Notably, the failure in [E5] (`'order-1'` vs `'order-1:1'`) is exactly the kind of request-ID handling the instruction highlights ("each request ID is captured at most once, even across restarts, retries, and concurrent requests"), suggesting the model altered request-ID representation and broke expected retry/duplicate output.

**The agent also self-verified with its own tests instead of the real ones.** The agent built its own migration fixtures and scenario scripts [E15, E18, E19], reported "all durable-state assertions passed" [E20], and declared the task complete twice [E21, E22], asserting "all end-to-end, crash-recovery, legacy-state migration, and concurrent-worker tests passed" [E23] — yet the verifier's `test_outputs.py` failed on both a lost-capture-retry case and a direct-capture/duplicate regression case [E1, E8]. The agent's grep-based checks [E16] never exercised the verifier's expected output contract. The gap between the agent's claimed success [E23] and the two concrete assertion failures [E5, E12] is a classic case of validating against self-constructed expectations rather than the actual required behavior — a model-process failure, not a task defect.
  > FAILED test_outputs.py::test_counterexample_lost_capture_retry - The test failed in the call phase due to an assertion error
  > assert created == {
  > assert first["status"] == "retrying"
  > assert first["request_id"] == "order-1"
  > E           AssertionError: assert 'order-1' == 'order-1:1'
  > E
  > E             - order-1:1
  > FAILED test_outputs.py::test_direct_capture_and_duplicate_request_regression - The test failed in the call phase due to an assertion error
  > assert created == {
  > assert worked["status"] == "captured"
  > assert worked["request_id"] == "edge-1"
  > E           AssertionError: assert {'amount': 7,...tity': 1, ...} == {'amount': 7,...tity': 1, ...}
  > E
  > E             Omitting 6 identical items, use -vv to show
  > $ rm -rf /tmp/orders-migrate && mkdir -p /tmp/orders-migrate
printf '%s\n' '{"status":"captured"}' > /tmp/orders-migrate/responses
python3 - <<'PY'
import json, sqlite3
p = '/tmp/orders-migrate/db.sqlite'
db = sqlite3.connect(p)
db.executescript('''
CREATE TABLE orders (request_id TEXT PRIMARY KEY, sk
  > $ python3 -m py_compile main.py payments.py store.py && grep -RIn 'finish_job_if_present\|operation_id =\|add_capture_entry\|capture_for' main.py payments.py store.py
  > $ python3 - <<'PY'
from pathlib import Path
path = Path('store.py')
text = path.read_text()
old = '''        entry = self.captured_entry(request_id)
        if entry is None:
            # Reconcile an old timeout row now that the gateway has confirmed
            # the capture instead of leaving ambi
  > $ printf '%s\n' '--- crash after gateway call ---'
python3 main.py --data /tmp/orders-crash-call/db.sqlite --gateway-responses /tmp/orders-crash-call/responses --gateway-state /tmp/orders-crash-call/gateway.json status
printf '%s\n' '--- stale captured migration ---'
rm -rf /tmp/orders-stale && mkdir 
  > $ python3 - <<'PY'
import json
import subprocess

def status(root):
    return json.loads(subprocess.check_output([
        'python3', 'main.py', '--data', f'{root}/db.sqlite',
        '--gateway-responses', f'{root}/responses',
        '--gateway-state', f'{root}/gateway.json', 'status',
    ]))

for
  > $ 
→ New Terminal Output:
ed')
> PY
all durable-state assertions passed
agent@b91746aae8b2:/app$ python3 -m compileall -q main.py payments.py store.py
agent@b91746aae8b2:/app$
  > agent declared the task complete
  > agent declared the task complete
  > final message: Analysis: Yes. The implementation compiles successfully, and all end-to-end, crash-recovery, legacy-state migration, and concurrent-worker tests passed. Assertions confirmed one gateway capture and exactly one matching captured ledger entry per request ID, with the correct receipt and amount.
Plan: No further changes are needed.

### aws-iter2-t07-v1-rollout5-r0
- attribution: model
- failing tests: test_outputs.py::test_counterexample_lost_capture_retry
- explanation: The hidden verifier test for the lost-capture-retry scenario failed on a value assertion, not on any environmental or spec problem [E1]. The test expected the captured ledger entry's `request_id` to be the original `
  > FAILED test_outputs.py::test_counterexample_lost_capture_retry - The test failed in the call phase due to an assertion error
  > assert created == {
  > assert first["status"] == "retrying"
  > assert first["request_id"] == "order-1"
  > E           AssertionError: assert 'order-1' == 'order-1:1'
  > E
  > E             - order-1:1
  > $ rm -rf /tmp/order-final-captured && mkdir -p /tmp/order-final-captured && printf '%s\n' '{"status":"captured"}' > /tmp/order-final-captured/responses.jsonl
base=(python3 main.py --data /tmp/order-final-captured/service.db --gateway-responses /tmp/order-final-captured/responses.jsonl --gateway-state 
  > $ rm -rf /tmp/order-final-declined && mkdir -p /tmp/order-final-declined && printf '%s\n' '{"status":"declined"}' > /tmp/order-final-declined/responses.jsonl
base=(python3 main.py --data /tmp/order-final-declined/service.db --gateway-responses /tmp/order-final-declined/responses.jsonl --gateway-state 
  > $ python3 - <<'PY'
from pathlib import Path
p = Path('store.py')
s = p.read_text()
old = '''CREATE INDEX IF NOT EXISTS ledger_request_idx ON ledger(request_id);
CREATE UNIQUE INDEX IF NOT EXISTS ledger_captured_request_idx
    ON ledger(request_id) WHERE state = 'captured';
"""
'''
new = '''CREATE IND
  > $ rm -rf /tmp/order-migration2 && mkdir -p /tmp/order-migration2
python3 - <<'PY'
import sqlite3
con = sqlite3.connect('/tmp/order-migration2/service.db')
con.executescript('''
CREATE TABLE orders (request_id TEXT PRIMARY KEY, sku TEXT NOT NULL, quantity INTEGER NOT NULL, amount INTEGER NOT NULL, stat
  > $ python3 - <<'PY'
import json
status = json.load(open('/tmp/order-final-declined/status.json'))
assert status['gateway_captures'] == [], status
assert len([row for row in status['ledger'] if row['state'] == 'declined']) == 1, status
assert status['orders'][0]['status'] == 'blocked', status
assert sta
  > $ rm -rf /tmp/order-smoke-final && mkdir -p /tmp/order-smoke-final && printf '%s\n' '{"status":"timeout"}' > /tmp/order-smoke-final/responses.jsonl
base=(python3 main.py --data /tmp/order-smoke-final/service.db --gateway-responses /tmp/order-smoke-final/responses.jsonl --gateway-state /tmp/order-smoke
→ er'] if row['state'] == 'captured']
> assert len(captures) == 1, status
> assert captures[0]['amount'] == 800, status
> assert captures[0]['receipt'] == status['gateway_captures'][0]['receipt'], status
> assert status['orders'][0]['status'] == 'captured', status
> assert status['queue'] == [], status
> print('final timeout-recovery smoke test passed')
> PY
final timeout-recovery smoke test passed
agent@33ac2c99df1c:/app$ python3 -m py_compile main.py store.py payments.py
agent@33ac2c99df1c:/app$
  > agent declared the task complete
  > agent declared the task complete
  > final message: Analysis: Yes. The implementation compiles and all required scenarios passed, including timeout retry after a lost response, post-capture worker death recovery, concurrent workers and creates, duplicate request handling, normal captured and declined behavior, legacy stuck-state recovery, and exactly-once ledger/receipt validation.
Plan: No further changes are needed.

## Cost

$1.8732 recorded across 10 jobs.
