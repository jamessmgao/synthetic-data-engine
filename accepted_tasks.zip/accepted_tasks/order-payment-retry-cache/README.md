# Recover lost payment captures exactly once

A Python order service can receive a gateway capture whose response is lost. Retries currently interact badly with cached responses and durable gateway state. The fix must recover the order while preserving one capture and one matching ledger entry.

## Scenario

The service exposes create, worker, and status commands backed by SQLite and a deterministic gateway adapter. Clients retry request IDs, workers run in separate processes, and a worker may be killed and restarted.

## Root cause (hidden from the agent)

A timeout is cached as a terminal-looking response, while the gateway has already durably recorded the operation as captured. Subsequent attempts also generate new operation IDs, so the gateway cannot deduplicate them.

## Correctness constraints

- **C1**: Each order request ID causes at most one payment gateway capture across retries, restarts, crashes, and concurrent order creation.
- **C2**: Every payment captured by the gateway for an accepted order has one matching captured ledger entry with the same receipt and order amount.
- **C3**: An accepted order whose captured payment response is lost still finishes as captured after a client retry.
- **C4**: Normal direct capture and decline handling, duplicate request behavior, empty-worker behavior, and the documented JSON command outcomes remain working.

## Subgoals

1. Represent an unresolved gateway operation durably enough to identify it after a process restart.
2. Reuse the gateway operation identity when retrying a lost response.
3. Reconcile the durable capture to exactly one captured ledger entry and finish the order.
4. Preserve direct capture, decline, duplicate request, and empty-queue behavior.

## Failure scenario

Create order-1, process it with a timeout journal response, retry it from a new process, and process again. The gateway contains one capture, but the order is blocked or retrying, its queue action is gone or mishandled, and its ledger has only an unknown entry. A fix must leave the order captured with one capture and one matching captured ledger entry.

## Expected agent pitfalls

- Removing the cached timeout response without preserving the original gateway operation identity.
- Storing retry metadata only in process memory, so it is lost when the worker exits.
- Writing a captured ledger entry without reconciling the gateway receipt.
- Breaking declines, duplicate requests, or normal direct captures while handling timeouts.

## Anti-shortcut measures

- Integration tests drive only the documented CLI and inspect its JSON status output.
- Fixed-seed schedules include SIGKILL, restart, retries, duplicate retries, and concurrent creates.
- Tests reject a new operation ID after a lost response because it creates a second gateway capture.
- Regression tests pin direct captured and declined outcomes and duplicate request behavior.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_each_request_id_causes_at_most_one_gateway_capture`, `test_counterexample_lost_capture_retry`, `test_direct_capture_and_duplicate_request_regression` |
| C2 | `test_each_gateway_capture_has_one_matching_captured_ledger_entry`, `test_counterexample_lost_capture_retry`, `test_direct_capture_and_duplicate_request_regression` |
| C3 | `test_lost_captured_response_finishes_captured_after_client_retry`, `test_counterexample_lost_capture_retry` |
| C4 | `test_direct_capture_and_duplicate_request_regression`, `test_declined_order_and_empty_worker_edge_case` |
