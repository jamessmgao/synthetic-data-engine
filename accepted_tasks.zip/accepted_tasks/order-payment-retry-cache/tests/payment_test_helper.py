import json
import os
import signal
import subprocess
import time
from pathlib import Path


class ServiceRun:
    """Drive the order service only through its command-line interface."""

    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.data = self.root / "orders.sqlite"
        self.responses = self.root / "gateway-responses"
        self.gateway_state = self.root / "gateway-state.json"

    def _base(self):
        return [
            "python3", "/app/main.py",
            "--data", str(self.data),
            "--gateway-responses", str(self.responses),
            "--gateway-state", str(self.gateway_state),
        ]

    def run(self, *args):
        completed = subprocess.run(
            self._base() + list(args), cwd="/app", text=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10,
        )
        if completed.returncode != 0:
            raise AssertionError(
                f"command failed ({completed.returncode}): {args}\n"
                f"stdout={completed.stdout!r}\nstderr={completed.stderr!r}"
            )
        try:
            return json.loads(completed.stdout)
        except json.JSONDecodeError as exc:
            raise AssertionError(
                f"non-JSON output for {args}: {completed.stdout!r}"
            ) from exc

    def write_responses(self, statuses):
        if self.responses.exists() or self.responses.is_fifo():
            self.responses.unlink()
        self.responses.write_text(
            "".join(json.dumps({"status": status}) + "\n" for status in statuses)
        )

    def create(self, request_id, sku, quantity, amount, now):
        return self.run(
            "create", "--request-id", request_id, "--sku", sku,
            "--quantity", str(quantity), "--amount", str(amount),
            "--now", str(now),
        )

    def worker(self, now):
        return self.run("worker", "--now", str(now))

    def status(self):
        return self.run("status")

    def kill_worker_while_waiting(self, now):
        """Start a worker, SIGKILL it while it waits for a gateway response."""
        if self.responses.exists() or self.responses.is_fifo():
            self.responses.unlink()
        os.mkfifo(self.responses)
        process = subprocess.Popen(
            self._base() + ["worker", "--now", str(now)], cwd="/app",
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        )
        time.sleep(0.03)
        if process.poll() is not None:
            process.communicate()
            if self.responses.is_fifo():
                self.responses.unlink()
            raise AssertionError("worker exited before the test could SIGKILL it")
        os.kill(process.pid, signal.SIGKILL)
        process.wait(timeout=10)
        process.communicate()
        if self.responses.is_fifo():
            self.responses.unlink()

    def order(self, state, request_id):
        return next(
            (row for row in state["orders"] if row["request_id"] == request_id),
            None,
        )

    def captures(self, state, request_id):
        return [row for row in state["gateway_captures"] if row["request_id"] == request_id]

    def ledger(self, state, request_id, ledger_state=None):
        rows = [row for row in state["ledger"] if row["request_id"] == request_id]
        if ledger_state is not None:
            rows = [row for row in rows if row["state"] == ledger_state]
        return rows

    def create_concurrently(self, orders):
        """Create independent orders from concurrently launched CLI processes."""
        processes = []
        for order in orders:
            args = [
                "create", "--request-id", order["request_id"],
                "--sku", order["sku"], "--quantity", str(order["quantity"]),
                "--amount", str(order["amount"]), "--now", str(order["now"]),
            ]
            processes.append(subprocess.Popen(
                self._base() + args, cwd="/app", stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, text=True,
            ))
        results = []
        for process in processes:
            stdout, stderr = process.communicate(timeout=10)
            if process.returncode != 0:
                raise AssertionError(
                    f"concurrent create failed: {stdout!r} {stderr!r}"
                )
            results.append(json.loads(stdout))
        return results


def random_recovery_schedule(service, seed):
    """Yield observable checkpoints for a deterministic crash/retry schedule."""
    import random

    rng = random.Random(seed)
    first = {
        "request_id": f"order-{seed}-first",
        "sku": rng.choice(["widget", "gadget", "book"]),
        "quantity": rng.randint(1, 5),
        "amount": rng.randint(1, 500),
        "now": 10 + seed,
    }
    second = {
        "request_id": f"order-{seed}-second",
        "sku": rng.choice(["widget", "gadget", "book"]),
        "quantity": rng.randint(1, 5),
        "amount": rng.randint(1, 500),
        "now": 20 + seed,
    }
    pair = [first, second]
    rng.shuffle(pair)
    service.create_concurrently(pair)
    context = {"seed": seed, "orders": {first["request_id"]: first, second["request_id"]: second}}
    yield "created", service.status(), context

    service.kill_worker_while_waiting(now=30 + seed)
    yield "worker_killed", service.status(), context

    second_status = rng.choice(["captured", "declined", "timeout"])
    context["second_status"] = second_status
    service.write_responses(["timeout", second_status])
    first_result = service.worker(now=40 + seed)
    context["first_id"] = first_result["request_id"]
    context["first_worker_result"] = first_result
    yield "lost_response", service.status(), context

    service.create(
        context["first_id"],
        context["orders"][context["first_id"]]["sku"],
        context["orders"][context["first_id"]]["quantity"],
        context["orders"][context["first_id"]]["amount"],
        now=50 + seed,
    )
    yield "retry_requested", service.status(), context

    recovered = service.worker(now=60 + seed)
    context["first_retry_result"] = recovered
    yield "first_recovered", service.status(), context

    second_worker = service.worker(now=70 + seed)
    context["second_id"] = second_worker["request_id"]
    context["second_worker_result"] = second_worker
    yield "second_response", service.status(), context

    if second_status == "timeout":
        service.write_responses(["timeout", "timeout", "captured"])
        second_order = context["orders"][context["second_id"]]
        service.create(
            context["second_id"], second_order["sku"],
            second_order["quantity"], second_order["amount"],
            now=80 + seed,
        )
        yield "second_retry_requested", service.status(), context
        second_retry = service.worker(now=90 + seed)
        context["second_retry_result"] = second_retry
        yield "second_recovered", service.status(), context

    for index in range(rng.randint(0, 2)):
        first_order = context["orders"][context["first_id"]]
        service.create(
            context["first_id"], first_order["sku"],
            first_order["quantity"], first_order["amount"],
            now=100 + seed + index,
        )
        yield f"duplicate_requested_{index}", service.status(), context
        worker_result = service.worker(now=110 + seed + index)
        context[f"duplicate_result_{index}"] = worker_result
        yield f"duplicate_processed_{index}", service.status(), context
