"""Command-line interface for the order service."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from payments import PaymentGateway
from store import Store


def output(value: Any) -> None:
    print(json.dumps(value, sort_keys=True))


def open_store(path: str) -> Store:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    return Store(path)


def create_order(store: Store, args: argparse.Namespace) -> dict[str, Any]:
    existing = store.get_order(args.request_id)
    if existing is not None:
        if existing["status"] != "captured":
            store.enqueue(args.request_id, "charge")
            store.commit()
        return {
            "status": "accepted",
            "request_id": args.request_id,
            "order_status": existing["status"],
        }

    order = {
        "request_id": args.request_id,
        "sku": args.sku,
        "quantity": args.quantity,
        "amount": args.amount,
        "status": "pending",
        "attempt": 0,
        "created_at": args.now,
    }
    store.put_order(order)
    store.enqueue(args.request_id, "charge")
    store.commit()
    return {
        "status": "accepted",
        "request_id": args.request_id,
        "order_status": "pending",
    }


def finish_captured(store: Store, request_id: str, result: dict[str, Any], now: int) -> dict[str, Any]:
    order = store.get_order(request_id)
    amount = order["amount"] if order else 0
    store.add_ledger_entry(
        request_id,
        amount,
        "captured",
        result.get("receipt", ""),
        now,
    )
    store.set_order_status(request_id, "captured")
    store.cache_response(request_id, result)
    store.commit()
    return {"status": "captured", "request_id": request_id, "receipt": result.get("receipt")}


def run_worker(store: Store, gateway: PaymentGateway, now: int) -> dict[str, Any]:
    job = store.next_job()
    if job is None:
        return {"status": "empty"}

    request_id = job["request_id"]
    order = store.get_order(request_id)
    if order is None:
        store.finish_job(job["id"])
        store.commit()
        return {"status": "missing_order", "request_id": request_id}

    previous = store.cached_response(request_id)
    if previous is not None:
        if previous.get("status") == "captured":
            store.set_order_status(request_id, "captured")
            store.finish_job(job["id"])
            store.commit()
            return {"status": "captured", "request_id": request_id}
        store.set_order_status(request_id, "blocked")
        store.finish_job(job["id"])
        store.commit()
        return {
            "status": "blocked",
            "request_id": request_id,
            "gateway_status": previous.get("status"),
        }

    attempt = order["attempt"] + 1
    store.set_order_status(request_id, "charging", attempt)
    store.commit()
    operation_id = f"{request_id}:{attempt}"
    result = gateway.call(operation_id, request_id, order["amount"])

    if result["status"] == "captured":
        store.finish_job(job["id"])
        return finish_captured(store, request_id, result, now)

    if result["status"] == "timeout":
        store.add_ledger_entry(
            request_id,
            order["amount"],
            "unknown",
            result.get("receipt", ""),
            now,
        )
        store.set_order_status(request_id, "retrying")
        store.cache_response(request_id, result)
        store.commit()
        return {
            "status": "retrying",
            "request_id": request_id,
            "attempt": attempt,
            "operation_id": operation_id,
        }

    store.add_ledger_entry(request_id, order["amount"], "declined", "", now)
    store.set_order_status(request_id, "declined")
    store.finish_job(job["id"])
    store.cache_response(request_id, result)
    store.commit()
    return {"status": "declined", "request_id": request_id}


def service_status(store: Store, gateway: PaymentGateway) -> dict[str, Any]:
    snapshot = store.snapshot()
    return {**snapshot, "gateway_captures": gateway.captures()}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Order service")
    parser.add_argument("--data", required=True, help="SQLite database path")
    parser.add_argument("--gateway-responses", required=True, help="Gateway response journal")
    parser.add_argument("--gateway-state", required=True, help="Gateway operation state path")
    commands = parser.add_subparsers(dest="command", required=True)

    create = commands.add_parser("create", help="create or retry an order request")
    create.add_argument("--request-id", required=True)
    create.add_argument("--sku", required=True)
    create.add_argument("--quantity", type=int, required=True)
    create.add_argument("--amount", type=int, required=True)
    create.add_argument("--now", type=int, default=1)

    work = commands.add_parser("worker", help="process one ready order action")
    work.add_argument("--now", type=int, default=1)

    commands.add_parser("status", help="print durable service state")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    store = open_store(args.data)
    gateway = PaymentGateway(args.gateway_responses, args.gateway_state)
    try:
        if args.command == "create":
            answer = create_order(store, args)
        elif args.command == "worker":
            answer = run_worker(store, gateway, args.now)
        else:
            answer = service_status(store, gateway)
        output(answer)
    finally:
        store.close()


if __name__ == "__main__":
    main()
