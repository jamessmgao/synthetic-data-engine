"""Deterministic adapter for the external payment gateway."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


class GatewayError(Exception):
    """The payment gateway could not be reached."""


class PaymentGateway:
    """Call a payment gateway and retain its durable operation state."""

    def __init__(self, responses_path: str | Path, state_path: str | Path):
        self.responses_path = str(responses_path)
        self.state_path = str(state_path)

    def _read_state(self) -> dict[str, Any]:
        try:
            with open(self.state_path, encoding="utf-8") as handle:
                value = json.load(handle)
            if not isinstance(value, dict):
                raise GatewayError("invalid gateway state")
            return value
        except FileNotFoundError:
            return {"operations": {}, "responses_read": 0}

    def _write_state(self, state: dict[str, Any]) -> None:
        path = Path(self.state_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".tmp")
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(state, handle, sort_keys=True)
        os.replace(temporary, path)

    def _next_response(self, state: dict[str, Any]) -> dict[str, Any]:
        offset = int(state.get("responses_read", 0))
        try:
            with open(self.responses_path, encoding="utf-8") as handle:
                for _ in range(offset):
                    if not handle.readline():
                        break
                line = handle.readline()
        except FileNotFoundError:
            line = ""
        if line.strip():
            state["responses_read"] = offset + 1
            response = json.loads(line)
            if not isinstance(response, dict):
                raise GatewayError("invalid gateway response")
            return response
        state["responses_read"] = offset + 1
        return {"status": "captured"}

    def call(self, operation_id: str, request_id: str, amount: int) -> dict[str, Any]:
        state = self._read_state()
        operations = state.setdefault("operations", {})
        if operation_id in operations:
            operation = operations[operation_id]
            return {
                "status": "captured",
                "receipt": operation["receipt"],
                "operation_id": operation_id,
            }

        response = self._next_response(state)
        status = response.get("status")
        if status not in {"captured", "timeout", "declined"}:
            raise GatewayError("unsupported gateway response")

        receipt = hashlib.sha256(
            f"{operation_id}:{request_id}:{amount}".encode("utf-8")
        ).hexdigest()[:24]
        if status in {"captured", "timeout"}:
            operations[operation_id] = {
                "request_id": request_id,
                "amount": amount,
                "receipt": receipt,
            }
        self._write_state(state)

        result: dict[str, Any] = {"status": status, "operation_id": operation_id}
        if status in {"captured", "timeout"}:
            result["receipt"] = receipt
        return result

    def captures(self) -> list[dict[str, Any]]:
        state = self._read_state()
        rows: list[dict[str, Any]] = []
        for operation_id, operation in state.get("operations", {}).items():
            rows.append(
                {
                    "operation_id": operation_id,
                    "request_id": operation["request_id"],
                    "amount": operation["amount"],
                    "receipt": operation["receipt"],
                }
            )
        return rows
