"""Durable state for the order service."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any


SCHEMA = """
CREATE TABLE IF NOT EXISTS orders (
    request_id TEXT PRIMARY KEY,
    sku TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    amount INTEGER NOT NULL,
    status TEXT NOT NULL,
    attempt INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS request_cache (
    request_id TEXT PRIMARY KEY,
    response TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT NOT NULL,
    action TEXT NOT NULL,
    available INTEGER NOT NULL DEFAULT 1,
    UNIQUE(request_id, action)
);
CREATE TABLE IF NOT EXISTS ledger (
    entry_id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT NOT NULL,
    amount INTEGER NOT NULL,
    state TEXT NOT NULL,
    receipt TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS queue_ready_idx ON queue(available, id);
CREATE INDEX IF NOT EXISTS ledger_request_idx ON ledger(request_id);
"""


class StoreError(Exception):
    """A durable-state operation could not be completed."""


class Store:
    """Small SQLite facade used by every service process."""

    def __init__(self, path: str | Path):
        self.path = str(path)
        self.db = sqlite3.connect(self.path, timeout=10)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys = ON")
        self.db.executescript(SCHEMA)
        self.db.commit()

    def close(self) -> None:
        self.db.close()

    def transaction(self) -> sqlite3.Connection:
        return self.db

    def execute(self, sql: str, values: tuple[Any, ...] = ()) -> sqlite3.Cursor:
        return self.db.execute(sql, values)

    def commit(self) -> None:
        self.db.commit()

    def rollback(self) -> None:
        self.db.rollback()

    def get_order(self, request_id: str) -> dict[str, Any] | None:
        row = self.db.execute(
            "SELECT request_id, sku, quantity, amount, status, attempt, created_at "
            "FROM orders WHERE request_id = ?",
            (request_id,),
        ).fetchone()
        return dict(row) if row else None

    def put_order(self, order: dict[str, Any]) -> None:
        self.db.execute(
            "INSERT INTO orders(request_id, sku, quantity, amount, status, attempt, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                order["request_id"],
                order["sku"],
                order["quantity"],
                order["amount"],
                order["status"],
                order.get("attempt", 0),
                order["created_at"],
            ),
        )

    def set_order_status(self, request_id: str, status: str, attempt: int | None = None) -> None:
        if attempt is None:
            self.db.execute(
                "UPDATE orders SET status = ? WHERE request_id = ?",
                (status, request_id),
            )
        else:
            self.db.execute(
                "UPDATE orders SET status = ?, attempt = ? WHERE request_id = ?",
                (status, attempt, request_id),
            )

    def cache_response(self, request_id: str, response: dict[str, Any]) -> None:
        self.db.execute(
            "INSERT INTO request_cache(request_id, response) VALUES (?, ?) "
            "ON CONFLICT(request_id) DO UPDATE SET response = excluded.response",
            (request_id, json.dumps(response, sort_keys=True)),
        )

    def cached_response(self, request_id: str) -> dict[str, Any] | None:
        row = self.db.execute(
            "SELECT response FROM request_cache WHERE request_id = ?", (request_id,)
        ).fetchone()
        return json.loads(row["response"]) if row else None

    def enqueue(self, request_id: str, action: str) -> None:
        self.db.execute(
            "INSERT OR IGNORE INTO queue(request_id, action, available) VALUES (?, ?, 1)",
            (request_id, action),
        )

    def next_job(self) -> dict[str, Any] | None:
        row = self.db.execute(
            "SELECT id, request_id, action FROM queue WHERE available = 1 ORDER BY id LIMIT 1"
        ).fetchone()
        return dict(row) if row else None

    def keep_job(self, job_id: int) -> None:
        self.db.execute("UPDATE queue SET available = 1 WHERE id = ?", (job_id,))

    def finish_job(self, job_id: int) -> None:
        self.db.execute("DELETE FROM queue WHERE id = ?", (job_id,))

    def ledger_entries(self, request_id: str) -> list[dict[str, Any]]:
        rows = self.db.execute(
            "SELECT entry_id, request_id, amount, state, receipt, created_at "
            "FROM ledger WHERE request_id = ? ORDER BY entry_id",
            (request_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def add_ledger_entry(self, request_id: str, amount: int, state: str, receipt: str, created_at: int) -> int:
        cursor = self.db.execute(
            "INSERT INTO ledger(request_id, amount, state, receipt, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (request_id, amount, state, receipt, created_at),
        )
        return int(cursor.lastrowid or 0)

    def snapshot(self) -> dict[str, Any]:
        orders = [dict(row) for row in self.db.execute(
            "SELECT request_id, sku, quantity, amount, status, attempt, created_at FROM orders ORDER BY request_id"
        )]
        queue = [dict(row) for row in self.db.execute(
            "SELECT id, request_id, action, available FROM queue ORDER BY id"
        )]
        ledger = [dict(row) for row in self.db.execute(
            "SELECT entry_id, request_id, amount, state, receipt, created_at FROM ledger ORDER BY entry_id"
        )]
        return {"orders": orders, "queue": queue, "ledger": ledger}
