# Fix linearizability violation in replicated KV store

A replicated key-value store loses acknowledged writes after failover when a restarted replica accepts stale leaders because the recovery mark doesn't persist the fencing term.

## Scenario

A three-node replicated KV store with leader-follower replication. The leader handles SET/DEL/GET, replicates to followers, and acknowledges writes. After failover, a restarted replica forgets the fencing term and accepts writes from a stale old leader.

## Root cause (hidden from the agent)

recovery.save_mark persists only the acknowledged index, not the fencing term. On restart, recovery.load_mark doesn't restore the term, so the replica can't reject stale leaders that carry an outdated term. A stale leader's delete then removes an acknowledged key.

## Correctness constraints

- **C1**: Acknowledged writes remain readable after failover to a replica
- **C2**: Followers reject write commands (SET, DEL, FLUSH) with ERR_NOT_LEADER
- **C3**: GET returns OK <value> for existing keys and NIL for missing or deleted keys

## Subgoals

1. Persist the fencing term alongside the acknowledged index in the recovery mark
2. Restore the fencing term on recovery so restarted replicas reject stale leaders
3. Ensure SET/DEL commits and persists the mark before acknowledging

## Failure scenario

After promoting a follower and writing a new key, killing and restarting the replica, then starting the old leader who deletes that key, the replica accepts the stale delete. Promoting the replica returns NIL for the acknowledged key.

## Expected agent pitfalls

- Adding COMMIT-before-ACK without persisting the term (the wrong fix)
- Only fixing the simple failover case without handling stale leaders after restart
- Modifying only kvstore.py without updating recovery.py's mark persistence

## Anti-shortcut measures

- Random scheduling of kills and restarts across 10 seeds exposes the stale-leader scenario
- Targeted test that restarts a replica and starts an old leader verifies term fencing
- Exact counterexample replay catches the original bug

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_acknowledged_writes_remain_readable_after_failover`, `test_counterexample_replay`, `test_acknowledged_del_remains_deleted_after_failover`, `test_stale_leader_rejected_after_replica_restart` |
| C2 | `test_follower_rejects_writes` |
| C3 | `test_basic_commands_and_edge_cases`, `test_overwrite_and_delete_consistency` |
