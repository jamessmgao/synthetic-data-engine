"""Test support helpers for the replicated KV store."""
import os
import signal
import socket
import subprocess
import time

DATA_DIR = "/app/data"


def clean_data():
    """Remove all WAL and mark files for a fresh start."""
    os.makedirs(DATA_DIR, exist_ok=True)
    for f in os.listdir(DATA_DIR):
        if f.endswith(".wal") or f.endswith(".mark") or f.endswith(".mark.tmp"):
            try:
                os.remove(os.path.join(DATA_DIR, f))
            except OSError:
                pass


def start_node(role, port, term=0, peers=""):
    """Start a KV store node, return its Popen object."""
    cmd = ["python3", "/app/kvstore.py", role, str(port), str(term)]
    if peers:
        cmd.append(peers)
    return subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )


def stop_node(proc):
    """Kill a KV store node and wait for it to exit."""
    if proc is None:
        return
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    except (OSError, ProcessLookupError):
        pass
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            proc.kill()
            proc.wait(timeout=2)
        except Exception:
            pass


def send_cmd(port, cmd_str, timeout=5.0):
    """Send one command to a KV store node over TCP and return the response."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect(("127.0.0.1", port))
        sock.sendall((cmd_str + "\n").encode())
        f = sock.makefile("rb")
        line = f.readline()
        return line.decode().strip()
    except socket.timeout:
        return "TIMEOUT"
    except OSError:
        return "ERR_CONN"
    finally:
        try:
            sock.close()
        except OSError:
            pass


def wait_for_server(port, timeout=5.0):
    """Poll until a node responds to STATUS."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        if send_cmd(port, "STATUS", timeout=1.0).startswith("role="):
            return True
        time.sleep(0.05)
    return False


def stop_all(procs):
    """Stop all tracked processes."""
    for proc in list(procs.values()):
        stop_node(proc)
    procs.clear()
