#!/usr/bin/env python3
"""Recovery helpers for the replicated key-value service."""

import json
import os


def load_mark(path):
    if not os.path.exists(path):
        return -1
    with open(path) as f:
        record = json.load(f)
    return int(record.get("index", -1))


def save_mark(path, index):
    parent = os.path.dirname(path)
    os.makedirs(parent, exist_ok=True)
    temporary = path + ".tmp"
    with open(temporary, "w") as f:
        json.dump({"index": int(index)}, f)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temporary, path)
    try:
        descriptor = os.open(parent, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    except OSError:
        pass


def get_replay_target(ack_index, mark_path):
    return load_mark(mark_path)


def on_promote(state, ack_index):
    if ack_index >= 0:
        state.apply_through(ack_index)
    return ack_index
