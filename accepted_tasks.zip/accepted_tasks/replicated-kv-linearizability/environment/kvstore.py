#!/usr/bin/env python3
"""Small replicated key-value service."""

import asyncio
import json
import os
import sys

import recovery

DATA_DIR = "/app/data"


class WAL:
    def __init__(self, path):
        self.path = path
        self.entries = []
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if os.path.exists(path):
            with open(path) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        self.entries.append(json.loads(line))

    def append(self, entry):
        self.entries.append(entry)
        with open(self.path, "a") as f:
            f.write(json.dumps(entry) + "\n")
            f.flush()
            os.fsync(f.fileno())
        return len(self.entries) - 1

    def truncate(self, index):
        self.entries = self.entries[:index]
        with open(self.path, "w") as f:
            for entry in self.entries:
                f.write(json.dumps(entry) + "\n")
            f.flush()
            os.fsync(f.fileno())

    @property
    def last_index(self):
        return len(self.entries) - 1 if self.entries else -1


class KVState:
    def __init__(self, wal_path):
        self.wal = WAL(wal_path)
        self.data = {}
        self.applied_up_to = -1

    def _apply(self, entry):
        if entry.get("op") == "SET":
            self.data[entry["key"]] = entry["value"]
        elif entry.get("op") == "DEL":
            self.data.pop(entry["key"], None)

    def apply_through(self, index):
        while self.applied_up_to < index:
            self.applied_up_to += 1
            self._apply(self.wal.entries[self.applied_up_to])

    def get(self, key):
        return self.data.get(key)

    def propose(self, op, key, value=None, term=None):
        entry = {"op": op, "key": key}
        if value is not None:
            entry["value"] = value
        if term is not None:
            entry["term"] = term
        return self.wal.append(entry)


class ReplicatedKV:
    def __init__(self, role, port, term=0, peers=""):
        self.role = role
        self.port = port
        self.term = int(term)
        self.peer_ports = [int(p) for p in peers.split(",") if p.strip()]
        self.peer_host = "127.0.0.1"
        wal_path = os.path.join(DATA_DIR, f"node_{port}.wal")
        self.mark_path = os.path.join(DATA_DIR, f"node_{port}.mark")
        self.state = KVState(wal_path)
        self.ack_index = -1
        self._recover()

    def _recover(self):
        self.ack_index = recovery.load_mark(self.mark_path)
        target = recovery.get_replay_target(self.ack_index, self.mark_path)
        if target >= 0:
            self.state.apply_through(target)

    async def _handle(self, reader, writer):
        try:
            while True:
                line = await reader.readline()
                if not line:
                    break
                command = line.decode().strip()
                if not command:
                    continue
                response = await self._dispatch(command)
                writer.write((response + "\n").encode())
                await writer.drain()
        except (ConnectionResetError, BrokenPipeError, asyncio.IncompleteReadError):
            pass
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    async def _dispatch(self, line):
        parts = line.split()
        if not parts:
            return "ERR"
        cmd = parts[0].upper()
        if cmd == "GET":
            return self._cmd_get(parts)
        if cmd == "SET":
            return await self._cmd_set(parts)
        if cmd == "DEL":
            return await self._cmd_del(parts)
        if cmd == "FLUSH":
            return await self._cmd_flush()
        if cmd == "REPLICATE":
            return self._cmd_replicate(parts)
        if cmd == "COMMIT":
            return self._cmd_commit(parts)
        if cmd == "PROMOTE":
            return self._cmd_promote()
        if cmd == "STATUS":
            return self._cmd_status()
        return f"ERR unknown: {cmd}"

    def _cmd_get(self, parts):
        key = parts[1]
        val = self.state.get(key)
        return f"OK {val}" if val is not None else "NIL"

    async def _cmd_set(self, parts):
        if self.role != "leader":
            return "ERR_NOT_LEADER"
        key, value = parts[1], parts[2]
        idx = self.state.propose("SET", key, value, self.term)
        self.state.apply_through(idx)
        if self.peer_ports:
            ok = await self._send_replicate(idx, self.term, "SET", key, value)
            if not ok:
                return "ERR_REPLICATE"
        return f"OK {idx}"

    async def _cmd_del(self, parts):
        if self.role != "leader":
            return "ERR_NOT_LEADER"
        key = parts[1]
        idx = self.state.propose("DEL", key, self.term)
        self.state.apply_through(idx)
        if self.peer_ports:
            ok = await self._send_replicate(idx, self.term, "DEL", key)
            if not ok:
                return "ERR_REPLICATE"
        return f"OK {idx}"

    async def _cmd_flush(self):
        if self.role != "leader":
            return "ERR_NOT_LEADER"
        last = self.state.wal.last_index
        if self.peer_ports and last >= 0:
            ok = await self._send_commit(last, self.term)
            if not ok:
                return "ERR_COMMIT"
        self.state.apply_through(last)
        self.ack_index = last
        recovery.save_mark(self.mark_path, self.ack_index)
        return f"OK {self.ack_index}"

    def _cmd_replicate(self, parts):
        idx = int(parts[1])
        term = int(parts[2])
        op = parts[3]
        key = parts[4]
        value = parts[5] if len(parts) > 5 else None
        if term < self.term:
            return "ERR_STALE"
        if term > self.term:
            self.term = term
        if idx <= self.state.wal.last_index:
            self.state.wal.truncate(idx)
            if self.state.applied_up_to >= idx:
                self.state.applied_up_to = idx - 1
        entry = {"op": op, "key": key}
        if value is not None:
            entry["value"] = value
        entry["term"] = term
        self.state.wal.append(entry)
        return f"ACK {idx}"

    def _cmd_commit(self, parts):
        idx = int(parts[1])
        term = int(parts[2])
        if term < self.term:
            return "ERR_STALE"
        if term > self.term:
            self.term = term
        self.state.apply_through(idx)
        self.ack_index = idx
        recovery.save_mark(self.mark_path, self.ack_index)
        return f"ACK {idx}"

    def _cmd_promote(self):
        self.term += 1
        recovery.on_promote(self.state, self.ack_index)
        self.role = "leader"
        recovery.save_mark(self.mark_path, self.ack_index)
        return "OK"

    def _cmd_status(self):
        return (f"role={self.role} term={self.term} "
                f"wal_last={self.state.wal.last_index}")

    async def _send_to_all(self, message):
        if not self.peer_ports:
            return True
        for port in self.peer_ports:
            try:
                reader, writer = await asyncio.open_connection(self.peer_host, port)
                writer.write((message + "\n").encode())
                await writer.drain()
                resp = await asyncio.wait_for(reader.readline(), timeout=5.0)
                writer.close()
                await writer.wait_closed()
                if not resp.decode().strip().startswith("ACK"):
                    return False
            except Exception:
                return False
        return True

    async def _send_replicate(self, idx, term, op, key, value=None):
        message = f"REPLICATE {idx} {term} {op} {key}"
        if value is not None:
            message += f" {value}"
        return await self._send_to_all(message)

    async def _send_commit(self, idx, term):
        return await self._send_to_all(f"COMMIT {idx} {term}")

    async def run(self):
        server = await asyncio.start_server(self._handle, "0.0.0.0", self.port)
        async with server:
            await server.serve_forever()


def main():
    role = sys.argv[1]
    port = int(sys.argv[2])
    term = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    peers = sys.argv[4] if len(sys.argv) > 4 else ""
    node = ReplicatedKV(role, port, term=term, peers=peers)
    asyncio.run(node.run())


if __name__ == "__main__":
    main()
