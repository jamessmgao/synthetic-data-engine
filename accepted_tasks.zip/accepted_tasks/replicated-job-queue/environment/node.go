package main

import (
	"bufio"
	"encoding/json"
	"os"
	"path"
	"strconv"
)

type Message struct {
	Op        string `json:"op"`
	Term      uint64 `json:"term"`
	Index     uint64 `json:"index"`
	Commit    uint64 `json:"commit"`
	Key       string `json:"key"`
	Value     string `json:"value"`
	Session   string `json:"session"`
	RequestID string `json:"request_id"`
	Stamp     uint64 `json:"stamp"`
}

type Result struct {
	OK           bool   `json:"ok"`
	Status       string `json:"status"`
	Term         uint64 `json:"term,omitempty"`
	Index        uint64 `json:"index,omitempty"`
	Commit       uint64 `json:"commit,omitempty"`
	AppliedIndex uint64 `json:"applied_index,omitempty"`
	AppliedTerm  uint64 `json:"applied_term,omitempty"`
	Value        string `json:"value,omitempty"`
}

type ReadStamp struct {
	Index uint64
	Term  uint64
}

type NodeState struct {
	dir         string
	log         *LogStore
	term        uint64
	commit      uint64
	applied     uint64
	appliedTerm uint64
	data        map[string]string
	requests    map[string]bool
}

func nodeProcess(dir string) error {
	lg, err := OpenLog(dir)
	if err != nil {
		return err
	}
	n := &NodeState{
		dir:      dir,
		log:      lg,
		data:     make(map[string]string),
		requests: make(map[string]bool),
	}
	if err := n.loadCommit(); err != nil {
		return err
	}
	if _, term, ok := lg.Last(); ok {
		n.term = term
	}
	n.applyCommitted()
	sc := bufio.NewScanner(os.Stdin)
	sc.Buffer(make([]byte, 1024*1024), 1024*1024)
	enc := json.NewEncoder(os.Stdout)
	for sc.Scan() {
		var msg Message
		if err := json.Unmarshal(sc.Bytes(), &msg); err != nil {
			return err
		}
		res := n.handle(msg)
		if err := enc.Encode(res); err != nil {
			return err
		}
	}
	return sc.Err()
}

func (n *NodeState) commitFile() string {
	return path.Join(n.dir, "commit.json")
}

func (n *NodeState) loadCommit() error {
	data, err := os.ReadFile(n.commitFile())
	if err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	text := string(data)
	if text == "" {
		return nil
	}
	v, err := strconv.ParseUint(text, 10, 64)
	if err != nil {
		return err
	}
	n.commit = v
	return nil
}

func (n *NodeState) saveCommit() error {
	return os.WriteFile(n.commitFile(), []byte(strconv.FormatUint(n.commit, 10)), 0o644)
}

func (n *NodeState) handle(msg Message) Result {
	switch msg.Op {
	case "term":
		if msg.Term > n.term {
			n.term = msg.Term
		}
		return Result{OK: true, Status: "term", Term: n.term}
	case "append":
		return n.append(msg)
	case "commit":
		if msg.Term < n.term {
			return Result{OK: false, Status: "stale_term"}
		}
		if msg.Term > n.term {
			n.term = msg.Term
		}
		if msg.Commit < n.commit {
			return Result{OK: false, Status: "commit_regressed"}
		}
		n.commit = msg.Commit
		if err := n.saveCommit(); err != nil {
			return Result{OK: false, Status: "commit_save_failed"}
		}
		n.applyCommitted()
		return Result{OK: true, Status: "committed", Term: n.term, Commit: n.commit, AppliedIndex: n.applied, AppliedTerm: n.appliedTerm}
	case "read":
		if n.applied < msg.Stamp {
			return Result{OK: false, Status: "not_caught_up", Term: n.term, Commit: n.commit, AppliedIndex: n.applied, AppliedTerm: n.appliedTerm}
		}
		return Result{OK: true, Status: "read", Value: n.data[msg.Key], Term: n.term, Commit: n.commit, AppliedIndex: n.applied, AppliedTerm: n.appliedTerm}
	case "state":
		return Result{OK: true, Status: "state", Term: n.term, Commit: n.commit, AppliedIndex: n.applied, AppliedTerm: n.appliedTerm}
	default:
		return Result{OK: false, Status: "unknown_op"}
	}
}

func (n *NodeState) append(msg Message) Result {
	if msg.Term < n.term {
		return Result{OK: false, Status: "stale_term"}
	}
	if msg.Term > n.term {
		n.term = msg.Term
	}
	if old, ok := n.log.At(msg.Index); ok {
		if old.Term == msg.Term && old.RequestID == msg.RequestID {
			return Result{OK: true, Status: "duplicate", Index: old.Index, Term: n.term}
		}
		if old.Term > msg.Term || old.Term == msg.Term {
			return Result{OK: false, Status: "conflict"}
		}
		if err := n.log.TruncateFrom(msg.Index); err != nil {
			return Result{OK: false, Status: "truncate_failed"}
		}
		n.rebuild(msg.Index)
	}
	e := Entry{Index: msg.Index, Term: msg.Term, Kind: KindCommand, Key: msg.Key, Value: msg.Value, Session: msg.Session, RequestID: msg.RequestID}
	if err := n.log.Append(e); err != nil {
		return Result{OK: false, Status: "append_failed"}
	}
	n.applyCommitted()
	return Result{OK: true, Status: "appended", Index: e.Index, Term: n.term}
}

func (n *NodeState) rebuild(from uint64) {
	n.applied = from - 1
	n.commit = from - 1
	n.appliedTerm = 0
	if from > 1 {
		if e, ok := n.log.At(from - 1); ok {
			n.appliedTerm = e.Term
		}
	}
	n.data = make(map[string]string)
	n.requests = make(map[string]bool)
	for i := uint64(1); i < from; i++ {
		if e, ok := n.log.At(i); ok && e.Kind == KindCommand {
			n.requests[e.RequestID] = true
			n.data[e.Key] = e.Value
		}
	}
}

func (n *NodeState) applyCommitted() {
	for i := n.applied + 1; i <= n.commit; i++ {
		e, ok := n.log.At(i)
		if !ok {
			return
		}
		if e.Kind != KindCommand || n.requests[e.RequestID] {
			n.applied = e.Index
			n.appliedTerm = e.Term
			continue
		}
		n.data[e.Key] = e.Value
		n.requests[e.RequestID] = true
		n.applied = e.Index
		n.appliedTerm = e.Term
	}
}
