package main

import (
	"fmt"
	"os"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: aqjobqueue <command> [args]")
		os.Exit(2)
	}
	switch os.Args[1] {
	case "node":
		if len(os.Args) != 3 {
			fmt.Fprintln(os.Stderr, "node requires a state directory")
			os.Exit(2)
		}
		if err := nodeProcess(os.Args[2]); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	case "run-plan":
		if len(os.Args) != 4 {
			fmt.Fprintln(os.Stderr, "run-plan requires a plan and state directory")
			os.Exit(2)
		}
		if err := runPlan(os.Args[2], os.Args[3]); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	default:
		fmt.Fprintln(os.Stderr, "unknown command")
		os.Exit(2)
	}
}
