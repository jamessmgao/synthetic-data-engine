package main

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"sync"
)

type PlanEvent struct {
	Op        string   `json:"op"`
	Node      string   `json:"node"`
	Reach     []string `json:"reach"`
	Term      uint64   `json:"term"`
	Index     uint64   `json:"index"`
	Commit    uint64   `json:"commit"`
	Key       string   `json:"key"`
	Value     string   `json:"value"`
	Session   string   `json:"session"`
	RequestID string   `json:"request_id"`
	Stamp     uint64   `json:"stamp"`
	Deliver   *bool    `json:"deliver"`
}

type Plan struct {
	Nodes []string    `json:"nodes"`
	Steps []PlanEvent `json:"steps"`
}

type StepResult struct {
	Step    int        `json:"step"`
	Op      string     `json:"op"`
	OK      bool       `json:"ok"`
	Outputs []Result   `json:"outputs,omitempty"`
	Stamp   *ReadStamp `json:"stamp,omitempty"`
	Error   string     `json:"error,omitempty"`
}

type NodeProc struct {
	name   string
	dir    string
	cmd    *exec.Cmd
	stdin  io.WriteCloser
	stdout *json.Decoder
	mu     sync.Mutex
}

type Cluster struct {
	root     string
	names    []string
	procs    map[string]*NodeProc
	next     uint64
	term     uint64
	sessions map[string]ReadStamp
	enc      *json.Encoder
}

func runPlan(planPath, root string) error {
	data, err := os.ReadFile(planPath)
	if err != nil {
		return err
	}
	var plan Plan
	if err := json.Unmarshal(data, &plan); err != nil {
		return err
	}
	if len(plan.Nodes) < 3 {
		return fmt.Errorf("plan needs at least three nodes")
	}
	if err := os.RemoveAll(root); err != nil {
		return err
	}
	if err := os.MkdirAll(root, 0o755); err != nil {
		return err
	}
	c := &Cluster{
		root: root, names: plan.Nodes, next: 1,
		procs:    make(map[string]*NodeProc),
		sessions: make(map[string]ReadStamp),
		enc:      json.NewEncoder(os.Stdout),
	}
	defer c.stopAll()
	for _, name := range plan.Nodes {
		if err := c.start(name); err != nil {
			return err
		}
	}
	for i, event := range plan.Steps {
		res := c.execute(i, event)
		if err := c.enc.Encode(res); err != nil {
			return err
		}
	}
	return nil
}

func (c *Cluster) start(name string) error {
	dir := filepath.Join(c.root, name)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	cmd := exec.Command(os.Args[0], "node", dir)
	in, err := cmd.StdinPipe()
	if err != nil {
		return err
	}
	out, err := cmd.StdoutPipe()
	if err != nil {
		return err
	}
	cmd.Stderr = os.Stderr
	if err := cmd.Start(); err != nil {
		return err
	}
	c.procs[name] = &NodeProc{name: name, dir: dir, cmd: cmd, stdin: in, stdout: json.NewDecoder(out)}
	return nil
}

func (c *Cluster) stop(name string) {
	p := c.procs[name]
	if p == nil || p.cmd == nil || p.cmd.Process == nil {
		return
	}
	_ = p.cmd.Process.Kill()
	_ = p.cmd.Wait()
	p.cmd = nil
	p.stdin = nil
	p.stdout = nil
}

func (c *Cluster) stopAll() {
	for _, name := range c.names {
		c.stop(name)
	}
}

func (c *Cluster) send(name string, msg Message) (Result, error) {
	p := c.procs[name]
	if p == nil {
		return Result{}, fmt.Errorf("unknown node %s", name)
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.stdin == nil || p.stdout == nil {
		return Result{}, fmt.Errorf("node %s is not running", name)
	}
	line, err := json.Marshal(msg)
	if err != nil {
		return Result{}, err
	}
	if _, err := p.stdin.Write(append(line, '\n')); err != nil {
		return Result{}, err
	}
	var result Result
	if err := p.stdout.Decode(&result); err != nil {
		return Result{}, err
	}
	return result, nil
}

func delivers(e PlanEvent) bool {
	return e.Deliver == nil || *e.Deliver
}

func (c *Cluster) execute(step int, e PlanEvent) StepResult {
	res := StepResult{Step: step, Op: e.Op, OK: true}
	switch e.Op {
	case "start":
		if err := c.start(e.Node); err != nil {
			res.OK, res.Error = false, err.Error()
		}
	case "crash":
		c.stop(e.Node)
	case "restart":
		c.stop(e.Node)
		if err := c.start(e.Node); err != nil {
			res.OK, res.Error = false, err.Error()
		}
	case "leader":
		if e.Term > c.term {
			c.term = e.Term
		}
		for _, name := range c.reach(e) {
			if !delivers(e) {
				res.Outputs = append(res.Outputs, Result{Status: "dropped"})
				continue
			}
			out, err := c.send(name, Message{Op: "term", Term: e.Term})
			c.collect(&res, name, out, err)
		}
	case "append":
		if !delivers(e) {
			res.Outputs = append(res.Outputs, Result{Status: "dropped"})
			break
		}
		out, err := c.send(e.Node, c.appendMessage(e))
		c.collect(&res, e.Node, out, err)
	case "commit":
		if !delivers(e) {
			res.Outputs = append(res.Outputs, Result{Status: "dropped"})
			break
		}
		commitTerm := e.Term
		if commitTerm == 0 {
			commitTerm = c.term
		}
		out, err := c.send(e.Node, Message{Op: "commit", Term: commitTerm, Commit: e.Commit})
		c.collect(&res, e.Node, out, err)
	case "enqueue":
		c.enqueue(&res, e)
	case "read":
		if e.Stamp == 0 {
			if stamp, ok := c.sessions[e.Session]; ok {
				e.Stamp = stamp.Index
			}
		}
		out, err := c.send(e.Node, Message{Op: "read", Key: e.Key, Stamp: e.Stamp})
		c.collect(&res, e.Node, out, err)
	case "state":
		out, err := c.send(e.Node, Message{Op: "state"})
		c.collect(&res, e.Node, out, err)
	default:
		res.OK, res.Error = false, "unknown plan operation"
	}
	return res
}

func (c *Cluster) appendMessage(e PlanEvent) Message {
	term := e.Term
	if term == 0 {
		term = c.term
	}
	return Message{Op: "append", Term: term, Index: e.Index, Key: e.Key, Value: e.Value, Session: e.Session, RequestID: e.RequestID}
}

func (c *Cluster) enqueue(res *StepResult, e PlanEvent) {
	if e.Index == 0 {
		e.Index = c.next
	}
	var acks []string
	for _, name := range c.reach(e) {
		if !delivers(e) {
			res.Outputs = append(res.Outputs, Result{Status: "dropped"})
			continue
		}
		out, err := c.send(name, c.appendMessage(e))
		c.collect(res, name, out, err)
		if err == nil && out.OK {
			acks = append(acks, name)
		}
	}
	if len(acks) < len(c.names)/2+1 {
		res.OK = false
		return
	}
	commitTerm := e.Term
	if commitTerm == 0 {
		commitTerm = c.term
	}
	for _, name := range c.names {
		out, err := c.send(name, Message{Op: "commit", Term: commitTerm, Commit: e.Index})
		c.collect(res, name, out, err)
	}
	if e.Index >= c.next {
		c.next = e.Index + 1
	}
	stamp := ReadStamp{Index: e.Index, Term: commitTerm}
	if e.Term != 0 {
		c.term = e.Term
	}
	c.sessions[e.Session] = stamp
	res.Stamp = &stamp
}

func (c *Cluster) reach(e PlanEvent) []string {
	if len(e.Reach) != 0 {
		return e.Reach
	}
	return c.names
}

func (c *Cluster) collect(res *StepResult, name string, out Result, err error) {
	if err != nil {
		res.OK = false
		res.Error = err.Error()
		return
	}
	res.Outputs = append(res.Outputs, out)
	if !out.OK {
		res.OK = false
	}
}
