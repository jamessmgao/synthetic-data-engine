package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path"
	"sync"
)

var ErrIndex = errors.New("log index out of range")

type EntryKind string

const (
	KindCommand EntryKind = "command"
	KindNoop    EntryKind = "noop"
)

type Entry struct {
	Index     uint64
	Term      uint64
	Kind      EntryKind
	Key       string
	Value     string
	Session   string
	RequestID string
}

type LogStore struct {
	mu      sync.Mutex
	dir     string
	entries []Entry
	next    uint64
}

func OpenLog(dir string) (*LogStore, error) {
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, err
	}
	s := &LogStore{dir: dir, next: 1}
	data, err := os.ReadFile(s.file())
	if errors.Is(err, os.ErrNotExist) {
		return s, nil
	}
	if err != nil {
		return nil, err
	}
	if len(data) != 0 {
		if err := json.Unmarshal(data, &s.entries); err != nil {
			return nil, fmt.Errorf("open log: %w", err)
		}
	}
	for _, e := range s.entries {
		if e.Index >= s.next {
			s.next = e.Index + 1
		}
	}
	return s, nil
}

func (s *LogStore) file() string {
	return path.Join(s.dir, "wal.json")
}

func (s *LogStore) Last() (uint64, uint64, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.entries) == 0 {
		return 0, 0, false
	}
	e := s.entries[len(s.entries)-1]
	return e.Index, e.Term, true
}

func (s *LogStore) At(i uint64) (Entry, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if i == 0 || i > uint64(len(s.entries)) {
		return Entry{}, false
	}
	return s.entries[i-1], true
}

func (s *LogStore) Append(e Entry) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if e.Index == 0 || e.Index < s.next {
		return nil
	}
	if e.Index > s.next {
		return ErrIndex
	}
	s.entries = append(s.entries, e)
	s.next++
	return s.persistLocked()
}

func (s *LogStore) TruncateFrom(i uint64) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if i == 0 || i > uint64(len(s.entries))+1 {
		return ErrIndex
	}
	s.entries = s.entries[:i-1]
	if uint64(len(s.entries)) < s.next-1 {
		s.next = i
	}
	return s.persistLocked()
}

func (s *LogStore) persistLocked() error {
	data, err := json.Marshal(s.entries)
	if err != nil {
		return err
	}
	tmp := s.file() + ".tmp"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0o644)
	if err != nil {
		return err
	}
	if _, err = f.Write(data); err != nil {
		f.Close()
		return err
	}
	if err = f.Sync(); err != nil {
		f.Close()
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	return os.Rename(tmp, s.file())
}
