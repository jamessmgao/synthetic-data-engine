# Fix stale reads from premature commit delivery

A replicated job queue delivers commit notifications to all nodes, even those that haven't appended the committed entry. This causes stale reads when a follower applies a different entry at the same index.

## Scenario

A Go-based replicated job queue uses a plan runner to coordinate writes across three nodes. The read-your-writes check only compares the applied index with the session stamp index, ignoring the term. Commit notifications are sent to all nodes regardless of whether they appended the entry, allowing a stale entry to be applied.

## Root cause (hidden from the agent)

Two bugs: (1) cluster.go sends commit notifications to all nodes in enqueue() instead of only to those that acknowledged the append; (2) node.go's read gate checks only applied index >= stamp index, not applied term >= stamp term, and applies committed entries immediately on append before the commit arrives.

## Correctness constraints

- **C1**: After a session write is acknowledged, a node serves that session a value from that write or reports that it is not caught up.
- **C2**: A node that has not advanced to a session write must not return an older value as though it were caught up.
- **C3**: An acknowledged request ID changes the job value at most once in the committed log.

## Subgoals

1. Fix cluster.go to send commit notifications only to nodes that acknowledged the enqueue
2. Fix node.go read gate to compare applied term with session stamp term
3. Remove premature applyCommitted call on append in node.go

## Failure scenario

A stale entry is appended to a follower, then a commit notification for a different entry at the same index arrives, causing the follower to apply the stale entry and serve it as a caught-up read.

## Expected agent pitfalls

- Adding only a term-aware read gate without fixing cluster delivery, which allows same-term stale entries to bypass the gate
- Fixing only the cluster delivery without the read gate, which doesn't protect against cross-term stale reads
- Removing applyCommitted on append without understanding why it matters for the commit flow

## Anti-shortcut measures

- Tests use random schedules with same-term conflicts that bypass a term-only gate
- Duplicate request ID tests ensure at-most-once semantics are preserved
- Restart tests ensure commit persistence survives crashes

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_session_write_acknowledged`, `test_counterexample_same_term_stale_read`, `test_normal_read_returns_value` |
| C2 | `test_no_older_value_as_caught_up`, `test_counterexample_same_term_stale_read` |
| C3 | `test_request_id_at_most_once`, `test_duplicate_request_id_no_rewrite` |
