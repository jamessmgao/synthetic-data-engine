"""Per-client dedup table for request idempotency."""


class DedupTable:
    """Tracks the highest request ID seen per client to filter duplicates."""

    def __init__(self):
        self.watermark = {}  # client_id -> highest request_id

    def is_dup(self, client_id, request_id):
        """Check if a request is a duplicate."""
        return request_id <= self.watermark.get(client_id, 0)

    def update(self, client_id, request_id):
        """Update the watermark for a client."""
        if request_id > self.watermark.get(client_id, 0):
            self.watermark[client_id] = request_id

    def rebuild_from_suffix(self, log, n=2):
        """Rebuild watermark from the last n log entries."""
        start = max(0, len(log) - n)
        for e in log[start:]:
            self.update(e.client_id, e.request_id)
