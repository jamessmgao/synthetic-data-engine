"""Replicated library cluster with leader, followers, WAL, and failover.

Three nodes run a replicated WAL. The leader accepts client checkout/return
requests, appends them to its log, replicates to followers, and advances the
commit index on majority. Per-client dedup watermarks prevent duplicate
processing of retried requests.

On failover the new leader rebuilds its dedup watermark from the log and
truncates uncommitted entries before resuming processing.
"""

from library import LibraryState
from dedup import DedupTable


class Entry:
    """A single WAL entry."""
    __slots__ = ('index', 'term', 'client_id', 'request_id', 'op', 'args')

    def __init__(self, index, term, client_id, request_id, op, args):
        self.index = index
        self.term = term
        self.client_id = client_id
        self.request_id = request_id
        self.op = op
        self.args = args


class Node:
    """A cluster node with its own WAL, library state, and dedup table."""

    def __init__(self, nid):
        self.nid = nid
        self.log = []
        self.commit_idx = 0
        self.applied_idx = 0
        self.term = 0
        self.state = LibraryState()
        self.dedup = DedupTable()
        self.is_leader = False
        self.alive = True

    def last_idx(self):
        return self.log[-1].index if self.log else 0

    def entry_at(self, idx):
        return next((e for e in self.log if e.index == idx), None)

    def apply_committed(self):
        """Apply all committed but not-yet-applied entries."""
        while self.applied_idx < self.commit_idx:
            self.applied_idx += 1
            e = self.entry_at(self.applied_idx)
            if e:
                self._apply(e)

    def _apply(self, e):
        if e.op == 'checkout':
            self.state.checkout(e.args['patron'], e.args['book'])
        elif e.op == 'return':
            self.state.return_book(e.args['patron'], e.args['book'])

    def truncate_uncommitted(self):
        """Remove all entries beyond the commit index."""
        self.log = [e for e in self.log if e.index <= self.commit_idx]


class Cluster:
    """A three-node replicated library cluster."""

    def __init__(self):
        self.nodes = [Node(i) for i in range(3)]
        self.nodes[0].is_leader = True
        self.nodes[0].term = 1
        for n in self.nodes:
            n.state.copies['B1'] = 1
            n.state.copies['B2'] = 1
        self.acked = set()

    def leader(self):
        return next((n for n in self.nodes if n.is_leader and n.alive), None)

    def do_append(self, cid, rid, op, args):
        l = self.leader()
        if not l:
            return 'no_leader'
        if l.dedup.is_dup(cid, rid):
            self.acked.add((cid, rid))
            return 'dup_ok'
        idx = l.last_idx() + 1
        e = Entry(idx, l.term, cid, rid, op, args)
        l.log.append(e)
        l.dedup.update(cid, rid)
        return 'appended'

    def do_ack(self, cid, rid):
        l = self.leader()
        if l:
            e = next((e for e in l.log
                       if e.client_id == cid and e.request_id == rid), None)
            if e and e.index <= l.commit_idx:
                self.acked.add((cid, rid))

    def do_replicate_to(self, entry_idx, target_nid):
        l = self.leader()
        if not l:
            return
        e = l.entry_at(entry_idx)
        if not e:
            return
        f = self.nodes[target_nid]
        if not f.alive:
            return
        f.log = [x for x in f.log if x.index < e.index]
        if not any(x.index == e.index for x in f.log):
            f.log.append(Entry(e.index, e.term, e.client_id,
                               e.request_id, e.op, dict(e.args)))
        f.log.sort(key=lambda x: x.index)

    def do_advance_commit(self):
        l = self.leader()
        if not l:
            return
        for idx in range(l.commit_idx + 1, l.last_idx() + 1):
            cnt = sum(1 for n in self.nodes
                      if n.alive and any(x.index == idx for x in n.log))
            if cnt >= 2:
                l.commit_idx = idx
            else:
                break

    def do_apply(self):
        l = self.leader()
        if l:
            l.apply_committed()

    def do_notify_commit(self):
        l = self.leader()
        if not l:
            return
        for f in self.nodes:
            if f.nid != l.nid and f.alive:
                f.commit_idx = l.commit_idx

    def do_crash(self, nid):
        self.nodes[nid].alive = False
        self.nodes[nid].is_leader = False

    def do_elect(self, nid):
        """Elect a new leader and recover the log."""
        if self.leader() is not None:
            return
        n = self.nodes[nid]
        if not n.alive:
            return
        for x in self.nodes:
            x.is_leader = False
        n.is_leader = True
        n.term += 1
        n.dedup.rebuild_from_suffix(n.log, n=2)
        n.truncate_uncommitted()
        n.apply_committed()

    def check_acked_applied(self):
        """Every acked request must have its entry applied on the leader."""
        l = self.leader()
        if not l:
            return True
        for cid, rid in self.acked:
            e = next((e for e in l.log
                       if e.client_id == cid and e.request_id == rid), None)
            if e is None:
                return (f"acked ({cid},rid={rid}) missing from leader log")
            if e.index > l.applied_idx:
                return (f"acked ({cid},rid={rid}) at idx {e.index} "
                        f"not applied (applied={l.applied_idx})")
        return True
