"""Deterministic replay of library cluster operations."""

from sde_repro import repro_main as sde_repro_main
from cluster import Cluster


def run(sequence):
    c = Cluster()
    steps = {
        'append_r1': lambda: c.do_append('C1', 1, 'checkout', {'patron': 'alice', 'book': 'B1'}),
        'replicate_r1_n1': lambda: c.do_replicate_to(1, 1),
        'replicate_r1_n2': lambda: c.do_replicate_to(1, 2),
        'commit_r1': lambda: c.do_advance_commit(),
        'apply_r1': lambda: c.do_apply(),
        'notify_r1': lambda: c.do_notify_commit(),
        'ack_r1': lambda: c.do_ack('C1', 1),
        'append_r2': lambda: c.do_append('C1', 2, 'checkout', {'patron': 'alice', 'book': 'B2'}),
        'replicate_r2_n1': lambda: c.do_replicate_to(2, 1),
        'crash_n0': lambda: c.do_crash(0),
        'elect_n1': lambda: c.do_elect(1),
        'retry_r2': lambda: c.do_append('C1', 2, 'checkout', {'patron': 'alice', 'book': 'B2'}),
        'ack_r2': lambda: c.do_ack('C1', 2),
        'advance_commit': lambda: c.do_advance_commit(),
        'apply': lambda: c.do_apply(),
        'notify': lambda: c.do_notify_commit(),
    }
    for step in sequence:
        if step in steps:
            steps[step]()
    return c


INVARIANTS = {
    "every acked write is applied": lambda c: c.check_acked_applied(),
}


if __name__ == '__main__':
    sde_repro_main(run, INVARIANTS)
