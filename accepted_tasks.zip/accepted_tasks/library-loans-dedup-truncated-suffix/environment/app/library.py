"""Library domain: books with copy counts, loans, holds."""


class LibraryState:
    """Tracks books, loans, and holds for a library branch."""

    def __init__(self):
        self.copies = {}    # book_id -> available copy count
        self.loans = {}     # (patron_id, book_id) -> loan count

    def checkout(self, patron_id, book_id):
        """Check out a book for a patron. Returns True on success."""
        if self.copies.get(book_id, 1) <= 0:
            return False
        self.copies[book_id] = self.copies.get(book_id, 1) - 1
        key = (patron_id, book_id)
        self.loans[key] = self.loans.get(key, 0) + 1
        return True

    def return_book(self, patron_id, book_id):
        """Return a book. Returns True on success."""
        key = (patron_id, book_id)
        if self.loans.get(key, 0) <= 0:
            return False
        self.loans[key] -= 1
        if self.loans[key] == 0:
            del self.loans[key]
        self.copies[book_id] = self.copies.get(book_id, 0) + 1
        return True

    def place_hold(self, patron_id, book_id):
        """Place a hold on a checked-out book. Returns True on success."""
        if self.copies.get(book_id, 1) > 0:
            return False
        return True

    def clone(self):
        s = LibraryState()
        s.copies = dict(self.copies)
        s.loans = dict(self.loans)
        return s
