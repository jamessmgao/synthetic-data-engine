# Library Loans Dedup Truncated Suffix

A replicated library loans cluster loses acknowledged checkout/return writes when a leader fails and a new leader rebuilds its dedup watermark from log entries that are later truncated.

## Scenario

A Python library loans service uses a three-node replicated cluster with per-client dedup watermarks. After a leader crash and election, the new leader rebuilds the dedup table before truncating uncommitted entries, causing retried requests to be incorrectly marked as duplicates and acknowledged without being in the log.

## Root cause (hidden from the agent)

In Cluster.do_elect, dedup.rebuild_from_suffix is called before truncate_uncommitted. The suffix includes uncommitted entries that are then removed, but their request IDs remain in the watermark. When a client retries, the dedup table says it is a duplicate and returns dup_ok, but the entry no longer exists in the log.

## Correctness constraints

- **C1**: Every acknowledged write is applied on the leader
- **C2**: Each request ID is applied at most once on the leader

## Subgoals

1. Understand the leader election recovery sequence in do_elect
2. Identify that rebuild_from_suffix captures uncommitted entries that are later truncated
3. Reorder truncation before dedup rebuild or rebuild from the full remaining log
4. Verify that retries of previously uncommitted entries are properly re-appended
5. Ensure no committed request is ever applied twice

## Failure scenario

After a leader crash with an uncommitted entry in the log, the new leader rebuilds dedup from the suffix including the uncommitted entry, then truncates it. A retry of that request is answered as a duplicate and acknowledged, but the write is missing from the log.

## Expected agent pitfalls

- Increasing the suffix window instead of fixing the order of operations
- Removing truncation entirely, which leaves uncommitted entries that never advance to commit
- Adding a local dedup cache that is lost on restart
- Only fixing the counterexample case without addressing the general ordering issue

## Anti-shortcut measures

- Deterministic failover scenarios test the dedup-after-truncation bug across many configurations
- Tests check both invariants: acked writes applied and no double application
- The wrong fix of increasing the suffix window still fails because uncommitted entries are always at the end of the log regardless of window size

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_1_ack_applied`, `test_counterexample`, `test_failover_retry_scenario`, `test_repro_main_ok_after_fix` |
| C2 | `test_invariant_2_dedup_at_most_once`, `test_counterexample`, `test_failover_retry_scenario` |
