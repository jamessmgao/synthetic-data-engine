#!/usr/bin/env python3
"""Model-check the library cluster: deterministic failover scenarios for inv1, random for inv2."""
import sys
import json
import random

sys.path.insert(0, '/app')
from cluster import Cluster


def run_failover_scenario(seed):
    """Deterministic failover scenarios that test the dedup-after-truncation bug."""
    rng = random.Random(seed)
    c = Cluster()
    inv1_violations = []
    inv2_violations = []

    # Scenario parameters based on seed
    num_committed = 1 + (seed % 5)  # 1-5 committed entries
    elect_node = 1 if seed < 7 else 2  # which follower to elect
    num_uncommitted = 1 + (seed % 3)  # 1-3 uncommitted entries
    use_c2 = seed >= 8  # use second client for some seeds
    cid = 'C2' if use_c2 else 'C1'

    # Phase 1: Append and commit entries
    for rid in range(1, num_committed + 1):
        result = c.do_append(cid, rid, 'checkout', {'patron': 'alice', 'book': f'B{rid}'})
        assert result == 'appended', f'append failed for rid {rid}: {result}'
        c.do_replicate_to(rid, 1)
        c.do_replicate_to(rid, 2)
        c.do_advance_commit()
        c.do_apply()
        c.do_notify_commit()
        c.do_ack(cid, rid)

    # Phase 2: Append uncommitted entries (replicate to one follower only)
    uncommitted_rids = []
    for i in range(num_uncommitted):
        rid = num_committed + 1 + i
        result = c.do_append(cid, rid, 'checkout', {'patron': 'alice', 'book': f'B{rid}'})
        assert result == 'appended', f'append failed for uncommitted rid {rid}: {result}'
        c.do_replicate_to(rid, 1)  # replicate to n1 only (not n2)
        uncommitted_rids.append(rid)

    # Phase 3: Crash the leader
    c.do_crash(0)

    # Phase 4: Elect new leader
    c.do_elect(elect_node)

    # Phase 5: Retry uncommitted entries
    for rid in uncommitted_rids:
        result = c.do_append(cid, rid, 'checkout', {'patron': 'alice', 'book': f'B{rid}'})
        # With the fix: should return 'appended' (not dup_ok)
        # With the bug: returns 'dup_ok' but entry is missing from log
        new_l = c.leader()
        if new_l and new_l.log:
            for n in c.nodes:
                if n.nid != new_l.nid and n.alive:
                    c.do_replicate_to(new_l.last_idx(), n.nid)
            c.do_advance_commit()
            c.do_apply()
            c.do_notify_commit()
        c.do_ack(cid, rid)

    # Check invariant 1: every acked write is applied
    inv1 = c.check_acked_applied()
    if inv1 is not True:
        inv1_violations.append({"seed": seed, "detail": str(inv1)})

    # Check invariant 2: each request ID is applied at most once
    l = c.leader()
    if l:
        applied = [e for e in l.log if e.index <= l.applied_idx]
        seen = {}
        for e in applied:
            key = f"({e.client_id},rid={e.request_id})"
            if key in seen:
                inv2_violations.append({"seed": seed, "detail": f"{key} applied {seen[key]+1} times"})
            seen[key] = seen.get(key, 0) + 1

    return {"inv1": inv1_violations, "inv2": inv2_violations}


def run_random_check(seed, max_steps=80):
    """Random model check for invariant 2 (no duplicate application)."""
    rng = random.Random(seed)
    c = Cluster()
    clients = ['C1', 'C2']
    next_rid = {'C1': 1, 'C2': 1}
    inv2_violations = []

    for step in range(max_steps):
        l = c.leader()
        alive = [n for n in c.nodes if n.alive]
        if not alive:
            break
        ops = []
        if l:
            for _ in range(3): ops.append('append')
            if l.log:
                for _ in range(2): ops.append('replicate')
            for _ in range(3): ops.append('commit_apply_notify')
            for _ in range(2): ops.append('crash_leader')
        if not l and alive:
            for _ in range(3): ops.append('elect')
        if not ops:
            break
        op = rng.choice(ops)

        if op == 'append' and l:
            cid = rng.choice(clients)
            rid = next_rid[cid]
            book = rng.choice(['B1', 'B2'])
            patron = rng.choice(['alice', 'bob'])
            rop = rng.choice(['checkout', 'return'])
            result = c.do_append(cid, rid, rop, {'patron': patron, 'book': book})
            if result == 'appended':
                next_rid[cid] += 1
                targets = [n for n in c.nodes if n.nid != l.nid and n.alive]
                if targets:
                    c.do_replicate_to(l.last_idx(), rng.choice(targets).nid)

        elif op == 'replicate' and l and l.log:
            idx = rng.choice([e.index for e in l.log])
            targets = [n for n in c.nodes if n.nid != l.nid and n.alive]
            if targets:
                c.do_replicate_to(idx, rng.choice(targets).nid)

        elif op == 'commit_apply_notify':
            c.do_advance_commit()
            c.do_apply()
            c.do_notify_commit()

        elif op == 'crash_leader' and l:
            c.do_crash(l.nid)

        elif op == 'elect':
            candidates = [n for n in alive if not n.is_leader]
            if not candidates:
                candidates = alive
            nid = rng.choice(candidates).nid
            c.do_elect(nid)
            # After elect, retry recent request IDs
            new_l = c.leader()
            if new_l:
                for cid in clients:
                    if next_rid[cid] > 1:
                        rid = rng.randint(1, next_rid[cid] - 1)
                        book = rng.choice(['B1', 'B2'])
                        patron = rng.choice(['alice', 'bob'])
                        rop = rng.choice(['checkout', 'return'])
                        c.do_append(cid, rid, rop, {'patron': patron, 'book': book})
                        if new_l.log:
                            for n in c.nodes:
                                if n.nid != new_l.nid and n.alive:
                                    c.do_replicate_to(new_l.last_idx(), n.nid)
                            c.do_advance_commit()
                            c.do_apply()
                            c.do_notify_commit()

        # Check invariant 2 only
        l = c.leader()
        if l:
            applied = [e for e in l.log if e.index <= l.applied_idx]
            seen = {}
            for e in applied:
                key = f"({e.client_id},rid={e.request_id})"
                if key in seen:
                    inv2_violations.append({"step": step, "op": op, "detail": f"{key} applied {seen[key]+1} times"})
                seen[key] = seen.get(key, 0) + 1

    return {"inv2": inv2_violations}


def run_counterexample():
    c = Cluster()
    steps = {
        'append_r1': lambda: c.do_append('C1', 1, 'checkout', {'patron': 'alice', 'book': 'B1'}),
        'replicate_r1_n1': lambda: c.do_replicate_to(1, 1),
        'replicate_r1_n2': lambda: c.do_replicate_to(1, 2),
        'commit_r1': lambda: c.do_advance_commit(),
        'apply_r1': lambda: c.do_apply(),
        'notify_r1': lambda: c.do_notify_commit(),
        'ack_r1': lambda: c.do_ack('C1', 1),
        'append_r2': lambda: c.do_append('C1', 2, 'checkout', {'patron': 'alice', 'book': 'B2'}),
        'replicate_r2_n1': lambda: c.do_replicate_to(2, 1),
        'crash_n0': lambda: c.do_crash(0),
        'elect_n1': lambda: c.do_elect(1),
        'retry_r2': lambda: c.do_append('C1', 2, 'checkout', {'patron': 'alice', 'book': 'B2'}),
        'ack_r2': lambda: c.do_ack('C1', 2),
    }
    sequence = ["append_r1", "replicate_r1_n1", "replicate_r1_n2", "commit_r1",
                "apply_r1", "notify_r1", "ack_r1", "append_r2", "replicate_r2_n1",
                "crash_n0", "elect_n1", "retry_r2", "ack_r2"]
    inv1_violations = []
    inv2_violations = []
    for i, step_name in enumerate(sequence):
        if step_name in steps:
            steps[step_name]()
        inv1 = c.check_acked_applied()
        if inv1 is not True:
            inv1_violations.append({"step": i, "op": step_name, "detail": str(inv1)})
        l = c.leader()
        if l:
            applied = [e for e in l.log if e.index <= l.applied_idx]
            seen = {}
            for e in applied:
                key = f"({e.client_id},rid={e.request_id})"
                if key in seen:
                    inv2_violations.append({"step": i, "op": step_name, "detail": f"{key} applied {seen[key]+1} times"})
                seen[key] = seen.get(key, 0) + 1
    return {"inv1": inv1_violations, "inv2": inv2_violations}


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'failover':
        seed = int(sys.argv[2])
        result = run_failover_scenario(seed)
        print(json.dumps(result))
        sys.exit(1 if result["inv1"] or result["inv2"] else 0)
    elif mode == 'random':
        seed = int(sys.argv[2])
        result = run_random_check(seed)
        print(json.dumps(result))
        sys.exit(1 if result.get("inv2") else 0)
    elif mode == 'counterexample':
        result = run_counterexample()
        print(json.dumps(result))
        sys.exit(1 if result["inv1"] or result["inv2"] else 0)
