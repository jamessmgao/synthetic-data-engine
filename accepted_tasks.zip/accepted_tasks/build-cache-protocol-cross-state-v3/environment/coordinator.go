package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
)

func writeInbox(filename string, v interface{}) error {
	path := filepath.Join(inboxDir, filename)
	data, err := json.Marshal(v)
	if err != nil {
		return err
	}
	return os.WriteFile(path, data, 0666)
}

func cmdPrepare(args []string) {
	if len(args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: prepare <txid> <target>")
		os.Exit(2)
	}
	txid := args[0]
	target := args[1]
	src := loadSourceState()
	digest, ok := src.Targets[target]
	if !ok {
		fmt.Fprintln(os.Stderr, "unknown target")
		os.Exit(1)
	}
	ps := loadProtocolState()
	cs := loadCoordinatorState()
	cs.Pending[txid] = PendingTx{
		Target: target,
		Digest: digest,
		Stage:  "prepared",
		Ver:    ps.Ver,
	}
	failOn(saveCoordinatorState(cs))
	msg := PrepareMessage{Txid: txid, Target: target, Digest: digest, Ver: ps.Ver}
	failOn(writeInbox("prepare-"+txid+".json", msg))
	fmt.Println("prepared", txid)
}

func cmdAck(args []string) {
	if len(args) < 1 {
		fmt.Fprintln(os.Stderr, "usage: ack <txid>")
		os.Exit(2)
	}
	txid := args[0]
	cs := loadCoordinatorState()
	pending, ok := cs.Pending[txid]
	if !ok {
		fmt.Fprintln(os.Stderr, "unknown transaction")
		os.Exit(1)
	}
	pending.Stage = "acked"
	cs.Pending[txid] = pending
	failOn(saveCoordinatorState(cs))
	msg := AckMessage{Txid: txid, Target: pending.Target, Digest: pending.Digest, Ver: pending.Ver}
	failOn(writeInbox("ack-"+txid+".json", msg))
	fmt.Println("acked", txid)
}

func cmdCommit(args []string) {
	if len(args) < 1 {
		fmt.Fprintln(os.Stderr, "usage: commit <txid>")
		os.Exit(2)
	}
	txid := args[0]
	cs := loadCoordinatorState()
	pending, ok := cs.Pending[txid]
	if !ok {
		fmt.Fprintln(os.Stderr, "unknown transaction")
		os.Exit(1)
	}
	pending.Stage = "committed"
	cs.Pending[txid] = pending
	failOn(saveCoordinatorState(cs))
	msg := CommitMessage{Txid: txid}
	failOn(writeInbox("commit-"+txid+".json", msg))
	fmt.Println("committed", txid)
}

func cmdBuild(args []string) {
	if len(args) < 1 {
		fmt.Fprintln(os.Stderr, "usage: build <target>")
		os.Exit(2)
	}
	target := args[0]
	src := loadSourceState()
	digest, ok := src.Targets[target]
	if !ok {
		fmt.Fprintln(os.Stderr, "unknown target")
		os.Exit(1)
	}
	cache := loadCacheState()
	if entry, ok := cache.Entries[target]; ok && entry.Digest == digest {
		fmt.Println("cache_hit", target)
		return
	}
	ps := loadProtocolState()
	cs := loadCoordinatorState()
	txid := fmt.Sprintf("tx-%d", len(cs.Pending)+1)
	cs.Pending[txid] = PendingTx{Target: target, Digest: digest, Stage: "prepared", Ver: ps.Ver}
	failOn(saveCoordinatorState(cs))
	msg := PrepareMessage{Txid: txid, Target: target, Digest: digest, Ver: ps.Ver}
	failOn(writeInbox("prepare-"+txid+".json", msg))
	fmt.Println("building", txid)
}

func cmdRetry() {
	ws := loadWorkerState()
	for txid := range ws.Staged {
		msg := CommitMessage{Txid: txid}
		failOn(writeInbox("commit-"+txid+".json", msg))
	}
	fmt.Println("retry sent", len(ws.Staged), "commits")
}
