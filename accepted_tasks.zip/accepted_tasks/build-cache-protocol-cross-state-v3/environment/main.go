package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
)

const stateDir = "/app/state"
const inboxDir = stateDir + "/inbox"

type ProtocolState struct {
	Ver int `json:"ver"`
}

type SourceState struct {
	Targets map[string]string `json:"targets"`
}

type CacheEntry struct {
	Digest   string `json:"digest"`
	Artifact string `json:"artifact"`
}

type CacheState struct {
	Entries map[string]CacheEntry `json:"entries"`
}

type PendingTx struct {
	Target string `json:"target"`
	Digest string `json:"digest"`
	Stage  string `json:"stage"`
	Ver    int    `json:"ver"`
}

type CoordinatorState struct {
	Pending map[string]PendingTx `json:"pending"`
}

type PreparedTx struct {
	Target   string `json:"target"`
	Digest   string `json:"digest"`
	Artifact string `json:"artifact"`
	Ver      int    `json:"ver"`
}

type WorkerState struct {
	Prepared map[string]PreparedTx `json:"prepared"`
	Staged   map[string]PreparedTx `json:"staged"`
}

type PrepareMessage struct {
	Txid   string `json:"txid"`
	Target string `json:"target"`
	Digest string `json:"digest"`
	Ver    int    `json:"ver"`
}

type AckMessage struct {
	Txid   string `json:"txid"`
	Target string `json:"target"`
	Digest string `json:"digest"`
	Ver    int    `json:"ver"`
}

type CommitMessage struct {
	Txid string `json:"txid"`
}

func failOn(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func loadJSON(path string, v interface{}) error {
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	if len(data) == 0 {
		return nil
	}
	return json.Unmarshal(data, v)
}

func saveJSON(path string, v interface{}) error {
	if err := os.MkdirAll(filepath.Dir(path), 0777); err != nil {
		return err
	}
	data, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, data, 0666)
}

func loadProtocolState() *ProtocolState {
	s := &ProtocolState{Ver: 0}
	_ = loadJSON(filepath.Join(stateDir, "protocol.json"), s)
	return s
}

func saveProtocolState(s *ProtocolState) error {
	return saveJSON(filepath.Join(stateDir, "protocol.json"), s)
}

func loadSourceState() *SourceState {
	s := &SourceState{Targets: map[string]string{}}
	_ = loadJSON(filepath.Join(stateDir, "source.json"), s)
	if s.Targets == nil {
		s.Targets = map[string]string{}
	}
	return s
}

func saveSourceState(s *SourceState) error {
	return saveJSON(filepath.Join(stateDir, "source.json"), s)
}

func loadCacheState() *CacheState {
	s := &CacheState{Entries: map[string]CacheEntry{}}
	_ = loadJSON(filepath.Join(stateDir, "cache.json"), s)
	if s.Entries == nil {
		s.Entries = map[string]CacheEntry{}
	}
	return s
}

func saveCacheState(s *CacheState) error {
	return saveJSON(filepath.Join(stateDir, "cache.json"), s)
}

func loadCoordinatorState() *CoordinatorState {
	s := &CoordinatorState{Pending: map[string]PendingTx{}}
	_ = loadJSON(filepath.Join(stateDir, "coordinator.json"), s)
	if s.Pending == nil {
		s.Pending = map[string]PendingTx{}
	}
	return s
}

func saveCoordinatorState(s *CoordinatorState) error {
	return saveJSON(filepath.Join(stateDir, "coordinator.json"), s)
}

func loadWorkerState() *WorkerState {
	s := &WorkerState{Prepared: map[string]PreparedTx{}, Staged: map[string]PreparedTx{}}
	_ = loadJSON(filepath.Join(stateDir, "worker.json"), s)
	if s.Prepared == nil {
		s.Prepared = map[string]PreparedTx{}
	}
	if s.Staged == nil {
		s.Staged = map[string]PreparedTx{}
	}
	return s
}

func saveWorkerState(s *WorkerState) error {
	return saveJSON(filepath.Join(stateDir, "worker.json"), s)
}

func cmdInit() {
	os.RemoveAll(stateDir)
	os.MkdirAll(inboxDir, 0777)
	failOn(saveProtocolState(&ProtocolState{Ver: 0}))
	failOn(saveSourceState(&SourceState{Targets: map[string]string{}}))
	failOn(saveCacheState(&CacheState{Entries: map[string]CacheEntry{}}))
	failOn(saveCoordinatorState(&CoordinatorState{Pending: map[string]PendingTx{}}))
	failOn(saveWorkerState(&WorkerState{Prepared: map[string]PreparedTx{}, Staged: map[string]PreparedTx{}}))
	fmt.Println("initialized")
}

func cmdSource(args []string) {
	if len(args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: source set <target> <digest>")
		os.Exit(2)
	}
	switch args[0] {
	case "set":
		if len(args) < 3 {
			fmt.Fprintln(os.Stderr, "usage: source set <target> <digest>")
			os.Exit(2)
		}
	case "get":
		if len(args) < 2 {
			fmt.Fprintln(os.Stderr, "usage: source get <target>")
			os.Exit(2)
		}
		s := loadSourceState()
		fmt.Println(s.Targets[args[1]])
		return
	default:
		fmt.Fprintln(os.Stderr, "unknown source command")
		os.Exit(2)
	}
	target := args[1]
	digest := args[2]
	s := loadSourceState()
	s.Targets[target] = digest
	failOn(saveSourceState(s))
	fmt.Println("set", target, digest)
}

type cacheReport struct {
	Target   string `json:"target"`
	Digest   string `json:"digest"`
	Artifact string `json:"artifact"`
}

func cmdCache(args []string) {
	if len(args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: cache get <target>")
		os.Exit(2)
	}
	if args[0] != "get" {
		fmt.Fprintln(os.Stderr, "unknown cache command")
		os.Exit(2)
	}
	target := args[1]
	c := loadCacheState()
	entry, ok := c.Entries[target]
	if !ok {
		entry = CacheEntry{}
	}
	out, err := json.Marshal(cacheReport{Target: target, Digest: entry.Digest, Artifact: entry.Artifact})
	failOn(err)
	fmt.Println(string(out))
}

func main() {
	if len(os.Args) < 2 {
		fmt.Println("buildcache [init|source|cache|prepare|ack|commit|build|worker|reconnect]")
		return
	}
	switch os.Args[1] {
	case "init":
		cmdInit()
	case "source":
		cmdSource(os.Args[2:])
	case "cache":
		cmdCache(os.Args[2:])
	case "prepare":
		cmdPrepare(os.Args[2:])
	case "ack":
		cmdAck(os.Args[2:])
	case "commit":
		cmdCommit(os.Args[2:])
	case "build":
		cmdBuild(os.Args[2:])
	case "worker":
		cmdWorker()
	case "reconnect":
		cmdReconnect()
	case "retry":
		cmdRetry()
	default:
		fmt.Fprintln(os.Stderr, "unknown command")
		os.Exit(2)
	}
}
