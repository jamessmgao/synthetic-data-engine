package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
)

func readInboxMessages(prefix string) []string {
	entries, err := os.ReadDir(inboxDir)
	if err != nil {
		return nil
	}
	var result []string
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		name := e.Name()
		if len(name) >= len(prefix) && name[:len(prefix)] == prefix {
			result = append(result, name)
		}
	}
	sort.Strings(result)
	return result
}

func processPrepareMessages() {
	files := readInboxMessages("prepare-")
	for _, f := range files {
		path := filepath.Join(inboxDir, f)
		data, err := os.ReadFile(path)
		if err != nil {
			continue
		}
		var msg PrepareMessage
		if err := json.Unmarshal(data, &msg); err != nil {
			continue
		}
		ws := loadWorkerState()
		artifact := fmt.Sprintf("artifact-for-%s-%s", msg.Target, msg.Digest)
		ws.Prepared[msg.Txid] = PreparedTx{
			Target:   msg.Target,
			Digest:   msg.Digest,
			Artifact: artifact,
			Ver:      msg.Ver,
		}
		failOn(saveWorkerState(ws))
		os.Remove(path)
	}
}

func processAckMessages() {
	files := readInboxMessages("ack-")
	for _, f := range files {
		path := filepath.Join(inboxDir, f)
		data, err := os.ReadFile(path)
		if err != nil {
			continue
		}
		var msg AckMessage
		if err := json.Unmarshal(data, &msg); err != nil {
			continue
		}
		ws := loadWorkerState()
		prep, exists := ws.Prepared[msg.Txid]
		if !exists {
			os.Remove(path)
			continue
		}
		ws.Staged[msg.Txid] = prep
		delete(ws.Prepared, msg.Txid)
		failOn(saveWorkerState(ws))
		os.Remove(path)
	}
}

func processCommitMessages() {
	files := readInboxMessages("commit-")
	for _, f := range files {
		path := filepath.Join(inboxDir, f)
		data, err := os.ReadFile(path)
		if err != nil {
			continue
		}
		var msg CommitMessage
		if err := json.Unmarshal(data, &msg); err != nil {
			continue
		}
		ws := loadWorkerState()
		staged, exists := ws.Staged[msg.Txid]
		if !exists {
			os.Remove(path)
			continue
		}
		cs := loadCoordinatorState()
		pending, pendingExists := cs.Pending[msg.Txid]
		if !pendingExists {
			os.Remove(path)
			continue
		}
		cache := loadCacheState()
		cache.Entries[pending.Target] = CacheEntry{
			Digest:   staged.Digest,
			Artifact: staged.Artifact,
		}
		failOn(saveCacheState(cache))
		delete(ws.Staged, msg.Txid)
		failOn(saveWorkerState(ws))
		os.Remove(path)
	}
}

func cmdWorker() {
	processPrepareMessages()
	processAckMessages()
	processCommitMessages()
	fmt.Println("processed")
}

func cmdReconnect() {
	ps := loadProtocolState()
	ps.Ver++
	failOn(saveProtocolState(ps))
	ws := loadWorkerState()
	ws.Prepared = map[string]PreparedTx{}
	failOn(saveWorkerState(ws))
	cs := loadCoordinatorState()
	cs.Pending = map[string]PendingTx{}
	failOn(saveCoordinatorState(cs))
	fmt.Println("reconnected")
}
