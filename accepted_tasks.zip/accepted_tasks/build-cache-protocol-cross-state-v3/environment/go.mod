module buildcache

go 1.23
