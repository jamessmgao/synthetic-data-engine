# Build cache protocol accepts wrong state after reconnect

A Go build cache coordinator and worker use a simple protocol over inbox files. After a reconnect resets protocol version and coordinator state, reused transaction identities and stale worker snapshots can write wrong digests into the cache, and retry can report success without completing interrupted builds.

## Scenario

The agent works in a Go CLI service that persists protocol, source, cache, coordinator, and worker state under /app/state and exchanges prepare/ack/commit JSON messages through /app/state/inbox. Users run buildcache init, source set, build, worker, ack, commit, reconnect, retry, and cache get. The defect appears under cross-component state resets and source changes.

## Root cause (hidden from the agent)

Transaction identities are derived from len(cs.Pending)+1, so reconnect clears pending state and identities are reused. Worker staged records survive reconnect with old digests and protocol versions. processCommitMessages trusts staged digests without validating against current source and protocol state. cmdRetry only resends commits for currently staged records and does not re-prepare or recover targets whose staged work is stale or whose coordinator mapping was reset. source set updates source state without invalidating stale cache entries.

## Correctness constraints

- **C1**: Every cache entry digest matches the current source digest for its target; after any command, cache get reports an empty entry or the current source digest.
- **C2**: After a source change, buildcache retry must complete the interrupted build so the target ends up cached with the digest current when retry runs; retry must not report success while the cache for that target is empty or unfilled.

## Subgoals

1. Invalidate cache entries when their source digest changes.
2. Ensure transaction identities are durable and not reused after reconnect.
3. Validate staged worker records against current source and protocol state before committing.
4. Make retry re-prepare and re-drive builds for targets with stale, staged, or pending interrupted work using the current source digest.

## Failure scenario

The replay builds app, stages tx-1, changes lib source, reconnects, builds lib reusing tx-1, commits, and runs retry. The worker writes a cache entry for lib from an old staged snapshot, and retry leaves the interrupted build unrecovered. Tests replay this and run randomized schedules over 10 fixed seeds.

## Expected agent pitfalls

- A local validation in processCommitMessages removes the stale write but leaves no staged record for retry to recover.
- Changing retry to only resend commits for staged records does not re-prepare builds after reconnect clears coordinator pending state.
- Ignoring source-set cache invalidation keeps stale digests visible through cache get.
- Reusing transaction ids after reconnect can join an old worker snapshot to a new target.

## Anti-shortcut measures

- Tests assert cache digests after every step of randomized schedules, not only at the end.
- Tests replay the exact counterexample and assert retry fills the cache after source change.
- Tests check durable artifacts and command outputs, not internal Go structs.
- Random schedules use fixed seeds and include worker kills, reconnects, retries, and source changes.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_1_cache_digest_matches_current_source`, `test_counterexample_replay`, `test_regression_cache_hit_errors_and_retry_keep_working`, `test_edge_cases_multiple_targets_reconnect_and_restart` |
| C2 | `test_invariant_2_retry_completes_interrupted_build_after_source_change`, `test_counterexample_replay`, `test_regression_cache_hit_errors_and_retry_keep_working`, `test_edge_cases_multiple_targets_reconnect_and_restart` |
