"""Black-box helpers for the jobd HTTP service."""
import json
import os
import shutil
import signal
import subprocess
import time
import urllib.error
import urllib.request

NODES = {
    "node-a": ("127.0.0.1", 18001),
    "node-b": ("127.0.0.1", 18002),
    "node-c": ("127.0.0.1", 18003),
}
PEERS = ",".join(f"{name}={host}:{port}" for name, (host, port) in NODES.items())

class Cluster:
    def __init__(self, root):
        self.root = str(root)
        self.procs = {}
        self.base = {name: f"http://{host}:{port}" for name, (host, port) in NODES.items()}
        self.reset()

    def reset(self):
        self.stop_all()
        shutil.rmtree(self.root, ignore_errors=True)
        os.makedirs(self.root, exist_ok=True)

    def start(self, name):
        if name in self.procs:
            return
        host, port = NODES[name]
        log_path = os.path.join(self.root, f"{name}.log")
        log = open(log_path, "ab")
        try:
            proc = subprocess.Popen(
                ["/app/jobd", "-id", name, "-addr", f"{host}:{port}",
                 "-dir", os.path.join(self.root, name), "-peers", PEERS],
                cwd="/app", stdout=log, stderr=log,
            )
        finally:
            log.close()
        self.procs[name] = proc
        self.wait_ready(name)

    def wait_ready(self, name, attempts=100):
        last = None
        for _ in range(attempts):
            proc = self.procs.get(name)
            if proc is not None and proc.poll() is not None:
                raise RuntimeError(f"{name} exited during startup: {proc.returncode}")
            try:
                self.get(name, "/status")
                return
            except Exception as exc:
                last = exc
                time.sleep(0.02)
        raise RuntimeError(f"{name} not ready: {last}")

    def start_all(self):
        for name in NODES:
            self.start(name)

    def kill(self, name):
        proc = self.procs.pop(name, None)
        if proc is not None and proc.poll() is None:
            proc.send_signal(signal.SIGKILL)
            proc.wait(timeout=3)

    def stop_all(self):
        for name in list(self.procs):
            proc = self.procs.pop(name)
            if proc.poll() is None:
                proc.send_signal(signal.SIGKILL)
                proc.wait(timeout=3)

    def request(self, name, path, method="GET", body=None, timeout=4):
        data = None if body is None else json.dumps(body).encode()
        req = urllib.request.Request(self.base[name] + path, data=data, method=method)
        if data is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                raw = response.read()
                return response.status, json.loads(raw) if raw else None
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            return exc.code, json.loads(raw) if raw else None

    def get(self, name, path, timeout=2):
        with urllib.request.urlopen(self.base[name] + path, timeout=timeout) as response:
            if response.status != 200:
                raise RuntimeError(f"unexpected status {response.status}")
            return json.loads(response.read())

    def put(self, name, request_id, account, amount):
        return self.request(name, "/put", "POST", {
            "request_id": request_id, "account": account, "amount": amount,
        })

    def promote(self, name):
        return self.request(name, "/admin/leader", "POST")

    def compact(self, name):
        return self.request(name, "/admin/compact", "POST")

    def status(self, name):
        return self.get(name, "/status")

    def log(self, name):
        return self.get(name, "/log")

    def balance(self, name, account):
        return int(self.status(name)["balance"].get(account, 0))
