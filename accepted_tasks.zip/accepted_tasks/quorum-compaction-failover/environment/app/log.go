package main

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
)

type Entry struct {
	Seq       int    `json:"seq"`
	Epoch     int    `json:"epoch"`
	RequestID string `json:"request_id"`
	Account   string `json:"account"`
	Amount    int    `json:"amount"`
}

type Snapshot struct {
	Balance     map[string]int `json:"balance"`
	LastApplied int            `json:"last_applied"`
}

type WAL struct {
	path string
	mu   sync.Mutex
}

func NewWAL(dataDir string) *WAL {
	return &WAL{path: filepath.Join(dataDir, "wal.jsonl")}
}

func (w *WAL) Append(e Entry) error {
	w.mu.Lock()
	defer w.mu.Unlock()

	f, err := os.OpenFile(w.path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return err
	}
	defer f.Close()

	enc := json.NewEncoder(f)
	if err := enc.Encode(e); err != nil {
		return err
	}
	return f.Sync()
}

func (w *WAL) scanEntriesLocked() ([]Entry, error) {
	f, err := os.Open(w.path)
	if os.IsNotExist(err) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var entries []Entry
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1024*1024), 1024*1024)
	for sc.Scan() {
		if len(sc.Bytes()) == 0 {
			continue
		}
		var e Entry
		if err := json.Unmarshal(sc.Bytes(), &e); err != nil {
			return nil, err
		}
		entries = append(entries, e)
	}
	if err := sc.Err(); err != nil {
		return nil, err
	}
	return entries, nil
}

func (w *WAL) Entries() ([]Entry, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.scanEntriesLocked()
}

func (w *WAL) LastSeq() int {
	entries, err := w.Entries()
	if err != nil {
		return 0
	}
	last := 0
	for _, e := range entries {
		if e.Seq > last {
			last = e.Seq
		}
	}
	return last
}

func (w *WAL) SaveSnapshot(s Snapshot) error {
	w.mu.Lock()
	defer w.mu.Unlock()

	snapPath := filepath.Join(filepath.Dir(w.path), "snapshot.json")
	data, err := json.Marshal(s)
	if err != nil {
		return err
	}
	if err := os.WriteFile(snapPath, data, 0o644); err != nil {
		return err
	}

	entries, err := w.scanEntriesLocked()
	if err != nil {
		return err
	}
	var kept []Entry
	for _, e := range entries {
		if e.Seq > s.LastApplied {
			kept = append(kept, e)
		}
	}

	tmp := w.path + ".tmp"
	f, err := os.Create(tmp)
	if err != nil {
		return err
	}
	enc := json.NewEncoder(f)
	for _, e := range kept {
		if err := enc.Encode(e); err != nil {
			f.Close()
			return err
		}
	}
	if err := f.Sync(); err != nil {
		f.Close()
		return err
	}
	f.Close()
	return os.Rename(tmp, w.path)
}

func (w *WAL) LoadSnapshot() (*Snapshot, error) {
	snapPath := filepath.Join(filepath.Dir(w.path), "snapshot.json")
	data, err := os.ReadFile(snapPath)
	if os.IsNotExist(err) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	var s Snapshot
	if err := json.Unmarshal(data, &s); err != nil {
		return nil, err
	}
	return &s, nil
}
