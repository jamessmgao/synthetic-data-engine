module jobd

go 1.23
