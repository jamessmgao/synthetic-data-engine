package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"net/http"
	"os"
	"strings"
	"sync"
)

type Node struct {
	mu          sync.Mutex
	id          string
	addr        string
	dataDir     string
	peers       map[string]string
	role        string
	epoch       int
	wal         *WAL
	balance     map[string]int
	nextSeq     int
	lastApplied int
}

type Status struct {
	ID          string            `json:"id"`
	Role        string            `json:"role"`
	Epoch       int               `json:"epoch"`
	Addr        string            `json:"addr"`
	Peers       map[string]string `json:"peers"`
	Balance     map[string]int    `json:"balance"`
	LastApplied int               `json:"last_applied"`
}

func newNode(id, addr, dir, peers string) (*Node, error) {
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, err
	}
	p := map[string]string{}
	for _, part := range strings.Split(peers, ",") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		k, v, ok := strings.Cut(part, "=")
		if !ok {
			return nil, fmt.Errorf("invalid peer %q", part)
		}
		p[k] = v
	}
	n := &Node{
		id:          id,
		addr:        addr,
		dataDir:     dir,
		peers:       p,
		role:        "follower",
		epoch:       0,
		wal:         NewWAL(dir),
		balance:     map[string]int{},
		nextSeq:     0,
		lastApplied: 0,
	}
	return n, nil
}

func (n *Node) status() Status {
	n.mu.Lock()
	defer n.mu.Unlock()
	bal := make(map[string]int, len(n.balance))
	for k, v := range n.balance {
		bal[k] = v
	}
	return Status{
		ID:          n.id,
		Role:        n.role,
		Epoch:       n.epoch,
		Addr:        n.addr,
		Peers:       n.peers,
		Balance:     bal,
		LastApplied: n.lastApplied,
	}
}

func (n *Node) writeJSON(w http.ResponseWriter, v any, code int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func (n *Node) routes() *http.ServeMux {
	mux := http.NewServeMux()
	mux.HandleFunc("/status", func(w http.ResponseWriter, r *http.Request) {
		n.writeJSON(w, n.status(), http.StatusOK)
	})
	mux.HandleFunc("/put", n.putHandler)
	mux.HandleFunc("/replicate", n.replicateHandler)
	mux.HandleFunc("/log", n.logHandler)
	mux.HandleFunc("/admin/leader", func(w http.ResponseWriter, r *http.Request) {
		n.becomeLeader()
		n.writeJSON(w, n.status(), http.StatusOK)
	})
	mux.HandleFunc("/admin/compact", n.compactHandler)
	return mux
}

func main() {
	id := flag.String("id", "", "node id")
	addr := flag.String("addr", "", "listen address")
	dir := flag.String("dir", "", "data directory")
	peers := flag.String("peers", "", "peers id=addr,...")
	flag.Parse()

	if *id == "" || *addr == "" || *dir == "" {
		fmt.Fprintln(os.Stderr, "id, addr and dir are required")
		os.Exit(2)
	}
	n, err := newNode(*id, *addr, *dir, *peers)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	n.replayWAL()
	srv := &http.Server{Addr: n.addr, Handler: n.routes()}
	fmt.Println(n.id, "listening", n.addr)
	if err := srv.ListenAndServe(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
