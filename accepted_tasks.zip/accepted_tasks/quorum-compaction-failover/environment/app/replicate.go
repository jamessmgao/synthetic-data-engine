package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

type PutRequest struct {
	RequestID string `json:"request_id"`
	Account   string `json:"account"`
	Amount    int    `json:"amount"`
}

type ReplicateRequest struct {
	Entry Entry `json:"entry"`
}

func (n *Node) applyEntry(e Entry) {
	n.mu.Lock()
	n.balance[e.Account] += e.Amount
	if e.Seq > n.lastApplied {
		n.lastApplied = e.Seq
	}
	n.mu.Unlock()
}

func (n *Node) replayWAL() {
	snap, err := n.wal.LoadSnapshot()
	if err != nil {
		snap = nil
	}
	if snap != nil {
		n.mu.Lock()
		for k, v := range snap.Balance {
			n.balance[k] = v
		}
		n.lastApplied = snap.LastApplied
		n.mu.Unlock()
	}
	entries, err := n.wal.Entries()
	if err != nil {
		return
	}
	for _, e := range entries {
		if e.Seq > n.lastApplied {
			n.applyEntry(e)
		}
		if e.Seq > n.nextSeq {
			n.nextSeq = e.Seq
		}
	}
	n.mu.Lock()
	if n.nextSeq > n.lastApplied {
		n.lastApplied = n.nextSeq
	}
	n.mu.Unlock()
}

func (n *Node) putHandler(w http.ResponseWriter, r *http.Request) {
	n.mu.Lock()
	isLeader := n.role == "leader"
	n.mu.Unlock()
	if !isLeader {
		n.writeJSON(w, map[string]string{"error": "not leader"}, http.StatusForbidden)
		return
	}
	body, err := io.ReadAll(r.Body)
	if err != nil {
		n.writeJSON(w, map[string]string{"error": "bad request"}, http.StatusBadRequest)
		return
	}
	var req PutRequest
	if err := json.Unmarshal(body, &req); err != nil {
		n.writeJSON(w, map[string]string{"error": "bad json"}, http.StatusBadRequest)
		return
	}
	n.mu.Lock()
	n.nextSeq++
	seq := n.nextSeq
	epoch := n.epoch
	n.mu.Unlock()
	entry := Entry{Seq: seq, Epoch: epoch, RequestID: req.RequestID, Account: req.Account, Amount: req.Amount}
	if err := n.wal.Append(entry); err != nil {
		n.writeJSON(w, map[string]string{"error": "wal error"}, http.StatusInternalServerError)
		return
	}
	replicated := n.sendToFollowers(entry)
	n.applyEntry(entry)
	n.writeJSON(w, map[string]any{"seq": seq, "epoch": epoch, "replicated": replicated, "account": req.Account, "amount": req.Amount}, http.StatusOK)
}

func (n *Node) replicateHandler(w http.ResponseWriter, r *http.Request) {
	body, err := io.ReadAll(r.Body)
	if err != nil {
		n.writeJSON(w, map[string]string{"error": "bad request"}, http.StatusBadRequest)
		return
	}
	var req ReplicateRequest
	if err := json.Unmarshal(body, &req); err != nil {
		n.writeJSON(w, map[string]string{"error": "bad json"}, http.StatusBadRequest)
		return
	}
	if err := n.wal.Append(req.Entry); err != nil {
		n.writeJSON(w, map[string]string{"error": "wal error"}, http.StatusInternalServerError)
		return
	}
	n.applyEntry(req.Entry)
	n.mu.Lock()
	if req.Entry.Seq > n.nextSeq {
		n.nextSeq = req.Entry.Seq
	}
	n.mu.Unlock()
	n.writeJSON(w, map[string]string{"status": "ok"}, http.StatusOK)
}

func (n *Node) sendToFollowers(entry Entry) int {
	n.mu.Lock()
	peers := make(map[string]string, len(n.peers))
	for k, v := range n.peers {
		peers[k] = v
	}
	n.mu.Unlock()

	total := 0
	for id := range peers {
		if id != n.id {
			total++
		}
	}
	needed := total / 2
	results := make(chan bool, total)
	for id, addr := range peers {
		if id == n.id {
			continue
		}
		go func(id, addr string) {
			url := fmt.Sprintf("http://%s/replicate", addr)
			payload, _ := json.Marshal(ReplicateRequest{Entry: entry})
			client := &http.Client{Timeout: 2 * time.Second}
			resp, err := client.Post(url, "application/json", bytes.NewReader(payload))
			if err != nil {
				results <- false
				return
			}
			resp.Body.Close()
			results <- resp.StatusCode == http.StatusOK
		}(id, addr)
	}

	ok := 0
	for i := 0; i < total; i++ {
		if <-results {
			ok++
		}
		if ok >= needed {
			return ok
		}
	}
	return ok
}

func (n *Node) becomeLeader() {
	n.mu.Lock()
	n.role = "leader"
	n.epoch++
	n.mu.Unlock()
	entries, err := n.wal.Entries()
	if err != nil {
		return
	}
	for _, e := range entries {
		n.applyEntry(e)
	}
}

func (n *Node) logHandler(w http.ResponseWriter, r *http.Request) {
	entries, err := n.wal.Entries()
	if err != nil {
		n.writeJSON(w, map[string]string{"error": "wal error"}, http.StatusInternalServerError)
		return
	}
	n.writeJSON(w, entries, http.StatusOK)
}

func (n *Node) compactHandler(w http.ResponseWriter, r *http.Request) {
	n.mu.Lock()
	bal := make(map[string]int, len(n.balance))
	for k, v := range n.balance {
		bal[k] = v
	}
	la := n.lastApplied
	n.mu.Unlock()
	snap := Snapshot{Balance: bal, LastApplied: la}
	if err := n.wal.SaveSnapshot(snap); err != nil {
		n.writeJSON(w, map[string]string{"error": "compact failed"}, http.StatusInternalServerError)
		return
	}
	n.writeJSON(w, map[string]string{"status": "ok"}, http.StatusOK)
}
