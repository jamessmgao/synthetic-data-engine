# Quorum compaction and failover recovery

A three-node Go balance service accepts requests with quorum replication, supports compaction and manual leadership changes, and can lose accepted state when a follower is promoted. The task is to make accepted-request accounting recoverable and idempotent across partial failures.

## Scenario

The service exposes HTTP endpoints for submitting requests, inspecting status and logs, compacting a node, and promoting a leader. Processes may be killed and restarted, and requests may be retried after leadership changes.

## Root cause (hidden from the agent)

Compaction persists balances and sequence metadata but not the accepted request-ID map, and promotion replays only the promoted node's local snapshot and WAL. A node that missed quorum-committed entries cannot reconstruct the globally accepted set.

## Correctness constraints

- **C1**: Each accepted request ID is applied to the account balance at most once.
- **C2**: After a leader failover, the new leader's balance for an account equals the sum of amounts from all accepted requests for that account.
- **C3**: Once a request is accepted, every later leader treats a retry of that request as a duplicate.
- **C4**: Normal submissions, retries, process restarts, compaction, leader promotion, and independent account balances continue to work.

## Subgoals

1. Persist enough accepted-request information to replay and deduplicate entries safely.
2. Recover accepted state when a follower that missed entries becomes leader.
3. Preserve ordinary service behavior and account isolation across restarts and promotion.

## Failure scenario

A quorum commits requests while one follower is down; another node compacts; after the old leader dies, the missed follower is promoted and a request is retried. Its balance omits earlier accepted requests.

## Expected agent pitfalls

- Persisting request IDs only in each node-local snapshot, which cannot help a promoted node that missed the original entries.
- Making replay idempotent without reconciling peer state.
- Breaking duplicate retries or sequence continuity while adding persistence.

## Anti-shortcut measures

- Property tests use fixed seeds, concurrent unique submissions, SIGKILL, restart, compaction, and two promotions.
- Tests observe only HTTP status output and process behavior.
- The supplied plausible local-only fix is rejected by the invariant tests.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_1_at_most_once`, `test_counterexample` |
| C2 | `test_invariant_2_failover_balance`, `test_counterexample` |
| C3 | `test_invariant_3_retry_duplicate`, `test_counterexample` |
| C4 | `test_regression_basic_and_restart`, `test_compaction_and_two_failovers` |
