package main

type Schedule struct {
NumSlots  int       `json:"num_slots"`
Quota     int       `json:"quota"`
WindowSize int      `json:"window_size"`
Requests  []Request `json:"requests"`
}

type Request struct {
ID       string `json:"id"`
Consumer string `json:"consumer"`
Slot     int    `json:"slot"`
Priority int    `json:"priority"`
}

type Choice struct {
RequestID string `json:"request_id"`
Consumer  string `json:"consumer"`
Slot      int    `json:"slot"`
Priority  int    `json:"priority"`
}

type Plan struct {
NumSlots   int     `json:"num_slots"`
Quota      int     `json:"quota"`
WindowSize int     `json:"window_size"`
Accepted   []Choice `json:"accepted"`
Priority   int     `json:"priority"`
}

type ReportedChoice struct {
RequestID string `json:"request_id"`
Consumer  string `json:"consumer"`
Slot      int    `json:"slot"`
Priority  int    `json:"priority"`
}

type Report struct {
Accepted     []ReportedChoice `json:"accepted"`
Priority     int              `json:"priority"`
ConsumerLoad map[string]int   `json:"consumer_load"`
SlotLoad     []int            `json:"slot_load"`
Commitment   string           `json:"commitment"`
}

func validateSchedule(s Schedule) error {
N := s.NumSlots
if N < 4 || N > 48 {
return errInvalid("num_slots must be between 4 and 48")
}
if s.Quota < 4 || s.Quota > 10 {
return errInvalid("quota must be between 4 and 10")
}
if s.WindowSize < 2 || s.WindowSize >= N {
return errInvalid("window_size must be between 2 and num_slots-1")
}
if len(s.Requests) < 1 || len(s.Requests) > 20 {
return errInvalid("requests must contain 1 to 20 entries")
}
ids := make(map[string]bool, len(s.Requests))
for _, r := range s.Requests {
if r.ID == "" {
return errInvalid("request id must not be empty")
}
if ids[r.ID] {
return errInvalid("duplicate request id " + r.ID)
}
ids[r.ID] = true
if r.Consumer == "" {
return errInvalid("request consumer must not be empty")
}
if r.Slot < 0 || r.Slot >= N {
return errInvalid("request slot out of range")
}
if r.Priority < 1 || r.Priority > 10000 {
return errInvalid("priority must be between 1 and 10000")
}
}
return nil
}

func errInvalid(msg string) error { return &invalidError{msg: msg} }

type invalidError struct{ msg string }

func (e *invalidError) Error() string { return "invalid: " + e.msg }
