package main

import "sort"

func planSchedule(s Schedule) Plan {
N := s.NumSlots
Q := s.Quota
W := s.WindowSize
reqs := s.Requests
n := len(reqs)

cidx := make(map[string]int)
for _, r := range reqs {
if _, ok := cidx[r.Consumer]; !ok {
cidx[r.Consumer] = len(cidx)
}
}
nC := len(cidx)
slotCnt := make([][]int, nC)
for i := range slotCnt {
slotCnt[i] = make([]int, N)
}

order := make([]int, n)
for i := range order {
order[i] = i
}
sort.Slice(order, func(a, b int) bool {
pa, pb := reqs[order[a]].Priority, reqs[order[b]].Priority
if pa != pb {
return pa > pb
}
return reqs[order[a]].ID < reqs[order[b]].ID
})

var accepted []Choice
totalPri := 0
for _, idx := range order {
ci := cidx[reqs[idx].Consumer]
slot := reqs[idx].Slot
slotCnt[ci][slot]++
if ok := capacityOK(slotCnt[ci], N, W, Q); ok {
accepted = append(accepted, Choice{
RequestID: reqs[idx].ID,
Consumer:  reqs[idx].Consumer,
Slot:      slot,
Priority:  reqs[idx].Priority,
})
totalPri += reqs[idx].Priority
} else {
slotCnt[ci][slot]--
}
}

return Plan{NumSlots: N, Quota: Q, WindowSize: W, Accepted: accepted, Priority: totalPri}
}

func capacityOK(cnt []int, N, W, Q int) bool {
for start := 0; start <= N-W; start++ {
total := 0
for s := start; s < start+W; s++ {
total += cnt[s]
}
if total > Q {
return false
}
}
return true
}
