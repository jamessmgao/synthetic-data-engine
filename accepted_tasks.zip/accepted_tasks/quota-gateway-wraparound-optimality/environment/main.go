package main

import (
"crypto/sha256"
"encoding/json"
"fmt"
"io"
"os"
"sort"
)

func main() {
data, err := io.ReadAll(os.Stdin)
if err != nil {
fmt.Fprintf(os.Stderr, "read error: %v\n", err)
os.Exit(1)
}
var sched Schedule
if err := json.Unmarshal(data, &sched); err != nil {
fmt.Fprintf(os.Stderr, "parse error: %v\n", err)
os.Exit(1)
}
if err := validateSchedule(sched); err != nil {
fmt.Fprintf(os.Stderr, "validation error: %v\n", err)
os.Exit(1)
}
plan := planSchedule(sched)
if !validatePlan(sched, plan) {
fmt.Fprintf(os.Stderr, "plan validation failed\n")
os.Exit(1)
}
report := buildReport(sched, plan)
out, _ := json.MarshalIndent(report, "", "  ")
fmt.Println(string(out))
}

func validatePlan(sched Schedule, plan Plan) bool {
N := sched.NumSlots
W := sched.WindowSize
Q := sched.Quota
cidx := make(map[string]int)
for _, r := range sched.Requests {
if _, ok := cidx[r.Consumer]; !ok {
cidx[r.Consumer] = len(cidx)
}
}
slotCnt := make([][]int, len(cidx))
for i := range slotCnt {
slotCnt[i] = make([]int, N)
}
for _, c := range plan.Accepted {
ci := cidx[c.Consumer]
slotCnt[ci][c.Slot]++
}
for consumer, ci := range cidx {
if !reportCapacityOK(slotCnt[ci], N, W, Q) {
fmt.Fprintf(os.Stderr, "quota exceeded for %s\n", consumer)
return false
}
}
return true
}

func reportCapacityOK(cnt []int, N, W, Q int) bool {
for start := 0; start <= N-W; start++ {
total := 0
for s := start; s < start+W; s++ {
total += cnt[s]
}
if total > Q {
return false
}
}
return true
}

func buildReport(sched Schedule, plan Plan) Report {
N := sched.NumSlots
var accepted []ReportedChoice
cload := make(map[string]int)
sload := make([]int, N)
for _, c := range plan.Accepted {
accepted = append(accepted, ReportedChoice{
RequestID: c.RequestID,
Consumer:  c.Consumer,
Slot:      c.Slot,
Priority:  c.Priority,
})
cload[c.Consumer]++
sload[c.Slot]++
}
sort.Slice(accepted, func(i, j int) bool {
if accepted[i].Slot != accepted[j].Slot {
return accepted[i].Slot < accepted[j].Slot
}
return accepted[i].RequestID < accepted[j].RequestID
})
return Report{
Accepted:     accepted,
Priority:     plan.Priority,
ConsumerLoad: cload,
SlotLoad:     sload,
Commitment:   computeCommitment(plan.Accepted),
}
}

func computeCommitment(choices []Choice) string {
h := sha256.New()
sorted := make([]Choice, len(choices))
copy(sorted, choices)
sort.Slice(sorted, func(i, j int) bool {
if sorted[i].Slot != sorted[j].Slot {
return sorted[i].Slot < sorted[j].Slot
}
return sorted[i].RequestID < sorted[j].RequestID
})
for _, c := range sorted {
fmt.Fprintf(h, "%s:%s:%d:%d|", c.RequestID, c.Consumer, c.Slot, c.Priority)
}
return fmt.Sprintf("%x", h.Sum(nil))[:16]
}
