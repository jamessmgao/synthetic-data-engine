package main

import "sort"

func planSchedule(s Schedule) Plan {
N := s.NumSlots
Q := s.Quota
W := s.WindowSize
reqs := s.Requests
n := len(reqs)

order := make([]int, n)
for i := range order {
order[i] = i
}
sort.Slice(order, func(a, b int) bool {
pa, pb := reqs[order[a]].Priority, reqs[order[b]].Priority
if pa != pb {
return pa > pb
}
return reqs[order[a]].ID < reqs[order[b]].ID
})

suffix := make([]int, n+1)
for i := n - 1; i >= 0; i-- {
suffix[i] = suffix[i+1] + reqs[order[i]].Priority
}

cidx := make(map[string]int)
for _, r := range reqs {
if _, ok := cidx[r.Consumer]; !ok {
cidx[r.Consumer] = len(cidx)
}
}
nC := len(cidx)
slotCnt := make([][]int, nC)
for i := range slotCnt {
slotCnt[i] = make([]int, N)
}

bestPri := 0
bestAcc := make([]bool, n)
curAcc := make([]bool, n)
curPri := 0

var search func(int)
search = func(d int) {
if d == n {
if curPri > bestPri {
bestPri = curPri
copy(bestAcc, curAcc)
}
return
}
if curPri+suffix[d] <= bestPri {
return
}
ri := order[d]
ci := cidx[reqs[ri].Consumer]
slot := reqs[ri].Slot

slotCnt[ci][slot]++
if ok := capacityOK(slotCnt[ci], N, W, Q); ok {
curAcc[ri] = true
curPri += reqs[ri].Priority
search(d + 1)
curPri -= reqs[ri].Priority
curAcc[ri] = false
}
slotCnt[ci][slot]--

search(d + 1)
}
search(0)

plan := Plan{NumSlots: N, Quota: Q, WindowSize: W, Priority: bestPri}
for i, acc := range bestAcc {
if acc {
plan.Accepted = append(plan.Accepted, Choice{
RequestID: reqs[i].ID,
Consumer:  reqs[i].Consumer,
Slot:      reqs[i].Slot,
Priority:  reqs[i].Priority,
})
}
}
return plan
}

func capacityOK(cnt []int, N, W, Q int) bool {
for start := 0; start < N; start++ {
total := 0
for s := 0; s < W; s++ {
total += cnt[(start+s)%N]
}
if total > Q {
return false
}
}
return true
}
