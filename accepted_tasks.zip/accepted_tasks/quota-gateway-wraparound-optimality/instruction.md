The `quota-gateway` command reads a JSON schedule on stdin and prints a JSON planning report. Users have seen it accept too many requests for one consumer and report a total priority that is too low.

For every valid schedule, the report must list each accepted request at most once, never exceed a consumer's quota over any `window_size` span of slots, and report the highest total priority the schedule allows. Invalid schedules must continue to be rejected with a non-zero exit code.
