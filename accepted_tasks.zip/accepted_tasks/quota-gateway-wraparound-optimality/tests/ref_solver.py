"""Reference solver for quota-gateway scheduling optimization."""


def capacity_ok(cnt, N, W, Q):
    """Check quota in every sliding window of W consecutive slots (with wraparound)."""
    for start in range(N):
        total = 0
        for s in range(W):
            total += cnt[(start + s) % N]
        if total > Q:
            return False
    return True


def solve(schedule):
    """Return (optimal_priority, list_of_accepted_request_indices) for the schedule."""
    N = schedule["num_slots"]
    Q = schedule["quota"]
    W = schedule["window_size"]
    requests = schedule["requests"]
    n = len(requests)

    order = sorted(range(n), key=lambda i: (-requests[i]["priority"], requests[i]["id"]))

    suffix = [0] * (n + 1)
    for i in range(n - 1, -1, -1):
        suffix[i] = suffix[i + 1] + requests[order[i]]["priority"]

    cidx = {}
    for r in requests:
        if r["consumer"] not in cidx:
            cidx[r["consumer"]] = len(cidx)
    nC = len(cidx)
    slot_cnt = [[0] * N for _ in range(nC)]

    best = [0, []]
    cur_acc = [False] * n
    cur_pri = [0]

    def search(d):
        if d == n:
            if cur_pri[0] > best[0]:
                best[0] = cur_pri[0]
                best[1] = [i for i in range(n) if cur_acc[i]]
            return
        if cur_pri[0] + suffix[d] <= best[0]:
            return
        ri = order[d]
        ci = cidx[requests[ri]["consumer"]]
        slot = requests[ri]["slot"]

        slot_cnt[ci][slot] += 1
        if capacity_ok(slot_cnt[ci], N, W, Q):
            cur_acc[ri] = True
            cur_pri[0] += requests[ri]["priority"]
            search(d + 1)
            cur_pri[0] -= requests[ri]["priority"]
            cur_acc[ri] = False
        slot_cnt[ci][slot] -= 1

        search(d + 1)

    search(0)
    return best[0], best[1]
