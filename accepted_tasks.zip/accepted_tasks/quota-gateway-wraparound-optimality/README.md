# Fix quota-gateway wraparound boundary and optimality bugs

The quota-gateway scheduler has two bugs: it fails to enforce the quota in sliding windows that wrap around the slot boundary, and its greedy planner produces suboptimal total priority. The fix must enforce wraparound quotas and use an optimal solver.

## Scenario

A Go command-line service that reads a scheduling problem from stdin, plans which requests to accept, validates the plan, and outputs a JSON report.

## Root cause (hidden from the agent)

capacityOK and reportCapacityOK iterate start from 0 to N-W, missing wraparound windows where start > N-W. Additionally, planSchedule uses a greedy approach that commits to high-priority requests early without backtracking, so it can miss the globally optimal set when the best combination spans the boundary.

## Correctness constraints

- **C1**: Every accepted request appears at most once in the report; no request ID is duplicated in the accepted list.
- **C2**: Each consumer's accepted requests respect the quota in every sliding window of window_size consecutive slots, including windows that wrap around from the last slot to the first.
- **C3**: The plan achieves the maximum total priority among all feasible acceptance sets that respect the per-consumer quota in every wraparound sliding window.

## Subgoals

1. Fix capacityOK and reportCapacityOK to check all N wraparound windows
2. Replace the greedy planner with an exhaustive search that finds the optimal acceptance set
3. Ensure the rebuilt binary still validates inputs and rejects invalid schedules

## Failure scenario

On a 6-slot schedule with quota 4, window_size 3, and 8 requests for consumer alpha, the gateway accepts 7 requests with total priority 672, exceeding the quota in the wrapping window [4,5,0] which contains 6 requests. The optimal plan accepts 6 requests with total priority 567.

## Expected agent pitfalls

- Fixing only the loop bounds in capacityOK/reportCapacityOK without replacing the greedy planner, which makes the validator pass but still produces suboptimal plans
- Fixing only the greedy planner without fixing the wraparound windows
- Breaking input validation while modifying the code

## Anti-shortcut measures

- The optimality test uses a reference solver to compute the true maximum priority for random schedules, catching any shortcut that only fixes the wraparound check without replacing the greedy algorithm
- The counterexample test verifies the exact case from the bug report
- Random schedule generation covers many slot/consumer/quota combinations

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_1_no_duplicates`, `test_counterexample`, `test_edge_all_same_slot` |
| C2 | `test_invariant_2_quota_per_consumer`, `test_counterexample`, `test_edge_wraparound_heavy` |
| C3 | `test_invariant_3_optimal_priority`, `test_counterexample`, `test_edge_multiple_consumers`, `test_edge_all_same_slot`, `test_edge_wraparound_heavy` |
