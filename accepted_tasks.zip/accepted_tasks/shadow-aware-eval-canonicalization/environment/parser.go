package main

import (
	"fmt"
	"strconv"
	"unicode"
)

type Expr interface{ exprNode() }
type Stmt interface{ stmtNode() }

type IntLit struct{ Value int64 }
type Ident struct {
	Name    string
	Binding int
}
type UnaryOp struct {
	Op   string
	Expr Expr
}
type BinaryOp struct {
	Op    string
	Left  Expr
	Right Expr
}

type Program struct{ Stmts []Stmt }

type LetStmt struct {
	Name    string
	Binding int
	Expr    Expr
}
type AssignStmt struct {
	Name    string
	Binding int
	Expr    Expr
}
type PrintStmt struct{ Expr Expr }
type IfStmt struct {
	Cond Expr
	Then []Stmt
	Else []Stmt
}

func (IntLit) exprNode()      {}
func (Ident) exprNode()       {}
func (*UnaryOp) exprNode()    {}
func (*BinaryOp) exprNode()   {}
func (*LetStmt) stmtNode()    {}
func (*AssignStmt) stmtNode() {}
func (*PrintStmt) stmtNode()  {}
func (*IfStmt) stmtNode()     {}

type token struct {
	typ string
	val string
}

type lexer struct {
	src string
	pos int
}

func (l *lexer) skipSpace() {
	for l.pos < len(l.src) && unicode.IsSpace(rune(l.src[l.pos])) {
		l.pos++
	}
}

func (l *lexer) next() (token, error) {
	l.skipSpace()
	if l.pos >= len(l.src) {
		return token{typ: "eof"}, nil
	}
	c := l.src[l.pos]
	if unicode.IsDigit(rune(c)) {
		start := l.pos
		for l.pos < len(l.src) && unicode.IsDigit(rune(l.src[l.pos])) {
			l.pos++
		}
		return token{typ: "int", val: l.src[start:l.pos]}, nil
	}
	if unicode.IsLetter(rune(c)) {
		start := l.pos
		for l.pos < len(l.src) && (unicode.IsLetter(rune(l.src[l.pos])) || unicode.IsDigit(rune(l.src[l.pos]))) {
			l.pos++
		}
		return token{typ: "ident", val: l.src[start:l.pos]}, nil
	}
	two := ""
	if l.pos+1 < len(l.src) {
		two = l.src[l.pos : l.pos+2]
	}
	switch two {
	case "==", "!=", "<=", ">=", "&&", "||":
		l.pos += 2
		return token{typ: "punct", val: two}, nil
	}
	switch string(c) {
	case "+", "-", "*", "/", "%", "(", ")", "{", "}", ";", "=", "<", ">", "!":
		l.pos++
		return token{typ: "punct", val: string(c)}, nil
	}
	return token{}, fmt.Errorf("unexpected character %q", c)
}

type parser struct {
	toks []token
	pos  int
}

func ParseProgram(src string) (*Program, error) {
	var toks []token
	lx := &lexer{src: src}
	for {
		tok, err := lx.next()
		if err != nil {
			return nil, err
		}
		toks = append(toks, tok)
		if tok.typ == "eof" {
			break
		}
	}
	p := &parser{toks: toks}
	prog := &Program{}
	for p.peek().typ != "eof" {
		stmt, err := p.parseStmt()
		if err != nil {
			return nil, err
		}
		prog.Stmts = append(prog.Stmts, stmt)
	}
	return prog, nil
}

func (p *parser) peek() token {
	return p.toks[p.pos]
}

func (p *parser) next() token {
	t := p.toks[p.pos]
	p.pos++
	return t
}

func (p *parser) expect(val string) (token, error) {
	t := p.next()
	if t.val != val {
		return t, fmt.Errorf("expected %q, got %q", val, t.val)
	}
	return t, nil
}

func (p *parser) parseStmt() (Stmt, error) {
	t := p.peek()
	if t.typ == "ident" {
		switch t.val {
		case "let":
			p.next()
			name := p.next()
			if name.typ != "ident" {
				return nil, fmt.Errorf("expected name after let")
			}
			if _, err := p.expect("="); err != nil {
				return nil, err
			}
			e, err := p.parseExpr()
			if err != nil {
				return nil, err
			}
			if _, err := p.expect(";"); err != nil {
				return nil, err
			}
			return &LetStmt{Name: name.val, Binding: nameBinding(name.val), Expr: e}, nil
		case "print":
			p.next()
			e, err := p.parseExpr()
			if err != nil {
				return nil, err
			}
			if _, err := p.expect(";"); err != nil {
				return nil, err
			}
			return &PrintStmt{Expr: e}, nil
		case "if":
			p.next()
			if _, err := p.expect("("); err != nil {
				return nil, err
			}
			cond, err := p.parseExpr()
			if err != nil {
				return nil, err
			}
			if _, err := p.expect(")"); err != nil {
				return nil, err
			}
			then, err := p.parseBlock()
			if err != nil {
				return nil, err
			}
			els := []Stmt{}
			if p.peek().val == "else" {
				p.next()
				els, err = p.parseBlock()
				if err != nil {
					return nil, err
				}
			}
			return &IfStmt{Cond: cond, Then: then, Else: els}, nil
		}
	}
	if t.typ == "ident" && p.toks[p.pos+1].val == "=" {
		name := p.next()
		p.next()
		e, err := p.parseExpr()
		if err != nil {
			return nil, err
		}
		if _, err := p.expect(";"); err != nil {
			return nil, err
		}
		return &AssignStmt{Name: name.val, Binding: nameBinding(name.val), Expr: e}, nil
	}
	return nil, fmt.Errorf("unexpected token %q", t.val)
}

func (p *parser) parseBlock() ([]Stmt, error) {
	if _, err := p.expect("{"); err != nil {
		return nil, err
	}
	var stmts []Stmt
	for p.peek().val != "}" {
		if p.peek().typ == "eof" {
			return nil, fmt.Errorf("unterminated block")
		}
		stmt, err := p.parseStmt()
		if err != nil {
			return nil, err
		}
		stmts = append(stmts, stmt)
	}
	if _, err := p.expect("}"); err != nil {
		return nil, err
	}
	return stmts, nil
}

func (p *parser) parseExpr() (Expr, error) {
	return p.parseOr()
}

func (p *parser) parseOr() (Expr, error) {
	left, err := p.parseAnd()
	if err != nil {
		return nil, err
	}
	for p.peek().val == "||" {
		op := p.next().val
		right, err := p.parseAnd()
		if err != nil {
			return nil, err
		}
		left = &BinaryOp{Op: op, Left: left, Right: right}
	}
	return left, nil
}

func (p *parser) parseAnd() (Expr, error) {
	left, err := p.parseEquality()
	if err != nil {
		return nil, err
	}
	for p.peek().val == "&&" {
		op := p.next().val
		right, err := p.parseEquality()
		if err != nil {
			return nil, err
		}
		left = &BinaryOp{Op: op, Left: left, Right: right}
	}
	return left, nil
}

func (p *parser) parseEquality() (Expr, error) {
	left, err := p.parseCompare()
	if err != nil {
		return nil, err
	}
	for p.peek().val == "==" || p.peek().val == "!=" {
		op := p.next().val
		right, err := p.parseCompare()
		if err != nil {
			return nil, err
		}
		left = &BinaryOp{Op: op, Left: left, Right: right}
	}
	return left, nil
}

func (p *parser) parseCompare() (Expr, error) {
	left, err := p.parseAdd()
	if err != nil {
		return nil, err
	}
	for p.peek().val == "<" || p.peek().val == "<=" || p.peek().val == ">" || p.peek().val == ">=" {
		op := p.next().val
		right, err := p.parseAdd()
		if err != nil {
			return nil, err
		}
		left = &BinaryOp{Op: op, Left: left, Right: right}
	}
	return left, nil
}

func (p *parser) parseAdd() (Expr, error) {
	left, err := p.parseMul()
	if err != nil {
		return nil, err
	}
	for p.peek().val == "+" || p.peek().val == "-" {
		op := p.next().val
		right, err := p.parseMul()
		if err != nil {
			return nil, err
		}
		left = &BinaryOp{Op: op, Left: left, Right: right}
	}
	return left, nil
}

func (p *parser) parseMul() (Expr, error) {
	left, err := p.parseUnary()
	if err != nil {
		return nil, err
	}
	for p.peek().val == "*" || p.peek().val == "/" || p.peek().val == "%" {
		op := p.next().val
		right, err := p.parseUnary()
		if err != nil {
			return nil, err
		}
		left = &BinaryOp{Op: op, Left: left, Right: right}
	}
	return left, nil
}

func (p *parser) parseUnary() (Expr, error) {
	if p.peek().val == "-" || p.peek().val == "!" {
		op := p.next().val
		e, err := p.parseUnary()
		if err != nil {
			return nil, err
		}
		return &UnaryOp{Op: op, Expr: e}, nil
	}
	return p.parsePrimary()
}

func (p *parser) parsePrimary() (Expr, error) {
	t := p.next()
	switch t.typ {
	case "int":
		v, err := strconv.ParseInt(t.val, 10, 64)
		if err != nil {
			return nil, err
		}
		return &IntLit{Value: v}, nil
	case "ident":
		return &Ident{Name: t.val, Binding: nameBinding(t.val)}, nil
	case "punct":
		if t.val == "(" {
			e, err := p.parseExpr()
			if err != nil {
				return nil, err
			}
			if _, err := p.expect(")"); err != nil {
				return nil, err
			}
			return e, nil
		}
	}
	return nil, fmt.Errorf("unexpected token %q", t.val)
}

func nameBinding(name string) int {
	var h uint64
	for _, c := range []byte(name) {
		h = h*131 + uint64(c)
	}
	return int(h)
}
