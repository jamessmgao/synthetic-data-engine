package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"sync"
)

var (
	cacheMu  sync.Mutex
	cacheMap = make(map[string]string)
)

func directResult(src string) string {
	prog, err := ParseProgram(src)
	if err != nil {
		return fmt.Sprintf("parse error: %v\n", err)
	}
	result, err := Evaluate(prog)
	if err != nil {
		return fmt.Sprintf("eval error: %v\n", err)
	}
	return result
}

func serviceResult(src string) (string, string) {
	prog, err := ParseProgram(src)
	if err != nil {
		return fmt.Sprintf("parse error: %v\n", err), ""
	}
	prepared := PrepareProgram(prog)
	result, err := Evaluate(prepared)
	if err != nil {
		return fmt.Sprintf("eval error: %v\n", err), ""
	}
	sum := sha256.Sum256([]byte(renderProgram(prepared)))
	tag := hex.EncodeToString(sum[:])
	return result, tag
}

func renderProgram(prog *Program) string {
	var b strings.Builder
	for _, s := range prog.Stmts {
		renderStmt(&b, s)
	}
	return b.String()
}

func renderStmt(b *strings.Builder, s Stmt) {
	switch v := s.(type) {
	case *LetStmt:
		fmt.Fprintf(b, "let %s = ", v.Name)
		renderExpr(b, v.Expr)
		b.WriteByte(';')
	case *AssignStmt:
		fmt.Fprintf(b, "%s = ", v.Name)
		renderExpr(b, v.Expr)
		b.WriteByte(';')
	case *PrintStmt:
		b.WriteString("print ")
		renderExpr(b, v.Expr)
		b.WriteByte(';')
	case *IfStmt:
		b.WriteString("if (")
		renderExpr(b, v.Cond)
		b.WriteString(") {")
		for _, x := range v.Then {
			renderStmt(b, x)
		}
		b.WriteString("}")
	}
}

func renderExpr(b *strings.Builder, e Expr) {
	switch v := e.(type) {
	case *IntLit:
		fmt.Fprintf(b, "%d", v.Value)
	case *Ident:
		b.WriteString(v.Name)
	case *UnaryOp:
		b.WriteString(v.Op)
		renderExpr(b, v.Expr)
	case *BinaryOp:
		b.WriteByte('(')
		renderExpr(b, v.Left)
		b.WriteString(v.Op)
		renderExpr(b, v.Right)
		b.WriteByte(')')
	}
}

func main() {
	if len(os.Args) > 1 {
		data, err := os.ReadFile(os.Args[1])
		if err != nil {
			fmt.Fprintf(os.Stderr, "read error: %v\n", err)
			os.Exit(2)
		}
		fmt.Print(directResult(strings.TrimSpace(string(data))))
		return
	}

	http.HandleFunc("/eval", func(w http.ResponseWriter, r *http.Request) {
		body, err := io.ReadAll(r.Body)
		if err != nil {
			http.Error(w, "read error", 400)
			return
		}
		src := strings.TrimSpace(string(body))
		if src == "" {
			http.Error(w, "empty program", 400)
			return
		}
		result, tag := serviceResult(src)
		w.Header().Set("ETag", `"`+tag+`"`)
		cacheMu.Lock()
		_, cached := cacheMap[tag]
		if !cached {
			cacheMap[tag] = result
		}
		cacheMu.Unlock()
		if cached {
			w.Header().Set("X-Cache", "HIT")
		} else {
			w.Header().Set("X-Cache", "MISS")
		}
		w.Write([]byte(result))
	})
	http.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(200)
		w.Write([]byte("ok\n"))
	})
	log.Fatal(http.ListenAndServe(":8080", nil))
}
