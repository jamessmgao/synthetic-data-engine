package main

func foldConstants(prog *Program) *Program {
	var out []Stmt
	for _, s := range prog.Stmts {
		out = append(out, foldStmt(s))
	}
	return &Program{Stmts: out}
}

func foldStmt(s Stmt) Stmt {
	switch v := s.(type) {
	case *LetStmt:
		return &LetStmt{Name: v.Name, Expr: foldExpr(v.Expr)}
	case *AssignStmt:
		return &AssignStmt{Name: v.Name, Expr: foldExpr(v.Expr)}
	case *PrintStmt:
		return &PrintStmt{Expr: foldExpr(v.Expr)}
	case *IfStmt:
		var nt, ne []Stmt
		for _, st := range v.Then {
			nt = append(nt, foldStmt(st))
		}
		for _, st := range v.Else {
			ne = append(ne, foldStmt(st))
		}
		return &IfStmt{Cond: foldExpr(v.Cond), Then: nt, Else: ne}
	}
	return s
}

func foldExpr(e Expr) Expr {
	switch v := e.(type) {
	case *UnaryOp:
		inner := foldExpr(v.Expr)
		if lit, ok := inner.(*IntLit); ok {
			switch v.Op {
			case "-":
				return &IntLit{Value: -lit.Value}
			case "!":
				if lit.Value == 0 {
					return &IntLit{Value: 1}
				}
				return &IntLit{Value: 0}
			}
		}
		return &UnaryOp{Op: v.Op, Expr: inner}
	case *BinaryOp:
		left := foldExpr(v.Left)
		right := foldExpr(v.Right)
		lLit, lOk := left.(*IntLit)
		rLit, rOk := right.(*IntLit)
		if lOk && rOk {
			return &IntLit{Value: evalBinOp(v.Op, lLit.Value, rLit.Value)}
		}
		return &BinaryOp{Op: v.Op, Left: left, Right: right}
	}
	return e
}

func evalBinOp(op string, l, r int64) int64 {
	switch op {
	case "+":
		return l + r
	case "-":
		return l - r
	case "*":
		return l * r
	case "/":
		if r != 0 {
			return l / r
		}
	case "%":
		if r != 0 {
			return l % r
		}
	case "==":
		if l == r {
			return 1
		}
	case "!=":
		if l != r {
			return 1
		}
	case "<":
		if l < r {
			return 1
		}
	case "<=":
		if l <= r {
			return 1
		}
	case ">":
		if l > r {
			return 1
		}
	case ">=":
		if l >= r {
			return 1
		}
	case "&&":
		if l != 0 && r != 0 {
			return 1
		}
	case "||":
		if l != 0 || r != 0 {
			return 1
		}
	}
	return 0
}
