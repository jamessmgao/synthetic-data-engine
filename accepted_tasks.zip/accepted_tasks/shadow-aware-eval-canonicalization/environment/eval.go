package main

import (
	"fmt"
	"strconv"
)

type Env struct {
	vars   map[string]int64
	parent *Env
}

func NewEnv(parent *Env) *Env {
	return &Env{vars: make(map[string]int64), parent: parent}
}

func (e *Env) Get(name string) (int64, bool) {
	if v, ok := e.vars[name]; ok {
		return v, true
	}
	if e.parent != nil {
		return e.parent.Get(name)
	}
	return 0, false
}

func (e *Env) Set(name string, val int64) {
	e.vars[name] = val
}

func Evaluate(prog *Program) (string, error) {
	env := NewEnv(nil)
	var out string
	for _, s := range prog.Stmts {
		o, err := evalStmt(s, env)
		if err != nil {
			return "", err
		}
		out += o
	}
	return out, nil
}

func evalStmt(s Stmt, env *Env) (string, error) {
	switch v := s.(type) {
	case *LetStmt:
		val, err := evalExpr(v.Expr, env)
		if err != nil {
			return "", err
		}
		env.Set(v.Name, val)
	case *AssignStmt:
		val, err := evalExpr(v.Expr, env)
		if err != nil {
			return "", err
		}
		env.Set(v.Name, val)
	case *PrintStmt:
		val, err := evalExpr(v.Expr, env)
		if err != nil {
			return "", err
		}
		return fmt.Sprintf("%d\n", val), nil
	case *IfStmt:
		cond, err := evalExpr(v.Cond, env)
		if err != nil {
			return "", err
		}
		var out string
		if cond != 0 {
			inner := NewEnv(env)
			for _, st := range v.Then {
				o, err := evalStmt(st, inner)
				if err != nil {
					return "", err
				}
				out += o
			}
		} else {
			inner := NewEnv(env)
			for _, st := range v.Else {
				o, err := evalStmt(st, inner)
				if err != nil {
					return "", err
				}
				out += o
			}
		}
		return out, nil
	}
	return "", nil
}

func evalExpr(e Expr, env *Env) (int64, error) {
	switch v := e.(type) {
	case *IntLit:
		return v.Value, nil
	case *Ident:
		val, ok := env.Get(v.Name)
		if !ok {
			return 0, fmt.Errorf("undefined variable %q", v.Name)
		}
		return val, nil
	case *UnaryOp:
		val, err := evalExpr(v.Expr, env)
		if err != nil {
			return 0, err
		}
		switch v.Op {
		case "-":
			return -val, nil
		case "!":
			if val == 0 {
				return 1, nil
			}
			return 0, nil
		}
	case *BinaryOp:
		left, err := evalExpr(v.Left, env)
		if err != nil {
			return 0, err
		}
		right, err := evalExpr(v.Right, env)
		if err != nil {
			return 0, err
		}
		return evalBinOp(v.Op, left, right), nil
	}
	return 0, fmt.Errorf("unhandled expression")
}

func formatExpr(e Expr) string {
	switch v := e.(type) {
	case *IntLit:
		return strconv.FormatInt(v.Value, 10)
	case *Ident:
		return v.Name
	case *UnaryOp:
		return fmt.Sprintf("(%s%s)", v.Op, formatExpr(v.Expr))
	case *BinaryOp:
		return fmt.Sprintf("(%s %s %s)", formatExpr(v.Left), v.Op, formatExpr(v.Right))
	}
	return "?"
}
