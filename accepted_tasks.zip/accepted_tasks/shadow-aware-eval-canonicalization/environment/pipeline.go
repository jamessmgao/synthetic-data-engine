package main

type prepContext struct {
	candidates map[int]Expr
	active     map[int]bool
}

func PrepareProgram(prog *Program) *Program {
	ctx := &prepContext{
		candidates: make(map[int]Expr),
		active:     make(map[int]bool),
	}
	collectBindings(prog.Stmts, ctx)
	stmts := replaceStmts(prog.Stmts, ctx)
	return foldConstants(&Program{Stmts: stmts})
}

func collectBindings(stmts []Stmt, ctx *prepContext) {
	for _, s := range stmts {
		switch v := s.(type) {
		case *LetStmt:
			ctx.candidates[v.Binding] = v.Expr
		case *IfStmt:
			collectBindings(v.Then, ctx)
			collectBindings(v.Else, ctx)
		}
	}
}

func replaceStmts(stmts []Stmt, ctx *prepContext) []Stmt {
	var out []Stmt
	for _, s := range stmts {
		s = replaceStmt(s, ctx)
		if v, ok := s.(*LetStmt); ok && ctx.active[v.Binding] {
			continue
		}
		out = append(out, s)
	}
	return out
}

func replaceStmt(s Stmt, ctx *prepContext) Stmt {
	switch v := s.(type) {
	case *LetStmt:
		ctx.active[v.Binding] = true
		return &LetStmt{Name: v.Name, Binding: v.Binding, Expr: replaceExpr(v.Expr, ctx)}
	case *AssignStmt:
		ctx.active[v.Binding] = false
		return &AssignStmt{Name: v.Name, Binding: v.Binding, Expr: replaceExpr(v.Expr, ctx)}
	case *PrintStmt:
		return &PrintStmt{Expr: replaceExpr(v.Expr, ctx)}
	case *IfStmt:
		return &IfStmt{Cond: replaceExpr(v.Cond, ctx), Then: replaceStmts(v.Then, ctx), Else: replaceStmts(v.Else, ctx)}
	}
	return s
}

func replaceExpr(e Expr, ctx *prepContext) Expr {
	switch v := e.(type) {
	case *Ident:
		if expr, ok := ctx.candidates[v.Binding]; ok && ctx.active[v.Binding] {
			return expr
		}
		return e
	case *UnaryOp:
		return &UnaryOp{Op: v.Op, Expr: replaceExpr(v.Expr, ctx)}
	case *BinaryOp:
		return &BinaryOp{Op: v.Op, Left: replaceExpr(v.Left, ctx), Right: replaceExpr(v.Right, ctx)}
	}
	return e
}
