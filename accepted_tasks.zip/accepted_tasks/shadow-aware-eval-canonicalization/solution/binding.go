package main

type lexicalScope struct {
parent *lexicalScope
names  map[string]int
}

type bindingResolver struct {
next int
}

func resolveProgram(prog *Program) {
r := &bindingResolver{next: 1}
resolveStmts(prog.Stmts, nil, r)
}

func resolveStmts(stmts []Stmt, parent *lexicalScope, r *bindingResolver) {
scope := &lexicalScope{parent: parent, names: make(map[string]int)}
for _, stmt := range stmts {
resolveStmt(stmt, scope, r)
}
}

func resolveStmt(stmt Stmt, scope *lexicalScope, r *bindingResolver) {
switch v := stmt.(type) {
case *LetStmt:
resolveExpr(v.Expr, scope, r)
v.Binding = r.next
r.next++
scope.names[v.Name] = v.Binding
case *AssignStmt:
resolveExpr(v.Expr, scope, r)
v.Binding = lookupBinding(scope, v.Name)
case *PrintStmt:
resolveExpr(v.Expr, scope, r)
case *IfStmt:
resolveExpr(v.Cond, scope, r)
resolveStmts(v.Then, scope, r)
resolveStmts(v.Else, scope, r)
}
}

func resolveExpr(expr Expr, scope *lexicalScope, r *bindingResolver) {
switch v := expr.(type) {
case *Ident:
v.Binding = lookupBinding(scope, v.Name)
case *UnaryOp:
resolveExpr(v.Expr, scope, r)
case *BinaryOp:
resolveExpr(v.Left, scope, r)
resolveExpr(v.Right, scope, r)
}
}

func lookupBinding(scope *lexicalScope, name string) int {
for s := scope; s != nil; s = s.parent {
if id, ok := s.names[name]; ok {
return id
}
}
return 0
}
