import subprocess, os, time, signal, http.client, random

class Service:
    def __init__(self):
        self.proc = None
    def start(self, timeout=15):
        subprocess.run(['pkill', '-f', '/app/world'], capture_output=True)
        time.sleep(0.2)
        self.proc = subprocess.Popen(
            ['/app/world'],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            preexec_fn=os.setsid
        )
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                c = http.client.HTTPConnection('127.0.0.1', 8080, timeout=2)
                c.request('GET', '/health')
                r = c.getresponse()
                c.close()
                if r.status == 200:
                    return True
            except Exception:
                pass
            time.sleep(0.2)
        self.stop()
        return False
    def stop(self):
        if self.proc and self.proc.poll() is None:
            try:
                os.killpg(os.getpgid(self.proc.pid), signal.SIGTERM)
            except Exception:
                self.proc.kill()
            try:
                self.proc.wait(timeout=5)
            except Exception:
                self.proc.kill()
            self.proc = None
    def kill(self):
        if self.proc and self.proc.poll() is None:
            try:
                os.killpg(os.getpgid(self.proc.pid), signal.SIGKILL)
            except Exception:
                self.proc.kill()
            try:
                self.proc.wait(timeout=5)
            except Exception:
                pass
            self.proc = None
    def eval_program(self, program, timeout=10):
        c = http.client.HTTPConnection('127.0.0.1', 8080, timeout=timeout)
        c.request('POST', '/eval', body=program)
        r = c.getresponse()
        body = r.read().decode()
        etag = r.getheader('ETag', '')
        cache = r.getheader('X-Cache', '')
        c.close()
        if etag.startswith('"') and etag.endswith('"'):
            etag = etag[1:-1]
        return body, etag, cache

def eval_direct(program):
    with open('/tmp/test_prog.lang', 'w') as f:
        f.write(program)
    r = subprocess.run(['/app/world', '/tmp/test_prog.lang'],
                       capture_output=True, text=True, timeout=10)
    return r.stdout

def gen_expr(rng, vars_avail, depth=0):
    if depth > 3 or rng.random() < 0.35:
        if vars_avail and rng.random() < 0.5:
            return rng.choice(vars_avail)
        return str(rng.randint(0, 20))
    kind = rng.choice(['binop', 'unary', 'literal', 'var'])
    if kind == 'literal':
        return str(rng.randint(0, 20))
    if kind == 'var' and vars_avail:
        return rng.choice(vars_avail)
    if kind == 'unary':
        op = rng.choice(['-', '!'])
        return f'{op}{gen_expr(rng, vars_avail, depth+1)}'
    op = rng.choice(['+', '-', '*'])
    l = gen_expr(rng, vars_avail, depth+1)
    r = gen_expr(rng, vars_avail, depth+1)
    return f'({l} {op} {r})'

def gen_program(rng, max_stmts=6, allow_shadow=True):
    vars_top = []
    stmts = []
    for _ in range(rng.randint(1, max_stmts)):
        kind = rng.choice(['let', 'print', 'if', 'print', 'assign'])
        if kind == 'let' and len(vars_top) < 6:
            name = f'v{len(vars_top)}'
            expr = gen_expr(rng, vars_top)
            stmts.append(f'let {name} = {expr};')
            vars_top.append(name)
        elif kind == 'assign' and vars_top:
            name = rng.choice(vars_top)
            expr = gen_expr(rng, vars_top)
            stmts.append(f'{name} = {expr};')
        elif kind == 'print' and vars_top:
            expr = gen_expr(rng, vars_top)
            stmts.append(f'print {expr};')
        elif kind == 'if' and vars_top:
            cond = gen_expr(rng, vars_top)
            inner_vars = list(vars_top)
            inner_stmts = []
            for _ in range(rng.randint(1, 3)):
                ik = rng.choice(['let', 'print', 'assign'])
                if ik == 'let' and allow_shadow and len(inner_vars) < 8:
                    iname = rng.choice(vars_top) if vars_top and rng.random() < 0.4 else f'v{len(inner_vars)}'
                    iexpr = gen_expr(rng, inner_vars)
                    inner_stmts.append(f'let {iname} = {iexpr};')
                    inner_vars.append(iname)
                elif ik == 'print' and inner_vars:
                    iexpr = gen_expr(rng, inner_vars)
                    inner_stmts.append(f'print {iexpr};')
                elif ik == 'assign' and inner_vars:
                    iname = rng.choice(inner_vars)
                    iexpr = gen_expr(rng, inner_vars)
                    inner_stmts.append(f'{iname} = {iexpr};')
            then_part = ' '.join(inner_stmts)
            stmts.append(f'if ({cond}) {{ {then_part} }}')
        else:
            expr = gen_expr(rng, vars_top if vars_top else [])
            stmts.append(f'print {expr};')
    return ' '.join(stmts)

def gen_shadow_program(rng):
    x = rng.randint(1, 50)
    y = rng.randint(1, 50)
    outer = f'let a = {x};'
    use_before = 'print a;' if rng.random() < 0.6 else ''
    shadow = f'let a = {y};'
    inner_use = 'print a;' if rng.random() < 0.7 else 'print 0;'
    use_after = 'print a;'
    parts = [outer, use_before, f'if (1) {{ {shadow} {inner_use} }}', use_after]
    return ' '.join(p for p in parts if p)
