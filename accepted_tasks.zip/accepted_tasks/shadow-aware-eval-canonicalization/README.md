# Shadow-aware canonicalization for eval service

A Go evaluation service has a preparation pass that substitutes closed-literal bindings, but uses name-based binding that breaks lexical shadowing. The fix must make shadowing work correctly while preserving ETag-based canonicalization and cache hit behavior for all bindings, not just single-use ones.

## Scenario

The /eval endpoint accepts programs with let-bindings, assignments, if-statements, and print. A preparation pass substitutes closed-literal bindings and removes the let, but uses name-based binding which conflates different variables that share a name across scopes, causing shadowing to produce wrong output. A naive fix restricts substitution to single-use bindings, which fixes shadowing but breaks ETag canonicalization for multi-use bindings.

## Root cause (hidden from the agent)

The preparation pass uses name-based binding (nameBinding) instead of lexical scope resolution, so when an inner let shadows an outer variable with the same name, the substitution replaces all references to that name with the inner binding's expression, even those outside the inner scope.

## Correctness constraints

- **C1**: A print statement outputs the value defined by the nearest enclosing binding of the variable in the original program.
- **C2**: An inner let binding that shadows an outer variable does not change the value seen by references outside that inner scope.
- **C3**: The service execution path preserves the observable output of every parsed program and returns exactly the result produced by direct evaluation.
- **C4**: For a single-use top-level binding initialized by a closed literal expression, the service response tag equals the tag for the corresponding print of the reduced literal expression.
- **C5**: For any top-level binding initialized by a closed literal expression with no reassignment, the service response tag equals the tag for the corresponding program that uses the literal directly, and the service cache header indicates a hit for the second request.

## Subgoals

1. Fix the binding resolution so that each variable reference resolves to its lexically enclosing binding.
2. Ensure the preparation pass canonicalizes all closed-literal bindings (not just single-use) so ETags match between binding and literal forms.
3. Verify cache hits when semantically equivalent programs are submitted.

## Failure scenario

Submitting 'let x = 10; print x; if (1) { let x = 20; print 0; }' to /eval prints 20 then 0, while direct evaluation prints 10 then 0. After a fix that only substitutes single-use bindings, 'let y = 3; print y; print y;' and 'print 3; print 3;' get different ETags and the second request is a cache miss.

## Expected agent pitfalls

- Fixing shadowing by restricting substitution to single-use bindings, which breaks ETag canonicalization.
- Adding scope tracking without updating the substitution pass to use the new binding IDs.
- Forgetting to update the collectCandidates condition from refs==1 to refs>0.

## Anti-shortcut measures

- Tests verify ETag equality for both single-use and multi-use bindings.
- Tests verify X-Cache: HIT for semantically equivalent programs.
- Random program generation tests shadowing across many programs.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_nearest_binding_outputs` |
| C2 | `test_shadow_does_not_change_outer` |
| C3 | `test_service_output_equals_direct` |
| C4 | `test_single_use_etag_matches_literal` |
| C5 | `test_multi_use_etag_and_cache_hit` |
