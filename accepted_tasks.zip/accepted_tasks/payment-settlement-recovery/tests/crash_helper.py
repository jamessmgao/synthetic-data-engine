"""Interface-only helpers for exercising the payment CLI."""

import json
import os
import subprocess
import tempfile

PYTHON = "python3"
APP = "/app/service.py"

CRASH_HOOK = (
    "import os, signal, sqlite3\n"
    "_fault = int(os.environ.get('FAULT_COMMIT', '0'))\n"
    "_count = 0\n"
    "_real_connect = sqlite3.connect\n"
    "class Connection:\n"
    "    def __init__(self, real):\n"
    "        object.__setattr__(self, '_real', real)\n"
    "    def commit(self):\n"
    "        global _count\n"
    "        object.__getattribute__(self, '_real').commit()\n"
    "        _count += 1\n"
    "        if _fault and _count == _fault:\n"
    "            os.kill(os.getpid(), signal.SIGKILL)\n"
    "    def rollback(self):\n"
    "        object.__getattribute__(self, '_real').rollback()\n"
    "    def close(self):\n"
    "        object.__getattribute__(self, '_real').close()\n"
    "    def __enter__(self):\n"
    "        return self\n"
    "    def __exit__(self, exc_type, exc_value, traceback):\n"
    "        if exc_type is None:\n"
    "            self.commit()\n"
    "        else:\n"
    "            self.rollback()\n"
    "        return False\n"
    "    def __getattr__(self, name):\n"
    "        return getattr(object.__getattribute__(self, '_real'), name)\n"
    "    def __setattr__(self, name, value):\n"
    "        if name == '_real':\n"
    "            object.__setattr__(self, name, value)\n"
    "        else:\n"
    "            setattr(object.__getattribute__(self, '_real'), name, value)\n"
    "sqlite3.connect = lambda *args, **kwargs: Connection(_real_connect(*args, **kwargs))\n"
)

DRIVER_CODE = (
    "import json, runpy, sys\n"
    "commands = json.loads(sys.argv[1])\n"
    "for command in commands:\n"
    "    sys.argv = ['/app/service.py', *command]\n"
    "    try:\n"
    "        runpy.run_path('/app/service.py', run_name='__main__')\n"
    "    except SystemExit as exit_code:\n"
    "        if exit_code.code:\n"
    "            raise\n"
)


class PaymentCLI:
    """A fresh database driven exclusively through the command-line interface."""

    def __init__(self, label):
        self._tmp = tempfile.TemporaryDirectory(prefix=f"payments-{label}-")
        self.db_path = os.path.join(self._tmp.name, "payments.sqlite")
        self._crash_dir = os.path.join(self._tmp.name, "crash-hook")
        os.mkdir(self._crash_dir)
        with open(os.path.join(self._crash_dir, "sitecustomize.py"), "w") as hook:
            hook.write(CRASH_HOOK)

    def _env(self, fault_commit=None):
        env = os.environ.copy()
        env["WORLD_DB"] = self.db_path
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["PYTHONUNBUFFERED"] = "1"
        if fault_commit is not None:
            env["PYTHONPATH"] = self._crash_dir
            env["FAULT_COMMIT"] = str(fault_commit)
        return env

    def run(self, *args, fault_commit=None, timeout=30):
        result = subprocess.run(
            [PYTHON, APP, *args],
            cwd="/app",
            env=self._env(fault_commit),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.stdout.strip(), result.stderr.strip(), result.returncode

    def run_json(self, *args, fault_commit=None):
        stdout, stderr, returncode = self.run(*args, fault_commit=fault_commit)
        assert returncode == 0, f"command {args!r} failed: {returncode}: {stderr}"
        return json.loads(stdout)

    def report(self):
        return self.run_json("report")

    def spawn(self, *args):
        return subprocess.Popen(
            [PYTHON, APP, *args],
            cwd="/app",
            env=self._env(),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

    def run_sequence(self, commands, fault_commit=None, timeout=30):
        """Run absolute CLI commands in one process (for transaction-counted crashes)."""
        result = subprocess.run(
            [PYTHON, "-c", DRIVER_CODE, json.dumps([list(item) for item in commands])],
            cwd="/app",
            env=self._env(fault_commit),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.stdout.strip(), result.stderr.strip(), result.returncode

    def close(self):
        self._tmp.cleanup()


def expected_totals(payments):
    """Net balances for an explicitly supplied list of settled payments."""
    totals = {}
    for sender, recipient, amount in payments:
        totals[sender] = totals.get(sender, 0) - amount
        totals[recipient] = totals.get(recipient, 0) + amount
    return totals


def assert_report_balance(cli, expected):
    report = cli.report()
    assert report["balances"] == expected, (
        f"balances={report['balances']} expected={expected} "
        f"journal={report['journal_totals']}"
    )


def assert_within_one_application(report, baseline, sender, recipient, amount):
    """A killed settlement may have committed zero or one application, never two."""
    balances = report["balances"]
    low = baseline.get(sender, 0) - amount
    high = baseline.get(sender, 0)
    assert low <= balances.get(sender, 0) <= high, (
        f"sender balance={balances.get(sender, 0)!r}, "
        f"expected range [{low}, {high}]"
    )
    low = baseline.get(recipient, 0)
    high = baseline.get(recipient, 0) + amount
    assert low <= balances.get(recipient, 0) <= high, (
        f"recipient balance={balances.get(recipient, 0)!r}, "
        f"expected range [{low}, {high}]"
    )
