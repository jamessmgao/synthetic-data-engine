"""Command-line interface and settlement worker for the payment service."""

import argparse
import json
import os
import sys

from store import Store


class PaymentService:
    def __init__(self, store=None):
        self.store = store or Store()

    def submit(self, request_id, sender, recipient, amount_cents):
        if amount_cents <= 0:
            raise ValueError("amount_cents must be positive")
        if sender == recipient:
            raise ValueError("sender and recipient must differ")
        return self.store.record_payment(
            request_id, sender, recipient, amount_cents
        )

    def request(self, request_id):
        return self.store.payment(request_id)

    def settle_request(self, request_id):
        payment = self.store.payment(request_id)
        if payment is None:
            raise KeyError(request_id)
        if payment["status"] == "pending":
            self.store.mark_settled(request_id)
            self.store.apply_balances(payment)
        return self.store.payment(request_id)

    def settle_next(self):
        payment = self.store.next_pending()
        if payment is None:
            return None
        self.store.mark_settled(payment["request_id"])
        self.store.apply_balances(payment)
        return self.store.payment(payment["request_id"])

    def run_worker(self, limit=None):
        settled = []
        while limit is None or limit > 0:
            payment = self.settle_next()
            if payment is None:
                break
            settled.append(payment["request_id"])
            if limit is not None:
                limit -= 1
        return settled

    def report(self):
        return {
            "journal_totals": self.store.journal_totals(),
            "balances": self.store.balances(),
        }


def emit(value):
    print(json.dumps(value, sort_keys=True, separators=(",", ":")))


def positive_int(text):
    value = int(text)
    if value <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    return value


def build_parser():
    parser = argparse.ArgumentParser(description="Payment recording and settlement")
    sub = parser.add_subparsers(dest="command", required=True)

    submit = sub.add_parser("submit", help="record a payment request")
    submit.add_argument("request_id")
    submit.add_argument("sender")
    submit.add_argument("recipient")
    submit.add_argument("amount_cents", type=positive_int)

    worker = sub.add_parser("worker", help="settle pending payment requests")
    worker.add_argument("worker_id")
    worker.add_argument("--limit", type=positive_int)

    settle = sub.add_parser("settle", help="settle one request")
    settle.add_argument("request_id")

    show = sub.add_parser("show", help="show one request")
    show.add_argument("request_id")

    sub.add_parser("report", help="show journal and balance totals")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    service = PaymentService()

    try:
        if args.command == "submit":
            emit(service.submit(
                args.request_id,
                args.sender,
                args.recipient,
                args.amount_cents,
            ))
        elif args.command == "worker":
            if args.limit is not None:
                emit(service.run_worker(limit=args.limit))
            else:
                emit(service.run_worker())
        elif args.command == "settle":
            emit(service.settle_request(args.request_id))
        elif args.command == "show":
            payment = service.request(args.request_id)
            if payment is None:
                raise KeyError(args.request_id)
            emit(payment)
        elif args.command == "report":
            emit(service.report())
    except (ValueError, KeyError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
