"""SQLite persistence for payment recording and settlement."""

import os
import sqlite3

DEFAULT_DB = os.environ.get("WORLD_DB", "/tmp/payments.sqlite")


class Store:
    def __init__(self, path=None):
        self.path = path or DEFAULT_DB
        self._ensure_schema()

    def connect(self):
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 10000")
        return connection

    def _ensure_schema(self):
        with self.connect() as db:
            db.executescript(
                """
                CREATE TABLE IF NOT EXISTS payments (
                    request_id TEXT PRIMARY KEY,
                    sender TEXT NOT NULL,
                    recipient TEXT NOT NULL,
                    amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
                    status TEXT NOT NULL CHECK (status IN ('pending', 'settled'))
                );

                CREATE TABLE IF NOT EXISTS journal (
                    entry_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    request_id TEXT NOT NULL,
                    account TEXT NOT NULL,
                    delta_cents INTEGER NOT NULL,
                    UNIQUE (request_id, account),
                    FOREIGN KEY (request_id)
                        REFERENCES payments(request_id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS balances (
                    account TEXT PRIMARY KEY,
                    balance_cents INTEGER NOT NULL DEFAULT 0
                );

                CREATE INDEX IF NOT EXISTS journal_request_idx
                    ON journal(request_id);
                CREATE INDEX IF NOT EXISTS payments_status_idx
                    ON payments(status, request_id);
                """
            )

    def record_payment(self, request_id, sender, recipient, amount_cents):
        """Record a payment and its journal entries, or return an existing request."""
        with self.connect() as db:
            row = db.execute(
                "SELECT * FROM payments WHERE request_id = ?", (request_id,)
            ).fetchone()
            if row is not None:
                return dict(row)

            db.execute(
                """
                INSERT INTO payments
                    (request_id, sender, recipient, amount_cents, status)
                VALUES (?, ?, ?, ?, 'pending')
                """,
                (request_id, sender, recipient, amount_cents),
            )
            db.executemany(
                """
                INSERT INTO journal (request_id, account, delta_cents)
                VALUES (?, ?, ?)
                """,
                [
                    (request_id, sender, -amount_cents),
                    (request_id, recipient, amount_cents),
                ],
            )
            return dict(
                db.execute(
                    "SELECT * FROM payments WHERE request_id = ?", (request_id,)
                ).fetchone()
            )

    def next_pending(self):
        with self.connect() as db:
            row = db.execute(
                """
                SELECT * FROM payments
                WHERE status = 'pending'
                ORDER BY rowid
                LIMIT 1
                """
            ).fetchone()
            return dict(row) if row is not None else None

    def apply_balances(self, payment):
        """Apply a payment's journal amounts to account balances."""
        with self.connect() as db:
            entries = db.execute(
                "SELECT account, delta_cents FROM journal WHERE request_id = ?",
                (payment["request_id"],),
            ).fetchall()
            for entry in entries:
                db.execute(
                    """
                    INSERT INTO balances (account, balance_cents)
                    VALUES (?, ?)
                    ON CONFLICT(account) DO UPDATE
                        SET balance_cents = balance_cents + excluded.balance_cents
                    """,
                    (entry["account"], entry["delta_cents"]),
                )

    def mark_settled(self, request_id):
        with self.connect() as db:
            db.execute(
                "UPDATE payments SET status = 'settled' WHERE request_id = ?",
                (request_id,),
            )

    def settle_payment(self, request_id):
        """Apply a pending payment and complete it in one transaction."""
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute(
                "SELECT * FROM payments WHERE request_id = ?", (request_id,)
            ).fetchone()
            if row is None:
                raise KeyError(request_id)
            if row["status"] == "pending":
                entries = db.execute(
                    """
                    SELECT account, delta_cents FROM journal
                    WHERE request_id = ?
                    """,
                    (request_id,),
                ).fetchall()
                for entry in entries:
                    db.execute(
                        """
                        INSERT INTO balances (account, balance_cents)
                        VALUES (?, ?)
                        ON CONFLICT(account) DO UPDATE
                            SET balance_cents = balance_cents + excluded.balance_cents
                        """,
                        (entry["account"], entry["delta_cents"]),
                    )
                db.execute(
                    "UPDATE payments SET status = 'settled' WHERE request_id = ?",
                    (request_id,),
                )
                row = db.execute(
                    "SELECT * FROM payments WHERE request_id = ?", (request_id,)
                ).fetchone()
            return dict(row)

    def payment(self, request_id):
        with self.connect() as db:
            row = db.execute(
                "SELECT * FROM payments WHERE request_id = ?", (request_id,)
            ).fetchone()
            return dict(row) if row is not None else None

    def journal_totals(self):
        with self.connect() as db:
            return {
                row["account"]: row["total_cents"]
                for row in db.execute(
                    """
                    SELECT account, SUM(delta_cents) AS total_cents
                    FROM journal
                    GROUP BY account
                    """
                )
            }

    def balances(self):
        with self.connect() as db:
            return {
                row["account"]: row["balance_cents"]
                for row in db.execute("SELECT account, balance_cents FROM balances")
            }

    def close(self):
        return None
