# Payment settlement crash recovery

A Python/SQLite payment service can apply a settlement twice when a process dies between balance and status writes. The task requires crash-safe, idempotent settlement while preserving the public CLI.

## Scenario

The agent receives a payment CLI backed by SQLite. Settlement retries and workers operate on persistent requests, and processes may be killed and restarted during settlement.

## Root cause (hidden from the agent)

Balance application and the pending-to-settled status update are committed in separate SQLite transactions. A retry cannot distinguish a partially settled request from a genuinely pending one.

## Correctness constraints

- **C1**: Each payment request changes account balances at most once across settlement retries.
- **C2**: After a retried settlement, the balances table equals the net journal total for every account.
- **C3**: Killed `settle` and `worker` processes may be restarted and retried without double-applying or losing a payment; concurrent settlement and worker processes preserve the same invariants.
- **C4**: The documented submit, show, settle, worker, report, duplicate-request, validation, and exact balance behavior continues to work.

## Subgoals

1. Make settlement idempotent and durable across process death.
2. Preserve direct settlement and worker paths under concurrency.
3. Maintain the existing JSON CLI and validation behavior.

## Failure scenario

A settlement is SIGKILLed after its first effect commit and retried. The original code applies balances twice; reversing the writes instead leaves a settled request without balance changes. Tests inspect only CLI JSON output and compare balances with journal totals.

## Expected agent pitfalls

- Assuming a process-local deduplication set survives restarts.
- Reordering the two writes without making them atomic.
- Fixing only `settle` and overlooking the worker path.
- Breaking duplicate submit or existing CLI behavior.

## Anti-shortcut measures

- Both direct settlement and worker paths are exercised.
- Tests use ten fixed seeds and deterministic SIGKILL injection after committed SQLite transactions.
- Concurrent processes test retry safety without relying on timing speed.
- Only public CLI JSON and documented environment paths are observed.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_each_payment_changes_balances_at_most_once_across_retries`, `test_killed_worker_restarts_and_completes_exactly_once`, `test_concurrent_settles_apply_one_payment_exactly_once`, `test_concurrent_workers_apply_each_request_exactly_once` |
| C2 | `test_retried_balances_equal_net_journal_totals`, `test_counterexample_replay` |
| C3 | `test_each_payment_changes_balances_at_most_once_across_retries`, `test_retried_balances_equal_net_journal_totals`, `test_counterexample_replay`, `test_killed_worker_restarts_and_completes_exactly_once`, `test_concurrent_settles_apply_one_payment_exactly_once`, `test_concurrent_workers_apply_each_request_exactly_once` |
| C4 | `test_documented_cli_and_worker_semantics`, `test_submit_is_idempotent_for_duplicate_requests`, `test_invalid_and_boundary_inputs_have_documented_errors`, `test_zero_value_accounts_are_reported_explicitly` |
