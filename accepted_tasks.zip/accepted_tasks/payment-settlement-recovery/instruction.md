The payment service sometimes reports balances that do not match its journal. This can happen after the process is killed and restarted, or when `settle` or `worker` commands run at the same time. Fix it so `report` always shows `balances` equal to `journal_totals` for every account.

Keep the existing `submit`, `show`, `settle`, `worker`, and `report` command behavior and their JSON output working, including duplicate request IDs.
