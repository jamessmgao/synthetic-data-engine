import json
import os
import shutil
import signal
import socket
import subprocess
import time
import urllib.error
import urllib.request


class Cluster:
    """Start and drive the public three-node ledger HTTP interface."""

    IDS = ("n1", "n2", "n3")

    def __init__(self, root):
        self.root = str(root)
        shutil.rmtree(self.root, ignore_errors=True)
        os.makedirs(self.root, exist_ok=True)
        self.nodes = {}
        for node_id in self.IDS:
            port = self._free_port()
            self.nodes[node_id] = {
                "id": node_id,
                "url": f"http://127.0.0.1:{port}",
                "port": port,
                "state": os.path.join(self.root, node_id),
                "proc": None,
            }

    def _free_port(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("127.0.0.1", 0))
            return sock.getsockname()[1]

    def _peers(self, node_id):
        return ",".join(self.nodes[x]["url"] for x in self.IDS if x != node_id)

    def start(self, node_id):
        node = self.nodes[node_id]
        if node["proc"] is not None:
            raise RuntimeError(f"{node_id} is already running")
        log_path = os.path.join(self.root, f"{node_id}.log")
        with open(log_path, "ab") as log:
            node["proc"] = subprocess.Popen(
                [
                    "/app/world",
                    "node",
                    "--id",
                    node_id,
                    "--http",
                    f"127.0.0.1:{node['port']}",
                    "--state",
                    node["state"],
                    "--peer",
                    self._peers(node_id),
                ],
                cwd="/app",
                stdout=log,
                stderr=log,
            )
        self.wait_ready(node_id)
        return node

    def start_all(self):
        for node_id in self.IDS:
            self.start(node_id)

    def wait_ready(self, node_id, attempts=300):
        url = self.nodes[node_id]["url"] + "/ready"
        for _ in range(attempts):
            proc = self.nodes[node_id]["proc"]
            if proc is None or proc.poll() is not None:
                raise RuntimeError(f"{node_id} exited before becoming ready")
            try:
                with urllib.request.urlopen(url, timeout=0.25) as response:
                    if response.status == 200:
                        return
            except Exception:
                time.sleep(0.01)
        raise RuntimeError(f"{node_id} did not become ready")

    def stop(self, node_id, sig=signal.SIGKILL):
        proc = self.nodes[node_id]["proc"]
        if proc is None:
            return
        proc.send_signal(sig)
        proc.wait(timeout=5)
        self.nodes[node_id]["proc"] = None

    def restart(self, node_id):
        self.start(node_id)

    def request(self, node_id, path, method="GET", body=None):
        url = self.nodes[node_id]["url"] + path
        data = None
        headers = {}
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=2) as response:
                raw = response.read()
                return response.status, json.loads(raw) if raw else {}
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            try:
                value = json.loads(raw) if raw else {}
            except Exception:
                value = {"raw": raw.decode("utf-8", "replace")}
            return exc.code, value

    def write(self, node_id, request_id, account, amount):
        return self.request(
            node_id,
            "/write",
            method="POST",
            body={"id": request_id, "account": account, "amount": amount},
        )

    def get(self, node_id, account):
        code, value = self.request(node_id, f"/get?account={account}")
        assert code == 200, (code, value)
        return value

    def status(self, node_id):
        code, value = self.request(node_id, "/status")
        assert code == 200, (code, value)
        return value

    def elect(self, node_id):
        return self.request(node_id, "/elect", method="POST", body={})

    def cleanup(self):
        for node in self.nodes.values():
            proc = node["proc"]
            if proc is not None:
                proc.kill()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    pass
            node["proc"] = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        self.cleanup()
        return False
