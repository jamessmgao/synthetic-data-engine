# Preserve acknowledged ledger writes across failover

A three-node Go ledger can return HTTP 200 for a quorum-written request and later elect a node that never learned that request. The task requires acknowledged writes and request-ID deduplication to survive process restarts and leadership changes.

## Scenario

The service exposes a small replicated HTTP ledger with write, read, status, and election operations. Nodes keep durable state but a failover can elect a node whose log is missing an already acknowledged request.

## Root cause (hidden from the agent)

Election recovery derives a quorum watermark and rebuilds state from the local log without fetching missing entries from a peer. A node that was down when a quorum-acknowledged write replicated can therefore become leader and return a balance that omits the write.

## Correctness constraints

- **C1**: Every write acknowledged with HTTP 200 remains reflected in the balance returned by every later successful leader.
- **C2**: A request ID changes an account balance at most once, even when its write is retried after a leader change or concurrently.
- **C3**: The public ledger semantics remain correct: unread accounts start at balance 0, amounts may be zero or negative, successful writes report the resulting balance and index, and a retry returns the original acknowledged result with repeat set to true.
- **C4**: A write sent directly to a non-leader remains an HTTP 409 conflict rather than being applied locally.

## Subgoals

1. Make election recovery reconstruct the quorum-acknowledged log, including entries absent from the newly elected node.
2. Rebuild account balances and request-ID results consistently from the recovered log.
3. Preserve deduplication and normal HTTP semantics across restarts and concurrent retries.

## Failure scenario

A follower is stopped before a quorum write, the leader acknowledges the write, the leader is killed, the empty follower restarts, and another election eventually makes that follower leader. The supplied counterexample replay checks that the acknowledged balance and log entry are still present.

## Expected agent pitfalls

- Adding only a process-local request cache, which cannot help a restarted process.
- Recovering log length without recovering the missing entries.
- Rebuilding request results without rebuilding balances, or vice versa.
- Breaking duplicate retry responses or non-leader conflict behavior while changing election recovery.

## Anti-shortcut measures

- Two dedicated invariant tests use ten fixed seeds each and exercise killed and restarted processes, every possible later leader, conflicting retries, and concurrent retries.
- The exact counterexample is replayed through the public HTTP interface.
- Regression tests check ordinary write, read, retry, non-leader, zero, and negative-amount behavior.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_acknowledged_write_survives_every_later_leader`, `test_counterexample_replay` |
| C2 | `test_request_id_changes_balance_at_most_once_after_failover` |
| C3 | `test_get_initial_balance`, `test_write_dedup_after_acknowledge`, `test_negative_and_zero_amounts`, `test_election_after_simple_write` |
| C4 | `test_write_rejects_non_leader` |
