package main

import (
	"fmt"
	"os"
)

const usage = "world node --id NAME --http ADDR --state DIR --peer ADDR[,ADDR] | world cluster"

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, usage)
		os.Exit(2)
	}
	switch os.Args[1] {
	case "node":
		if err := runNode(os.Args[2:]); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	case "cluster":
		fmt.Println("start nodes with: world node --id NAME --http ADDR --state DIR --peer ADDR[,ADDR]")
	default:
		fmt.Fprintln(os.Stderr, usage)
		os.Exit(2)
	}
}
