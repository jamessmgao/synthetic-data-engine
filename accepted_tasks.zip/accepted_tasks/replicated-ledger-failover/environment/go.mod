module aqworld

go 1.23
