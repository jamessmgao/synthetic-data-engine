package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
)

type entry struct {
	Term    uint64 `json:"term"`
	Index   uint64 `json:"index"`
	ID      string `json:"id"`
	Account string `json:"account"`
	Amount  int64  `json:"amount"`
}

type result struct {
	Account string `json:"account"`
	Amount  int64  `json:"amount"`
	Balance int64  `json:"balance"`
	Index   uint64 `json:"index"`
}

type nodeState struct {
	ID          string            `json:"id"`
	Term        uint64            `json:"term"`
	Leader      string            `json:"leader"`
	Balances    map[string]int64  `json:"balances"`
	Requests    map[string]result `json:"requests"`
	Log         []entry           `json:"log"`
	CommitIndex uint64            `json:"commitIndex"`
}

type node struct {
	mu    sync.Mutex
	dir   string
	addr  string
	peers []string
	state nodeState
}

func (n *node) load() error {
	path := filepath.Join(n.dir, "state.json")
	data, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		n.state = nodeState{ID: n.state.ID, Leader: "n1", Balances: map[string]int64{}, Requests: map[string]result{}, Log: []entry{}}
		return n.save()
	}
	if err != nil {
		return err
	}
	if err := json.Unmarshal(data, &n.state); err != nil {
		return fmt.Errorf("state: %w", err)
	}
	if n.state.Balances == nil {
		n.state.Balances = map[string]int64{}
	}
	if n.state.Requests == nil {
		n.state.Requests = map[string]result{}
	}
	if n.state.Log == nil {
		n.state.Log = []entry{}
	}
	return nil
}

func (n *node) save() error {
	data, err := json.MarshalIndent(n.state, "", "  ")
	if err != nil {
		return err
	}
	path := filepath.Join(n.dir, "state.json")
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, data, 0600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

func (n *node) status(w http.ResponseWriter, r *http.Request) {
	n.mu.Lock()
	defer n.mu.Unlock()
	writeJSON(w, http.StatusOK, map[string]any{
		"id": n.state.ID, "term": n.state.Term, "leader": n.state.Leader, "commit": n.state.CommitIndex, "last": len(n.state.Log),
		"log": len(n.state.Log), "applied": len(n.state.Requests),
	})
}

func (n *node) get(w http.ResponseWriter, r *http.Request) {
	account := r.URL.Query().Get("account")
	n.mu.Lock()
	defer n.mu.Unlock()
	writeJSON(w, http.StatusOK, map[string]any{"account": account, "balance": n.state.Balances[account]})
}

func (n *node) logEntries(w http.ResponseWriter, r *http.Request) {
	from := uint64(0)
	fmt.Sscanf(r.URL.Query().Get("from"), "%d", &from)
	n.mu.Lock()
	defer n.mu.Unlock()
	entries := []entry{}
	for _, e := range n.state.Log {
		if e.Index > from {
			entries = append(entries, e)
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{"entries": entries})
}

func writeJSON(w http.ResponseWriter, code int, value any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(value)
}

func runNode(args []string) error {
	fs := flag.NewFlagSet("node", flag.ContinueOnError)
	id := fs.String("id", "", "node id")
	addr := fs.String("http", "", "listen address")
	stateDir := fs.String("state", "", "state directory")
	peerList := fs.String("peer", "", "comma-separated peer base URLs")
	if err := fs.Parse(args); err != nil {
		return err
	}
	if *id == "" || *addr == "" || *stateDir == "" {
		return fmt.Errorf("--id, --http and --state are required")
	}
	if strings.Contains(*addr, "://") {
		return fmt.Errorf("--http must be host:port")
	}
	peers := []string{}
	if *peerList != "" {
		for _, item := range strings.Split(*peerList, ",") {
			if item != "" {
				peers = append(peers, strings.TrimRight(item, "/"))
			}
		}
	}
	n := &node{dir: *stateDir, addr: *addr, peers: peers, state: nodeState{ID: *id}}
	if err := os.MkdirAll(n.dir, 0750); err != nil {
		return err
	}
	if err := n.load(); err != nil {
		return err
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/ready", func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusOK) })
	mux.HandleFunc("/status", n.status)
	mux.HandleFunc("/get", n.get)
	mux.HandleFunc("/write", n.write)
	mux.HandleFunc("/replicate", n.replicate)
	mux.HandleFunc("/elect", n.elect)
	mux.HandleFunc("/log", n.logEntries)
	fmt.Printf("node %s listening on %s\n", strconv.Quote(*id), n.addr)
	return http.ListenAndServe(n.addr, mux)
}
