package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sort"
	"sync"
	"time"
)

var clusterClient = &http.Client{Timeout: 500 * time.Millisecond}

type writeRequest struct {
	ID      string `json:"id"`
	Account string `json:"account"`
	Amount  int64  `json:"amount"`
}

type statusInfo struct {
	ID     string `json:"id"`
	Term   uint64 `json:"term"`
	Leader string `json:"leader"`
	Commit uint64 `json:"commit"`
	Last   uint64 `json:"last"`
}

func postJSON(base, path string, body any) (map[string]any, error) {
	data, err := json.Marshal(body)
	if err != nil {
		return nil, err
	}
	resp, err := clusterClient.Post(base+path, "application/json", bytes.NewReader(data))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	out := map[string]any{}
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil && err != io.EOF {
		return nil, err
	}
	if resp.StatusCode >= 300 {
		return out, fmt.Errorf("peer returned %s", resp.Status)
	}
	return out, nil
}

func number(value map[string]any, key string) uint64 {
	raw, _ := value[key].(float64)
	if raw < 0 {
		return 0
	}
	return uint64(raw)
}

func (n *node) replicate(w http.ResponseWriter, r *http.Request) {
	var e entry
	if err := json.NewDecoder(r.Body).Decode(&e); err != nil {
		http.Error(w, "invalid entry", http.StatusBadRequest)
		return
	}
	n.mu.Lock()
	defer n.mu.Unlock()
	if old, ok := n.state.Requests[e.ID]; ok && old.Index == e.Index {
		writeJSON(w, http.StatusOK, map[string]any{"index": e.Index})
		return
	}
	if e.Index <= uint64(len(n.state.Log)) {
		http.Error(w, "index occupied", http.StatusConflict)
		return
	}
	balance := n.state.Balances[e.Account] + e.Amount
	n.state.Log = append(n.state.Log, e)
	n.state.Requests[e.ID] = result{Account: e.Account, Amount: e.Amount, Balance: balance, Index: e.Index}
	if err := n.save(); err != nil {
		http.Error(w, "state unavailable", http.StatusInternalServerError)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"index": e.Index})
}

func (n *node) write(w http.ResponseWriter, r *http.Request) {
	var req writeRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.ID == "" || req.Account == "" {
		http.Error(w, "invalid write", http.StatusBadRequest)
		return
	}
	n.mu.Lock()
	if old, ok := n.state.Requests[req.ID]; ok {
		value := map[string]any{"id": req.ID, "account": old.Account, "balance": old.Balance, "index": old.Index, "repeat": true}
		n.mu.Unlock()
		writeJSON(w, http.StatusOK, value)
		return
	}
	if n.state.Leader != n.state.ID {
		leader := n.state.Leader
		n.mu.Unlock()
		writeJSON(w, http.StatusConflict, map[string]any{"leader": leader})
		return
	}
	e := entry{Term: n.state.Term, Index: uint64(len(n.state.Log)) + 1, ID: req.ID, Account: req.Account, Amount: req.Amount}
	n.state.Log = append(n.state.Log, e)
	if err := n.save(); err != nil {
		n.mu.Unlock()
		http.Error(w, "state unavailable", http.StatusInternalServerError)
		return
	}
	n.mu.Unlock()
	ack := uint64(1)
	var mu sync.Mutex
	for _, peer := range n.peers {
		_, err := postJSON(peer, "/replicate", e)
		if err == nil {
			mu.Lock()
			ack++
			mu.Unlock()
		}
	}
	if ack < 2 {
		writeJSON(w, http.StatusServiceUnavailable, map[string]any{"id": req.ID, "replicas": ack})
		return
	}
	n.mu.Lock()
	n.state.CommitIndex = e.Index
	n.state.Balances[e.Account] += e.Amount
	n.state.Requests[e.ID] = result{Account: e.Account, Amount: e.Amount, Balance: n.state.Balances[e.Account], Index: e.Index}
	if err := n.save(); err != nil {
		n.mu.Unlock()
		http.Error(w, "state unavailable", http.StatusInternalServerError)
		return
	}
	n.mu.Unlock()
	writeJSON(w, http.StatusOK, map[string]any{"id": req.ID, "account": e.Account, "balance": n.state.Balances[e.Account], "index": e.Index})
}

func (n *node) currentStatus() statusInfo {
	return statusInfo{ID: n.state.ID, Term: n.state.Term, Leader: n.state.Leader, Commit: n.state.CommitIndex, Last: uint64(len(n.state.Log))}
}

func (n *node) getLog(base string, from uint64) ([]entry, error) {
	value, err := postJSON(base, fmt.Sprintf("/log?from=%d", from), map[string]string{})
	if err != nil {
		return nil, err
	}
	raw, _ := json.Marshal(value["entries"])
	var entries []entry
	if err := json.Unmarshal(raw, &entries); err != nil {
		return nil, err
	}
	return entries, nil
}

func (n *node) elect(w http.ResponseWriter, _ *http.Request) {
	n.mu.Lock()
	self := n.currentStatus()
	n.mu.Unlock()
	terms := []uint64{self.Term}
	lasts := []uint64{self.Last}
	for _, peer := range n.peers {
		value, err := postJSON(peer, "/status", map[string]string{})
		if err != nil {
			continue
		}
		terms = append(terms, number(value, "term"))
		lasts = append(lasts, number(value, "last"))
	}
	sort.Slice(terms, func(i, j int) bool { return terms[i] < terms[j] })
	sort.Slice(lasts, func(i, j int) bool { return lasts[i] < lasts[j] })
	watermark := lasts[0]
	if len(lasts) >= 2 && lasts[1] > watermark {
		watermark = lasts[1]
	}
	n.mu.Lock()
	defer n.mu.Unlock()
	if watermark > uint64(len(n.state.Log)) {
		for _, peer := range n.peers {
			entries, err := n.getLog(peer, uint64(len(n.state.Log)))
			if err != nil {
				continue
			}
			for _, e := range entries {
				if e.Index > uint64(len(n.state.Log)) && e.Index <= watermark {
					n.state.Log = append(n.state.Log, e)
				}
			}
			if uint64(len(n.state.Log)) >= watermark {
				break
			}
		}
	}
	recovered := watermark
	if recovered > uint64(len(n.state.Log)) {
		recovered = uint64(len(n.state.Log))
	}
	if recovered < uint64(len(n.state.Log)) {
		n.state.Log = n.state.Log[:recovered]
	}
	n.state.Term = terms[len(terms)-1] + 1
	n.state.Leader = n.state.ID
	n.state.CommitIndex = recovered
	n.state.Balances = map[string]int64{}
	for _, e := range n.state.Log {
		if e.Index <= recovered {
			n.state.Balances[e.Account] += e.Amount
			n.state.Requests[e.ID] = result{Account: e.Account, Amount: e.Amount, Balance: n.state.Balances[e.Account], Index: e.Index}
		}
	}
	if err := n.save(); err != nil {
		http.Error(w, "state unavailable", http.StatusInternalServerError)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"id": n.state.ID, "term": n.state.Term, "commit": n.state.CommitIndex, "last": len(n.state.Log)})
}
