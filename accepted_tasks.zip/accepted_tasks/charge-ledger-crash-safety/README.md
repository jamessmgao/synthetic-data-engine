# Charge Ledger Crash Safety

The charge ledger service can double-credit wallets and exceed account limits when retry_pending is interrupted by a crash and restarted. The fix must make each charge an atomic, idempotent, limit-aware operation.

## Scenario

A Python service backed by SQLite tracks accounts, charge requests, ledger entries, and wallet balances. The retry command processes pending charges but is not crash-safe: killing the process mid-run can leave wallet credits committed while ledger entries remain unapplied, so a restart credits them again.

## Root cause (hidden from the agent)

store.settle_pending credits all pending wallets in one pass then records all settlements in a second pass. A crash between passes leaves credits without corresponding ledger entries. service.apply_charge credits the wallet and marks the ledger in separate transactions, so a retry can duplicate the credit. Neither step checks the account limit before crediting.

## Correctness constraints

- **C1**: For each customer, the wallet balance equals the sum of amounts from ledger entries where applied is 1.
- **C2**: Each charge request credits its amount to the wallet at most once, even across retries after crashes.
- **C3**: A wallet balance never exceeds the customer's account limit, even when multiple charges are settled.

## Subgoals

1. Make each charge application atomic and idempotent
2. Check the account limit before crediting
3. Route settle and retry through the atomic apply

## Failure scenario

Tests start a traced retry process, observe committed wallet credits via the state command, kill the process, and restart with retry. On the defective code this produces a balance that exceeds the applied ledger total and the account limit.

## Expected agent pitfalls

- Adding an idempotency guard without checking the account limit
- Making apply_charge atomic but not routing settle/retry through it
- Checking the limit in apply_charge but not in settle_pending

## Anti-shortcut measures

- Tests kill and restart retry processes to expose non-atomic applies
- Tests settle charges that individually fit but together exceed the limit
- Tests run concurrent applies to expose race conditions

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_wallet_equals_applied_total` |
| C2 | `test_no_duplicate_credits` |
| C3 | `test_balance_within_limit` |
