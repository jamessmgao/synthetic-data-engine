"""Interface-only driver for the charge service tests."""
from __future__ import annotations

import json
import random
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any

APP = Path("/app")
CLI = str(APP / "cli.py")


class Service:
    """Drive the command-line interface with an isolated database."""

    def __init__(self, root: str | Path) -> None:
        self.db = str(Path(root) / "charges.db")

    def argv(self, *args: object) -> list[str]:
        return ["python3", CLI, "--db", self.db, *[str(a) for a in args]]

    def run(self, *args: object, check: bool = True) -> subprocess.CompletedProcess[str]:
        proc = subprocess.run(
            self.argv(*args),
            cwd=APP,
            text=True,
            capture_output=True,
            timeout=15,
        )
        if check and proc.returncode != 0:
            raise AssertionError(
                f"command {args} failed ({proc.returncode}): {proc.stderr or proc.stdout}"
            )
        return proc

    def state(self) -> dict[str, Any]:
        proc = self.run("state")
        try:
            value = json.loads(proc.stdout)
        except json.JSONDecodeError as exc:
            raise AssertionError(f"invalid state JSON: {proc.stdout!r}") from exc
        if not isinstance(value, dict):
            raise AssertionError(f"state is not a JSON object: {proc.stdout!r}")
        return value

    def start_traced_retry(self, pipe: bool = False) -> subprocess.Popen[bytes]:
        stdout = subprocess.PIPE if pipe else subprocess.DEVNULL
        return subprocess.Popen(
            ["python3", "-m", "trace", "--trace", CLI, "--db", self.db, "retry"],
            cwd=APP,
            stdout=stdout,
            stderr=subprocess.DEVNULL,
        )

    def kill_retry_after_first_commit(self) -> bool:
        """SIGKILL retry after its first transaction commit is observed."""
        process = self.start_traced_retry(pipe=True)
        assert process.stdout is not None
        saw_commit = False
        for raw in process.stdout:
            if b"COMMIT" in raw:
                saw_commit = True
                break
        alive = process.poll() is None
        if alive:
            process.kill()
        process.wait()
        return saw_commit and alive


def has_progress(state: dict[str, Any]) -> bool:
    return any(int(wallet["balance"]) != 0 for wallet in state["wallets"]) or any(
        int(entry["applied"]) == 1 for entry in state["ledger"]
    )


def kill_retry_when_progress_changes(service: Service) -> tuple[bool, dict[str, Any] | None]:
    """SIGKILL a retry after an interface-visible state change."""
    process = service.start_traced_retry()
    last: dict[str, Any] | None = None
    deadline = time.monotonic() + 12
    while time.monotonic() < deadline:
        if process.poll() is not None:
            process.wait()
            return False, last
        last = service.state()
        if has_progress(last):
            process.kill()
            process.wait()
            return True, last
    if process.poll() is None:
        process.kill()
        process.wait()
        return False, last
    return False, last


def run_schedule(seed: int, root: str | Path) -> dict[str, Any]:
    """Run one deterministic mixed schedule and record state after each step."""
    rng = random.Random(seed)
    service = Service(root)
    records: list[tuple[str, dict[str, Any]]] = []

    def record(label: str) -> dict[str, Any]:
        value = service.state()
        records.append((label, value))
        return value

    service.run("reset")
    record("reset")

    customers = [f"customer-{seed}-{index}" for index in range(3)]
    limits = [rng.randrange(0, 18), rng.randrange(0, 22), rng.randrange(0, 26)]
    requests = [f"request-{seed}-{index}" for index in range(18)]
    assert len(set(customers)) == len(customers)
    assert len(set(requests)) == len(requests)
    assert all(0 <= value <= 25 for value in limits)

    for customer, limit in zip(customers, limits):
        service.run("open-account", customer, limit)
        record(f"open {customer}")

    amounts: dict[str, int] = {}
    for index, request in enumerate(requests[:8]):
        customer = rng.choice(customers)
        amount = rng.randrange(0, 10)
        assert 0 <= amount <= 9
        amounts[request] = amount
        service.run("submit", request, customer, amount)
        record(f"submit {request}")

    for index in range(4):
        request = rng.choice(requests[:8])
        operation = rng.choice(["apply", "settle", "mark", "duplicate-apply"])
        if operation == "duplicate-apply":
            service.run("apply", request)
            service.run("apply", request)
        else:
            service.run(operation, request)
        record(f"prelude {index} {operation} {request}")

    for request in requests[8:]:
        customer = rng.choice(customers)
        amount = rng.randrange(0, 10)
        assert 0 <= amount <= 9
        amounts[request] = amount
        service.run("submit", request, customer, amount)
        record(f"submit {request}")

    killed, observed = kill_retry_when_progress_changes(service)
    if observed is not None:
        records.append(("killed retry", observed))
    else:
        record("retry before forced kill")
    assert killed, "the test could not kill a live retry process"

    service.run("retry")
    record("restart retry")

    concurrent_request = f"request-{seed}-concurrent"
    assert concurrent_request not in requests
    concurrent_customer = rng.choice(customers)
    concurrent_amount = rng.randrange(0, 10)
    assert 0 <= concurrent_amount <= 9
    service.run(
        "submit", concurrent_request, concurrent_customer, concurrent_amount
    )
    record("submit concurrent request")

    workers = [
        subprocess.Popen(
            service.argv("apply", concurrent_request),
            cwd=APP,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        for _ in range(2)
    ]
    for worker in workers:
        stdout, stderr = worker.communicate(timeout=15)
        assert worker.returncode == 0, stderr.decode(errors="replace")
    record("concurrent duplicate apply")

    retry_workers = [
        subprocess.Popen(
            service.argv("retry"),
            cwd=APP,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        for _ in range(2)
    ]
    for worker in retry_workers:
        stdout, stderr = worker.communicate(timeout=15)
        assert worker.returncode == 0, stderr.decode(errors="replace")
    record("concurrent retries")

    service.run("retry")
    record("final retry")
    return {"seed": seed, "steps": records}


def schedules() -> list[dict[str, Any]]:
    values: list[dict[str, Any]] = []
    for seed in range(10):
        with tempfile.TemporaryDirectory(prefix=f"charge-seed-{seed}-") as root:
            values.append(run_schedule(seed, root))
    return values
