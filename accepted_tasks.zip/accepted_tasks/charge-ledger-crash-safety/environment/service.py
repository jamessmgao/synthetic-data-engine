"""Charge ledger service backed by SQLite."""

from __future__ import annotations

from store import DEFAULT_DB_PATH, Store, connect, reset


class LedgerPay:
    """Tracks accounts, charge requests, ledger entries, and wallet balances."""

    def __init__(self, path: str = DEFAULT_DB_PATH) -> None:
        self.path = path
        self.store = connect(path)

    def close(self) -> None:
        self.store.close()

    def reset(self) -> None:
        self.store.close()
        reset(self.path)
        self.store = connect(self.path)

    def open_account(self, customer_id: str, credit_limit: int) -> str:
        with self.store.transaction():
            cur = self.store.execute(
                "INSERT OR IGNORE INTO accounts(customer_id, credit_limit) VALUES(?, ?)",
                (customer_id, credit_limit),
            )
        return "opened" if cur.rowcount == 1 else "already opened"

    def submit_charge(self, request_id: str, customer_id: str, amount: int) -> str:
        with self.store.transaction():
            cur = self.store.execute(
                "INSERT OR IGNORE INTO charges(request_id, customer_id, amount, state) "
                "VALUES(?, ?, ?, 'submitted')",
                (request_id, customer_id, amount),
            )
            if cur.rowcount == 0:
                return "already submitted"
            self.store.execute(
                "INSERT OR IGNORE INTO ledger(code, customer_id, amount, applied) "
                "VALUES(?, ?, ?, 0)",
                (request_id, customer_id, amount),
            )
        return "submitted"

    def apply_charge(self, request_id: str) -> str:
        row = self.store.query_one(
            "SELECT customer_id, amount, state FROM charges WHERE request_id = ?",
            (request_id,),
        )
        if row is None:
            raise KeyError(request_id)
        if row["state"] == "charged":
            return "already charged"

        with self.store.transaction():
            self.store.execute(
                "INSERT INTO wallets(customer_id, balance) VALUES(?, ?) "
                "ON CONFLICT(customer_id) DO UPDATE SET balance = balance + excluded.balance",
                (row["customer_id"], row["amount"]),
            )

        with self.store.transaction():
            self.store.execute(
                "UPDATE ledger SET applied = 1 WHERE code = ?",
                (request_id,),
            )
        return "applied"

    def mark_charged(self, request_id: str) -> str:
        with self.store.transaction():
            self.store.execute(
                "UPDATE charges SET state = 'charged' WHERE request_id = ?",
                (request_id,),
            )
        return "charged"

    def settle_charge(self, request_id: str) -> str:
        self.apply_charge(request_id)
        self.mark_charged(request_id)
        return "settled"

    def retry_pending(self) -> list[str]:
        return self.store.settle_pending()

    def wallet_balance(self, customer_id: str) -> int:
        row = self.store.query_one(
            "SELECT balance FROM wallets WHERE customer_id = ?",
            (customer_id,),
        )
        return int(row["balance"]) if row else 0

    def charges(self) -> list[dict[str, object]]:
        return [
            {
                "request_id": r["request_id"],
                "customer_id": r["customer_id"],
                "amount": r["amount"],
                "state": r["state"],
            }
            for r in self.store.query_all(
                "SELECT request_id, customer_id, amount, state FROM charges ORDER BY request_id"
            )
        ]

    def ledger_entries(self) -> list[dict[str, object]]:
        return [
            {
                "code": r["code"],
                "customer_id": r["customer_id"],
                "amount": r["amount"],
                "applied": r["applied"],
            }
            for r in self.store.query_all(
                "SELECT code, customer_id, amount, applied FROM ledger ORDER BY code"
            )
        ]

    def wallets(self) -> list[dict[str, object]]:
        return [
            {"customer_id": r["customer_id"], "balance": r["balance"]}
            for r in self.store.query_all(
                "SELECT customer_id, balance FROM wallets ORDER BY customer_id"
            )
        ]

    def accounts(self) -> list[dict[str, object]]:
        return [
            {"customer_id": r["customer_id"], "credit_limit": r["credit_limit"]}
            for r in self.store.query_all(
                "SELECT customer_id, credit_limit FROM accounts ORDER BY customer_id"
            )
        ]

    def state(self) -> dict[str, object]:
        return {
            "accounts": self.accounts(),
            "charges": self.charges(),
            "ledger": self.ledger_entries(),
            "wallets": self.wallets(),
        }
