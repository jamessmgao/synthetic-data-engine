"""Black-box driver for the replicated ledger service."""

import json
import os
import random
import select
import subprocess
import sys
import tempfile
import time


class NodeProcess:
    def __init__(self, node_id, data_dir):
        self.node_id = node_id
        self.data_dir = data_dir
        self.process = None
        self._buffer = b""

    def start(self):
        if self.process is not None and self.process.poll() is None:
            return
        self.process = subprocess.Popen(
            [sys.executable, "-u", "/app/node.py", "--node", self.node_id,
             "--data-dir", self.data_dir],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            bufsize=0,
        )
        self._buffer = b""

    def _write(self, message):
        if self.process is None or self.process.poll() is not None:
            raise AssertionError(f"node {self.node_id} is not running")
        data = (json.dumps(message, sort_keys=True) + "\n").encode("utf-8")
        try:
            self.process.stdin.write(data)
            self.process.stdin.flush()
        except (BrokenPipeError, OSError) as exc:
            raise AssertionError(f"node {self.node_id} rejected input: {exc}")

    def _read(self, timeout=3.0):
        deadline = time.monotonic() + timeout
        while b"\n" not in self._buffer:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                self.kill()
                raise AssertionError(f"node {self.node_id} timed out")
            ready, _, _ = select.select([self.process.stdout], [], [], remaining)
            if not ready:
                continue
            chunk = os.read(self.process.stdout.fileno(), 4096)
            if not chunk:
                self.kill()
                detail = self.process.stderr.read().decode("utf-8", "replace")
                raise AssertionError(f"node {self.node_id} exited: {detail}")
            self._buffer += chunk
        line, self._buffer = self._buffer.split(b"\n", 1)
        return json.loads(line.decode("utf-8"))

    def send(self, message, timeout=3.0):
        self._write(message)
        return self._read(timeout)

    def kill(self):
        if self.process is not None and self.process.poll() is None:
            self.process.kill()
        if self.process is not None:
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=2)

    def stop(self):
        self.kill()
        if self.process is not None:
            self.process.stdin.close()
            self.process.stdout.close()
            self.process.stderr.close()
            self.process = None


def send_concurrent(pairs, timeout=3.0):
    """Start requests on independent replicas before collecting any reply."""
    for process, message in pairs:
        process._write(message)
    return [process._read(timeout) for process, _ in pairs]


def _requests(rng, seed):
    accounts = ["A", "B", "C"]
    requests = []
    for number in range(6):
        requests.append({
            "request_id": f"seed-{seed}-TX{number}",
            "account": rng.choice(accounts),
            "amount": rng.choice([1, 2, 5, 10]),
            "term": rng.randint(1, 4),
            "index": number + 1,
        })
    return requests


def _record_prepare(node, response, operation, known_entries):
    if response.get("state") != "reserved":
        return
    index = response["index"]
    known_entries[node][index] = operation


def run_random_schedule(seed, validate):
    """Run a deterministic schedule and validate every observable step."""
    rng = random.Random(seed)
    requests = _requests(rng, seed)
    nodes = ["n0", "n1", "n2"]
    with tempfile.TemporaryDirectory(prefix=f"ledger-seed-{seed}-") as root:
        handles = {
            node: NodeProcess(node, os.path.join(root, node)) for node in nodes
        }
        known_entries = {node: {} for node in nodes}

        def snapshot():
            states = {
                node: handles[node].send({"action": "status"})
                for node in nodes
            }
            validate(states, known_entries)

        try:
            for handle in handles.values():
                handle.start()
            snapshot()

            # Exercise overlapping requests on independent replica processes.
            concurrent_requests = [requests[0], requests[1]]
            concurrent_nodes = [handles["n0"], handles["n1"]]
            concurrent_responses = send_concurrent([
                (process, {
                    "action": "prepare", "term": request["term"],
                    "request_id": request["request_id"],
                    "account": request["account"],
                    "amount": request["amount"],
                })
                for process, request in zip(concurrent_nodes, concurrent_requests)
            ])
            for process, request, response in zip(
                    concurrent_nodes, concurrent_requests, concurrent_responses):
                assert response["state"] == "reserved"
                _record_prepare(process.node_id, response, request, known_entries)
            snapshot()

            # Every seed includes a durable restart and a retried request.
            recovery = rng.choice(requests[2:])
            target = rng.choice(nodes)
            leader = rng.choice([n for n in nodes if n != target])
            response = handles[leader].send({
                "action": "prepare", "term": recovery["term"],
                "request_id": recovery["request_id"],
                "account": recovery["account"], "amount": recovery["amount"],
            })
            assert response["state"] == "reserved"
            _record_prepare(leader, response, recovery, known_entries)
            snapshot()

            append_result = handles[target].send({
                "action": "append", "term": recovery["term"],
                "index": recovery["index"], "operation": recovery,
            })
            assert append_result["stored"] is True
            known_entries[target][recovery["index"]] = recovery
            snapshot()

            handles[target].kill()
            handles[target].start()
            snapshot()

            retry = handles[target].send({
                "action": "prepare", "term": recovery["term"] + 1,
                "request_id": recovery["request_id"],
                "account": recovery["account"], "amount": recovery["amount"],
            })
            assert retry["state"] == "reserved"
            _record_prepare(target, retry, recovery, known_entries)
            snapshot()

            handles[target].send({
                "action": "commit", "term": recovery["term"] + 1,
                "index": recovery["index"],
            })
            snapshot()

            for _ in range(12):
                choice = rng.randrange(7)
                request = rng.choice(requests)
                node = rng.choice(nodes)
                if choice in (0, 1):
                    response = handles[node].send({
                        "action": "prepare", "term": request["term"],
                        "request_id": request["request_id"],
                        "account": request["account"],
                        "amount": request["amount"],
                    })
                    _record_prepare(node, response, request, known_entries)
                elif choice in (2, 3):
                    result = handles[node].send({
                        "action": "append", "term": request["term"],
                        "index": request["index"], "operation": request,
                    })
                    if result["stored"]:
                        known_entries[node][request["index"]] = request
                elif choice in (4, 5):
                    handles[node].send({
                        "action": "commit", "term": request["term"],
                        "index": request["index"],
                    })
                else:
                    handles[node].kill()
                    handles[node].start()
                snapshot()
            return {
                node: handles[node].send({"action": "status"}) for node in nodes
            }
        finally:
            for handle in handles.values():
                handle.stop()
