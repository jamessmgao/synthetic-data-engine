"""Durable state for one replica of the replicated account log."""

import argparse
import json
import os
from collections import defaultdict


class ReplicatedLedger:
    def __init__(self, node_id, directory):
        self.node_id = node_id
        self.directory = directory
        os.makedirs(directory, exist_ok=True)
        self.wal_path = os.path.join(directory, "wal.jsonl")
        self.entries = {}
        self.intents = {}
        self.request_to_index = {}
        self.completed = {}
        self.committed = set()
        self.balances = defaultdict(int)
        self.effect_count = defaultdict(int)
        self._load()

    def _append_record(self, record):
        with open(self.wal_path, "a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())

    def _load(self):
        if not os.path.exists(self.wal_path):
            return
        with open(self.wal_path, "r", encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                record = json.loads(line)
                kind = record["kind"]
                if kind == "intent":
                    request_id = record["request_id"]
                    if request_id not in self.completed:
                        self.intents[request_id] = record["index"]
                        self.request_to_index[request_id] = record["index"]
                elif kind == "entry":
                    self.entries[record["index"]] = record["operation"]
                    rid = record["operation"].get("request_id")
                    if rid is not None:
                        self.request_to_index[rid] = record["index"]
                elif kind == "commit":
                    self._apply_through(record["index"])

    def request_status(self, request_id):
        if request_id in self.completed:
            return "completed", self.completed[request_id]
        if request_id in self.intents:
            return "reserved", {"index": self.intents[request_id]}
        if request_id in self.request_to_index:
            return "reserved", {"index": self.request_to_index[request_id]}
        return "new", None

    def record_intent(self, request_id, index):
        status, value = self.request_status(request_id)
        if status != "new":
            return status, value
        self._append_record({
            "kind": "intent",
            "request_id": request_id,
            "index": index,
        })
        self.intents[request_id] = index
        self.request_to_index[request_id] = index
        return "reserved", {"index": index}

    def append_entry(self, term, index, operation):
        if index in self.entries:
            return {"stored": False, "index": index}
        record = {
            "kind": "entry",
            "term": term,
            "index": index,
            "operation": operation,
        }
        self._append_record(record)
        self.entries[index] = operation
        rid = operation.get("request_id")
        if rid is not None:
            self.request_to_index[rid] = index
        return {"stored": True, "index": index}

    def _apply(self, index):
        if index in self.committed:
            return False
        operation = self.entries.get(index)
        if operation is None:
            return False
        request_id = operation["request_id"]
        account = operation["account"]
        amount = int(operation["amount"])
        self.balances[account] += amount
        self.effect_count[request_id] += 1
        self.completed[request_id] = {
            "account": account,
            "amount": amount,
            "balance": self.balances[account],
            "index": index,
        }
        self.intents.pop(request_id, None)
        self.committed.add(index)
        return True

    def _apply_through(self, index):
        applied = []
        for entry_index in sorted(self.entries):
            if entry_index <= index:
                if self._apply(entry_index):
                    applied.append(entry_index)
        return applied

    def commit_through(self, term, index):
        self._append_record({"kind": "commit", "term": term, "index": index})
        applied = self._apply_through(index)
        return applied

    def next_index(self):
        return max(self.entries, default=0) + 1

    def snapshot(self, account=None):
        result = {
            "node": self.node_id,
            "entries": len(self.entries),
            "committed": sorted(self.committed),
            "balances": dict(self.balances),
            "effects": {
                key: value for key, value in sorted(self.effect_count.items())
            },
            "entry_requests": [
                self.entries[i]["request_id"]
                for i in sorted(self.entries)
                if "request_id" in self.entries[i]
            ],
        }
        if account is not None:
            result["account_balance"] = self.balances.get(account, 0)
        return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--node", required=True)
    parser.add_argument("--data-dir", required=True)
    args = parser.parse_args()
    ledger = ReplicatedLedger(args.node, args.data_dir)
    print(json.dumps(ledger.snapshot(), sort_keys=True))


if __name__ == "__main__":
    main()
