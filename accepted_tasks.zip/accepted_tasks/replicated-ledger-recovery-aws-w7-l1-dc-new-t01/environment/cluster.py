"""Drive a fixed sequence of messages across replica processes."""

import argparse
import json
import subprocess
import sys


class Cluster:
    def __init__(self, node_ids, root):
        self.node_ids = list(node_ids)
        self.root = root
        self.processes = {}

    def _start(self, node_id):
        command = [
            sys.executable,
            "-u",
            "/app/node.py",
            "--node",
            node_id,
            "--data-dir",
            f"{self.root}/{node_id}",
        ]
        process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
        self.processes[node_id] = process
        return process

    def _send(self, node_id, message):
        process = self.processes[node_id]
        if process.poll() is not None:
            raise RuntimeError(f"node {node_id} is not running")
        line = json.dumps(message, sort_keys=True)
        process.stdin.write(line + "\n")
        process.stdin.flush()
        response = process.stdout.readline()
        if not response:
            errors = process.stderr.read()
            raise RuntimeError(f"node {node_id} stopped: {errors}")
        return json.loads(response)

    def _restart(self, node_id):
        process = self.processes.get(node_id)
        if process is not None and process.poll() is None:
            process.terminate()
            process.wait()
        process = self._start(node_id)
        return {"started": True, "node": node_id}

    def execute(self, steps):
        for node_id in self.node_ids:
            self._start(node_id)

        events = []
        for number, step in enumerate(steps):
            kind = step["kind"]
            if kind == "send":
                node_id = step["node"]
                response = self._send(node_id, step["message"])
                events.append({
                    "step": number,
                    "node": node_id,
                    "response": response,
                })
            elif kind == "restart":
                node_id = step["node"]
                response = self._restart(node_id)
                events.append({
                    "step": number,
                    "node": node_id,
                    "response": response,
                })
            else:
                raise ValueError("unsupported schedule step")

        statuses = []
        for node_id in self.node_ids:
            statuses.append({
                "node": node_id,
                "response": self._send(node_id, {"action": "status"}),
            })

        for process in self.processes.values():
            if process.poll() is None:
                process.stdin.close()
                process.wait()
        return {"events": events, "statuses": statuses}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--nodes", default="n0,n1,n2")
    parser.add_argument("--root", required=True)
    parser.add_argument("--schedule", default="-")
    args = parser.parse_args()

    if args.schedule == "-":
        document = json.load(sys.stdin)
    else:
        with open(args.schedule, encoding="utf-8") as handle:
            document = json.load(handle)

    cluster = Cluster(args.nodes.split(","), args.root)
    result = cluster.execute(document["steps"])
    json.dump(result, sys.stdout, sort_keys=True)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
