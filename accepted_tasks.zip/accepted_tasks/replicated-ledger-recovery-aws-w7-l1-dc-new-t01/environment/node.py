"""One replica process in the account cluster."""

import argparse
import json
import os
import sys

from ledger import ReplicatedLedger


class Node:
    def __init__(self, node_id, data_dir):
        self.node_id = node_id
        self.ledger = ReplicatedLedger(node_id, data_dir)

    def _prepare(self, message):
        request_id = message["request_id"]
        operation = {
            "request_id": request_id,
            "account": message["account"],
            "amount": int(message["amount"]),
        }
        status, value = self.ledger.request_status(request_id)
        if status == "new":
            index = self.ledger.next_index()
            self.ledger.record_intent(request_id, index)
        elif status == "reserved":
            index = value["index"]
        else:
            return {"state": status, "result": value}

        if index not in self.ledger.entries:
            self.ledger.append_entry(message["term"], index, operation)
        return {"state": "reserved", "index": index}

    def handle(self, message):
        action = message["action"]
        if action == "status":
            result = self.ledger.snapshot()
            result["next_index"] = self.ledger.next_index()
        elif action == "prepare":
            result = self._prepare(message)
        elif action == "append":
            result = self.ledger.append_entry(
                message["term"], message["index"], message["operation"]
            )
        elif action == "commit":
            result = {
                "applied": self.ledger.commit_through(
                    message["term"], message["index"]
                )
            }
        else:
            raise ValueError("unsupported action")
        result["node"] = self.node_id
        return result

    def serve(self):
        for line in sys.stdin:
            if not line.strip():
                continue
            try:
                response = self.handle(json.loads(line))
            except Exception as exc:
                response = {"error": type(exc).__name__, "detail": str(exc)}
            sys.stdout.write(json.dumps(response, sort_keys=True) + "\n")
            sys.stdout.flush()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--node", required=True)
    parser.add_argument("--data-dir", required=True)
    args = parser.parse_args()
    Node(args.node, args.data_dir).serve()


if __name__ == "__main__":
    main()
