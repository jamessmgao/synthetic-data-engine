# Recover replicated ledger request identity across restarts

A replica can lose the in-memory mapping for a request while retaining its durable log entry. A retry then creates a second log entry and can debit the same request twice. The fix must preserve request identity durably while retaining all existing command behavior.

## Scenario

The repository contains a Python service whose replica processes accept status, prepare, append, and commit JSON messages and persist state in a write-ahead log. Processes may be killed and restarted, and the same request may be retried after recovery.

## Root cause (hidden from the agent)

ReplicatedLedger reconstructs intents and entries on restart, but request_status only checks the in-memory intents map. An entry already durable in the WAL is therefore treated as a new request after restart, causing a duplicate index and duplicate application of the same request ID.

## Correctness constraints

- **C1**: On every node, each request ID appears at most once among the reported entry request IDs and takes effect at most once.
- **C2**: On every node, each account balance equals the sum of exactly one debit for each request ID that has taken effect on that node.
- **C3**: The existing status, prepare, append, commit, duplicate-append, completed-request retry, error-reporting, and SIGKILL-restart behavior continues to work with its current observable response and status format.

## Subgoals

1. Recover request identity from all durable records, including entries without a live intent.
2. Make prepare reuse the existing index for a durable request after restart.
3. Preserve application, snapshot, and command-response behavior for valid inputs.

## Failure scenario

A request is committed on one replica, its entry is appended on another, that second replica restarts, and the request is retried. The defective ledger treats the request as new, appends a second entry, and commits both, producing two effects and balance 20 instead of one effect and balance 10.

## Expected agent pitfalls

- Suppressing the duplicate only at apply time, which hides the wrong balance but leaves duplicate request IDs in the log.
- Using process-local request state that is itself lost on restart.
- Breaking existing completed-request responses or status fields while changing recovery.

## Anti-shortcut measures

- Tests inspect only command responses and status output, never internal ledger objects.
- Deterministic schedules include restarts, retries, duplicate appends, and concurrent requests.
- A dedicated invariant rejects duplicate request IDs even when their balance effect is suppressed.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_each_request_id_debits_at_most_once_on_any_node`, `test_counterexample_recovery_keeps_one_request_and_correct_balance` |
| C2 | `test_each_account_balance_sums_exactly_one_debit_per_request_id`, `test_counterexample_recovery_keeps_one_request_and_correct_balance` |
| C3 | `test_all_commands_restart_and_retry_keep_documented_results`, `test_each_request_id_debits_at_most_once_on_any_node`, `test_each_account_balance_sums_exactly_one_debit_per_request_id` |
