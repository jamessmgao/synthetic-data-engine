# RBAC Entitlement Service

Computes per-subject dollar entitlements from an RBAC policy.

## Usage

```python
from service import RBACService
s = RBACService('/app/policy.json')
s.get_entitlement('alice', 'budget')   # entitlement for one subject/resource
s.get_entitlements('alice')             # all entitlements for one subject
s.resource_totals()                     # total for each resource
s.audit()                               # full audit trail
```

## Entitlement Computation

Each subject's entitlement for a resource is the sum of:
- Allow grants from groups the subject belongs to (directly or through parent groups)
- Deny grants (subtracted)
- Equal-share pool grants (pool amount split equally among all members)

## Allocation and Rounding

All dollar amounts are rounded half-up to the cent (0.005 rounds to 0.01).

The per-subject entitlements for a resource must sum exactly to the reported
resource total. When individual entitlements are rounded to the cent and their
sum differs from the resource total, the residual cents are distributed to the
subjects with the largest rounding remainder; ties are broken by subject id in
lexicographic order.

The resource total for each resource is the exact cent-rounded sum of all
policy grants for that resource.
