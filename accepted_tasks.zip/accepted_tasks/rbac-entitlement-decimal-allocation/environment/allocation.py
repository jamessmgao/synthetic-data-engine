"""Outcome allocation."""

from decimal import Decimal, ROUND_HALF_UP


_CENT = Decimal("0.01")


def allocate(raw_values):
    result = {}
    for subject_id, resources in raw_values.items():
        result[subject_id] = {}
        for resource, amount in resources.items():
            value = amount if isinstance(amount, Decimal) else Decimal(str(amount))
            result[subject_id][resource] = value.quantize(
                _CENT, rounding=ROUND_HALF_UP
            )
    return result
