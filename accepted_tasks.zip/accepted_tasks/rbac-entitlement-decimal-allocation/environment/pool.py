"""Pool grant handling."""

from policy_store import PolicyStore


class PoolService:
    def __init__(self, store: PolicyStore):
        self._store = store
        self._pools = store.pool_grants()

    def pool_shares(self, subject_id: str) -> dict:
        totals: dict[str, float] = {}
        groups = self._member_groups(subject_id)
        for pool in self._pools:
            if pool["group"] in groups:
                members = self._members(pool["group"])
                if members:
                    share = float(pool["amount"]) / len(members)
                    totals[pool["resource"]] = totals.get(pool["resource"], 0.0) + share
        return totals

    def _member_groups(self, subject_id: str) -> set[str]:
        direct = self._store.subject_groups(subject_id)
        visited: set[str] = set()
        queue = list(direct)
        while queue:
            gid = queue.pop(0)
            if gid in visited:
                continue
            visited.add(gid)
            for parent in self._store.group_parents(gid):
                if parent not in visited:
                    queue.append(parent)
        return visited

    def _members(self, group_id: str) -> list[str]:
        result: list[str] = []
        for sid in self._store.subject_ids():
            if group_id in self._member_groups(sid):
                result.append(sid)
        return result
