"""Entitlement computation."""

from policy_store import PolicyStore
from pool import PoolService


class EntitlementService:
    def __init__(self, store: PolicyStore, pool_svc: PoolService):
        self._store = store
        self._pool = pool_svc

    def _effective_groups(self, subject_id: str) -> list[str]:
        direct = self._store.subject_groups(subject_id)
        visited: set[str] = set()
        result: list[str] = []
        queue = list(direct)
        while queue:
            gid = queue.pop(0)
            if gid in visited:
                continue
            visited.add(gid)
            result.append(gid)
            for parent in self._store.group_parents(gid):
                if parent not in visited:
                    queue.append(parent)
        return result

    def raw_entitlements(self, subject_id: str) -> dict:
        totals: dict[str, float] = {}
        for gid in self._effective_groups(subject_id):
            group_subtotal: dict[str, float] = {}
            for perm in self._store.permissions_for_group(gid):
                if perm.effect == "allow":
                    val = float(perm.amount)
                elif perm.effect == "deny":
                    val = -float(perm.amount)
                else:
                    continue
                group_subtotal[perm.resource] = group_subtotal.get(
                    perm.resource, 0.0
                ) + val
            for resource, subtotal in group_subtotal.items():
                totals[resource] = totals.get(resource, 0.0) + subtotal
        for resource, share in self._pool.pool_shares(subject_id).items():
            totals[resource] = totals.get(resource, 0.0) + share
        return totals

    def entitlements(self, subject_id: str) -> dict:
        return self.raw_entitlements(subject_id)

    def entitlement(self, subject_id: str, resource: str):
        return self.entitlements(subject_id).get(resource, 0.0)
