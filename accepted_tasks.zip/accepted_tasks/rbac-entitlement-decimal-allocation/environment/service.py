"""RBAC Entitlement Service."""

import json
from policy_store import PolicyStore
from pool import PoolService
from entitlement import EntitlementService
from allocation import allocate


class RBACService:
    def __init__(self, policy_path: str):
        with open(policy_path) as f:
            self._raw = json.load(f)
        self._store = PolicyStore(self._raw)
        self._pool = PoolService(self._store)
        self._entitlement = EntitlementService(self._store, self._pool)
        self._subject_ids = [
            str(s["id"]) for s in self._raw.get("subjects", [])
        ]
        raw = {
            subject_id: self._entitlement.raw_entitlements(subject_id)
            for subject_id in self._subject_ids
        }
        self._allocated = allocate(raw)

    def subject_ids(self) -> list[str]:
        return list(self._subject_ids)

    def get_entitlements(self, subject_id: str) -> dict:
        return dict(self._allocated.get(subject_id, {}))

    def get_entitlement(self, subject_id: str, resource: str):
        return self.get_entitlements(subject_id).get(resource, 0.0)

    def resource_totals(self) -> dict:
        collected: dict[str, list] = {}
        for sid in self._subject_ids:
            ents = self.get_entitlements(sid)
            for resource, amount in ents.items():
                collected.setdefault(resource, []).append(float(amount))
        totals: dict[str, float] = {}
        for resource, amounts in collected.items():
            totals[resource] = sum(amounts)
        return totals

    def audit(self) -> list[dict]:
        rows = []
        for sid in self._subject_ids:
            ents = self.get_entitlements(sid)
            for resource, amount in ents.items():
                rows.append({
                    "subject": sid,
                    "resource": resource,
                    "amount": amount,
                })
        return rows
