"""Policy loading and access."""

from dataclasses import dataclass
from typing import Any


@dataclass
class Group:
    id: str
    parents: tuple[str, ...]


@dataclass
class Permission:
    group: str
    resource: str
    amount: str
    effect: str


class PolicyStore:
    def __init__(self, policy: dict[str, Any]):
        self._groups: list[Group] = []
        for item in policy.get("groups", []):
            self._groups.append(
                Group(
                    id=str(item["id"]),
                    parents=tuple(str(p) for p in item.get("parents", [])),
                )
            )

        self._subjects: dict[str, list[str]] = {}
        for item in policy.get("subjects", []):
            self._subjects[str(item["id"])] = [str(g) for g in item.get("groups", [])]

        self._permissions_by_group: dict[str, list[Permission]] = {}
        for item in policy.get("permissions", []):
            permission = Permission(
                group=str(item["group"]),
                resource=str(item["resource"]),
                amount=str(item.get("amount", "0")),
                effect=str(item.get("effect", "allow")),
            )
            self._permissions_by_group.setdefault(permission.group, []).append(permission)

        self._pool_grants: list[dict[str, str]] = []
        for item in policy.get("pool_grants", []):
            self._pool_grants.append({
                "group": str(item["group"]),
                "resource": str(item["resource"]),
                "amount": str(item.get("amount", "0")),
                "share_type": str(item.get("share_type", "equal")),
            })

    def group_ids(self) -> list[str]:
        return [group.id for group in self._groups]

    def _find_group(self, group_id: str) -> Group | None:
        for group in self._groups:
            if group.id == group_id:
                return group
        return None

    def group_parents(self, group_id: str) -> tuple[str, ...]:
        group = self._find_group(group_id)
        if group is None:
            return ()
        return group.parents

    def subject_groups(self, subject_id: str) -> list[str]:
        return list(self._subjects.get(subject_id, []))

    def subject_ids(self) -> list[str]:
        return list(self._subjects.keys())

    def permissions_for_group(self, group_id: str) -> list[Permission]:
        return list(self._permissions_by_group.get(group_id, []))

    def pool_grants(self) -> list[dict[str, str]]:
        return list(self._pool_grants)
