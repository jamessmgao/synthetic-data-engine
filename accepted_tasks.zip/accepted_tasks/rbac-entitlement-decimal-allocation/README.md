# RBAC Entitlement Decimal Allocation

A Python RBAC service computes per-subject resource entitlements from policy grants and pool shares. Float arithmetic and independent rounding produce wrong totals and entitlements when large deny/allow offsets combine with shared pool grants.

## Scenario

The service loads a policy JSON and exposes entitlements, resource totals, and audit. Users report incorrect entitlements and totals that are off by cents.

## Root cause (hidden from the agent)

pool.py uses float for pool share division; entitlement.py uses float for grant accumulation; service.py sums entitlements with float and computes resource_totals with float. Additionally, allocation.py independently rounds each subject without largest-remainder allocation, so the sum of rounded entitlements can differ from the rounded total by residual cents.

## Correctness constraints

- **C1**: Each subject's per-resource entitlement follows the exact Decimal sum of applicable allow, deny, and equal-share pool grants, rounded half-up to the cent with residual cents allocated by largest remainder and subject-id tie break
- **C2**: Each resource total equals the exact cent-rounded Decimal sum of all policy grants for that resource
- **C3**: The sum of returned per-subject entitlements equals the returned resource total exactly, and residual cents are assigned by largest remainder with ties broken by subject id

## Subgoals

1. Convert all float arithmetic to exact rational arithmetic throughout pool.py, entitlement.py, and service.py
2. Implement largest-remainder allocation in allocation.py so that the sum of rounded entitlements equals the rounded resource total

## Failure scenario

Loading the shipped policy.json gives alice budget=0.13 (expected 0.11) and total=1000000000000000.20 (expected 1000000000000000.22) because float arithmetic drifts the pool share and independent rounding loses a residual cent.

## Expected agent pitfalls

- Converting only pool.py to Decimal but missing service.py float aggregation
- Converting everything to Decimal but independently rounding each subject, missing the largest-remainder allocation step
- Using Decimal with default 28-digit precision, which loses significant digits after large cancellations (1e15 - 1e15)

## Anti-shortcut measures

- Random policies with pool grants and large offsets ensure float-to-exact conversion is tested broadly
- Invariant 3 specifically checks the sum-of-subjects equals resource-total, catching independent rounding
- The counterexample policy has a large offset (1e15) that causes both float drift and Decimal precision loss

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_1_per_subject_entitlement` |
| C2 | `test_invariant_2_resource_total` |
| C3 | `test_invariant_3_sum_equals_total` |
