"""Helper to query the RBAC service and output results as JSON."""
import sys
import json
sys.path.insert(0, "/app")
from decimal import Decimal
from service import RBACService

def main():
    if len(sys.argv) < 2:
        print("Usage: query_service.py <policy_path>", file=sys.stderr)
        sys.exit(1)
    policy_path = sys.argv[1]
    service = RBACService(policy_path)
    entitlements = {}
    for sid in service.subject_ids():
        ents = service.get_entitlements(sid)
        entitlements[sid] = {k: str(v) for k, v in ents.items()}
    totals = service.resource_totals()
    totals_str = {k: str(v) for k, v in totals.items()}
    audit = service.audit()
    audit_str = []
    for row in audit:
        audit_str.append({k: str(v) if isinstance(v, Decimal) else v for k, v in row.items()})
    output = {
        "entitlements": entitlements,
        "resource_totals": totals_str,
        "subject_ids": service.subject_ids(),
        "audit": audit_str,
    }
    print(json.dumps(output))

if __name__ == "__main__":
    main()
