from pathlib import Path
from textwrap import dedent

pool_code = dedent('''
    # Pool grant handling.
    from decimal import Decimal
    from policy_store import PolicyStore

    class PoolService:
        def __init__(self, store: PolicyStore):
            self._store = store
            self._pools = store.pool_grants()

        def pool_shares(self, subject_id: str) -> dict[str, Decimal]:
            totals: dict[str, Decimal] = {}
            groups = self._member_groups(subject_id)
            for pool in self._pools:
                if pool["group"] in groups:
                    members = self._members(pool["group"])
                    if members:
                        share = Decimal(pool["amount"]) / len(members)
                        totals[pool["resource"]] = totals.get(
                            pool["resource"], Decimal("0")
                        ) + share
            return totals

        def _member_groups(self, subject_id: str) -> set[str]:
            direct = self._store.subject_groups(subject_id)
            visited: set[str] = set()
            queue = list(direct)
            while queue:
                gid = queue.pop(0)
                if gid in visited:
                    continue
                visited.add(gid)
                for parent in self._store.group_parents(gid):
                    if parent not in visited:
                        queue.append(parent)
            return visited

        def _members(self, group_id: str) -> list[str]:
            result: list[str] = []
            for sid in self._store.subject_ids():
                if group_id in self._member_groups(sid):
                    result.append(sid)
            return result
''').strip()

entitlement_code = dedent('''
    # Per-subject entitlement computation.
    from decimal import Decimal, ROUND_HALF_UP
    from policy_store import PolicyStore
    from pool import PoolService

    _CENT = Decimal("0.01")

    class EntitlementService:
        def __init__(self, store: PolicyStore, pool: PoolService):
            self._store = store
            self._pool = pool

        def _effective_groups(self, subject_id: str) -> list[str]:
            direct = self._store.subject_groups(subject_id)
            visited: set[str] = set()
            result: list[str] = []
            queue = list(direct)
            while queue:
                gid = queue.pop(0)
                if gid in visited:
                    continue
                visited.add(gid)
                result.append(gid)
                for parent in self._store.group_parents(gid):
                    if parent not in visited:
                        queue.append(parent)
            return result

        def raw_entitlements(self, subject_id: str) -> dict[str, Decimal]:
            totals: dict[str, Decimal] = {}
            for gid in self._effective_groups(subject_id):
                for perm in self._store.permissions_for_group(gid):
                    if perm.effect == "allow":
                        val = Decimal(perm.amount)
                    elif perm.effect == "deny":
                        val = -Decimal(perm.amount)
                    else:
                        continue
                    totals[perm.resource] = totals.get(
                        perm.resource, Decimal("0")
                    ) + val
            for resource, share in self._pool.pool_shares(subject_id).items():
                totals[resource] = totals.get(resource, Decimal("0")) + share
            return totals

        def entitlements(self, subject_id: str) -> dict[str, Decimal]:
            raw = self.raw_entitlements(subject_id)
            return {
                resource: amount.quantize(_CENT, rounding=ROUND_HALF_UP)
                for resource, amount in raw.items()
            }

        def entitlement(self, subject_id: str, resource: str) -> Decimal:
            return self.entitlements(subject_id).get(resource, Decimal("0"))
''').strip()

allocation_code = dedent('''
    # Independent per-subject cent rounding.
    from decimal import Decimal, ROUND_HALF_UP

    _CENT = Decimal("0.01")

    def allocate(raw_values):
        result = {}
        for subject_id, resources in raw_values.items():
            result[subject_id] = {}
            for resource, amount in resources.items():
                value = amount if isinstance(amount, Decimal) else Decimal(str(amount))
                result[subject_id][resource] = value.quantize(
                    _CENT, rounding=ROUND_HALF_UP
                )
        return result
''').strip()

service_code = dedent('''
    # RBAC entitlement service.
    import json
    from decimal import Decimal
    from policy_store import PolicyStore
    from pool import PoolService
    from entitlement import EntitlementService
    from allocation import allocate

    class RBACService:
        def __init__(self, policy_path: str):
            with open(policy_path) as f:
                self._raw = json.load(f, parse_float=Decimal)
            self._store = PolicyStore(self._raw)
            self._pool = PoolService(self._store)
            self._entitlement = EntitlementService(self._store, self._pool)
            self._subject_ids = [
                str(subject["id"]) for subject in self._raw.get("subjects", [])
            ]
            raw = {
                subject_id: self._entitlement.raw_entitlements(subject_id)
                for subject_id in self._subject_ids
            }
            self._allocated = allocate(raw)

        def subject_ids(self) -> list[str]:
            return list(self._subject_ids)

        def get_entitlements(self, subject_id: str) -> dict[str, Decimal]:
            return dict(self._allocated.get(subject_id, {}))

        def get_entitlement(self, subject_id: str, resource: str) -> Decimal:
            return self.get_entitlements(subject_id).get(resource, Decimal("0"))

        def resource_totals(self) -> dict[str, Decimal]:
            totals: dict[str, Decimal] = {}
            for subject_id in self._subject_ids:
                entitlements = self.get_entitlements(subject_id)
                for resource, amount in entitlements.items():
                    totals[resource] = totals.get(resource, Decimal("0")) + amount
            return totals

        def audit(self) -> list[dict]:
            rows = []
            for subject_id in self._subject_ids:
                entitlements = self.get_entitlements(subject_id)
                for resource, amount in entitlements.items():
                    rows.append({
                        "subject": subject_id,
                        "resource": resource,
                        "amount": str(amount),
                    })
            return rows
''').strip()

files = {
    "pool.py": pool_code,
    "entitlement.py": entitlement_code,
    "allocation.py": allocation_code,
    "service.py": service_code,
}
for name, code in files.items():
    Path("/app", name).write_text(code + "\n")

print("wrong fix applied")
