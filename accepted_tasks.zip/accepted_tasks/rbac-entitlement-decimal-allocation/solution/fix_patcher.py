import textwrap

pool_code = textwrap.dedent('''
    """Pool grant handling."""

    from fractions import Fraction
    from policy_store import PolicyStore


    class PoolService:
        def __init__(self, store: PolicyStore):
            self._store = store
            self._pools = store.pool_grants()

        def pool_shares(self, subject_id: str) -> dict[str, Fraction]:
            totals: dict[str, Fraction] = {}
            groups = self._member_groups(subject_id)
            for pool in self._pools:
                if pool["group"] in groups:
                    members = self._members(pool["group"])
                    if members:
                        share = Fraction(pool["amount"]) / len(members)
                        totals[pool["resource"]] = totals.get(pool["resource"], Fraction(0)) + share
            return totals

        def _member_groups(self, subject_id: str) -> set[str]:
            direct = self._store.subject_groups(subject_id)
            visited: set[str] = set()
            queue = list(direct)
            while queue:
                gid = queue.pop(0)
                if gid in visited:
                    continue
                visited.add(gid)
                for parent in self._store.group_parents(gid):
                    if parent not in visited:
                        queue.append(parent)
            return visited

        def _members(self, group_id: str) -> list[str]:
            result: list[str] = []
            for sid in self._store.subject_ids():
                if group_id in self._member_groups(sid):
                    result.append(sid)
            return result
''').strip()

entitlement_code = textwrap.dedent('''
    """Per-subject entitlement computation."""

    from fractions import Fraction
    from decimal import Decimal, ROUND_HALF_UP
    from policy_store import PolicyStore
    from pool import PoolService


    _CENT = Decimal("0.01")


    def _to_cents_frac(value: Fraction) -> Decimal:
        d = Decimal(value.numerator) / Decimal(value.denominator)
        return d.quantize(_CENT, rounding=ROUND_HALF_UP)


    class EntitlementService:
        def __init__(self, store: PolicyStore, pool: PoolService):
            self._store = store
            self._pool = pool

        def _effective_groups(self, subject_id: str) -> list[str]:
            direct = self._store.subject_groups(subject_id)
            visited: set[str] = set()
            result: list[str] = []
            queue = list(direct)
            while queue:
                gid = queue.pop(0)
                if gid in visited:
                    continue
                visited.add(gid)
                result.append(gid)
                for parent in self._store.group_parents(gid):
                    if parent not in visited:
                        queue.append(parent)
            return result

        def raw_entitlements(self, subject_id: str) -> dict[str, Fraction]:
            totals: dict[str, Fraction] = {}
            for gid in self._effective_groups(subject_id):
                for perm in self._store.permissions_for_group(gid):
                    if perm.effect == "allow":
                        val = Fraction(perm.amount)
                    elif perm.effect == "deny":
                        val = -Fraction(perm.amount)
                    else:
                        continue
                    totals[perm.resource] = totals.get(perm.resource, Fraction(0)) + val
            for resource, share in self._pool.pool_shares(subject_id).items():
                totals[resource] = totals.get(resource, Fraction(0)) + share
            return totals

        def entitlements(self, subject_id: str) -> dict[str, Decimal]:
            return {k: _to_cents_frac(v) for k, v in self.raw_entitlements(subject_id).items()}

        def entitlement(self, subject_id: str, resource: str) -> Decimal:
            return self.entitlements(subject_id).get(resource, Decimal("0"))
''').strip()

allocation_code = textwrap.dedent('''
    """Outcome allocation."""

    from fractions import Fraction
    from decimal import Decimal, ROUND_HALF_UP


    _CENT = Decimal("0.01")


    def _to_cents_frac(value: Fraction) -> Decimal:
        d = Decimal(value.numerator) / Decimal(value.denominator)
        return d.quantize(_CENT, rounding=ROUND_HALF_UP)


    def allocate(raw_values):
        subject_ids = list(raw_values.keys())
        result = {sid: {} for sid in subject_ids}

        resources = set()
        for sid in subject_ids:
            resources.update(raw_values[sid].keys())

        for resource in sorted(resources):
            raw_total = sum(
                raw_values[sid].get(resource, Fraction(0)) for sid in subject_ids
            )
            target = _to_cents_frac(raw_total)

            rounded = {}
            remainders = {}
            for sid in subject_ids:
                raw_val = raw_values[sid].get(resource, Fraction(0))
                if not isinstance(raw_val, Fraction):
                    raw_val = Fraction(str(raw_val))
                r = _to_cents_frac(raw_val)
                rounded[sid] = r
                remainders[sid] = raw_val - Fraction(str(r))

            rounded_sum = sum(rounded[sid] for sid in subject_ids)
            residual = target - rounded_sum

            if residual == Decimal("0"):
                for sid in subject_ids:
                    result[sid][resource] = rounded[sid]
            else:
                residual_cents = int(residual / _CENT)
                if residual_cents > 0:
                    sorted_sids = sorted(subject_ids, key=lambda s: (-remainders[s], s))
                else:
                    sorted_sids = sorted(subject_ids, key=lambda s: (remainders[s], s))
                count = abs(residual_cents)
                for sid in sorted_sids:
                    if count > 0:
                        result[sid][resource] = rounded[sid] + (residual_cents // abs(residual_cents)) * _CENT
                        count -= 1
                    else:
                        result[sid][resource] = rounded[sid]

        return result
''').strip()

service_code = textwrap.dedent('''
    """RBAC Entitlement Service."""

    import json
    from decimal import Decimal
    from policy_store import PolicyStore
    from pool import PoolService
    from entitlement import EntitlementService
    from allocation import allocate


    class RBACService:
        def __init__(self, policy_path: str):
            with open(policy_path) as f:
                self._raw = json.load(f)
            self._store = PolicyStore(self._raw)
            self._pool = PoolService(self._store)
            self._entitlement = EntitlementService(self._store, self._pool)
            self._subject_ids = [
                str(s["id"]) for s in self._raw.get("subjects", [])
            ]
            raw = {
                subject_id: self._entitlement.raw_entitlements(subject_id)
                for subject_id in self._subject_ids
            }
            self._allocated = allocate(raw)

        def subject_ids(self) -> list[str]:
            return list(self._subject_ids)

        def get_entitlements(self, subject_id: str) -> dict[str, Decimal]:
            return dict(self._allocated.get(subject_id, {}))

        def get_entitlement(self, subject_id: str, resource: str) -> Decimal:
            return self.get_entitlements(subject_id).get(resource, Decimal("0"))

        def resource_totals(self) -> dict[str, Decimal]:
            totals: dict[str, Decimal] = {}
            for sid in self._subject_ids:
                ents = self.get_entitlements(sid)
                for resource, amount in ents.items():
                    totals[resource] = totals.get(resource, Decimal("0")) + amount
            return {k: v for k, v in totals.items()}

        def audit(self) -> list[dict]:
            rows = []
            for sid in self._subject_ids:
                ents = self.get_entitlements(sid)
                for resource, amount in ents.items():
                    rows.append({
                        "subject": sid,
                        "resource": resource,
                        "amount": str(amount),
                    })
            return rows
''').strip()

with open('/app/pool.py', 'w') as f:
    f.write(pool_code + '\n')
with open('/app/entitlement.py', 'w') as f:
    f.write(entitlement_code + '\n')
with open('/app/allocation.py', 'w') as f:
    f.write(allocation_code + '\n')
with open('/app/service.py', 'w') as f:
    f.write(service_code + '\n')

print('fix applied')
