package main

import (
"flag"
"log"
"net/http"
"strings"

"replicatedledger/internal/node"
)

func main() {
var id, addr, data string
var term int
var leader bool
flag.StringVar(&id, "id", "", "node ID")
flag.StringVar(&addr, "listen", "", "listen address")
flag.StringVar(&data, "data", "", "log path")
flag.IntVar(&term, "term", 1, "configuration term")
flag.BoolVar(&leader, "leader", false, "act as leader in this term")
peers := peerList{}
flag.Var(&peers, "peer", "peer as id=address")
flag.Parse()
if id == "" || addr == "" || data == "" {
log.Fatal("id, listen, and data are required")
}
n, err := node.New(node.Config{ID: id, Addr: addr, Data: data, Term: term, Leader: leader, Peers: peers})
if err != nil {
log.Fatal(err)
}
log.Printf("%s listening on %s", id, addr)
log.Fatal(http.ListenAndServe(addr, n.Handler()))
}

type peerList map[string]string

func (p peerList) String() string {
var parts []string
for k, v := range p {
parts = append(parts, k+"="+v)
}
return strings.Join(parts, ",")
}

func (p peerList) Set(value string) error {
id, addr, ok := strings.Cut(value, "=")
if !ok || id == "" || addr == "" {
return http.ErrAbortHandler
}
p[id] = addr
return nil
}
