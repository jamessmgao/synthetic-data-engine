package node

import (
"bytes"
"encoding/json"
"fmt"
"net/http"
"sort"
"sync"
"time"

"replicatedledger/internal/store"
)

type Config struct {
ID     string
Addr   string
Data   string
Term   int
Leader bool
Peers  map[string]string
}

type Node struct {
mu     sync.Mutex
cfg    Config
log    *store.Log
client *http.Client
}

type RecordSummary struct {
Index     int    `json:"index"`
Term      int    `json:"term"`
RequestID string `json:"request_id"`
Amount    int    `json:"amount"`
}

func New(cfg Config) (*Node, error) {
lg, err := store.Open(cfg.Data)
if err != nil {
return nil, err
}
return &Node{cfg: cfg, log: lg, client: &http.Client{Timeout: 200 * time.Millisecond}}, nil
}

func (n *Node) Handler() http.Handler {
mux := http.NewServeMux()
mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
writeJSON(w, map[string]string{"status": "ready"})
})
mux.HandleFunc("/write", n.handleWrite)
mux.HandleFunc("/replicate", n.handleReplicate)
mux.HandleFunc("/commit", n.handleCommit)
mux.HandleFunc("/settle", n.handleSettle)
mux.HandleFunc("/recover", n.handleRecover)
mux.HandleFunc("/records", n.handleRecords)
mux.HandleFunc("/balance", n.handleBalance)
return mux
}

func (n *Node) handleWrite(w http.ResponseWriter, r *http.Request) {
n.mu.Lock()
defer n.mu.Unlock()
if !n.cfg.Leader {
writeJSONStatus(w, http.StatusPreconditionFailed, map[string]any{"ok": false, "leader": n.cfg.ID})
return
}
var req struct {
RequestID string `json:"request_id"`
Amount    int    `json:"amount"`
}
if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.RequestID == "" {
writeJSONStatus(w, http.StatusBadRequest, map[string]any{"ok": false, "error": "invalid request"})
return
}
for _, rec := range n.log.Records() {
if rec.RequestID == req.RequestID {
writeJSON(w, map[string]any{
"ok": true, "duplicate": true, "index": rec.Index,
"balance": n.log.Balance(), "leader": n.cfg.ID,
})
return
}
}
idx := n.log.NextIndex()
rec := store.Record{Index: idx, Term: n.cfg.Term, RequestID: req.RequestID, Amount: req.Amount}
if _, err := n.log.Append(rec); err != nil {
writeJSONStatus(w, http.StatusInternalServerError, map[string]any{"ok": false, "error": err.Error()})
return
}
acked := 0
for _, id := range n.peerIDs() {
var resp struct{ OK bool }
if err := n.postJSON(n.cfg.Peers[id]+"/replicate", map[string]any{
"record": rec, "leader_term": n.cfg.Term,
}, &resp); err == nil && resp.OK {
acked++
}
}
if acked == 0 {
writeJSONStatus(w, http.StatusServiceUnavailable, map[string]any{"ok": false, "error": "no quorum"})
return
}
if err := n.log.MarkThrough(idx); err != nil {
writeJSONStatus(w, http.StatusInternalServerError, map[string]any{"ok": false, "error": err.Error()})
return
}
for _, id := range n.peerIDs() {
var resp struct{ OK bool }
n.postJSON(n.cfg.Peers[id]+"/commit", map[string]any{"index": idx}, &resp)
}
writeJSON(w, map[string]any{
"ok": true, "duplicate": false, "index": idx,
"balance": n.log.Balance(), "leader": n.cfg.ID,
})
}

func (n *Node) handleReplicate(w http.ResponseWriter, r *http.Request) {
n.mu.Lock()
defer n.mu.Unlock()
var req struct {
Record     store.Record `json:"record"`
LeaderTerm int         `json:"leader_term"`
}
if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
writeJSONStatus(w, http.StatusBadRequest, map[string]any{"ok": false})
return
}
if req.LeaderTerm < n.cfg.Term {
writeJSONStatus(w, http.StatusConflict, map[string]any{"ok": false})
return
}
if req.LeaderTerm > n.cfg.Term {
n.cfg.Term = req.LeaderTerm
}
if _, err := n.log.Append(req.Record); err != nil {
writeJSONStatus(w, http.StatusConflict, map[string]any{"ok": false, "error": err.Error()})
return
}
writeJSON(w, map[string]any{"ok": true})
}

func (n *Node) handleCommit(w http.ResponseWriter, r *http.Request) {
n.mu.Lock()
defer n.mu.Unlock()
var req struct{ Index int }
if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
writeJSONStatus(w, http.StatusBadRequest, map[string]any{"ok": false})
return
}
if err := n.log.MarkThrough(req.Index); err != nil {
writeJSONStatus(w, http.StatusInternalServerError, map[string]any{"ok": false})
return
}
writeJSON(w, map[string]any{"ok": true})
}

func (n *Node) handleSettle(w http.ResponseWriter, r *http.Request) {
n.mu.Lock()
defer n.mu.Unlock()
if !n.cfg.Leader {
writeJSONStatus(w, http.StatusPreconditionFailed, map[string]any{"ok": false})
return
}
last := n.log.NextIndex() - 1
for _, id := range n.peerIDs() {
var resp struct{ OK bool }
n.postJSON(n.cfg.Peers[id]+"/commit", map[string]any{"index": last}, &resp)
}
writeJSON(w, map[string]any{"ok": true, "index": last})
}

func (n *Node) handleRecover(w http.ResponseWriter, r *http.Request) {
n.mu.Lock()
defer n.mu.Unlock()
if !n.cfg.Leader {
writeJSONStatus(w, http.StatusPreconditionFailed, map[string]any{"ok": false})
return
}
for _, id := range n.peerIDs() {
var resp struct{ Records []store.Record }
if err := n.getJSON(n.cfg.Peers[id]+"/records", &resp); err != nil {
continue
}
for _, rec := range resp.Records {
n.log.Append(rec)
}
}
writeJSON(w, map[string]any{"ok": true, "balance": n.log.Balance()})
}

func (n *Node) handleRecords(w http.ResponseWriter, r *http.Request) {
n.mu.Lock()
defer n.mu.Unlock()
recs := n.log.Records()
summaries := make([]RecordSummary, len(recs))
for i, rec := range recs {
summaries[i] = RecordSummary{
Index: rec.Index, Term: rec.Term,
RequestID: rec.RequestID, Amount: rec.Amount,
}
}
writeJSON(w, map[string]any{"records": summaries, "balance": n.log.Balance()})
}

func (n *Node) handleBalance(w http.ResponseWriter, r *http.Request) {
n.mu.Lock()
defer n.mu.Unlock()
writeJSON(w, map[string]any{"balance": n.log.Balance()})
}

func (n *Node) peerIDs() []string {
ids := make([]string, 0, len(n.cfg.Peers))
for id := range n.cfg.Peers {
ids = append(ids, id)
}
sort.Strings(ids)
return ids
}

func (n *Node) postJSON(url string, body any, out any) error {
data, err := json.Marshal(body)
if err != nil {
return err
}
resp, err := n.client.Post(url, "application/json", bytes.NewReader(data))
if err != nil {
return err
}
defer resp.Body.Close()
if resp.StatusCode < 200 || resp.StatusCode >= 300 {
return fmt.Errorf("peer returned %s", resp.Status)
}
return json.NewDecoder(resp.Body).Decode(out)
}

func (n *Node) getJSON(url string, out any) error {
resp, err := n.client.Get(url)
if err != nil {
return err
}
defer resp.Body.Close()
if resp.StatusCode < 200 || resp.StatusCode >= 300 {
return fmt.Errorf("peer returned %s", resp.Status)
}
return json.NewDecoder(resp.Body).Decode(out)
}

func writeJSON(w http.ResponseWriter, value any) {
w.Header().Set("Content-Type", "application/json")
_ = json.NewEncoder(w).Encode(value)
}

func writeJSONStatus(w http.ResponseWriter, status int, value any) {
w.WriteHeader(status)
writeJSON(w, value)
}
