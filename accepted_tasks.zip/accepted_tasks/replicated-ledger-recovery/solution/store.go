package store

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"sync"
)

type Record struct {
	Index     int    `json:"index"`
	Term      int    `json:"term"`
	RequestID string `json:"request_id"`
	Amount    int    `json:"amount"`
	Committed bool   `json:"committed"`
}

type Log struct {
	mu      sync.RWMutex
	path    string
	records []Record
}

func Open(path string) (*Log, error) {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return nil, err
	}
	data, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		return &Log{path: path}, nil
	}
	if err != nil {
		return nil, err
	}
	if len(data) == 0 {
		return &Log{path: path}, nil
	}
	var records []Record
	if err := json.Unmarshal(data, &records); err != nil {
		return nil, err
	}
	sort.Slice(records, func(i, j int) bool { return records[i].Index < records[j].Index })
	return &Log{path: path, records: records}, nil
}

func (l *Log) saveLocked() error {
	data, err := json.MarshalIndent(l.records, "", "  ")
	if err != nil {
		return err
	}
	tmp := l.path + ".tmp"
	if err := os.WriteFile(tmp, data, 0o644); err != nil {
		return err
	}
	if err := os.Rename(tmp, l.path); err != nil {
		return err
	}
	return nil
}

func sameValue(a, b Record) bool {
	return a.Index == b.Index && a.Term == b.Term && a.RequestID == b.RequestID && a.Amount == b.Amount
}

func (l *Log) Append(record Record) (bool, error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	for _, old := range l.records {
		if old.Index == record.Index {
			if sameValue(old, record) {
				return false, nil
			}
			return false, fmt.Errorf("log index %d conflicts", record.Index)
		}
	}
	l.records = append(l.records, record)
	if err := l.saveLocked(); err != nil {
		l.records = l.records[:len(l.records)-1]
		return false, err
	}
	return true, nil
}

func (l *Log) Records() []Record {
	l.mu.RLock()
	defer l.mu.RUnlock()
	out := make([]Record, len(l.records))
	copy(out, l.records)
	return out
}

func (l *Log) NextIndex() int {
	l.mu.RLock()
	defer l.mu.RUnlock()
	if len(l.records) == 0 {
		return 1
	}
	return l.records[len(l.records)-1].Index + 1
}

func (l *Log) MarkThrough(index int) error {
	l.mu.Lock()
	defer l.mu.Unlock()
	for i := range l.records {
		if l.records[i].Index <= index {
			l.records[i].Committed = true
		}
	}
	return l.saveLocked()
}

func (l *Log) CommittedIndexes() []int {
	l.mu.RLock()
	defer l.mu.RUnlock()
	var indexes []int
	for _, record := range l.records {
		if record.Committed {
			indexes = append(indexes, record.Index)
		}
	}
	return indexes
}

func (l *Log) MarkIndexes(indexes []int) error {
	if len(indexes) == 0 {
		return nil
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	wanted := make(map[int]bool, len(indexes))
	for _, index := range indexes {
		wanted[index] = true
	}
	changed := false
	for i := range l.records {
		if wanted[l.records[i].Index] && !l.records[i].Committed {
			l.records[i].Committed = true
			changed = true
		}
	}
	if !changed {
		return nil
	}
	return l.saveLocked()
}

func (l *Log) Balance() int {
	l.mu.RLock()
	defer l.mu.RUnlock()
	seen := make(map[string]bool)
	balance := 0
	for _, record := range l.records {
		if !record.Committed || seen[record.RequestID] {
			continue
		}
		seen[record.RequestID] = true
		balance += record.Amount
	}
	return balance
}

func (l *Log) Committed() []Record {
	l.mu.RLock()
	defer l.mu.RUnlock()
	var out []Record
	seen := make(map[string]bool)
	for _, record := range l.records {
		if record.Committed && !seen[record.RequestID] {
			seen[record.RequestID] = true
			out = append(out, record)
		}
	}
	return out
}
