# Replicated ledger recovery loses committed entries

A replicated ledger service loses committed entries after failover recovery because /records omits the Committed field, so handleRecover imports all records as uncommitted.

## Scenario

A Go replicated ledger service with leader/follower replication, crash recovery via /recover, and a /balance endpoint. The /records endpoint returns RecordSummary without a Committed field, so recovered records lose their committed status.

## Root cause (hidden from the agent)

handleRecords returns RecordSummary (no Committed field) and handleRecover appends imported records without restoring committed status, so previously committed entries become uncommitted after recovery.

## Correctness constraints

- **C1**: Each request ID contributes its amount at most once to the committed balance; uncommitted entries must not inflate the balance.
- **C2**: After failover and recovery, all previously committed entries remain committed.

## Subgoals

1. Preserve committed status across the /records endpoint
2. Restore committed status during /recover from peer metadata
3. Ensure uncommitted replicated entries are not marked committed during recovery

## Failure scenario

After writing r1(+7) and r2(+5) on leader a (r2 replicated only to c after b is killed), injecting uncommitted r3 on c, killing a, and recovering on new leader b from c, balance=7 instead of 12 because r2 lost its committed status and r3 was never committed.

## Expected agent pitfalls

- Marking all imported records as committed (breaks invariant C1: uncommitted entries counted)
- Adding Committed to RecordSummary but not updating handleRecover to use it
- Fixing /records but forgetting to handle the transition for existing persisted data

## Anti-shortcut measures

- Invariant tests inject uncommitted entries via /replicate and verify they never appear in balance
- Counterexample test replays the exact failure scenario
- Multi-restart regression test verifies committed amounts survive multiple crash-recovery cycles

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_at_most_once_per_request_id`, `test_counterexample_recovery` |
| C2 | `test_committed_entries_survive_failover_and_recovery`, `test_counterexample_recovery` |
