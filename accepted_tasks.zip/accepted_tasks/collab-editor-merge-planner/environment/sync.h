#ifndef SYNC_H
#define SYNC_H

#define MAX_OPS 20
#define MAX_PEERS 6
#define MAX_TEXT 1024
#define MAX_ARG 64

typedef enum {
    OP_INSERT = 0,
    OP_DELETE = 1
} OpKind;

typedef struct {
    int id;
    int peer;
    OpKind kind;
    int pos;
    char arg[MAX_ARG];
    int latency;
    int set_cd;
    int weight;
    int deadline;
} Operation;

typedef struct {
    char text[MAX_TEXT];
    int cooldown;
    int budget;
    int wait_penalty;
    Operation ops[MAX_OPS];
    int op_count;
} Scenario;

typedef struct {
    int cost;
    int budget_used;
    int max_lag;
    int steps;
    int order[MAX_OPS];
    int waits[MAX_OPS + 1];
} Plan;

void editor_apply(char *text, const Operation *op);
int editor_valid(const char *text, const Operation *op);
int editor_transform(const Operation *earlier, const Operation *later, int pos);
Plan *plan_merge(const Scenario *scenario);
void verify_plan(const Scenario *scenario, Plan *plan);
void report_plan(const Scenario *scenario, const Plan *plan);
int find_op_by_id(const Scenario *scenario, int id);

#endif
