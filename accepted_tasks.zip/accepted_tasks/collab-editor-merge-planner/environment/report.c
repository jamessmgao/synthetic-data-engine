#include <stdio.h>
#include <string.h>
#include "sync.h"

int find_op_by_id(const Scenario *scenario, int id) {
    for (int i = 0; i < scenario->op_count; i++) {
        if (scenario->ops[i].id == id) return i;
    }
    return -1;
}

void verify_plan(const Scenario *scenario, Plan *p) {
    int time = 0;
    int peer_avail[MAX_PEERS];
    memset(peer_avail, 0, sizeof(peer_avail));
    int max_lag = 0;

    for (int i = 0; i < p->steps; i++) {
        const Operation *op = &scenario->ops[i];
        int peer = op->peer - 1;
        int ready = time;
        if (op->latency > ready) ready = op->latency;
        if (peer_avail[peer] > ready) ready = peer_avail[peer];

        int lag = ready - op->latency;
        if (lag > max_lag) max_lag = lag;

        time = ready;
        peer_avail[peer] = ready + scenario->cooldown + op->set_cd;
    }
    p->max_lag = max_lag;
}

void report_plan(const Scenario *scenario, const Plan *p) {
    (void)scenario;
    printf("plan cost %d\n", p->cost);
    printf("budget_used %d\n", p->budget_used);
    printf("max_lag %d\n", p->max_lag);
    printf("steps %d\n", p->steps);
    printf("order");
    for (int i = 0; i < p->steps; i++) printf(" %d", p->order[i]);
    printf("\n");
    printf("waits");
    for (int i = 0; i <= p->steps; i++) printf(" %d", p->waits[i]);
    printf("\n");
}
