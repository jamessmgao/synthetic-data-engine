#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "sync.h"

typedef struct {
    int cost;
    int time;
    int budget;
    int peer_avail[MAX_PEERS];
    int steps;
    int order[MAX_OPS];
} State;

typedef struct {
    State **items;
    int count;
    int cap;
} StateList;

static int op_count;
static Scenario scenario;

static int apply_op(const State *cur, int idx, State *next) {
    const Operation *op = &scenario.ops[idx];

    if (op->peer < 1 || op->peer > MAX_PEERS) return 0;

    int peer = op->peer - 1;
    int ready = cur->time;
    if (op->latency > ready) ready = op->latency;
    int queued = cur->peer_avail[peer] > ready;
    if (queued) ready = cur->peer_avail[peer];
    if (ready > op->deadline) return 0;

    int charge = queued ? op->weight : 0;
    if (scenario.budget > 0 && cur->budget + charge > scenario.budget) return 0;

    int wait = ready - cur->time;
    if (wait < 0) wait = 0;

    *next = *cur;
    next->time = ready;
    next->cost = cur->cost + wait * scenario.wait_penalty;
    next->budget = cur->budget + charge;
    next->peer_avail[peer] = ready + scenario.cooldown + op->set_cd;
    next->order[cur->steps] = op->id;
    next->steps = cur->steps + 1;
    return 1;
}

static int state_dominates(const State *a, const State *b) {
    return a->cost <= b->cost &&
           a->budget <= b->budget &&
           (a->cost < b->cost || a->budget < b->budget);
}

static int list_push(StateList *list, const State *state) {
    for (int i = 0; i < list->count; i++) {
        if (state_dominates(list->items[i], state)) return 0;
    }

    int kept = 0;
    for (int i = 0; i < list->count; i++) {
        if (state_dominates(state, list->items[i])) {
            free(list->items[i]);
        } else {
            list->items[kept++] = list->items[i];
        }
    }
    list->count = kept;

    if (list->count == list->cap) {
        int cap = list->cap ? list->cap * 2 : 8;
        State **items = realloc(list->items, (size_t)cap * sizeof(State *));
        if (!items) return 0;
        list->items = items;
        list->cap = cap;
    }

    State *copy = malloc(sizeof(State));
    if (!copy) return 0;
    *copy = *state;
    list->items[list->count++] = copy;
    return 1;
}

static void free_table(StateList *table, int masks) {
    for (int i = 0; i < masks; i++) {
        for (int j = 0; j < table[i].count; j++) free(table[i].items[j]);
        free(table[i].items);
    }
    free(table);
}

static int better_state(const State *a, const State *b) {
    if (a->cost != b->cost) return a->cost < b->cost;
    for (int i = 0; i < a->steps; i++) {
        if (a->order[i] != b->order[i]) return a->order[i] < b->order[i];
    }
    return 0;
}

static Plan *make_plan(const State *state) {
    Plan *p = malloc(sizeof(Plan));
    if (!p) return NULL;
    p->cost = state->cost;
    p->budget_used = state->budget;
    p->steps = state->steps;
    memcpy(p->order, state->order, sizeof(int) * (size_t)state->steps);

    int time = 0;
    int peer_avail[MAX_PEERS] = {0};
    for (int i = 0; i < state->steps; i++) {
        int idx = find_op_by_id(&scenario, state->order[i]);
        const Operation *op = &scenario.ops[idx];
        int peer = op->peer - 1;
        int ready = time;
        if (op->latency > ready) ready = op->latency;
        if (peer_avail[peer] > ready) ready = peer_avail[peer];
        p->waits[i] = ready - time;
        time = ready;
        peer_avail[peer] = ready + scenario.cooldown + op->set_cd;
    }
    p->waits[state->steps] = time;
    return p;
}

Plan *plan_merge(const Scenario *s) {
    scenario = *s;
    op_count = s->op_count;

    if (op_count <= 0) {
        Plan *p = calloc(1, sizeof(Plan));
        return p;
    }

    int full_mask = (1 << op_count) - 1;
    int masks = full_mask + 1;
    StateList *table = calloc((size_t)masks, sizeof(StateList));
    if (!table) return NULL;

    State start;
    memset(&start, 0, sizeof(start));
    if (!list_push(&table[0], &start)) {
        free_table(table, masks);
        return NULL;
    }

    for (int mask = 0; mask <= full_mask; mask++) {
        for (int i = 0; i < table[mask].count; i++) {
            State *cur = table[mask].items[i];
            for (int idx = 0; idx < op_count; idx++) {
                if (mask & (1 << idx)) continue;
                State next;
                if (apply_op(cur, idx, &next)) {
                    list_push(&table[mask | (1 << idx)], &next);
                }
            }
        }
    }

    State *best = NULL;
    for (int i = 0; i < table[full_mask].count; i++) {
        State *st = table[full_mask].items[i];
        if (!best || better_state(st, best)) best = st;
    }

    Plan *plan = best ? make_plan(best) : NULL;
    free_table(table, masks);
    return plan;
}
