#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sync.h"

static int parse_setting(char *line, Scenario *s) {
    int value;
    if (sscanf(line, "document %1023[^\n]", s->text) == 1) return 1;
    if (sscanf(line, "cooldown %d", &s->cooldown) == 1) return 1;
    if (sscanf(line, "budget %d", &s->budget) == 1) return 1;
    if (sscanf(line, "wait_penalty %d", &s->wait_penalty) == 1) return 1;
    if (sscanf(line, "ops %d", &value) == 1) {
        if (value < 0 || value > MAX_OPS) return 0;
        s->op_count = value;
        return 1;
    }
    return 0;
}

static int parse_operation(char *line, Operation *op) {
    char kind[16];
    int fields = sscanf(line, "%d %d %15s %d %63s %d %d %d %d",
                        &op->id, &op->peer, kind, &op->pos, op->arg,
                        &op->latency, &op->set_cd, &op->weight, &op->deadline);
    if (fields != 9) return 0;
    if (strcmp(kind, "insert") == 0) op->kind = OP_INSERT;
    else if (strcmp(kind, "delete") == 0) op->kind = OP_DELETE;
    else return 0;
    return 1;
}

static int read_scenario(Scenario *s) {
    char line[4096];
    int seen = 0;

    memset(s, 0, sizeof(*s));
    while (fgets(line, sizeof(line), stdin)) {
        line[strcspn(line, "\r\n")] = 0;
        if (line[0] == 0 || line[0] == '#') continue;
        if (seen < s->op_count) {
            if (!parse_operation(line, &s->ops[seen])) {
                fprintf(stderr, "invalid operation: %s\n", line);
                return 0;
            }
            seen++;
            continue;
        }
        if (!parse_setting(line, s)) {
            fprintf(stderr, "invalid input: %s\n", line);
            return 0;
        }
        if (s->op_count > 0) seen = 0;
    }
    if (seen != s->op_count) {
        fprintf(stderr, "missing operations\n");
        return 0;
    }
    return 1;
}

int main(void) {
    Scenario scenario;
    if (!read_scenario(&scenario)) return 1;

    Plan *plan = plan_merge(&scenario);
    if (!plan) {
        fprintf(stderr, "no plan\n");
        return 1;
    }
    verify_plan(&scenario, plan);
    report_plan(&scenario, plan);
    free(plan);
    return 0;
}
