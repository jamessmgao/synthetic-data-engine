#include <string.h>
#include "sync.h"

static int text_length(const char *text) {
    int length = 0;
    while (text[length] != 0 && length < MAX_TEXT) length++;
    return length;
}

static int argument_length(const char *argument) {
    int length = 0;
    while (argument[length] != 0 && length < MAX_ARG) length++;
    return length;
}

int editor_valid(const char *text, const Operation *op) {
    int length = text_length(text);
    int arg_length = argument_length(op->arg);

    if (op->kind == OP_INSERT) {
        if (arg_length == 0) return 0;
        if (op->pos < 0 || op->pos > length) return 0;
        if (length + arg_length >= MAX_TEXT) return 0;
        return 1;
    }
    if (op->kind != OP_DELETE) return 0;
    if (arg_length == 0) return 0;
    if (op->pos < 0 || op->pos + arg_length > length) return 0;
    return strncmp(text + op->pos, op->arg, (size_t)arg_length) == 0;
}

void editor_apply(char *text, const Operation *op) {
    int length = text_length(text);
    int arg_length = argument_length(op->arg);

    if (!editor_valid(text, op)) return;
    if (op->kind == OP_INSERT) {
        memmove(text + op->pos + arg_length, text + op->pos,
                (size_t)(length - op->pos + 1));
        memcpy(text + op->pos, op->arg, (size_t)arg_length);
        return;
    }
    memmove(text + op->pos, text + op->pos + arg_length,
            (size_t)(length - op->pos - arg_length + 1));
}

int editor_transform(const Operation *earlier, const Operation *later, int pos) {
    if (earlier->kind == OP_INSERT) {
        if (pos > earlier->pos) return pos + 1;
        if (pos == earlier->pos && earlier->peer < later->peer) return pos + 1;
        return pos;
    }
    if (earlier->kind != OP_DELETE) return pos;
    if (pos > earlier->pos) return pos - 1;
    return pos;
}
