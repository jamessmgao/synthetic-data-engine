# Fix unsound dominance pruning and misaligned verification in syncplan

The syncplan planner uses dominance pruning that ignores time and peer availability, producing suboptimal plans. The verification step also computes max_lag against the wrong operation order.

## Scenario

A collaborative editor sync planner reads scenario descriptions from stdin and reports the optimal merge plan, but currently reports incorrect costs and max_lag values.

## Root cause (hidden from the agent)

state_dominates in planner.c compares only cost and budget, ignoring time and peer_avail, which allows pruning states that would lead to better solutions. verify_plan in report.c iterates by index i instead of looking up operations by the plan order, computing max_lag against the input order rather than the planned execution order.

## Correctness constraints

- **C1**: plan_merge returns a merge order with the minimum total wait cost over all orders that respect peer cooldowns, operation deadlines, and rebase budget.
- **C2**: No operation in the returned plan is scheduled after its deadline.
- **C3**: The reported plan cost equals the total wait cost of the returned order.
- **C4**: The reported max_lag equals the maximum difference between scheduled ready time and operation latency across all operations in the plan.

## Subgoals

1. Fix state_dominates to include time and peer_avail
2. Fix verify_plan to use plan order instead of input order

## Failure scenario

Running syncplan on a 3-operation scenario reports cost 15 instead of 12, and on a 5-operation scenario reports max_lag 17 instead of 7 after a partial fix.

## Expected agent pitfalls

- Fixing only the dominance pruning without fixing verify_plan
- Assuming verify_plan is correct because it passes the simpler scenario

## Anti-shortcut measures

- Property-based tests with independent oracles verify all four invariants over many random scenarios; the max_lag test specifically checks against the planned order, catching a single-file fix.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_min_cost`, `test_counterexample` |
| C2 | `test_no_missed_deadlines`, `test_counterexample` |
| C3 | `test_cost_equals_wait_cost`, `test_counterexample` |
| C4 | `test_max_lag_correct`, `test_counterexample` |
