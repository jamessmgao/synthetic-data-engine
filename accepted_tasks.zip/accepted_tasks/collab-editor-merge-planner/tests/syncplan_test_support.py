import itertools
import random
import subprocess
import time
from collections import Counter

APP = "/app/syncplan"
MAX_PEERS = 6


def simulate_order(scenario, order):
    """Independently simulate one complete merge order."""
    by_id = {op["id"]: op for op in scenario["ops"]}
    peer_avail = [0] * MAX_PEERS
    current = 0
    cost = 0
    budget_used = 0
    max_lag = 0
    deadline_ok = True
    budget_ok = True
    ready_times = []

    for op_id in order:
        op = by_id[op_id]
        peer = op["peer"] - 1
        base_ready = max(current, op["latency"])
        queued = peer_avail[peer] > base_ready
        ready = max(base_ready, peer_avail[peer])
        ready_times.append(ready)

        if ready > op["deadline"]:
            deadline_ok = False
        charge = op["weight"] if queued else 0
        if scenario["budget"] > 0 and budget_used + charge > scenario["budget"]:
            budget_ok = False

        wait = max(0, ready - current)
        cost += wait * scenario["wait_penalty"]
        budget_used += charge
        max_lag = max(max_lag, ready - op["latency"])
        current = ready
        peer_avail[peer] = ready + scenario["cooldown"] + op["set_cd"]

    return {
        "valid": deadline_ok and budget_ok,
        "deadline_ok": deadline_ok,
        "budget_ok": budget_ok,
        "cost": cost,
        "budget_used": budget_used,
        "max_lag": max_lag,
        "ready_times": ready_times,
        "final_time": current,
    }


def make_scenario(rng):
    """Build a random scenario whose input order is provably valid."""
    count = rng.randint(2, 7)
    ids = rng.sample(range(1, 100), count)
    ops = []
    for op_id in ids:
        ops.append({
            "id": op_id,
            "peer": rng.randint(1, MAX_PEERS),
            "kind": "insert",
            "pos": 0,
            "arg": "x",
            "latency": rng.randint(0, 12),
            "set_cd": rng.randint(0, 4),
            "weight": rng.randint(0, 5),
            "deadline": 10**9,
        })

    provisional = {
        "text": "property test document",
        "cooldown": rng.randint(0, 5),
        "budget": 10**9,
        "wait_penalty": rng.randint(1, 3),
        "ops": ops,
    }
    input_result = simulate_order(provisional, ids)
    assert input_result["valid"]

    for op in ops:
        op["deadline"] = input_result["ready_times"][ids.index(op["id"])] + rng.randint(0, 10)
    scenario = {
        "text": provisional["text"],
        "cooldown": provisional["cooldown"],
        "budget": input_result["budget_used"] + rng.randint(1, 8),
        "wait_penalty": provisional["wait_penalty"],
        "ops": ops,
    }
    assert simulate_order(scenario, ids)["valid"]
    return scenario


def render_scenario(scenario):
    lines = [
        f"document {scenario['text']}",
        f"cooldown {scenario['cooldown']}",
        f"budget {scenario['budget']}",
        f"wait_penalty {scenario['wait_penalty']}",
        f"ops {len(scenario['ops'])}",
    ]
    for op in scenario["ops"]:
        lines.append(
            f"{op['id']} {op['peer']} {op['kind']} {op['pos']} {op['arg']} "
            f"{op['latency']} {op['set_cd']} {op['weight']} {op['deadline']}"
        )
    return "\n".join(lines) + "\n"


def run_syncplan(scenario):
    return subprocess.run(
        [APP],
        input=render_scenario(scenario),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd="/app",
        timeout=10,
    )


def parse_output(output):
    lines = output.splitlines()
    assert len(lines) == 6, output
    parsed = {}
    for line in lines:
        if line.startswith("plan cost "):
            parsed["plan_cost"] = int(line.split()[2])
        elif line.startswith("budget_used "):
            parsed["budget_used"] = int(line.split()[1])
        elif line.startswith("max_lag "):
            parsed["max_lag"] = int(line.split()[1])
        elif line.startswith("steps "):
            parsed["steps"] = int(line.split()[1])
        elif line.startswith("order"):
            parsed["order"] = [int(x) for x in line.split()[1:]]
        elif line.startswith("waits"):
            parsed["waits"] = [int(x) for x in line.split()[1:]]
        else:
            raise AssertionError(f"unexpected output line: {line!r}")
    assert set(parsed) == {"plan_cost", "budget_used", "max_lag", "steps", "order", "waits"}
    return parsed


def assert_order_complete(scenario, parsed):
    expected = [op["id"] for op in scenario["ops"]]
    assert parsed["steps"] == len(expected)
    assert len(parsed["order"]) == len(expected)
    assert Counter(parsed["order"]) == Counter(expected)


def brute_force_minimum(scenario):
    ids = [op["id"] for op in scenario["ops"]]
    valid_costs = [
        simulate_order(scenario, order)["cost"]
        for order in itertools.permutations(ids)
        if simulate_order(scenario, order)["valid"]
    ]
    assert valid_costs, "generator produced an unsolvable scenario"
    return min(valid_costs)


def exercise_scenario(scenario):
    """Kill a run, restart it, retry it, and run two requests concurrently."""
    full_input = render_scenario(scenario)
    setting_line_count = 5
    op_lines = full_input.splitlines()[setting_line_count:]
    partial_input = "\n".join(full_input.splitlines()[:setting_line_count] + op_lines[:-1]) + "\n"

    killed = subprocess.Popen(
        [APP], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, text=True, cwd="/app"
    )
    try:
        killed.stdin.write(partial_input)
        killed.stdin.flush()
        time.sleep(0.01)
        assert killed.poll() is None, "process exited before the test could kill it"
        killed.kill()
        killed.communicate(timeout=2)
    finally:
        if killed.poll() is None:
            killed.kill()
            killed.communicate(timeout=2)
    assert killed.returncode == -9

    first = run_syncplan(scenario)
    assert first.returncode == 0, first.stderr
    retry = run_syncplan(scenario)
    assert retry.returncode == 0, retry.stderr
    assert retry.stdout == first.stdout

    one = subprocess.Popen(
        [APP], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, text=True, cwd="/app"
    )
    two = subprocess.Popen(
        [APP], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, text=True, cwd="/app"
    )
    try:
        one_out, one_err = one.communicate(full_input, timeout=10)
        two_out, two_err = two.communicate(full_input, timeout=10)
    except Exception:
        for process in (one, two):
            if process.poll() is None:
                process.kill()
                process.communicate(timeout=2)
        raise
    assert one.returncode == 0, one_err
    assert two.returncode == 0, two_err
    assert one_out == first.stdout
    assert two_out == first.stdout
    return first.stdout
