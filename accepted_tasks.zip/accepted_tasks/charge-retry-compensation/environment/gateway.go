package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
)

type ChargeRecord struct {
	OrderID string `json:"order_id"`
	Attempt int    `json:"attempt"`
	Receipt string `json:"receipt"`
	Amount  int64  `json:"amount"`
}

type RefundRecord struct {
	OrderID string `json:"order_id"`
	Receipt string `json:"receipt"`
}

type PaymentGateway struct {
	mu      sync.Mutex
	dataDir string
}

func NewPaymentGateway(dataDir string) *PaymentGateway {
	return &PaymentGateway{dataDir: dataDir}
}

func (g *PaymentGateway) chargesPath() string {
	return filepath.Join(g.dataDir, "charges.jsonl")
}

func (g *PaymentGateway) refundsPath() string {
	return filepath.Join(g.dataDir, "refunds.jsonl")
}

func (g *PaymentGateway) Capture(orderID string, attempt int, amount int64) (string, error) {
	g.mu.Lock()
	defer g.mu.Unlock()
	if err := os.MkdirAll(g.dataDir, 0o755); err != nil {
		return "", err
	}
	charges, err := readCharges(g.chargesPath())
	if err != nil {
		return "", err
	}
	for _, c := range charges {
		if c.OrderID == orderID && c.Attempt == attempt {
			return c.Receipt, nil
		}
	}
	receipt := fmt.Sprintf("%s-%d", orderID, attempt)
	c := ChargeRecord{OrderID: orderID, Attempt: attempt, Receipt: receipt, Amount: amount}
	if err := appendJSONL(g.chargesPath(), c); err != nil {
		return "", err
	}
	return receipt, nil
}

func (g *PaymentGateway) ChargeForOrder(orderID string) (string, bool, error) {
	g.mu.Lock()
	defer g.mu.Unlock()
	charges, err := readCharges(g.chargesPath())
	if err != nil {
		return "", false, err
	}
	for _, c := range charges {
		if c.OrderID == orderID {
			return c.Receipt, true, nil
		}
	}
	return "", false, nil
}

func (g *PaymentGateway) Refund(orderID, receipt string) error {
	g.mu.Lock()
	defer g.mu.Unlock()
	if err := os.MkdirAll(g.dataDir, 0o755); err != nil {
		return err
	}
	return appendJSONL(g.refundsPath(), RefundRecord{OrderID: orderID, Receipt: receipt})
}

func (g *PaymentGateway) Charges() ([]ChargeRecord, error) {
	g.mu.Lock()
	defer g.mu.Unlock()
	return readCharges(g.chargesPath())
}

func (g *PaymentGateway) Refunds() ([]RefundRecord, error) {
	g.mu.Lock()
	defer g.mu.Unlock()
	return readRefunds(g.refundsPath())
}

func readCharges(path string) ([]ChargeRecord, error) {
	f, err := os.Open(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	defer f.Close()
	var records []ChargeRecord
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := sc.Bytes()
		if len(line) == 0 {
			continue
		}
		var c ChargeRecord
		if err := json.Unmarshal(line, &c); err != nil {
			return nil, err
		}
		records = append(records, c)
	}
	return records, sc.Err()
}

func readRefunds(path string) ([]RefundRecord, error) {
	f, err := os.Open(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	defer f.Close()
	var records []RefundRecord
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := sc.Bytes()
		if len(line) == 0 {
			continue
		}
		var r RefundRecord
		if err := json.Unmarshal(line, &r); err != nil {
			return nil, err
		}
		records = append(records, r)
	}
	return records, sc.Err()
}

func appendJSONL(path string, v any) error {
	b, err := json.Marshal(v)
	if err != nil {
		return err
	}
	b = append(b, 10)
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = f.Write(b)
	return err
}
