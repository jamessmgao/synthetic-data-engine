module chargeflow

go 1.23
