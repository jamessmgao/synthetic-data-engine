# Charge once and compensate correctly across process restarts

ChargeFlow persists orders but can capture a payment again when processing resumes in a new process. The fix must reconcile the durable payment state before capturing and preserve cancellation and API behavior.

## Scenario

A Go HTTP service creates orders, captures payments, exposes charge and refund records, and persists order state. Processing may be retried after the process is killed, and multiple processing requests may overlap.

## Root cause (hidden from the agent)

After a process dies following capture but before order finalization, a retry sees the charging state but increments the attempt and captures again instead of reconciling with the already durable charge record.

## Correctness constraints

- **C1**: Each order ID is charged at most once for its amount.
- **C2**: After an order is cancelled, every charge record for that order has a matching refund record.
- **C3**: The existing HTTP interface continues to create, read, process, and cancel orders with its documented statuses and error responses, and observable state persists across service restarts.
- **C4**: Processing an already charged or cancelled order is idempotent and does not create another charge.

## Subgoals

1. Identify the durable effect that can survive process death.
2. Reconcile interrupted processing with durable gateway state before capturing.
3. Serialize overlapping operations for the same order.
4. Preserve cancellation refund behavior and the public HTTP interface.

## Failure scenario

A process captures an order, is killed, and a restarted process retries processing. The unfixed retry increments the attempt and captures again; cancellation then refunds only one charge.

## Expected agent pitfalls

- Using only process-local synchronization, which is forgotten on restart.
- Trusting an order status that was not updated before the process died.
- Fixing the visible retry but allowing overlapping requests to capture twice.
- Breaking cancellation, validation, or idempotent processing while changing the workflow.

## Anti-shortcut measures

- Interface-only tests inspect public charge and refund records.
- The exact crash-retry-cancel schedule is replayed after a real process exit and restart.
- Both invariants are checked after every operation over ten fixed seeds.
- Concurrent processing and explicit SIGKILL restarts reject process-local shortcuts.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_each_order_id_is_charged_at_most_once`, `test_exact_counterexample_crash_retry_and_cancel`, `test_regression_api_validation_idempotency_and_restart_persistence` |
| C2 | `test_cancelled_order_charges_all_have_matching_refunds`, `test_exact_counterexample_crash_retry_and_cancel`, `test_regression_api_validation_idempotency_and_restart_persistence` |
| C3 | `test_regression_api_validation_idempotency_and_restart_persistence` |
| C4 | `test_regression_api_validation_idempotency_and_restart_persistence` |
