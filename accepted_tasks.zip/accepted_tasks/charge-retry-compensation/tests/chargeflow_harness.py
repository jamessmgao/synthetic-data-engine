import http.client
import json
import os
import signal
import socket
import subprocess
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class Service:
    """Drive the ChargeFlow HTTP interface, including restarts and SIGKILL."""

    def __init__(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="chargeflow-test-")
        self.data_dir = self.tmp.name
        self.port = None
        self.proc = None
        self.start()

    @staticmethod
    def _pick_port():
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("127.0.0.1", 0))
            return sock.getsockname()[1]

    def start(self, crash=False):
        if self.proc is not None:
            self.stop()
        if self.port is None:
            self.port = self._pick_port()
        env = os.environ.copy()
        env.pop("SDE_CRASH", None)
        if crash:
            env["SDE_CRASH"] = "1"
        self.proc = subprocess.Popen(
            ["/app/server", "-addr", f"127.0.0.1:{self.port}", "-data", self.data_dir],
            cwd="/app",
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        self._wait_ready()

    def _wait_ready(self):
        deadline = time.monotonic() + 5.0
        while time.monotonic() < deadline:
            if self.proc.poll() is not None:
                raise RuntimeError(f"server exited during startup: {self.proc.returncode}")
            status, body = self.request("/healthz")
            if status == 200 and body == b"ok\n":
                return
            time.sleep(0.02)
        raise RuntimeError("server did not become ready")

    def stop(self):
        if self.proc is None:
            return
        if self.proc.poll() is None:
            self.proc.send_signal(signal.SIGKILL)
        try:
            self.proc.wait(timeout=2.0)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait(timeout=2.0)
        self.proc = None

    def restart(self, crash=False):
        self.stop()
        self.start(crash=crash)

    def wait_exit(self):
        if self.proc is None:
            raise RuntimeError("server is not running")
        self.proc.wait(timeout=2.0)
        return self.proc.returncode

    def request(self, path, method="GET", timeout=2.0):
        data = b"" if method == "POST" else None
        req = Request(f"http://127.0.0.1:{self.port}{path}", data=data, method=method)
        try:
            with urlopen(req, timeout=timeout) as response:
                return response.status, response.read()
        except HTTPError as exc:
            return exc.code, exc.read()
        except (URLError, http.client.HTTPException, OSError):
            return 0, b""

    def json_request(self, path, method="GET"):
        status, raw = self.request(path, method=method)
        if not raw:
            return status, None
        try:
            return status, json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise AssertionError(f"non-JSON response from {path}: {raw!r}") from exc

    def state(self, name):
        status, value = self.json_request(f"/state/{name}")
        assert status == 200, (status, value)
        return value if value is not None else []

    def order(self, order_id):
        status, value = self.json_request(f"/orders/{order_id}")
        assert status == 200, (order_id, status, value)
        return value

    def process(self, order_id):
        return self.json_request(f"/orders/{order_id}/process", method="POST")

    def cancel(self, order_id):
        return self.json_request(f"/orders/{order_id}/cancel", method="POST")

    def parallel_process(self, order_id, count):
        from concurrent.futures import ThreadPoolExecutor

        with ThreadPoolExecutor(max_workers=count) as pool:
            return list(pool.map(lambda _: self.process(order_id), range(count)))

    def close(self):
        self.stop()
        self.tmp.cleanup()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def create(self, order_id, amount):
        from urllib.parse import quote
        path = f"/orders?id={quote(order_id, safe='')}&amount={amount}"
        return self.json_request(path, method="POST")
