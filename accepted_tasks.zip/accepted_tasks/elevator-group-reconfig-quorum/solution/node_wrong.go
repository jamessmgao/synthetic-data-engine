package main

import "sort"

type Node struct {
ID            string
Running       bool
Role          string
Term          int
VotedFor      string
LeaderID      string
Log           []LogEntry
WAL           []LogEntry
PersistedTerm int
PersistedVote string
PersistedCommit int
CommitIndex   int
LastApplied   int
SnapshotIndex int
SnapshotTerm  int
ActiveConfig  []string
ConfigIndex   int
PendingConfig []string
PendingIndex  int
State         *ElevatorState
}

func NewNode(id string, config []string) *Node {
return &Node{
ID: id, Running: true, Role: "follower",
ActiveConfig: append([]string(nil), config...),
State:        NewElevatorState(),
}
}

func (n *Node) LastIndex() int { return n.SnapshotIndex + len(n.Log) }

func (n *Node) LastTerm() int {
if len(n.Log) == 0 {
return n.SnapshotTerm
}
return n.Log[len(n.Log)-1].Term
}

func (n *Node) entry(index int) (LogEntry, bool) {
if index <= n.SnapshotIndex || index < 1 || index > n.LastIndex() {
return LogEntry{}, false
}
return n.Log[index-n.SnapshotIndex-1], true
}

func (n *Node) persistMetadata() {
n.PersistedTerm = n.Term
n.PersistedVote = n.VotedFor
}

func (n *Node) SyncTo(index int) {
	rel := index - n.SnapshotIndex
	if rel < 0 {
		rel = 0
	}
	if rel > len(n.Log) {
		rel = len(n.Log)
	}
	n.WAL = append([]LogEntry(nil), n.Log[:rel]...)
}

func (n *Node) AppendLocal(entry LogEntry) bool {
if !n.Running || entry.Index != n.LastIndex()+1 {
return false
}
entry.Term = n.Term
n.Log = append(n.Log, entry)
n.SyncTo(entry.Index)
n.recordConfig(entry)
return true
}

func (n *Node) recordConfig(entry LogEntry) {
if entry.Type != "config" {
return
}
n.PendingConfig = append([]string(nil), entry.Config...)
n.PendingIndex = entry.Index
}

func (n *Node) settleConfig(committed int) {
if n.PendingIndex > 0 && committed >= n.PendingIndex {
n.ActiveConfig = append([]string(nil), n.PendingConfig...)
n.ConfigIndex = n.PendingIndex
n.PendingConfig = nil
n.PendingIndex = 0
}
}

func (n *Node) AppendFromLeader(term, prevIndex, prevTerm, leaderCommit int, entries []LogEntry) (int, int, bool) {
if !n.Running || term < n.Term || len(entries) == 0 {
return n.LastIndex(), n.Term, false
}
if term > n.Term {
n.Term = term
n.VotedFor = ""
n.Role = "follower"
n.LeaderID = ""
n.persistMetadata()
}
if prevIndex > n.LastIndex() {
return n.LastIndex(), n.Term, false
}
if prevIndex > 0 {
prev, _ := n.entry(prevIndex)
if prev.Term != prevTerm {
return n.LastIndex(), n.Term, false
}
}
for _, e := range entries {
at := prevIndex + e.Index - entries[0].Index + 1
old, exists := n.entry(at)
if exists && old.Term != e.Term {
if at <= n.CommitIndex {
return n.LastIndex(), n.Term, false
}
n.Log = n.Log[:at-n.SnapshotIndex-1]
n.State = NewElevatorState()
kept := n.CommitIndex
if kept >= at {
kept = at - 1
}
n.CommitIndex = 0
n.LastApplied = 0
n.PersistedCommit = 0
n.AdvanceCommit(kept)
} else if exists {
continue
}
if at != n.LastIndex()+1 {
return n.LastIndex(), n.Term, false
}
n.Log = append(n.Log, e)
}
lastSent := entries[len(entries)-1].Index
if n.LastIndex() > lastSent {
n.Log = n.Log[:lastSent-n.SnapshotIndex]
}
n.SyncTo(n.LastIndex())
for _, e := range entries {
n.recordConfig(e)
}
if leaderCommit > n.CommitIndex {
n.AdvanceCommit(min(leaderCommit, n.LastIndex()))
}
return n.LastIndex(), n.Term, true
}

func (n *Node) RequestVote(term int, candidate string) bool {
if !n.Running || term < n.Term {
return false
}
if term > n.Term {
n.Term = term
n.VotedFor = ""
n.Role = "follower"
n.persistMetadata()
}
if n.VotedFor != "" && n.VotedFor != candidate {
return false
}
if candidate == n.ID {
n.VotedFor = candidate
n.persistMetadata()
return true
}
c := nodes[candidate]
if c == nil || !c.Running {
return false
}
candidateLast := c.LastIndex()
candidateTerm := c.LastTerm()
if candidateTerm != n.LastTerm() {
if candidateTerm < n.LastTerm() {
return false
}
} else if candidateLast < n.LastIndex() {
return false
}
n.VotedFor = candidate
n.persistMetadata()
return true
}

func (n *Node) AdvanceCommit(index int) {
if index <= n.CommitIndex || index > n.LastIndex() {
return
}
n.CommitIndex = index
n.PersistedCommit = index
n.settleConfig(index)
for n.LastApplied < n.CommitIndex {
n.LastApplied++
if e, ok := n.entry(n.LastApplied); ok {
n.State.Apply(e)
}
}
}

func (n *Node) Compact(index int) bool {
if index <= n.SnapshotIndex || index > n.CommitIndex {
return false
}
for n.LastApplied < index {
n.AdvanceCommit(n.LastApplied + 1)
}
e, ok := n.entry(index)
if !ok {
return false
}
	offset := index - n.SnapshotIndex
n.SnapshotIndex = index
	n.SnapshotTerm = e.Term
	n.Log = append([]LogEntry(nil), n.Log[offset:]...)
	n.SyncTo(n.LastIndex())
	return true
}

func (n *Node) Crash() {
n.Running = false
n.Role = "stopped"
n.LeaderID = ""
n.Log = nil
n.CommitIndex = 0
n.LastApplied = 0
n.PendingConfig = nil
n.PendingIndex = 0
}

func (n *Node) Recover() {
n.Running = true
n.Role = "follower"
n.Term = n.PersistedTerm
n.VotedFor = n.PersistedVote
n.Log = append([]LogEntry(nil), n.WAL...)
n.CommitIndex = 0
n.LastApplied = 0
n.State = NewElevatorState()
for _, e := range n.WAL {
n.recordConfig(e)
}
n.AdvanceCommit(n.PersistedCommit)
}

func sortedIDs(ids []string) []string {
out := append([]string(nil), ids...)
sort.Strings(out)
return out
}

func min(a, b int) int {
if a < b {
return a
}
return b
}
