# Elevator group reconfiguration quorum and recovery fix

A deterministic Go elevator cluster model loses acknowledged call requests after membership changes and after log compaction followed by crash recovery. The task is to fix the consensus and recovery paths so acknowledged calls remain present in every running node's call state.

## Scenario

The agent is given a Go service that simulates an elevator group controller with Raft-like elections, configuration changes, call assignment, log compaction, crash, recovery, and sync. Running it with a JSON schedule prints a JSON report of cluster state. Some schedules lose acknowledged calls.

## Root cause (hidden from the agent)

The commit quorum switches to the new configuration when a membership change is appended rather than committed, and compaction truncates the WAL without preserving a state snapshot. Recovery rebuilds applied state from the truncated WAL, losing compacted acknowledged calls.

## Correctness constraints

- **C1**: Every acknowledged elevator call request remains present in the call state of every running node in the final leader's active configuration.
- **C2**: After a membership change, a leader elected from the old configuration cannot commit a conflicting call that removes an acknowledged call from the active group.
- **C3**: After log compaction, a node that crashes and recovers must preserve every acknowledged call in its applied call state.

## Subgoals

1. Understand the deterministic JSON schedule CLI and report format.
2. Identify the early configuration activation and quorum switch during membership changes.
3. Identify that compaction truncates the WAL and recovery rebuilds only from the WAL.
4. Fix commit quorum to use joint old/new configuration during membership changes.
5. Fix compaction and recovery to preserve applied call state across crash/recovery.

## Failure scenario

The tests replay the exact counterexample and randomized schedules that elect a leader, submit calls, compact, crash, recover, re-elect, and sync. The unfixed service loses acknowledged calls after compaction and recovery, and after old-config failover during membership changes.

## Expected agent pitfalls

- Fixing only the visible quorum symptom and leaving compaction recovery broken.
- Truncating the WAL during compaction without preserving a state snapshot.
- Breaking existing call assignment or sync behavior while changing consensus paths.

## Anti-shortcut measures

- Tests run fixed-seed random schedules with crashes, restarts, retries, and concurrency where the model allows.
- Tests assert all three invariants over many schedules, not just the counterexample.
- Tests inspect only observable JSON report state, not implementation internals.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_invariant_1_acknowledged_calls_present`, `test_concurrent_overlapping_calls_dedup` |
| C2 | `test_invariant_2_no_conflicting_call_after_membership_change` |
| C3 | `test_invariant_3_compaction_recovery_preserves_calls`, `test_counterexample_replay` |
