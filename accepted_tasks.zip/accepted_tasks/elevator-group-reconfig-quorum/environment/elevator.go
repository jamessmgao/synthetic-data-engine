package main

type Command struct {
Op        string `json:"op"`
Floor     int    `json:"floor,omitempty"`
RequestID string `json:"request_id"`
}

type LogEntry struct {
Index  int      `json:"index"`
Term   int      `json:"term"`
Type   string   `json:"type"`
Cmd    *Command `json:"cmd,omitempty"`
Config []string `json:"config,omitempty"`
}

type Elevator struct {
ID     string `json:"id"`
Floor  int    `json:"floor"`
Target int    `json:"target"`
State  string `json:"state"`
}

type Call struct {
Floor      int    `json:"floor"`
RequestID  string `json:"request_id"`
ElevatorID string `json:"elevator_id"`
Completed  bool   `json:"completed"`
}

type ElevatorState struct {
Elevators map[string]*Elevator `json:"elevators"`
Calls     map[string]*Call     `json:"calls"`
Dedup     map[string]bool      `json:"dedup"`
}

func NewElevatorState() *ElevatorState {
return &ElevatorState{
Elevators: map[string]*Elevator{
"L": {ID: "L", Floor: 1, Target: 1, State: "idle"},
"R": {ID: "R", Floor: 1, Target: 1, State: "idle"},
},
Calls: map[string]*Call{},
Dedup: map[string]bool{},
}
}

func (s *ElevatorState) Apply(entry LogEntry) {
if entry.Type != "command" || entry.Cmd == nil {
return
}
cmd := *entry.Cmd
if s.Dedup[cmd.RequestID] {
return
}
switch cmd.Op {
case "assign_call":
eid := s.pickElevator(cmd.Floor)
s.Calls[cmd.RequestID] = &Call{
Floor:      cmd.Floor,
RequestID:  cmd.RequestID,
ElevatorID: eid,
}
if e, ok := s.Elevators[eid]; ok {
e.Target = cmd.Floor
e.State = "moving"
}
s.Dedup[cmd.RequestID] = true
case "complete_call":
if c, ok := s.Calls[cmd.RequestID]; ok {
c.Completed = true
if e, ok := s.Elevators[c.ElevatorID]; ok {
e.Floor = c.Floor
e.Target = c.Floor
e.State = "idle"
}
s.Dedup[cmd.RequestID] = true
}
}
}

func (s *ElevatorState) pickElevator(floor int) string {
best := ""
bestDist := -1
for _, id := range []string{"L", "R"} {
e := s.Elevators[id]
d := e.Floor - floor
if d < 0 {
d = -d
}
if bestDist < 0 || d < bestDist || (d == bestDist && id < best) {
best = id
bestDist = d
}
}
return best
}
