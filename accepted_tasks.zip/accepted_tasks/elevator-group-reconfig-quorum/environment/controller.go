package main

import (
"encoding/json"
"os"
"strings"
)

var nodes map[string]*Node

type Cluster struct {
Nodes    map[string]*Node
IDs      []string
Config   []string
Term     int
LeaderID string
Acked    []string
Events   []string
}

type Operation struct {
Op        string   `json:"op"`
Node      string   `json:"node,omitempty"`
Nodes     []string `json:"nodes,omitempty"`
Members   []string `json:"members,omitempty"`
Floor     int      `json:"floor,omitempty"`
RequestID string   `json:"request_id,omitempty"`
Index     int      `json:"index",omitempty`
}

type NodeReport struct {
ID        string         `json:"id"`
Running   bool           `json:"running"`
Role      string         `json:"role"`
Term      int            `json:"term"`
Commit    int            `json:"commit"`
Applied   int            `json:"applied"`
LastIndex int            `json:"last_index"`
Config    []string       `json:"config"`
Elevators map[string]*Elevator `json:"elevators"`
Calls     map[string]*Call      `json:"calls"`
}

type Report struct {
Leader string       `json:"leader"`
Term   int          `json:"term"`
Config []string     `json:"config"`
Acked  []string     `json:"acked"`
Events []string     `json:"events"`
Nodes  []NodeReport `json:"nodes"`
}

func quorumOf(ids []string) int { return len(ids)/2 + 1 }

func NewCluster(ids, config []string) *Cluster {
c := &Cluster{Nodes: map[string]*Node{}, IDs: sortedIDs(ids), Config: sortedIDs(config)}
for _, id := range c.IDs {
c.Nodes[id] = NewNode(id, config)
}
nodes = c.Nodes
return c
}

func (c *Cluster) leader() *Node {
if c.LeaderID == "" {
return nil
}
n := c.Nodes[c.LeaderID]
if n == nil || !n.Running || n.Role != "leader" {
return nil
}
return n
}

func (c *Cluster) event(text string) { c.Events = append(c.Events, text) }

func (c *Cluster) Elect(id string) bool {
n := c.Nodes[id]
if n == nil || !n.Running {
return false
}
c.Term++
n.Term = c.Term
n.Role = "candidate"
n.VotedFor = id
n.persistMetadata()
votes := 0
for _, voterID := range n.ActiveConfig {
if c.Nodes[voterID].RequestVote(c.Term, id) {
votes++
}
}
if votes < quorumOf(n.ActiveConfig) {
n.Role = "follower"
c.LeaderID = ""
c.event("election_failed:" + id)
return false
}
n.Role = "leader"
c.LeaderID = id
c.Config = n.ActiveConfig
for _, peerID := range n.ActiveConfig {
if peer := c.Nodes[peerID]; peer != nil && peerID != id {
peer.Role = "follower"
peer.LeaderID = id
}
}
c.event("leader:" + id)
return true
}

func (c *Cluster) replicate(l *Node) []string {
acks := []string{}
entries := append([]LogEntry(nil), l.Log...)
for _, id := range sortedIDs(l.ActiveConfig) {
if id == l.ID {
continue
}
n := c.Nodes[id]
if n == nil || !n.Running {
continue
}
_, _, ok := n.AppendFromLeader(l.Term, 0, 0, l.CommitIndex, entries)
if ok {
acks = append(acks, id)
}
}
if l.Running {
acks = append(acks, l.ID)
}
return sortedIDs(acks)
}

func (c *Cluster) commitAt(l *Node, index int, acks []string) bool {
ackSet := map[string]bool{}
for _, id := range acks {
ackSet[id] = true
}
count := 0
for _, id := range l.ActiveConfig {
if ackSet[id] {
count++
}
}
if count < quorumOf(l.ActiveConfig) {
return false
}
l.AdvanceCommit(index)
for _, id := range sortedIDs(l.ActiveConfig) {
if n := c.Nodes[id]; n != nil && n.Running && id != l.ID {
n.AppendFromLeader(l.Term, 0, 0, index, append([]LogEntry(nil), l.Log...))
}
}
return true
}

func (c *Cluster) CompactNode(id string, index int) bool {
	n := c.Nodes[id]
	if n == nil || !n.Running {
		return false
	}
	return n.Compact(index)
}

func (c *Cluster) ChangeConfig(members []string) bool {
l := c.leader()
if l == nil {
return false
}
entry := LogEntry{Index: l.LastIndex() + 1, Type: "config", Config: sortedIDs(members)}
if !l.AppendLocal(entry) {
return false
}
c.Config = sortedIDs(members)
acks := c.replicate(l)
if !c.commitAt(l, entry.Index, acks) {
return false
}
c.Config = sortedIDs(members)
c.event("config_appended:" + strings.Join(entry.Config, "+"))
return true
}

func (c *Cluster) SubmitCall(floor int, requestID string) bool {
l := c.leader()
if l == nil {
return false
}
entry := LogEntry{Index: l.LastIndex() + 1, Type: "command", Cmd: &Command{Op: "assign_call", Floor: floor, RequestID: requestID}}
if !l.AppendLocal(entry) {
return false
}
acks := c.replicate(l)
if !c.commitAt(l, entry.Index, acks) {
return false
}
c.Acked = append(c.Acked, requestID)
c.event("acked:" + requestID)
return true
}

func (c *Cluster) Sync() bool {
l := c.leader()
if l == nil {
return false
}
c.replicate(l)
c.event("sync")
return true
}

func (c *Cluster) report() Report {
cfg := c.Config
if l := c.leader(); l != nil {
cfg = l.ActiveConfig
}
r := Report{Leader: c.LeaderID, Term: c.Term, Config: cfg, Acked: c.Acked, Events: c.Events}
for _, id := range c.IDs {
n := c.Nodes[id]
r.Nodes = append(r.Nodes, NodeReport{
ID: id, Running: n.Running, Role: n.Role, Term: n.Term,
Commit: n.CommitIndex, Applied: n.LastApplied, LastIndex: n.LastIndex(),
Config: n.ActiveConfig, Elevators: n.State.Elevators, Calls: n.State.Calls,
})
}
return r
}

func main() {
path := "/world/repro/sequence.json"
if len(os.Args) == 2 {
path = os.Args[1]
}
data, err := os.ReadFile(path)
if err != nil {
panic(err)
}
var ops []Operation
if err := json.Unmarshal(data, &ops); err != nil {
panic(err)
}
c := NewCluster([]string{"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"}, []string{"A", "B", "C", "D", "E", "F", "G"})
for _, op := range ops {
switch op.Op {
case "elect":
c.Elect(op.Node)
case "config":
c.ChangeConfig(op.Members)
case "call":
c.SubmitCall(op.Floor, op.RequestID)
case "crash":
for _, id := range op.Nodes {
c.Nodes[id].Crash()
}
if c.leader() == nil {
c.LeaderID = ""
}
case "recover":
for _, id := range op.Nodes {
c.Nodes[id].Recover()
}
case "compact":
		c.CompactNode(op.Node, op.Index)
case "sync":
c.Sync()
}
}
json.NewEncoder(os.Stdout).Encode(c.report())
}
