#ifndef STORE_H
#define STORE_H

#include <stddef.h>
#include <stdio.h>

#define KEY_MAX 64
#define VALUE_MAX 256
#define RANK_MAX 32

typedef struct {
    char key[KEY_MAX];
    char value[VALUE_MAX];
    char rank[RANK_MAX];
    long seq;
} Row;

typedef struct {
    Row *rows;
    size_t count;
    size_t cap;
    long next_seq;
} Store;

int store_load(Store *st, const char *path);
void store_free(Store *st);
int store_save(Store *st, const char *path);
int store_put(Store *st, const char *key, const char *value, const char *rank);
int store_delete(Store *st, const char *key);
int store_write_snapshot(Store *st, const char *path);
int store_retrieve(const char *snap_path, long offset, long limit, Row *out, long *out_count);
int store_seek(const char *snap_path, const char *after_rank, long limit, Row *out, long *out_count);

Row *row_alloc(long n);
void row_release(Row *rows, long n);
long store_peak_held(void);
void store_reset_peak(void);

#endif
