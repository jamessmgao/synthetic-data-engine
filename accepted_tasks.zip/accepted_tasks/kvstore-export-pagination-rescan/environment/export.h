#ifndef EXPORT_H
#define EXPORT_H

int export_run(const char *snap_path, const char *plan_path, const char *out_path);
int export_run_cursor(const char *snap_path, const char *plan_path, const char *out_path);

#endif
