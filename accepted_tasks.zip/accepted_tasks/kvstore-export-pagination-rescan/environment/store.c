#define _POSIX_C_SOURCE 200809L
#include "store.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static long g_held_rows = 0;
static long g_peak_held = 0;
static int g_internal_depth = 0;

static void track_add(long count) {
    g_held_rows += count;
    if (g_internal_depth == 0 && g_held_rows > g_peak_held)
        g_peak_held = g_held_rows;
}

static void track_sub(long count) {
    g_held_rows -= count;
    if (g_held_rows < 0) g_held_rows = 0;
}

Row *row_alloc(long n) {
    if (n <= 0) return NULL;
    Row *r = malloc((size_t)n * sizeof(Row));
    if (r) track_add(n);
    return r;
}

void row_release(Row *rows, long n) {
    if (rows && n > 0) {
        track_sub(n);
        free(rows);
    }
}

long store_peak_held(void) { return g_peak_held; }
void store_reset_peak(void) { g_peak_held = 0; g_held_rows = 0; }

static void internal_enter(void) { g_internal_depth++; }
static void internal_leave(void) { g_internal_depth--; }

static int row_grow(Store *st, size_t need) {
    if (need <= st->cap) return 0;
    size_t nc = st->cap ? st->cap * 2 : 16;
    while (nc < need) nc *= 2;
    Row *nr = realloc(st->rows, nc * sizeof(Row));
    if (!nr) return -1;
    st->rows = nr; st->cap = nc; return 0;
}

static void row_copy(Row *dst, const char *key, const char *value, const char *rank, long seq) {
    snprintf(dst->key, KEY_MAX, "%s", key);
    snprintf(dst->value, VALUE_MAX, "%s", value);
    snprintf(dst->rank, RANK_MAX, "%s", rank);
    dst->seq = seq;
}

int store_load(Store *st, const char *path) {
    memset(st, 0, sizeof(*st));
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    char line[KEY_MAX + VALUE_MAX + RANK_MAX + 64];
    while (fgets(line, sizeof(line), f)) {
        char *save = NULL;
        char *key = strtok_r(line, "\t\n", &save);
        if (!key) continue;
        char *value = strtok_r(NULL, "\t\n", &save);
        char *rank = strtok_r(NULL, "\t\n", &save);
        char *seq_s = strtok_r(NULL, "\t\n", &save);
        if (!value || !rank || !seq_s) continue;
        long seq = strtol(seq_s, NULL, 10);
        if (row_grow(st, st->count + 1) != 0) { fclose(f); return -1; }
        Row *r = &st->rows[st->count++];
        row_copy(r, key, value, rank, seq);
        if (seq >= st->next_seq) st->next_seq = seq + 1;
    }
    fclose(f);
    track_add((long)st->count);
    return 0;
}

void store_free(Store *st) {
    if (st->rows) {
        track_sub((long)st->count);
        free(st->rows);
    }
    st->rows = NULL; st->count = 0; st->cap = 0; st->next_seq = 1;
}

int store_save(Store *st, const char *path) {
    char tmp[4096];
    snprintf(tmp, sizeof(tmp), "%s.tmp", path);
    FILE *f = fopen(tmp, "w");
    if (!f) return -1;
    for (size_t i = 0; i < st->count; i++) {
        Row *r = &st->rows[i];
        if (fprintf(f, "%s\t%s\t%s\t%ld\n", r->key, r->value, r->rank, r->seq) < 0) {
            fclose(f); return -1;
        }
    }
    if (fclose(f) != 0) return -1;
    if (rename(tmp, path) != 0) return -1;
    return 0;
}

int store_put(Store *st, const char *key, const char *value, const char *rank) {
    for (size_t i = 0; i < st->count; i++) {
        if (strcmp(st->rows[i].key, key) == 0) {
            snprintf(st->rows[i].value, VALUE_MAX, "%s", value);
            snprintf(st->rows[i].rank, RANK_MAX, "%s", rank);
            return 0;
        }
    }
    if (row_grow(st, st->count + 1) != 0) return -1;
    row_copy(&st->rows[st->count], key, value, rank, st->next_seq);
    st->next_seq++; st->count++; return 0;
}

int store_delete(Store *st, const char *key) {
    for (size_t i = 0; i < st->count; i++) {
        if (strcmp(st->rows[i].key, key) == 0) {
            st->rows[i] = st->rows[--st->count]; return 0;
        }
    }
    return -1;
}

int store_write_snapshot(Store *st, const char *path) {
    return store_save(st, path);
}

static int row_cmp(const void *a, const void *b) {
    const Row *ra = a, *rb = b;
    int c = strcmp(ra->rank, rb->rank);
    if (c) return c;
    if (ra->seq < rb->seq) return -1;
    if (ra->seq > rb->seq) return 1;
    return strcmp(ra->key, rb->key);
}

int store_retrieve(const char *snap_path, long offset, long limit, Row *out, long *out_count) {
    Store st;
    internal_enter();
    if (store_load(&st, snap_path) != 0) { internal_leave(); return -1; }
    if (st.count > 0) qsort(st.rows, st.count, sizeof(Row), row_cmp);
    long start = offset;
    if (start < 0) start = 0;
    if ((size_t)start > st.count) start = (long)st.count;
    long n = (long)st.count - start;
    if (n > limit) n = limit;
    if (n < 0) n = 0;
    for (long i = 0; i < n; i++) out[i] = st.rows[start + i];
    *out_count = n;
    store_free(&st);
    internal_leave();
    return 0;
}

int store_seek(const char *snap_path, const char *after_rank, long limit, Row *out, long *out_count) {
    Store st;
    internal_enter();
    if (store_load(&st, snap_path) != 0) { internal_leave(); return -1; }
    long count = 0;
    for (size_t i = 0; i < st.count; i++) {
        if (!after_rank || after_rank[0] == '\0' || strcmp(st.rows[i].rank, after_rank) > 0) {
            if (count < limit) out[count] = st.rows[i];
            count++;
        }
    }
    *out_count = (count > limit) ? limit : count;
    store_free(&st);
    internal_leave();
    return 0;
}
