#ifndef CHECKPOINT_H
#define CHECKPOINT_H

int checkpoint_export(const char *db_path, const char *snap_path,
                      const char *plan_path, const char *out_path);
int checkpoint_verify(const char *out_path, long expected_count);
long checkpoint_count_rows(const char *path);

#endif
