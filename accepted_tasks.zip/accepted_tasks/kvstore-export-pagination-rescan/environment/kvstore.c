#define _POSIX_C_SOURCE 200809L
#include "store.h"
#include "export.h"
#include "checkpoint.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int cmd_init(const char *db_path) {
    Store st; memset(&st, 0, sizeof(st));
    int r = store_save(&st, db_path); store_free(&st); return r;
}

static int cmd_put(const char *db_path, const char *key, const char *value, const char *rank) {
    Store st;
    if (store_load(&st, db_path) != 0) return 1;
    if (store_put(&st, key, value, rank) != 0) { store_free(&st); return 1; }
    int r = store_save(&st, db_path); store_free(&st); return r != 0 ? 1 : 0;
}

static int cmd_get(const char *db_path, const char *key) {
    Store st;
    if (store_load(&st, db_path) != 0) return 1;
    int found = 0;
    for (size_t i = 0; i < st.count; i++) {
        if (strcmp(st.rows[i].key, key) == 0) {
            printf("%s\t%s\t%s\t%ld\n", st.rows[i].key, st.rows[i].value, st.rows[i].rank, st.rows[i].seq);
            found = 1; break;
        }
    }
    store_free(&st); return found ? 0 : 1;
}

static int cmd_delete(const char *db_path, const char *key) {
    Store st;
    if (store_load(&st, db_path) != 0) return 1;
    if (store_delete(&st, key) != 0) { store_free(&st); return 1; }
    int r = store_save(&st, db_path); store_free(&st); return r != 0 ? 1 : 0;
}

static int cmd_snapshot(const char *db_path, const char *snap_path) {
    Store st;
    if (store_load(&st, db_path) != 0) return 1;
    int r = store_write_snapshot(&st, snap_path); store_free(&st); return r != 0 ? 1 : 0;
}

static int cmd_export(const char *snap_path, const char *plan_path, const char *out_path) {
    FILE *pf = fopen(plan_path, "r");
    long page_size = 10;
    if (pf) { if (fscanf(pf, "%ld", &page_size) != 1) page_size = 10; fclose(pf); }
    if (page_size <= 0) page_size = 10;
    long mem_limit = page_size + 2;
    store_reset_peak();
    int r = export_run(snap_path, plan_path, out_path);
    if (r != 0) return 1;
    if (store_peak_held() > mem_limit) {
        fprintf(stderr, "export: memory limit violated, peak %ld rows held, limit %ld\n",
                store_peak_held(), mem_limit);
        return 1;
    }
    return 0;
}

static int cmd_export_cursor(const char *snap_path, const char *plan_path, const char *out_path) {
    FILE *pf = fopen(plan_path, "r");
    long page_size = 10;
    if (pf) { if (fscanf(pf, "%ld", &page_size) != 1) page_size = 10; fclose(pf); }
    if (page_size <= 0) page_size = 10;
    long mem_limit = page_size + 2;
    store_reset_peak();
    int r = export_run_cursor(snap_path, plan_path, out_path);
    if (r != 0) return 1;
    if (store_peak_held() > mem_limit) {
        fprintf(stderr, "export: memory limit violated, peak %ld rows held, limit %ld\n",
                store_peak_held(), mem_limit);
        return 1;
    }
    return 0;
}

static int cmd_checkpoint(const char *db_path, const char *snap_path,
                           const char *plan_path, const char *out_path) {
    return checkpoint_export(db_path, snap_path, plan_path, out_path) != 0 ? 1 : 0;
}

static int cmd_verify(const char *out_path, long expected) {
    return checkpoint_verify(out_path, expected) != 0 ? 1 : 0;
}

static int cmd_count(const char *db_path) {
    Store st;
    if (store_load(&st, db_path) != 0) return 1;
    printf("%zu\n", st.count); store_free(&st); return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "Usage: kvstore <cmd> [args...]\n"); return 1; }
    const char *cmd = argv[1];
    if (strcmp(cmd, "init") == 0 && argc == 3) return cmd_init(argv[2]);
    if (strcmp(cmd, "put") == 0 && argc == 6) return cmd_put(argv[2], argv[3], argv[4], argv[5]);
    if (strcmp(cmd, "get") == 0 && argc == 4) return cmd_get(argv[2], argv[3]);
    if (strcmp(cmd, "delete") == 0 && argc == 4) return cmd_delete(argv[2], argv[3]);
    if (strcmp(cmd, "snapshot") == 0 && argc == 4) return cmd_snapshot(argv[2], argv[3]);
    if (strcmp(cmd, "export") == 0 && argc == 5) return cmd_export(argv[2], argv[3], argv[4]);
    if (strcmp(cmd, "export-cursor") == 0 && argc == 5) return cmd_export_cursor(argv[2], argv[3], argv[4]);
    if (strcmp(cmd, "checkpoint") == 0 && argc == 6) return cmd_checkpoint(argv[2], argv[3], argv[4], argv[5]);
    if (strcmp(cmd, "verify") == 0 && argc == 4) return cmd_verify(argv[2], atol(argv[3]));
    if (strcmp(cmd, "count") == 0 && argc == 3) return cmd_count(argv[2]);
    fprintf(stderr, "Unknown command: %s\n", cmd); return 1;
}
