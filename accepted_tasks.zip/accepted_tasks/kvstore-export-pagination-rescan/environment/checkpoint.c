#define _POSIX_C_SOURCE 200809L
#include "checkpoint.h"
#include "store.h"
#include "export.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int checkpoint_export(const char *db_path, const char *snap_path,
                      const char *plan_path, const char *out_path) {
    Store st;
    if (store_load(&st, db_path) != 0) {
        fprintf(stderr, "checkpoint: load failed\n");
        return -1;
    }
    if (store_write_snapshot(&st, snap_path) != 0) {
        fprintf(stderr, "checkpoint: snapshot failed\n");
        store_free(&st);
        return -1;
    }
    store_free(&st);
    if (export_run(snap_path, plan_path, out_path) != 0) {
        fprintf(stderr, "checkpoint: export failed\n");
        return -1;
    }
    return 0;
}

long checkpoint_count_rows(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    long count = 0;
    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        if (line[0] != '\n' && line[0] != '\0') count++;
    }
    fclose(f);
    return count;
}

int checkpoint_verify(const char *out_path, long expected_count) {
    long actual = checkpoint_count_rows(out_path);
    if (actual < 0) {
        fprintf(stderr, "verify: cannot read %s\n", out_path);
        return -1;
    }
    if (actual != expected_count) {
        fprintf(stderr, "verify: expected %ld rows, got %ld\n", expected_count, actual);
        return -1;
    }
    return 0;
}
