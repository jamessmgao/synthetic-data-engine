import errno
import os
import random
import signal
import subprocess
import time
from collections import Counter

KVSTORE = os.environ.get("KVSTORE_TEST_BIN", "/app/kvstore")
CWD = os.environ.get("KVSTORE_TEST_CWD", "/app")


def run_kv(*args, timeout=30):
    return subprocess.run(
        [KVSTORE, *args], cwd=CWD, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout,
    )


def write_plan(path, page_size):
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"{page_size}\n")


def random_rows(rng, n):
    rows = []
    for i in range(n):
        key = f"k{i:05d}"
        value = f"v{rng.randrange(10000):05d}"
        rank = rng.choice(["A", "A", "B", "C"])
        for field in (key, value, rank):
            assert field and "\t" not in field and "\n" not in field
        rows.append((key, value, rank))
    assert len({r[0] for r in rows}) == n
    return rows


def with_seq(rows):
    return [(k, v, r, i) for i, (k, v, r) in enumerate(rows)]


def row_sort_key(row):
    return (row[2], row[3], row[0])


def read_rows(path):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.rstrip("\n").split("\t")
            assert len(parts) == 4
            rows.append((parts[0], parts[1], parts[2], int(parts[3])))
    return rows


def assert_export_result(path, expected):
    actual = read_rows(path)
    assert len(actual) == len(expected)
    assert Counter(actual) == Counter(expected)
    assert actual == sorted(expected, key=row_sort_key)


def build_db(path, rows):
    r = run_kv("init", path)
    assert r.returncode == 0, r.stderr
    for key, value, rank in rows:
        r = run_kv("put", path, key, value, rank)
        assert r.returncode == 0, r.stderr


def make_snapshot(db_path, snap_path):
    r = run_kv("snapshot", db_path, snap_path)
    assert r.returncode == 0, r.stderr


def _open_fifo_writer(path, proc, timeout=5):
    deadline = time.monotonic() + timeout
    while True:
        try:
            return os.open(path, os.O_WRONLY | os.O_NONBLOCK)
        except OSError as exc:
            if exc.errno != errno.ENXIO:
                raise
            if proc.poll() is not None:
                raise AssertionError("export exited before opening snapshot")
            if time.monotonic() > deadline:
                proc.kill()
                proc.wait(timeout=5)
                raise AssertionError("timed out waiting for export to open snapshot")
            time.sleep(0.01)


def kill_export_and_retry_concurrently(snap_path, db_path, plan_path, retry_path, expected_count):
    """Kill a blocked export while count runs, then retry from the real snapshot."""
    paused_snapshot = snap_path + ".paused"
    partial_output = snap_path + ".partial-output"
    os.mkfifo(paused_snapshot)
    proc = subprocess.Popen(
        [KVSTORE, "export", paused_snapshot, plan_path, partial_output],
        cwd=CWD, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    fd = _open_fifo_writer(paused_snapshot, proc)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as writer:
            with open(snap_path, "r", encoding="utf-8") as source:
                for line in source:
                    writer.write(line)
            writer.flush()
            concurrent_count = run_kv("count", db_path)
            assert concurrent_count.returncode == 0, concurrent_count.stderr
            assert concurrent_count.stdout == f"{expected_count}\n"
            os.kill(proc.pid, signal.SIGKILL)
        proc.wait(timeout=5)
        assert proc.returncode == -signal.SIGKILL
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait(timeout=5)
        if proc.stdout:
            proc.stdout.close()
        if proc.stderr:
            proc.stderr.close()
        try:
            os.unlink(paused_snapshot)
        except FileNotFoundError:
            pass
    retry = run_kv("export", snap_path, plan_path, retry_path)
    assert retry.returncode == 0, retry.stderr
    return retry_path


def timed_run(*args, timeout=30):
    start = time.perf_counter()
    result = run_kv(*args, timeout=timeout)
    elapsed_ms = (time.perf_counter() - start) * 1000.0
    return result, elapsed_ms
