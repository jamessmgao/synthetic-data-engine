# kvstore export pagination rescan

The kvstore export command re-sorts and re-scans the entire snapshot for every page under offset pagination, making it O(n^2) on tied-rank data. A fix must preserve exact output, stay under 100ms for 3000 rows, and honor the page-size+2 Row memory budget.

## Scenario

A C key-value store with init, put, get, delete, snapshot, export, export-cursor, checkpoint, verify, and count commands. The export command pages through a snapshot using offset pagination and must produce rows sorted by rank then sequence then key.

## Root cause (hidden from the agent)

export_run calls store_retrieve for each page; store_retrieve loads and sorts the entire snapshot on every call, yielding O(n^2) work. The cursor path has the same repeated-load issue and also skips rows sharing a rank.

## Correctness constraints

- **C1**: Every row in the store appears exactly once in the export output, sorted by rank then sequence then key.
- **C2**: Export of 3000 rows completes within 100ms.
- **C3**: Peak Row objects held during export must not exceed page_size + 2.
- **C4**: All existing CLI commands (init, put, get, delete, snapshot, export, export-cursor, checkpoint, verify, count) continue to produce their current output and exit codes.

## Subgoals

1. Eliminate per-page full reload and re-sort in export_run
2. Ensure export preserves exact sorted output
3. Ensure the fixed export and export-cursor honor the page-size+2 Row memory budget for all page sizes

## Failure scenario

On a 3000-row snapshot where all rows share rank A, export with page_size=1 re-sorts the entire snapshot 3000 times, taking over 1 second. A one-pass external merge fix holds one live Row per run (N/page_size), exceeding page_size+2 when page_size is small.

## Expected agent pitfalls

- Rewriting export to load-and-sort-once violates the memory budget for small page sizes
- A one-pass external merge sort holds N/page_size live Rows, violating the streaming bound when page_size is small
- The cursor path skip-duplicates bug must also be fixed

## Anti-shortcut measures

- Tests export with page_size=1 on small and large tied-rank data to catch memory-bound violations
- Exact-output checks prevent reordering or dropping rows
- Timing test on 3000 tied-rank rows catches any approach that does not eliminate per-page rescanning

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_every_row_appears_exactly_once`, `test_exact_counterexample_3000_tied_rows_page_size_1`, `test_cli_regressions_and_every_command`, `test_export_edge_cases_and_plan_boundaries` |
| C2 | `test_export_3000_rows_completes_within_100ms`, `test_exact_counterexample_3000_tied_rows_page_size_1` |
| C3 | `test_peak_row_objects_do_not_exceed_page_size_plus_2`, `test_exact_counterexample_3000_tied_rows_page_size_1`, `test_export_edge_cases_and_plan_boundaries` |
| C4 | `test_cli_regressions_and_every_command`, `test_export_edge_cases_and_plan_boundaries` |
