import json
import os
import socket
import subprocess
import time
import urllib.error
import urllib.request

APP_DIR = os.environ.get("FLAGD_APP_DIR", "/app")
FLAGD = os.environ.get("FLAGD_BINARY", "/app/flagd")


def free_port():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()
    return port


class FlagdService:
    def __init__(self, data_dir, port=None):
        self.data_dir = data_dir
        self.port = port if port is not None else free_port()
        self.process = None

    @property
    def base_url(self):
        return f"http://127.0.0.1:{self.port}"

    def start(self, timeout=5.0):
        if self.process is not None and self.process.poll() is None:
            raise RuntimeError("service is already running")
        self.process = subprocess.Popen(
            [FLAGD, "serve", "--data-dir", self.data_dir, "--port", str(self.port)],
            cwd=APP_DIR,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                raise RuntimeError(f"flagd exited during startup with status {self.process.returncode}")
            try:
                status, _, _ = self.request("GET", "/flags")
                if status == 200:
                    return
            except (urllib.error.URLError, TimeoutError, OSError):
                pass
            time.sleep(0.02)
        self.stop()
        raise RuntimeError("flagd did not become ready")

    def _wait(self, timeout=2.0):
        if self.process is None:
            return
        try:
            self.process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait(timeout=timeout)

    def stop(self):
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
        self._wait()
        self.process = None

    def crash(self):
        if self.process is not None and self.process.poll() is None:
            self.process.kill()
        self._wait()
        self.process = None

    def restart(self):
        self.stop()
        self.start()

    def crash_restart(self):
        self.crash()
        self.start()

    def request(self, method, path, payload=None, timeout=2.0):
        data = None
        headers = {}
        if payload is not None:
            data = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(self.base_url + path, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                status = response.status
                body = response.read()
        except urllib.error.HTTPError as exc:
            status = exc.code
            body = exc.read()
        if body:
            try:
                value = json.loads(body.decode("utf-8"))
            except json.JSONDecodeError:
                value = body.decode("utf-8", errors="replace")
        else:
            value = None
        return status, value, body

    def post_flag(self, request_id, name, value, timeout=2.0):
        return self.request("POST", "/flag", {"request_id": request_id, "name": name, "value": value}, timeout)

    def flags(self, timeout=2.0):
        status, value, _ = self.request("GET", "/flags", timeout=timeout)
        if status != 200 or not isinstance(value, dict):
            raise AssertionError(f"GET /flags failed: status={status}, body={value!r}")
        return value

    def stats(self, timeout=2.0):
        status, value, _ = self.request("GET", "/stats", timeout=timeout)
        if status != 200 or not isinstance(value, dict):
            raise AssertionError(f"GET /stats failed: status={status}, body={value!r}")
        return value

    def take_snapshot(self, timeout=2.0):
        return self.request("POST", "/snapshot", timeout=timeout)

    def snapshot_data(self):
        path = os.path.join(self.data_dir, "snapshot.json")
        with open(path, encoding="utf-8") as f:
            return json.load(f)

    def wait_for_dedup_bound(self, max_entries=8, timeout=2.0):
        deadline = time.monotonic() + timeout
        last = None
        while time.monotonic() < deadline:
            last = self.stats().get("dedup_count")
            if isinstance(last, int) and last <= max_entries:
                return last
            time.sleep(0.02)
        raise AssertionError(f"live dedup map did not stay bounded; last count={last!r}")

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.stop()
        return False
