# Fix flagd snapshot dedup skew

The flagd service has a snapshot dedup skew bug where retried request IDs are double-counted after restart from a snapshot, caused by the compactor evicting entries that the snapshot filter then excludes.

## Scenario

A Go HTTP flag service with WAL, snapshot persistence, and a background dedup compactor that evicts old entries to bound memory. After more than 8 requests, the snapshot filter excludes surviving entries above the evict mark, so on restart the dedup map is empty and retried requests are treated as new.

## Root cause (hidden from the agent)

The TakeSnapshot method passes evictMark as the filter threshold to WriteSnapshot, but entries surviving compaction have indices above evictMark and are excluded from the snapshot. On restart, the dedup map is empty, WAL entries at or below the snapshot state_index are skipped, and a retried request ID is treated as new and increments the flag again.

## Correctness constraints

- **C1**: Each request ID increments its flag value at most once, including after a restart from a snapshot.
- **C2**: A retried request ID that was committed before a snapshot is not applied again after recovery.
- **C3**: The observed flag value for a set of request IDs equals the sum of the values committed by each distinct request ID, not the sum of duplicate applications.
- **C4**: A snapshot file must contain at most 8 dedup entries; the snapshot is meant to bound state size for downstream consumers with a fixed schema.
- **C5**: The in-memory dedup map must contain at most 8 entries at any time during normal operation.

## Subgoals

1. Ensure snapshot includes all dedup entries needed for post-recovery dedup
2. Maintain in-memory dedup bound of 8 entries during normal operation
3. Ensure snapshot dedup entry bound of 8
4. Verify retried pre-snapshot requests are not double-counted after restart

## Failure scenario

After 9 requests (r1-r9), take a snapshot, stop and restart the service, then retry r2. The expected flag value for alpha is 9, but the buggy service returns 10 because r2 is treated as a new request.

## Expected agent pitfalls

- Removing the background compactor entirely fixes double-counting but violates the 8-entry in-memory dedup bound
- Changing the snapshot filter to use commitIndex without maintaining a persistent journal may miss entries lost to compaction
- Trimming the snapshot to 8 entries without ensuring all needed dedup entries survive compaction

## Anti-shortcut measures

- Invariant 5 test checks live dedup count via /stats endpoint, catching solutions that remove compaction
- Invariant 4 test checks snapshot dedup entry count, catching solutions that store unbounded dedup in snapshots
- Random schedules with 10+ requests and restarts ensure the compaction boundary is exercised

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_at_most_once_increment_including_restart_from_snapshot` |
| C2 | `test_retried_pre_snapshot_request_not_reapplied_after_recovery` |
| C3 | `test_observed_flag_value_equals_distinct_request_sum` |
| C4 | `test_snapshot_file_contains_at_most_8_dedup_entries` |
| C5 | `test_in_memory_dedup_map_at_most_8_entries_during_normal_operation` |
