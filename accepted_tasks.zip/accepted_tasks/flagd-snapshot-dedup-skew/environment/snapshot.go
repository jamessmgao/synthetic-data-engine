package main

import (
"encoding/json"
"fmt"
"os"
"path/filepath"
)

type SnapshotData struct {
StateIndex  uint64            `json:"state_index"`
CompactMark uint64            `json:"compact_mark"`
Flags       map[string]int    `json:"flags"`
Dedup       map[string]uint64 `json:"dedup"`
}

func snapshotPath(dir string) string {
return filepath.Join(dir, "snapshot.json")
}

func writeJSONFile(path string, v any) error {
tmp := path + ".tmp"
b, err := json.MarshalIndent(v, "", "  ")
if err != nil {
return err
}
f, err := os.Create(tmp)
if err != nil {
return err
}
if _, err := f.Write(b); err != nil {
f.Close()
return err
}
if err := f.Sync(); err != nil {
f.Close()
return err
}
if err := f.Close(); err != nil {
return err
}
return os.Rename(tmp, path)
}

func WriteSnapshot(dir string, stateIndex uint64, mark uint64, flags map[string]int, dedup map[string]uint64) error {
data := SnapshotData{
StateIndex:  stateIndex,
CompactMark: mark,
Flags:       make(map[string]int),
Dedup:       make(map[string]uint64),
}
for k, v := range flags {
data.Flags[k] = v
}
for k, v := range dedup {
if v <= mark {
data.Dedup[k] = v
}
}
return writeJSONFile(snapshotPath(dir), data)
}

func LoadSnapshot(dir string) (*SnapshotData, error) {
b, err := os.ReadFile(snapshotPath(dir))
if os.IsNotExist(err) {
return nil, nil
}
if err != nil {
return nil, err
}
var s SnapshotData
if err := json.Unmarshal(b, &s); err != nil {
return nil, fmt.Errorf("load snapshot: %w", err)
}
return &s, nil
}
