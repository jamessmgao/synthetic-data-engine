package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

const maxDedupEntries = 8

type WALEntry struct {
	Index     uint64 `json:"index"`
	RequestID string `json:"request_id"`
	Name      string `json:"name"`
	Value     int    `json:"value"`
}

type SetRequest struct {
	RequestID string `json:"request_id"`
	Name      string `json:"name"`
	Value     int    `json:"value"`
}

type SetResponse struct {
	Name  string `json:"name"`
	Value int    `json:"value"`
	Index uint64 `json:"index"`
}

type Service struct {
	mu          sync.Mutex
	dataDir     string
	flags       map[string]int
	dedup       map[string]uint64
	lastIndex   uint64
	commitIndex uint64
	evictMark   uint64
	walFile     *os.File
	done        chan struct{}
}

func NewService(dataDir string) (*Service, error) {
	if err := os.MkdirAll(dataDir, 0755); err != nil {
		return nil, err
	}
	s := &Service{
		dataDir: dataDir,
		flags:   make(map[string]int),
		dedup:   make(map[string]uint64),
		done:    make(chan struct{}),
	}
	snap, err := LoadSnapshot(dataDir)
	if err != nil {
		return nil, err
	}
	if snap != nil {
		s.flags = snap.Flags
		if s.flags == nil {
			s.flags = make(map[string]int)
		}
		s.dedup = snap.Dedup
		if s.dedup == nil {
			s.dedup = make(map[string]uint64)
		}
		s.commitIndex = snap.StateIndex
		s.lastIndex = snap.StateIndex
	}
	walPath := filepath.Join(dataDir, "wal.json")
	f, err := os.OpenFile(walPath, os.O_CREATE|os.O_RDWR|os.O_APPEND, 0644)
	if err != nil {
		return nil, err
	}
	s.walFile = f
	if err := s.replayWAL(); err != nil {
		f.Close()
		return nil, err
	}
	s.runBackgroundTasks()
	return s, nil
}

func (s *Service) runBackgroundTasks() {
	go func() {
		ticker := time.NewTicker(50 * time.Millisecond)
		defer ticker.Stop()
		for {
			select {
			case <-s.done:
				return
			case <-ticker.C:
				s.mu.Lock()
				s.compactDedup()
				s.mu.Unlock()
			}
		}
	}()
}

func (s *Service) replayWAL() error {
	data, err := os.ReadFile(filepath.Join(s.dataDir, "wal.json"))
	if err != nil {
		return nil
	}
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		var entry WALEntry
		if err := json.Unmarshal([]byte(line), &entry); err != nil {
			continue
		}
		if entry.Index <= s.commitIndex {
			continue
		}
		s.flags[entry.Name] += entry.Value
		s.dedup[entry.RequestID] = entry.Index
		if entry.Index > s.lastIndex {
			s.lastIndex = entry.Index
		}
		s.commitIndex = entry.Index
	}
	return nil
}

func (s *Service) appendWAL(entry WALEntry) error {
	b, err := json.Marshal(entry)
	if err != nil {
		return err
	}
	b = append(b, '\n')
	if _, err := s.walFile.Write(b); err != nil {
		return err
	}
	return s.walFile.Sync()
}

func (s *Service) compactDedup() {
	if len(s.dedup) <= maxDedupEntries {
		if s.commitIndex > uint64(maxDedupEntries) {
			s.evictMark = s.commitIndex - uint64(maxDedupEntries)
		} else {
			s.evictMark = 0
		}
		return
	}
	type kv struct {
		key string
		val uint64
	}
	var entries []kv
	for k, v := range s.dedup {
		entries = append(entries, kv{k, v})
	}
	sort.Slice(entries, func(i, j int) bool {
		return entries[i].val < entries[j].val
	})
	toRemove := len(s.dedup) - maxDedupEntries
	for i := 0; i < toRemove; i++ {
		delete(s.dedup, entries[i].key)
	}
	s.evictMark = entries[toRemove-1].val
}

func (s *Service) TakeSnapshot() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.compactDedup()
	return WriteSnapshot(s.dataDir, s.commitIndex, s.evictMark, s.flags, s.dedup)
}

func (s *Service) ProcessRequest(req SetRequest) SetResponse {
	s.mu.Lock()
	defer s.mu.Unlock()

	if idx, ok := s.dedup[req.RequestID]; ok {
		return SetResponse{Name: req.Name, Value: s.flags[req.Name], Index: idx}
	}

	s.lastIndex++
	entry := WALEntry{
		Index:     s.lastIndex,
		RequestID: req.RequestID,
		Name:      req.Name,
		Value:     req.Value,
	}
	if err := s.appendWAL(entry); err != nil {
		panic(fmt.Sprintf("WAL write failed: %v", err))
	}
	s.commitIndex = s.lastIndex
	s.flags[entry.Name] += entry.Value
	s.dedup[req.RequestID] = s.lastIndex
	s.compactDedup()

	return SetResponse{Name: req.Name, Value: s.flags[entry.Name], Index: s.lastIndex}
}

func (s *Service) GetFlag(name string) (int, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	v, ok := s.flags[name]
	return v, ok
}

func (s *Service) Close() {
	close(s.done)
	if s.walFile != nil {
		s.walFile.Close()
	}
}

func (s *Service) DedupCount() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.dedup)
}

func (s *Service) AllFlags() map[string]int {
	s.mu.Lock()
	defer s.mu.Unlock()
	cp := make(map[string]int)
	for k, v := range s.flags {
		cp[k] = v
	}
	return cp
}
