package main

import (
	"testing"
)

// invariant: 5 - The service keeps at most 8 live request-ID records.
func TestDedupStateRemainsBounded(t *testing.T) {
	s, err := NewService(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	for i := 0; i < 12; i++ {
		s.ProcessRequest(SetRequest{RequestID: string(rune('a' + i)), Name: "alpha", Value: 1})
	}
	s.mu.Lock()
	count := len(s.dedup)
	s.mu.Unlock()
	if count > maxDedupEntries {
		t.Fatalf("live request records: %d, want at most %d", count, maxDedupEntries)
	}
}
