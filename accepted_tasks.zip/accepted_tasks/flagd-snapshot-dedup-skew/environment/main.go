package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
)

func main() {
	serveCmd := flag.NewFlagSet("serve", flag.ExitOnError)
	dataDir := serveCmd.String("data-dir", "/tmp/flagd", "data directory")
	port := serveCmd.Int("port", 8080, "HTTP port")

	if len(os.Args) < 2 {
		fmt.Fprintf(os.Stderr, "usage: flagd serve --data-dir DIR --port PORT\n")
		os.Exit(1)
	}

	switch os.Args[1] {
	case "serve":
		serveCmd.Parse(os.Args[2:])
		svc, err := NewService(*dataDir)
		if err != nil {
			log.Fatalf("failed to create service: %v", err)
		}
		defer svc.Close()

		mux := http.NewServeMux()

		mux.HandleFunc("/flag", func(w http.ResponseWriter, r *http.Request) {
			switch r.Method {
			case http.MethodPost:
				body, err := io.ReadAll(r.Body)
				if err != nil {
					http.Error(w, err.Error(), http.StatusBadRequest)
					return
				}
				var req SetRequest
				if err := json.Unmarshal(body, &req); err != nil {
					http.Error(w, err.Error(), http.StatusBadRequest)
					return
				}
				resp := svc.ProcessRequest(req)
				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(resp)
			case http.MethodGet:
				name := r.URL.Query().Get("name")
				v, ok := svc.GetFlag(name)
				if !ok {
					http.Error(w, "not found", http.StatusNotFound)
					return
				}
				w.Header().Set("Content-Type", "application/json")
				json.NewEncoder(w).Encode(map[string]any{"name": name, "value": v})
			default:
				http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			}
		})

		mux.HandleFunc("/snapshot", func(w http.ResponseWriter, r *http.Request) {
			if r.Method != http.MethodPost {
				http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
				return
			}
			if err := svc.TakeSnapshot(); err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
			w.WriteHeader(http.StatusNoContent)
		})

		mux.HandleFunc("/flags", func(w http.ResponseWriter, r *http.Request) {
			if r.Method != http.MethodGet {
				http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
				return
			}
			flags := svc.AllFlags()
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(flags)
		})

		mux.HandleFunc("/stats", func(w http.ResponseWriter, r *http.Request) {
			if r.Method != http.MethodGet {
				http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(map[string]any{"dedup_count": svc.DedupCount()})
		})

		addr := fmt.Sprintf(":%d", *port)
		srv := &http.Server{Addr: addr, Handler: mux}

		go func() {
			if err := srv.ListenAndServe(); err != http.ErrServerClosed {
				log.Fatalf("server error: %v", err)
			}
		}()

		log.Printf("flagd listening on %s", addr)

		sigCh := make(chan os.Signal, 1)
		signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
		<-sigCh
		srv.Close()

	default:
		fmt.Fprintf(os.Stderr, "unknown command: %s\n", os.Args[1])
		os.Exit(1)
	}
}
