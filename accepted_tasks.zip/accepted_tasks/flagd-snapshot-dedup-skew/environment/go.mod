module flagd

go 1.23
