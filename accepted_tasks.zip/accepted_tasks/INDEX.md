# Accepted tasks (46)

Each folder is one accepted task in the Harbor / Terminal-Bench format, with its `verdict.md`.
Accepted means 1-3 of 5 agent runs passed (terminus-2 + glm-5.3-flash, reasoning high).

| Folder | Task id | Family | Mechanism | Accepted version | Agent runs | Cost (ledger) |
|---|---|---|---|---|---|---|
| `greedy-allocator-affinity-conflict` | aws-w2-l5-t01 | algorithmic_constraints | global_constraint_interaction | v1 | ✓✓✗✗✓ | $1.00 |
| `collab-editor-merge-planner` | aws-w4-l5-algnew-t02 | algorithmic_constraints | unsound_dominance_pruning | v2 | ·✓✗✓✗ | $8.81 |
| `matchmaker-durable-queue-optimum` | aws-w4-l5-algnew-t04 | algorithmic_constraints | state_key_omits_rare_component | v4 | ·✗✓·✗ | $12.09 |
| `url-shortener-budget-tiebreak` | aws-w5-l5-algnew-t03 | algorithmic_constraints | local_tiebreak_not_global_lexicographic | v1 | ✓✗✓✗✓ | $5.65 |
| `quota-gateway-wraparound-optimality` | aws-w5-l5-algnew-t05 | algorithmic_constraints | wraparound_boundary_in_sweep | v2 | ✓✗✗✗✗ | $7.52 |
| `incremental-scope-parse` | aws-w1-l2-t03 | compilers_parsers | stateful_incremental_parse | v2 | ✗✗✗✓✗ | $6.29 |
| `template-runtime-aliasing` | aws-w1-l2-t05 | compilers_parsers | aliasing_side_effects | v1 | ✓✓✗✗✗ | $1.97 |
| `stateful-template-snapshot-edit` | aws-w1-l4-t05 | compilers_parsers | stateful_incremental_parse | v2 | ✓✓✗✓✗ | $5.07 |
| `alias-freeze-transform` | aws-w1-l5-t02 | compilers_parsers | semantics_changing_transform | v3 | ✓✗✗✗✗ | $9.05 |
| `shadow-aware-eval-canonicalization` | aws-w2-l5-t02 | compilers_parsers | fragmented_frames | v4 | ✗✗✗✗✓ | $17.59 |
| `regex-macro-hygiene` | aws-w7-l3-new-b-t02 | compilers_parsers | macro_hygiene_capture | v3 | ✓✓✗✓✗ | $7.53 |
| `sql-parser-cte-leak` | aws-w7-l3-new-t01 | compilers_parsers | error_recovery_state_leak | v1 | ✗✗✗✗✓ | $2.74 |
| `charge-retry-compensation` | aws-iter2-t01 | cross_component_stateful | compensation_after_irreversible_effect | v1 | ✗✓✓✗✗ | $3.10 |
| `order-payment-retry-cache` | aws-iter2-t07 | cross_component_stateful | retry_cache_commit_interaction | v1 | ✓✓✓✗✗ | $1.87 |
| `video-pipeline-saga-refund-block` | aws-w7-l3-new-b-t01 | cross_component_stateful | saga_timeout_double_compensation | v1 | ✗✓✓✗✗ | $1.52 |
| `saga-timeout-double-compensation` | aws-w8-l1-new-t04 | cross_component_stateful | saga_timeout_double_compensation | v2 | ✗✓✗✓· | $12.12 |
| `airline-seat-clock-skew` | aws-w9-l1-new-t02 | cross_component_stateful | wall_clock_ordering_skew | v2 | ✓✓✗·✗ | $2.86 |
| `build-cache-protocol-cross-state-v3` | aws-w9-l1-new-t03 | cross_component_stateful | protocol_wrong_state_accept | v3 | ✗✓✗·✗ | $9.57 |
| `quota-charge-idempotent-retry` | aws-iter2-t03 | database_consistency | idempotent_retry | v2 | ✓✗✓✓✗ | $6.22 |
| `charge-ledger-retry-credit` | aws-iter2-t08 | database_consistency | isolation_anomaly | v2 | ✓✗✗✗✓ | $4.84 |
| `reservation-dispatch-recovery` | aws-w1-l1-t02 | database_consistency | crash_between_commit_and_effect | v1 | ✓✓✗✗✗ | $3.80 |
| `payment-settlement-recovery` | aws-w1-l1-t03 | database_consistency | idempotent_retry | v2 | ✗✓✗✗✗ | $6.33 |
| `bank-write-skew` | aws-w1-l1-t05 | database_consistency | write_skew | v1 | ✗✗✓✓✓ | $3.54 |
| `charge-ledger-crash-safety` | aws-w2-l4-t02 | database_consistency | isolation_anomaly | v3 | ✗✗✓✗✗ | $8.75 |
| `warehouse-pick-capacity` | aws-w7-l3-new-t04 | database_consistency | phantom_range_check | v1 | ✓✓✗✗✓ | $4.24 |
| `quorum-compaction-failover` | aws-iter2-t06 | distributed_concurrency | partial_failure_recovery | v3 | ✗✗✓✗· | $8.99 |
| `replicated-log-failover-dedup` | aws-iter2-t10 | distributed_concurrency | adversarial_schedule | v1 | ✓✗✗✓✗ | $4.38 |
| `replicated-ledger-recovery` | aws-w1-l3-t03 | distributed_concurrency | linearizability_violation | v1 | ··✗✓✗ | $4.28 |
| `replicated-ledger-failover` | aws-w1-l3-t05 | distributed_concurrency | lost_acknowledged_write | v1 | ✗✓✓✗✓ | $7.69 |
| `distributed-ledger-lost-ack` | aws-w2-l3-t01 | distributed_concurrency | lost_acknowledged_write | v2 | ✓✗✗✓✓ | $6.59 |
| `lost-acknowledged-write-ledger` | aws-w2-l4-t03 | distributed_concurrency | lost_acknowledged_write | v4 | ✗✗✓·· | $17.31 |
| `replicated-kv-linearizability` | aws-w4-l2-t01 | distributed_concurrency | linearizability_violation | v2 | ✗✗✓✓· | $3.76 |
| `leaderboard-seasons-idempotency` | aws-w5-l2-b-t01 | distributed_concurrency | tenant_key_dropped_on_replay | v2 | ✗✗✗·✓ | $7.82 |
| `elevator-group-reconfig-quorum` | aws-w5-l2-b-t03 | distributed_concurrency | reconfig_quorum_early_switch | v2 | ✓✓✗✗✓ | $17.65 |
| `replicated-job-queue` | aws-w5-l2-b-t04 | distributed_concurrency | session_index_without_term | v3 | ✗✓✗✓· | $14.65 |
| `library-loans-dedup-truncated-suffix` | aws-w6-l2-t01 | distributed_concurrency | dedup_watermark_from_truncated_suffix | v1 | ·✗·✗✓ | $5.43 |
| `replicated-ledger-recovery-aws-w7-l1-dc-new-t01` | aws-w7-l1-dc-new-t01 | distributed_concurrency | partial_failure_recovery | v1 | ✗··✗✓ | $1.51 |
| `snapshot-dedup-skew-ride-dispatch` | aws-w7-l2-t03 | distributed_concurrency | snapshot_dedup_skew | v4 | ✗✗✓✗· | $9.00 |
| `tenant-key-dropped-on-replay` | aws-w7-l2-t04 | distributed_concurrency | tenant_key_dropped_on_replay | v4 | ··✗✗✓ | $9.95 |
| `flagd-snapshot-dedup-skew` | aws-w9-l4-dist-t01 | distributed_concurrency | snapshot_dedup_skew | v3 | ✗✓✗·· | $9.74 |
| `reconcile-ledger-resource-bound` | aws-iter2-t09 | performance_resources | memory_bound | v2 | ✓✗✗✓✓ | $7.85 |
| `timeline-merger-memory` | aws-w1-l5-t01 | performance_resources | memory_bound | v1 | ✗✗·✓✓ | $3.73 |
| `presence-stampede-fix` | aws-w10-l4-perf-t01 | performance_resources | stampede_on_shared_miss | v1 | ✗✓✗✓✓ | $4.39 |
| `kvstore-export-pagination-rescan` | aws-w8-l4-perf-t01 | performance_resources | offset_pagination_rescan | v3 | ·✗·✓✗ | $11.24 |
| `feed-cache-stampede` | aws-w9-l4-perf-t01 | performance_resources | stampede_on_shared_miss | v1 | ✓✓✗✓✗ | $2.61 |
| `rbac-entitlement-decimal-allocation` | aws-w9-l4-perf-t03 | performance_resources | reassociation_drift | v4 | ✗✓✗✗✓ | $10.13 |
