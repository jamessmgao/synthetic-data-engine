package main

import (
    "fmt"
)

type ConflictGraph map[string]map[string]bool

func buildConflictGraph(conflicts []ConflictPair) ConflictGraph {
    graph := make(ConflictGraph)
    for _, c := range conflicts {
        if graph[c.A] == nil {
            graph[c.A] = make(map[string]bool)
        }
        if graph[c.B] == nil {
            graph[c.B] = make(map[string]bool)
        }
        graph[c.A][c.B] = true
        graph[c.B][c.A] = true
    }
    return graph
}

type placement struct {
    taskMachine  map[string]string
    machineLoad  map[string]int
    machineTasks map[string]map[string]bool
}

func newPlacement() *placement {
    return &placement{
        taskMachine:  make(map[string]string),
        machineLoad:  make(map[string]int),
        machineTasks: make(map[string]map[string]bool),
    }
}

func (p *placement) place(taskID, machineID string, size int) {
    p.taskMachine[taskID] = machineID
    p.machineLoad[machineID] += size
    if p.machineTasks[machineID] == nil {
        p.machineTasks[machineID] = make(map[string]bool)
    }
    p.machineTasks[machineID][taskID] = true
}

func (p *placement) hasConflictOn(graph ConflictGraph, taskID, machineID string) bool {
    for t := range p.machineTasks[machineID] {
        if graph[taskID] != nil && graph[taskID][t] {
            return true
        }
    }
    return false
}

func findMachine(machines []Machine, id string) *Machine {
    for i := range machines {
        if machines[i].ID == id {
            return &machines[i]
        }
    }
    return nil
}

func RunAllocation(req AllocateRequest) AllocateResponse {
    for _, m := range req.Machines {
        if m.Capacity <= 0 {
            return AllocateResponse{Success: false, Error: fmt.Sprintf("machine %s has non-positive capacity", m.ID)}
        }
    }
    taskIDs := make(map[string]bool)
    for _, t := range req.Tasks {
        if taskIDs[t.ID] {
            return AllocateResponse{Success: false, Error: fmt.Sprintf("duplicate task id %s", t.ID)}
        }
        taskIDs[t.ID] = true
        if t.Size <= 0 {
            return AllocateResponse{Success: false, Error: fmt.Sprintf("task %s has non-positive size", t.ID)}
        }
    }
    for _, c := range req.Conflicts {
        if !taskIDs[c.A] || !taskIDs[c.B] {
            return AllocateResponse{Success: false, Error: "conflict references unknown task"}
        }
    }
    graph := buildConflictGraph(req.Conflicts)
    groups := make(map[string][]Task)
    var groupOrder []string
    var independent []Task
    for _, t := range req.Tasks {
        if t.Group != "" {
            if _, ok := groups[t.Group]; !ok {
                groupOrder = append(groupOrder, t.Group)
            }
            groups[t.Group] = append(groups[t.Group], t)
        } else {
            independent = append(independent, t)
        }
    }
    p := newPlacement()
    for _, g := range groupOrder {
        total := 0
        for _, t := range groups[g] {
            total += t.Size
        }
        placed := false
        for _, m := range req.Machines {
            if p.machineLoad[m.ID]+total > m.Capacity {
                continue
            }
            conflict := false
            for _, t := range groups[g] {
                if p.hasConflictOn(graph, t.ID, m.ID) {
                    conflict = true
                    break
                }
            }
            if conflict {
                continue
            }
            for _, t := range groups[g] {
                p.place(t.ID, m.ID, t.Size)
            }
            placed = true
            break
        }
        if !placed {
            return AllocateResponse{Success: false, Error: fmt.Sprintf("unable to place group %s", g)}
        }
    }
    for _, t := range independent {
        placed := false
        for _, m := range req.Machines {
            if p.machineLoad[m.ID]+t.Size > m.Capacity {
                continue
            }
            if p.hasConflictOn(graph, t.ID, m.ID) {
                continue
            }
            p.place(t.ID, m.ID, t.Size)
            placed = true
            break
        }
        if !placed {
            return AllocateResponse{Success: false, Error: fmt.Sprintf("unable to place task %s", t.ID)}
        }
    }
    assignments := make([]TaskAssignment, 0)
    for _, t := range req.Tasks {
        assignments = append(assignments, TaskAssignment{TaskID: t.ID, MachineID: p.taskMachine[t.ID]})
    }
    return AllocateResponse{Success: true, Assignments: assignments}
}
