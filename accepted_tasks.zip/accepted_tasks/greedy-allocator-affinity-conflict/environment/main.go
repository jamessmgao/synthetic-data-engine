package main

import (
"encoding/json"
"log"
"net/http"
)

type Machine struct {
ID       string `json:"id"`
Capacity int    `json:"capacity"`
}

type Task struct {
ID    string `json:"id"`
Size  int    `json:"size"`
Group string `json:"group,omitempty"`
}

type ConflictPair struct {
A string `json:"a"`
B string `json:"b"`
}

type AllocateRequest struct {
Machines  []Machine      `json:"machines"`
Tasks     []Task         `json:"tasks"`
Conflicts []ConflictPair `json:"conflicts"`
}

type TaskAssignment struct {
TaskID    string `json:"task_id"`
MachineID string `json:"machine_id"`
}

type AllocateResponse struct {
Success     bool             `json:"success"`
Assignments []TaskAssignment `json:"assignments,omitempty"`
Error       string           `json:"error,omitempty"`
}

func main() {
http.HandleFunc("/allocate", handleAllocate)
http.HandleFunc("/health", handleHealth)
log.Println("allocator starting on :8080")
log.Fatal(http.ListenAndServe(":8080", nil))
}

func handleHealth(w http.ResponseWriter, r *http.Request) {
w.WriteHeader(200)
w.Write([]byte("ok"))
}

func handleAllocate(w http.ResponseWriter, r *http.Request) {
if r.Method != http.MethodPost {
http.Error(w, "method not allowed", 405)
return
}
var req AllocateRequest
if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
http.Error(w, "bad request", 400)
return
}
result := RunAllocation(req)
w.Header().Set("Content-Type", "application/json")
json.NewEncoder(w).Encode(result)
}
