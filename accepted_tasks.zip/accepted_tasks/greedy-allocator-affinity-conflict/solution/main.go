package main

import (
    "encoding/json"
    "log"
    "net/http"
)

type Machine struct {
    ID       string `json:"id"`
    Capacity int    `json:"capacity"`
}

type Task struct {
    ID    string `json:"id"`
    Size  int    `json:"size"`
    Group string `json:"group,omitempty"`
}

type ConflictPair struct {
    A string `json:"a"`
    B string `json:"b"`
}

type AllocateRequest struct {
    Machines  []Machine      `json:"machines"`
    Tasks     []Task         `json:"tasks"`
    Conflicts []ConflictPair `json:"conflicts"`
}

type TaskAssignment struct {
    TaskID    string `json:"task_id"`
    MachineID string `json:"machine_id"`
}

type AllocateResponse struct {
    Success     bool             `json:"success"`
    Assignments []TaskAssignment `json:"assignments,omitempty"`
    Error       string           `json:"error,omitempty"`
}

func main() {
    http.HandleFunc("/allocate", handleAllocate)
    http.HandleFunc("/health", handleHealth)
    log.Println("allocator starting on :8080")
    log.Fatal(http.ListenAndServe(":8080", nil))
}

func handleHealth(w http.ResponseWriter, r *http.Request) {
    w.WriteHeader(200)
    w.Write([]byte("ok"))
}

func handleAllocate(w http.ResponseWriter, r *http.Request) {
    if r.Method != http.MethodPost {
        http.Error(w, "method not allowed", 405)
        return
    }
    var req AllocateRequest
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, "bad request", 400)
        return
    }
    result := RunAllocation(req)
    if result.Success && !validateResponse(req, result) {
        result = AllocateResponse{Success: false, Error: "assignment validation failed"}
    }
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(result)
}

func validateResponse(req AllocateRequest, resp AllocateResponse) bool {
    if !resp.Success {
        return true
    }
    assigned := make(map[string]string)
    for _, a := range resp.Assignments {
        assigned[a.TaskID] = a.MachineID
    }
    for _, t := range req.Tasks {
        if _, ok := assigned[t.ID]; !ok {
            return false
        }
    }
    machineCaps := make(map[string]int)
    for _, m := range req.Machines {
        machineCaps[m.ID] = m.Capacity
    }
    loads := make(map[string]int)
    for _, t := range req.Tasks {
        loads[assigned[t.ID]] += t.Size
    }
    for m, load := range loads {
        if load > machineCaps[m] {
            return false
        }
    }
    for _, c := range req.Conflicts {
        if assigned[c.A] == assigned[c.B] {
            return false
        }
    }
    groupMachine := make(map[string]string)
    for _, t := range req.Tasks {
        if t.Group != "" {
            if prev, ok := groupMachine[t.Group]; ok {
                if prev != assigned[t.ID] {
                    return false
                }
            } else {
                groupMachine[t.Group] = assigned[t.ID]
            }
        }
    }
    return true
}
