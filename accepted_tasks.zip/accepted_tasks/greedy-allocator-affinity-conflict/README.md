# Greedy allocator affinity and conflict interaction

A Go allocation service greedily places affinity groups then independent tasks without backtracking. It rejects feasible requests when a valid assignment requires moving groups or independents differently. The fix must make every feasible request succeed while preserving validation and stateless behavior.

## Scenario

The agent is given a Go HTTP allocator with /allocate and /health endpoints. /allocate accepts machines, tasks, affinity groups, and conflict pairs, then returns JSON success/assignments or an error. The current implementation returns success=false for some feasible requests.

## Root cause (hidden from the agent)

RunAllocation in allocator.go places affinity groups in first-fit order, then independent tasks in first-fit order. It never backtracks or relocates already placed groups/independents, so it rejects feasible requests when a later task can only be placed by moving earlier placements.

## Correctness constraints

- **C1**: Every feasible allocation request returns success with assignments satisfying all capacity, conflict, and affinity constraints
- **C2**: All tasks in the same affinity group are assigned to the same machine
- **C3**: No two conflicting tasks are assigned to the same machine
- **C4**: No machine is assigned more than its capacity

## Subgoals

1. Reproduce the rejection through the HTTP interface
2. Replace greedy non-backtracking placement with exhaustive search over small machine/group/task assignments
3. Preserve validation for duplicate tasks, non-positive sizes/capacities, and unknown conflict references
4. Verify stateless behavior under restart and concurrent requests

## Failure scenario

Tests start the service, POST feasible allocation requests including the hidden counterexample and randomized generated feasible requests, and assert success with assignments satisfying capacity, conflict, and affinity constraints.

## Expected agent pitfalls

- A single-group relocation heuristic fixes the visible symptom but fails when two groups must move simultaneously
- Changing only task order may pass some cases but not all feasible inputs
- Breaking existing validation or assuming persistent state across restarts

## Anti-shortcut measures

- Randomized feasible inputs use hidden known assignments, so hard-coded outputs fail
- The wrong fix that relocates only the most recent group is rejected by a deeper two-group case
- Restart and concurrent schedules ensure no process-local shortcut passes

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_counterexample`, `test_invariant_1_feasible_success`, `test_restart_preserves_behavior`, `test_concurrent_requests`, `test_single_machine_tight_fit`, `test_all_tasks_conflict` |
| C2 | `test_invariant_2_affinity_group`, `test_counterexample`, `test_restart_preserves_behavior`, `test_concurrent_requests` |
| C3 | `test_invariant_3_no_conflicts`, `test_counterexample`, `test_restart_preserves_behavior`, `test_concurrent_requests`, `test_all_tasks_conflict` |
| C4 | `test_invariant_4_capacity`, `test_counterexample`, `test_restart_preserves_behavior`, `test_concurrent_requests`, `test_single_machine_tight_fit` |
