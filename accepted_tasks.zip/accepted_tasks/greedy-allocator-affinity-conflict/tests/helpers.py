import json
import subprocess
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

ALLOCATOR = "/app/bin/allocator"
BASE_URL = "http://127.0.0.1:8080"


class AllocatorService:
    def __init__(self):
        self.process = None

    def start(self):
        self.process = subprocess.Popen(
            [ALLOCATOR], cwd="/app", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        deadline = time.monotonic() + 5.0
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                raise RuntimeError("allocator exited during startup")
            try:
                with urllib.request.urlopen(BASE_URL + "/health", timeout=0.2) as response:
                    if response.status == 200 and response.read() == b"ok":
                        return
            except Exception:
                time.sleep(0.02)
        raise RuntimeError("allocator did not become ready")

    def kill(self):
        if self.process is not None and self.process.poll() is None:
            self.process.kill()
            self.process.wait(timeout=2)
        if self.process is not None:
            self.process.stdout

    def restart(self):
        self.kill()
        self.start()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc, traceback):
        self.kill()


def post(request, timeout=2.0):
    data = json.dumps(request, separators=(",", ":")).encode()
    req = urllib.request.Request(
        BASE_URL + "/allocate",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return response.status, json.loads(response.read().decode())
    except urllib.error.HTTPError as error:
        body = error.read().decode(errors="replace")
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            payload = body
        return error.code, payload


def random_feasible_request(rng):
    """Build a request whose hidden assignment proves it is feasible."""
    machine_count = rng.randint(2, 4)
    machine_ids = [f"m{index}" for index in range(machine_count)]
    assignment = {}
    tasks = []

    group_count = rng.randint(1, 3)
    for group_index in range(group_count):
        group = f"group{group_index}"
        machine = rng.choice(machine_ids)
        for member_index in rng.sample(range(10), rng.randint(2, 3)):
            task_id = f"g{group_index}_{member_index}"
            size = rng.randint(1, 3)
            tasks.append({"id": task_id, "size": size, "group": group})
            assignment[task_id] = machine

    independent_count = rng.randint(2, 5)
    for index in range(independent_count):
        task_id = f"i{index}"
        size = rng.randint(1, 4)
        tasks.append({"id": task_id, "size": size})
        assignment[task_id] = rng.choice(machine_ids)

    rng.shuffle(tasks)
    all_ids = [task["id"] for task in tasks]
    cross_machine = [
        (left, right)
        for left in all_ids
        for right in all_ids
        if left < right and assignment[left] != assignment[right]
    ]
    rng.shuffle(cross_machine)
    conflicts = [
        {"a": left, "b": right}
        for left, right in cross_machine[: rng.randint(1, min(4, len(cross_machine)))]
    ]

    loads = {machine_id: 0 for machine_id in machine_ids}
    for task in tasks:
        loads[assignment[task["id"]]] += task["size"]
    machines = [
        {"id": machine_id, "capacity": max(1, loads[machine_id] + rng.randint(0, 3))}
        for machine_id in machine_ids
    ]
    rng.shuffle(machines)
    request = {"machines": machines, "tasks": tasks, "conflicts": conflicts}

    assert len({m["id"] for m in machines}) == len(machines)
    assert len(all_ids) == len(set(all_ids))
    assert all(m["capacity"] > 0 for m in machines)
    assert all(t["size"] > 0 for t in tasks)
    known = set(all_ids)
    assert all(c["a"] != c["b"] and c["a"] in known and c["b"] in known for c in conflicts)
    groups = {}
    for task in tasks:
        if task.get("group"):
            groups.setdefault(task["group"], set()).add(assignment[task["id"]])
    assert all(len(used) == 1 for used in groups.values())
    for conflict in conflicts:
        assert assignment[conflict["a"]] != assignment[conflict["b"]]
    for machine in machines:
        used = sum(t["size"] for t in tasks if assignment[t["id"]] == machine["id"])
        assert used <= machine["capacity"]
    return request


def successful_assignments(request, payload):
    assert payload.get("success") is True, payload
    assignments = payload.get("assignments")
    assert isinstance(assignments, list), payload
    actual = {item["task_id"]: item["machine_id"] for item in assignments}
    expected_tasks = {task["id"] for task in request["tasks"]}
    assert set(actual) == expected_tasks
    machine_ids = {machine["id"] for machine in request["machines"]}
    assert set(actual.values()) <= machine_ids
    assert len(assignments) == len(actual)
    return actual


def affinity_holds(request, actual):
    used = {}
    for task in request["tasks"]:
        group = task.get("group")
        if group:
            machine = actual[task["id"]]
            assert used.setdefault(group, machine) == machine


def conflicts_hold(request, actual):
    for conflict in request["conflicts"]:
        assert actual[conflict["a"]] != actual[conflict["b"]]


def capacity_holds(request, actual):
    loads = {machine["id"]: 0 for machine in request["machines"]}
    for task in request["tasks"]:
        loads[actual[task["id"]]] += task["size"]
    capacities = {machine["id"]: machine["capacity"] for machine in request["machines"]}
    for machine_id, load in loads.items():
        assert load <= capacities[machine_id]


def all_constraints_hold(request, actual):
    affinity_holds(request, actual)
    conflicts_hold(request, actual)
    capacity_holds(request, actual)


def run_random_schedule(service, rng, checker):
    request = random_feasible_request(rng)
    operations = ["request", "concurrent", "restart", "retry"]
    rng.shuffle(operations)
    for operation in operations:
        if operation == "request":
            _, payload = post(request)
            checker(request, successful_assignments(request, payload))
        elif operation == "retry":
            for _ in range(2):
                _, payload = post(request)
                checker(request, successful_assignments(request, payload))
        elif operation == "concurrent":
            with ThreadPoolExecutor(max_workers=3) as pool:
                results = list(pool.map(lambda _: post(request), range(3)))
            for _, payload in results:
                checker(request, successful_assignments(request, payload))
        else:
            service.restart()
            _, payload = post(request)
            checker(request, successful_assignments(request, payload))
