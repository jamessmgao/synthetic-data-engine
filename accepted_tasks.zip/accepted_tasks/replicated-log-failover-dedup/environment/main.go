package main

import (
"encoding/json"
"flag"
"fmt"
"os"
)

type Op struct {
Type      string `json:"op"`
Node      string `json:"node,omitempty"`
From      string `json:"from,omitempty"`
To        string `json:"to,omitempty"`
RequestID string `json:"request_id,omitempty"`
Amount    int    `json:"amount,omitempty"`
Index     int    `json:"index,omitempty"`
Term      int    `json:"term,omitempty"`
}

type Schedule struct {
Base string `json:"base,omitempty"`
Ops  []Op   `json:"ops"`
}

type ResponseRecord struct {
Op        string `json:"op"`
Node      string `json:"node,omitempty"`
RequestID string `json:"request_id,omitempty"`
Status    string `json:"status,omitempty"`
Index     int    `json:"index,omitempty"`
Error     string `json:"error,omitempty"`
}

type NodeResult struct {
ID      string         `json:"id"`
Role    string         `json:"role"`
Term    int            `json:"term"`
Balance int            `json:"balance"`
Log     []Entry        `json:"log"`
Dedup   map[string]int `json:"dedup"`
}

type Result struct {
Responses []ResponseRecord `json:"responses"`
Nodes     []NodeResult     `json:"nodes"`
}

func main() {
var schedule string
flag.StringVar(&schedule, "schedule", "", "path to a schedule file")
flag.Parse()
if schedule == "" {
fmt.Println("world ready")
return
}
data, err := os.ReadFile(schedule)
if err != nil {
fmt.Printf("read schedule: %v\n", err)
os.Exit(2)
}
var sch Schedule
if err := json.Unmarshal(data, &sch); err != nil {
fmt.Printf("parse schedule: %v\n", err)
os.Exit(2)
}
base := sch.Base
if base == "" {
base = "/tmp/world-cluster"
}
os.RemoveAll(base)
cluster, err := NewCluster(base)
if err != nil {
fmt.Printf("start cluster: %v\n", err)
os.Exit(2)
}
result := Result{Responses: []ResponseRecord{}}
for _, op := range sch.Ops {
rec := ResponseRecord{Op: op.Type}
switch op.Type {
case "propose":
n := cluster.Node(op.Node)
if n == nil {
rec.Error = "node not found"
break
}
resp := n.Propose(op.RequestID, op.Amount)
rec.Node = op.Node
rec.RequestID = op.RequestID
rec.Status = resp.Status
rec.Index = resp.Index
case "replicate":
rec.Node = op.From
rec.Error = str(cluster.Replicate(op.From, op.To))
case "commit":
n := cluster.Node(op.Node)
if n == nil {
rec.Error = "node not found"
break
}
rec.Node = op.Node
rec.Index = op.Index
rec.Error = str(n.Commit(op.Index))
case "crash":
n := cluster.Node(op.Node)
if n == nil {
rec.Error = "node not found"
break
}
rec.Node = op.Node
rec.Error = str(cluster.Crash(op.Node))
case "promote":
n := cluster.Node(op.Node)
if n == nil {
rec.Error = "node not found"
break
}
rec.Node = op.Node
rec.Error = str(n.Promote(op.Term))
case "restart":
n := cluster.Node(op.Node)
if n == nil {
rec.Error = "node not found"
break
}
rec.Node = op.Node
rec.Error = str(n.Restart())
default:
rec.Error = "unknown op"
}
result.Responses = append(result.Responses, rec)
}
for _, id := range []string{"n1", "n2", "n3"} {
n := cluster.Node(id)
if n == nil {
continue
}
state := n.store.State()
result.Nodes = append(result.Nodes, NodeResult{
ID:      id,
Role:    n.Role(),
Term:    n.Term(),
Balance: n.Balance(),
Log:     state.Log,
Dedup:   state.Dedup,
})
}
out, err := json.MarshalIndent(result, "", "  ")
if err != nil {
fmt.Printf("marshal result: %v\n", err)
os.Exit(2)
}
fmt.Println(string(out))
}

func str(err error) string {
if err == nil {
return ""
}
return err.Error()
}
