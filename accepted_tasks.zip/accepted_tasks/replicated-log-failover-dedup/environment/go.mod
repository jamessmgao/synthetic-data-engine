module world

go 1.23
