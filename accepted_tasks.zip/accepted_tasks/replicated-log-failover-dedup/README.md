# Replicated Log Commit Consistency Across Failover

A deterministic Go cluster simulator lets an adversarial schedule propose, replicate, commit, crash, promote, and restart nodes. The defect permits stale successful dedup responses and uncommitted follower copies of globally committed requests. The task is to repair commitment propagation while preserving the public schedule interface.

## Scenario

The agent works in a small Go service that executes JSON schedules against a three-node in-process cluster and prints response records plus node state. The existing behavior is deterministic and persists each node store, making failures reproducible through the public CLI.

## Root cause (hidden from the agent)

ReplicateEntry ignores an existing matching entry instead of upgrading it when the copy on the leader has become committed. Promote also leaves stale dedup mappings after uncommitted suffix truncation, so Propose can report ok from a stale index without a committed local entry.

## Correctness constraints

- **C1**: If a request ID is committed on any node, every node that has a log entry for that request ID must have it committed.
- **C2**: A successful propose response for a request ID has a committed log entry with that request ID on the responding node.
- **C3**: The public schedule CLI continues to produce its documented JSON responses and node state, including pending, redirect, successful retry, not-found and unknown-operation errors, roles, terms, balances, log entries, dedup mappings, and idempotent commit and replication.
- **C4**: Correctness survives an external process kill and a fresh-process restart, and independent schedule invocations can run concurrently without interfering with one another.

## Subgoals

1. Reproduce the failover inconsistency through public schedules.
2. Repair commitment propagation for matching replicated entries.
3. Repair request deduplication and propose status around truncation and restart.
4. Preserve all public CLI responses and persisted observable state.
5. Validate deterministic seeded schedules, crashes, retries, process restarts, and concurrent invocations.

## Failure scenario

A leader proposes and replicates an uncommitted request, commits it, replicates again, restarts, promotes a follower, and retries the request. The old follower still has an uncommitted matching entry, while stale dedup can produce a successful response. The exact counterexample and fixed-seed property tests exercise this through /app/world.

## Expected agent pitfalls

- Treating a matching follower entry as already current without upgrading its committed flag.
- Returning success only when the local index is committed but never repairing follower state.
- Deleting stale dedup without accounting for truncated entries and restarts.
- Breaking pending, redirect, idempotent-commit, or exact JSON behavior while repairing the invariant.
- Assuming replication is automatic when the schedule operation is explicit.

## Anti-shortcut measures

- Two dedicated invariant tests replay every logical step for ten fixed seeds.
- The exact failover counterexample is replayed through the public CLI.
- Exact regression and edge tests pin existing observable CLI and state behavior.
- An external SIGKILL and fresh process restart exercise persistence without a system-side crash hook.
- Concurrent independent schedules detect cross-cluster state leakage.
- The plausible local-success wrong fix fails the committed-copy invariant on every seed.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_committed_request_is_committed_wherever_it_appears`, `test_counterexample_retry_after_failover_is_committed_everywhere`, `test_concurrent_independent_schedules_remain_correct` |
| C2 | `test_successful_propose_has_committed_entry_on_responder`, `test_counterexample_retry_after_failover_is_committed_everywhere`, `test_regression_roles_retries_errors_and_exact_state` |
| C3 | `test_regression_roles_retries_errors_and_exact_state`, `test_edge_cases_and_idempotent_operations` |
| C4 | `test_process_sigkill_and_restart_remains_correct`, `test_concurrent_independent_schedules_remain_correct` |
