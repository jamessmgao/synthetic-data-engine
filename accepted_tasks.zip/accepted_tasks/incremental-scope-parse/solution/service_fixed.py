from __future__ import annotations

import json
import sys

from runtime import ResolutionError, Resolver, Runtime, RuntimeErrorKind
from syntax import SyntaxError, duplicate, parse_line


class RequestError(Exception):
    pass


class IncrementalParser:
    def __init__(self):
        self.entries: dict[str, Node] = {}

    def entry(self, source: str, line: int) -> Node:
        node = self.entries.get(source)
        if node is None:
            node = parse_line(source, line)
            self.entries[source] = node
        result = duplicate(node, line)
        if result.kind == "let":
            result.cell = (source, line)
        return result

    def discard(self, source: str) -> None:
        self.entries.pop(source, None)


class Session:
    def __init__(self):
        self.sources: list[str] = []
        self.parser = IncrementalParser()

    def request(self, request: object) -> dict[str, object]:
        if not isinstance(request, dict):
            raise RequestError("request must be an object")
        operation = request.get("op")
        if operation == "append":
            source = self.source(request)
            self.sources.append(source)
            return {"ok": True, "lines": len(self.sources)}
        if operation == "insert":
            index = self.index(request, upper=len(self.sources))
            self.sources.insert(index, self.source(request))
            return {"ok": True, "lines": len(self.sources)}
        if operation == "replace":
            index = self.index(request, upper=len(self.sources) - 1)
            old = self.sources[index]
            replacement = self.source(request)
            self.sources[index] = replacement
            if old != replacement and old not in self.sources:
                self.parser.discard(old)
            return {"ok": True, "lines": len(self.sources)}
        if operation == "delete":
            index = self.index(request, upper=len(self.sources) - 1)
            removed = self.sources.pop(index)
            if removed not in self.sources:
                self.parser.discard(removed)
            return {"ok": True, "lines": len(self.sources)}
        if operation == "run":
            return self.run()
        raise RequestError(f"unknown operation {operation!r}")

    @staticmethod
    def source(request: dict[str, object]) -> str:
        source = request.get("source")
        if not isinstance(source, str):
            raise RequestError("source must be a string")
        return source

    @staticmethod
    def index(request: dict[str, object], upper: int) -> int:
        index = request.get("index")
        if not isinstance(index, int) or isinstance(index, bool):
            raise RequestError("index must be an integer")
        if index < 0 or index > upper:
            raise RequestError("index is out of range")
        return index

    def statements(self) -> list[Node]:
        return [self.parser.entry(source, number)
                for number, source in enumerate(self.sources, 1)]

    def run(self) -> dict[str, object]:
        program = Resolver().resolve(self.statements())
        result = Runtime().execute(program)
        return {"ok": True, "output": result.output}


class Service:
    def __init__(self):
        self.session = Session()

    def handle(self, raw: str) -> dict[str, object]:
        try:
            request = json.loads(raw)
            return self.session.request(request)
        except (RequestError, SyntaxError, ResolutionError, RuntimeErrorKind, json.JSONDecodeError) as error:
            return {"ok": False, "error": str(error)}

    def serve(self) -> None:
        for raw in sys.stdin:
            line = raw.strip()
            if not line:
                continue
            response = self.handle(line)
            print(json.dumps(response, separators=(",", ":")), flush=True)


def main() -> None:
    Service().serve()


if __name__ == "__main__":
    main()
