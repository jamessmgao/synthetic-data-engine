from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Token:
    kind: str
    text: str
    column: int


class SyntaxError(Exception):
    def __init__(self, message: str, line: int, column: int):
        super().__init__(f"line {line}, column {column}: {message}")
        self.line = line
        self.column = column


@dataclass
class Node:
    kind: str
    value: object = None
    kids: list["Node"] = None
    line: int = 0
    column: int = 0
    binding: object = None
    cell: object = None

    def __post_init__(self):
        if self.kids is None:
            self.kids = []




def duplicate(node: Node, line: int) -> Node:
    result = Node(node.kind, node.value, [], line, node.column)
    result.binding = node.binding
    result.cell = node.cell
    for kid in node.kids:
        result.kids.append(duplicate(kid, line))
    return result


class Lexer:
    two_char = {"==", "!=", "<=", ">=", "&&", "||"}
    one_char = set("+-*/()=!<>")

    def __init__(self, source: str, line: int):
        self.source = source
        self.line = line
        self.index = 0

    def error(self, message: str) -> SyntaxError:
        return SyntaxError(message, self.line, self.index + 1)

    def next(self) -> Token:
        while self.index < len(self.source) and self.source[self.index].isspace():
            self.index += 1
        start = self.index
        if start >= len(self.source):
            return Token("eof", "", start)
        char = self.source[start]
        if char.isdigit():
            while self.index < len(self.source) and self.source[self.index].isdigit():
                self.index += 1
            return Token("int", self.source[start:self.index], start)
        if char.isalpha() or char == "_":
            while self.index < len(self.source) and (self.source[self.index].isalnum() or self.source[self.index] == "_"):
                self.index += 1
            return Token("name", self.source[start:self.index], start)
        if self.index + 1 < len(self.source):
            pair = self.source[start:start + 2]
            if pair in self.two_char:
                self.index += 2
                return Token("op", pair, start)
        if char in self.one_char:
            self.index += 1
            return Token("op", char, start)
        raise self.error("unexpected character")

    def tokens(self) -> list[Token]:
        result = []
        while True:
            token = self.next()
            result.append(token)
            if token.kind == "eof":
                return result


class Parser:
    def __init__(self, source: str, line: int):
        self.source = source
        self.tokens = Lexer(source, line).tokens()
        self.position = 0
        self.line = line

    def peek(self) -> Token:
        return self.tokens[self.position]

    def take(self) -> Token:
        token = self.peek()
        self.position += 1
        return token

    def accept(self, text: str) -> Optional[Token]:
        if self.peek().text == text:
            return self.take()
        return None

    def expect(self, text: str) -> Token:
        if self.peek().text != text:
            raise SyntaxError(f"expected {text!r}", self.line, self.peek().column + 1)
        return self.take()

    def at_end(self) -> bool:
        return self.peek().kind == "eof"

    def statement(self) -> Node:
        token = self.peek()
        if token.kind == "name" and token.text == "let":
            self.take()
            target = self.take()
            if target.kind != "name" or target.text in ("block", "end"):
                raise SyntaxError("expected a name", self.line, target.column + 1)
            self.expect("=")
            value = self.expression()
            self.end()
            return Node("let", target.text, [value], self.line, token.column, cell=self.source)
        if token.kind == "name" and token.text == "print":
            self.take()
            value = self.expression()
            self.end()
            return Node("print", None, [value], self.line, token.column)
        if token.kind == "name" and token.text == "block":
            self.take()
            self.end()
            return Node("block_open", None, [], self.line, token.column)
        if token.kind == "name" and token.text == "end":
            self.take()
            self.end()
            return Node("block_close", None, [], self.line, token.column)
        value = self.expression()
        self.end()
        return Node("expression", None, [value], self.line, token.column)

    def end(self) -> None:
        if not self.at_end():
            token = self.peek()
            raise SyntaxError("unexpected trailing input", self.line, token.column + 1)

    def expression(self, minimum: int = 0) -> Node:
        left = self.prefix()
        while True:
            token = self.peek()
            precedence = self.precedence(token)
            if precedence is None or precedence < minimum:
                return left
            self.take()
            right = self.expression(precedence + 1)
            left = Node("binary", token.text, [left, right], self.line, token.column)

    def prefix(self) -> Node:
        token = self.take()
        if token.kind == "int":
            return Node("literal", int(token.text), [], self.line, token.column)
        if token.kind == "name":
            if token.text in ("block", "end", "let", "print"):
                raise SyntaxError("reserved word", self.line, token.column + 1)
            return Node("name", token.text, [], self.line, token.column)
        if token.text == "-":
            return Node("unary", "-", [self.expression(6)], self.line, token.column)
        if token.text == "!":
            return Node("unary", "!", [self.expression(6)], self.line, token.column)
        if token.text == "(":
            inner = self.expression()
            self.expect(")")
            return inner
        raise SyntaxError("expected an expression", self.line, token.column + 1)

    @staticmethod
    def precedence(token: Token) -> Optional[int]:
        if token.kind != "op":
            return None
        return {"||": 1, "&&": 2, "==": 3, "!=": 3,
                "<": 4, ">": 4, "<=": 4, ">=": 4,
                "+": 5, "-": 5, "*": 6, "/": 6}.get(token.text)


def parse_line(source: str, line: int) -> Node:
    return Parser(source, line).statement()
