# Position-sensitive incremental parsing and interpretation

A line-oriented incremental parser caches parsed lines while allowing the current program to be edited. It currently reuses position-independent parse results, causing scope, diagnostic, and storage errors.

## Scenario

The Python service accepts append, insert, replace, delete, and run requests as JSON lines. Repeated source text is common, and later runs must reflect the current program rather than the first position at which a line appeared.

## Root cause (hidden from the agent)

The incremental parser keys ASTs only by source text. Cached nodes retain stale line numbers and declaration identity, so repeated occurrences share bindings and runtime storage even after their program positions change.

## Correctness constraints

- **C1**: A repeated source line resolves in the lexical environment of each program position.
- **C2**: A diagnostic for a source line names that line's position in the current program.
- **C3**: Every declaration in the current program has storage distinct from declarations at other positions, even when source text repeats.

## Subgoals

1. Materialize parse occurrences for the current program without losing parser reuse.
2. Resolve every repeated line against its current lexical position.
3. Report current positions in unresolved-name diagnostics.
4. Give each declaration occurrence storage unique to its current program position.
5. Preserve all existing edit operations, expression semantics, block validation, and response format.

## Failure scenario

A program with repeated declarations and print lines in nested and outer lexical scopes produces the same value at both prints instead of the inner and outer values respectively.

## Expected agent pitfalls

- Cloning ASTs while retaining declaration identity fixes line positions but leaves repeated declarations sharing storage.
- Disabling the parse cache fixes correctness but sacrifices incremental behavior unnecessarily.
- Updating only the top-level node line misses nested expression diagnostics.
- Fixing append alone leaves insert, replace, and delete schedules broken.

## Anti-shortcut measures

- Independent reference evaluation compares complete run responses after every edit.
- Ten fixed seeds drive random edit schedules and repeated source text.
- SIGKILL/restart replay and repeated runs ensure state is reconstructed correctly.
- Two concurrent processes replay the same history to ensure independent session state.

## Requirement-to-test coverage

| Requirement | Tests |
|---|---|
| C1 | `test_repeated_source_line_resolves_in_lexical_environment_at_each_position` |
| C2 | `test_diagnostic_for_source_line_names_current_program_position` |
| C3 | `test_each_declaration_at_a_different_position_has_distinct_storage`, `test_exact_counterexample_shadowing_program` |
