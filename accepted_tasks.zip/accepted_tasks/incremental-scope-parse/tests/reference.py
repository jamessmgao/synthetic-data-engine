from __future__ import annotations

import json
import subprocess
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass


SERVICE = "/app/service.py"
WORKDIR = "/app"


class ServiceProcess:
    def _spawn(self) -> subprocess.Popen:
        return subprocess.Popen(
            ["python3", SERVICE],
            cwd=WORKDIR,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )

    def __init__(self) -> None:
        self.process = self._spawn()
        self.history: list[tuple[dict, dict]] = []

    def request(self, request: dict, record: bool = True) -> dict:
        raw = json.dumps(request, separators=(",", ":"))
        self.process.stdin.write(raw + "\n")
        self.process.stdin.flush()
        line = self.process.stdout.readline()
        if not line:
            _, stderr = self.process.communicate(timeout=5)
            raise AssertionError(f"service exited before responding: {stderr}")
        response = json.loads(line)
        if record:
            self.history.append((request, response))
        return response

    def retry_run(self, expected: dict) -> None:
        again = self.request({"op": "run"}, record=False)
        assert again == expected

    def restart(self) -> None:
        self.process.kill()
        self.process.wait()
        self.process = self._spawn()
        for old_request, old_response in self.history:
            actual = self.request(old_request, record=False)
            assert actual == old_response

    def close(self) -> None:
        self.process.stdin.close()
        returncode = self.process.wait(timeout=5)
        assert returncode == 0


def run_concurrent(history: list[tuple[dict, dict]]) -> list[list[dict]]:
    requests = [request for request, _ in history]
    payload = "".join(
        json.dumps(request, separators=(",", ":")) + "\n" for request in requests
    )
    processes = [
        subprocess.Popen(
            ["python3", SERVICE],
            cwd=WORKDIR,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        for _ in range(2)
    ]
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(
            pool.map(
                lambda process: process.communicate(payload, timeout=10),
                processes,
            )
        )
    responses = []
    for process, (stdout, stderr) in zip(processes, results):
        assert process.returncode == 0, stderr
        responses.append([json.loads(line) for line in stdout.splitlines() if line])
    return responses


class UndefinedName(Exception):
    def __init__(self, name: str):
        self.name = name


def parse_simple(source: str) -> tuple[str, str, str]:
    text = source.strip()
    if text == "block":
        return "block", "", ""
    if text == "end":
        return "end", "", ""
    if text.startswith("let "):
        declaration, separator, value = text[4:].partition("=")
        name, rhs = declaration.strip(), value.strip()
        assert separator and name and rhs
        return "let", name, rhs
    if text.startswith("print "):
        return "print", "", text[6:].strip()
    raise AssertionError("unsupported generated source")


def expected_response(sources: list[str]) -> dict:
    scopes: list[dict[str, tuple[int, str]]] = [{}]
    values: dict[tuple[int, str], int] = {}
    output: list[str] = []

    def value(rhs: str, line_number: int) -> int:
        if rhs.isdigit():
            return int(rhs)
        for scope in reversed(scopes):
            if rhs in scope:
                return values[scope[rhs]]
        raise UndefinedName(rhs)

    for line_number, source in enumerate(sources, 1):
        kind, name, rhs = parse_simple(source)
        if kind == "block":
            scopes.append({})
            continue
        if kind == "end":
            if len(scopes) == 1:
                return {"ok": False, "error": "there is no block to close"}
            scopes.pop()
            continue
        try:
            current = value(rhs, line_number)
        except UndefinedName as error:
            return {
                "ok": False,
                "error": f"line {line_number}: {error.name} is not defined",
            }
        if kind == "let":
            slot = (line_number, source)
            values[slot] = current
            scopes[-1][name] = slot
        else:
            output.append(str(current))

    if len(scopes) != 1:
        return {"ok": False, "error": "a block is not closed"}
    return {"ok": True, "output": output}


def apply_mutation(sources: list[str], request: dict) -> list[str]:
    operation = request["op"]
    if operation == "append":
        return sources + [request["source"]]
    if operation == "insert":
        index = request["index"]
        return sources[:index] + [request["source"]] + sources[index:]
    if operation == "replace":
        index = request["index"]
        return sources[:index] + [request["source"]] + sources[index + 1 :]
    if operation == "delete":
        index = request["index"]
        return sources[:index] + sources[index + 1 :]
    raise AssertionError(f"unsupported mutation {operation}")


def apply_and_check(process: ServiceProcess, sources: list[str], request: dict) -> tuple[list[str], dict]:
    sources = apply_mutation(sources, request)
    acknowledgement = process.request(request)
    assert acknowledgement == {"ok": True, "lines": len(sources)}
    expected = expected_response(sources)
    actual = process.request({"op": "run"})
    assert actual == expected
    process.retry_run(expected)
    return sources, expected
