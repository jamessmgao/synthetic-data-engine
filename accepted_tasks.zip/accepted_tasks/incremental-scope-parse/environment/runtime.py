from __future__ import annotations

from dataclasses import dataclass

from syntax import Node


class ResolutionError(Exception):
    pass


@dataclass
class Declaration:
    slot: object
    name: str
    line: int


@dataclass
class Program:
    statements: list[Node]
    declarations: list[Declaration]


class Scope:
    def __init__(self, parent: "Scope | None" = None):
        self.parent = parent
        self.names: dict[str, int] = {}

    def declare(self, name: str, slot: int) -> None:
        self.names[name] = slot

    def lookup(self, name: str) -> int:
        scope: Scope | None = self
        while scope is not None:
            if name in scope.names:
                return scope.names[name]
            scope = scope.parent
        raise ResolutionError(f"{name} is not defined")


class Resolver:
    def resolve(self, statements: list[Node]) -> Program:
        self.scope = Scope()
        self.declarations: list[Declaration] = []
        for statement in statements:
            self.statement(statement)
        if self.scope.parent is not None:
            raise ResolutionError("a block is not closed")
        return Program(statements, self.declarations)

    def statement(self, node: Node) -> None:
        if node.kind == "block_open":
            self.scope = Scope(self.scope)
            return
        if node.kind == "block_close":
            if self.scope.parent is None:
                raise ResolutionError("there is no block to close")
            self.scope = self.scope.parent
            return
        if node.kind == "let":
            self.expression(node.kids[0])
            node.binding = node.cell
            self.declarations.append(Declaration(node.binding, str(node.value), node.line))
            self.scope.declare(str(node.value), node.binding)
            return
        if node.kind in ("print", "expression"):
            self.expression(node.kids[0])
            return
        raise ResolutionError(f"unsupported statement {node.kind}")


    def expression(self, node: Node) -> None:
        if node.kind == "name":
            if node.binding is None:
                try:
                    node.binding = self.scope.lookup(str(node.value))
                except ResolutionError as error:
                    raise ResolutionError(f"line {node.line}: {error}") from error
            return
        for kid in node.kids:
            self.expression(kid)


class RuntimeErrorKind(Exception):
    pass


@dataclass
class RunResult:
    output: list[str]


class Runtime:
    def execute(self, program: Program) -> RunResult:
        values: dict[object, int] = {}
        output: list[str] = []
        for statement in program.statements:
            if statement.kind == "block_open" or statement.kind == "block_close":
                continue
            if statement.kind == "let":
                values[statement.binding] = self.value(statement.kids[0], values)
                continue
            if statement.kind == "print":
                output.append(str(self.value(statement.kids[0], values)))
                continue
            if statement.kind == "expression":
                self.value(statement.kids[0], values)
                continue
            raise RuntimeErrorKind(f"unsupported statement {statement.kind}")
        return RunResult(output)

    def value(self, node: Node, values: dict[object, int]) -> int:
        if node.kind == "literal":
            return int(node.value)
        if node.kind == "name":
            slot = node.binding
            if slot not in values:
                raise RuntimeErrorKind(f"line {node.line}: {node.value} has no value")
            return values[slot]
        if node.kind == "unary":
            operand = self.value(node.kids[0], values)
            if node.value == "-":
                return -operand
            if node.value == "!":
                return 0 if operand else 1
            raise RuntimeErrorKind(f"unsupported operator {node.value}")
        if node.kind != "binary":
            raise RuntimeErrorKind(f"unsupported expression {node.kind}")
        if node.value == "&&":
            left = self.value(node.kids[0], values)
            return (self.value(node.kids[1], values) if left else 0)
        if node.value == "||":
            left = self.value(node.kids[0], values)
            return left if left else self.value(node.kids[1], values)
        left = self.value(node.kids[0], values)
        right = self.value(node.kids[1], values)
        if node.value == "+":
            return left + right
        if node.value == "-":
            return left - right
        if node.value == "*":
            return left * right
        if node.value == "/":
            if right == 0:
                raise RuntimeErrorKind("division by zero")
            return left // right
        if node.value == "==":
            return int(left == right)
        if node.value == "!=":
            return int(left != right)
        if node.value == "<":
            return int(left < right)
        if node.value == ">":
            return int(left > right)
        if node.value == "<=":
            return int(left <= right)
        if node.value == ">=":
            return int(left >= right)
        raise RuntimeErrorKind(f"unsupported operator {node.value}")
